"""Unified operations System Center for SENTINEL administrators."""

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

from core.db import google_sheets_backup_status, google_sheets_sync_now
from core.observability import readiness_snapshot, snapshot as runtime_observability_snapshot
from modules.system_center import build_system_center_snapshot
from modules.google_sheets_monitor import build_google_sheets_monitor
from modules.job_control import job_is_protected, job_token, set_job_paused, summarize_jobs
from modules.config_wizard import config_wizard_snapshot
from modules.feature_flags import DEFAULT_FEATURE_FLAGS, feature_flag_snapshot, set_feature_flag, set_feature_rollout
from modules.operations_intelligence import operations_command_center_snapshot, run_safe_self_healing
from modules.app_migrations import migration_status, simulate_migration


def _status_icon(value: str) -> str:
    return {
        "healthy": "🟢",
        "degraded": "🟠",
        "offline": "🔴",
        "critical": "🔴",
        "disabled": "⚪️",
        "unknown": "🟡",
    }.get(str(value), "🟡")


def _format_uptime(seconds: int) -> str:
    seconds = max(0, int(seconds or 0))
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, _ = divmod(rem, 60)
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def _latest_backup_metadata() -> dict[str, Any]:
    try:
        rows = list_payload_backups(SETTINGS.backup_dir, limit=1)
        return backup_metadata(rows[0]) if rows else {}
    except Exception as exc:
        return {"error": f"{exc.__class__.__name__}:{str(exc)[:160]}"}


async def system_center_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    try:
        google = google_sheets_backup_status()
    except Exception as exc:
        google = {"enabled": True, "configured": False, "error": str(exc)}
    snapshot = build_system_center_snapshot(
        db,
        observability=runtime_observability_snapshot(),
        readiness=readiness_snapshot(),
        google_sheets=google,
        latest_backup=_latest_backup_metadata(),
    )
    components = snapshot["components"]
    order = [
        ("telegram", "Telegram"),
        ("database", "Database"),
        ("job_queue", "Background Jobs"),
        ("google_sheets", "Google Sheets"),
        ("providers", "Market Providers"),
        ("backup", "Backup"),
    ]
    lines = [
        f"{_status_icon(snapshot['overall'])} <b>SENTINEL System Center</b>",
        f"Uptime: <b>{_format_uptime(snapshot['uptime_seconds'])}</b>",
        "",
    ]
    for key, title in order:
        row = components[key]
        lines.append(f"{_status_icon(row['state'])} <b>{title}</b> — {esc(row['detail'])}")
    incidents = snapshot["incidents"]
    lines.extend([
        "",
        f"🚨 Open incidents: <b>{int(incidents.get('open', 0) or 0)}</b> · critical <b>{int(incidents.get('critical', 0) or 0)}</b>",
        f"⚙️ Jobs: <b>{snapshot['jobs']['ok']}</b> ok · <b>{snapshot['jobs']['running']}</b> running · <b>{snapshot['jobs']['failed']}</b> degraded/failed",
    ])
    if snapshot["recent_errors"]:
        latest = snapshot["recent_errors"][-1]
        lines.extend(["", f"آخرین خطا: <code>{esc(latest.get('component'))}</code> — {esc(str(latest.get('error') or '')[:180])}"])
    rows = [[InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_system_center")], back("admin_cat:system")[0]]
    await edit(query, "\n".join(lines), rows)


async def google_sheets_monitor_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_INTEGRATION_HEALTH_VIEW):
        return
    query = update.callback_query
    await query.answer()
    try:
        from core.google_sheets_backup import normalized_pending_tables
        normalized_pending = len(normalized_pending_tables())
    except Exception:
        normalized_pending = 0
    status = google_sheets_backup_status()
    monitor = build_google_sheets_monitor(
        status,
        runtime_observability_snapshot(),
        normalized_pending=normalized_pending,
    )
    icon = _status_icon(monitor["health"])
    sync = monitor["sync"]
    snap = monitor["snapshot"]
    lines = [
        f"{icon} <b>Google Sheets Monitor</b>",
        "",
        f"Enabled: <b>{'yes' if monitor['enabled'] else 'no'}</b>",
        f"Configured: <b>{'yes' if monitor['configured'] else 'no'}</b>",
        f"Pending queue: <b>{monitor['total_pending']}</b> · legacy {monitor['legacy_pending']} · normalized {monitor['normalized_pending']}",
        f"Failover: <b>{'ACTIVE' if monitor['failover_active'] else 'off'}</b>",
        f"Sync worker: <b>{esc(sync['status'])}</b> · failures {sync['consecutive_failures']}",
        f"Last sync: <code>{esc(sync.get('last_success_at') or 'not recorded')}</code>",
        f"Full snapshot: <b>{esc(snap['status'])}</b> · last <code>{esc(snap.get('last_success_at') or 'not recorded')}</code>",
    ]
    if monitor["service_account_email"]:
        lines.append(f"Service account: <code>{esc(monitor['service_account_email'])}</code>")
    if monitor["error"]:
        lines.extend(["", f"⚠️ Last error: <code>{esc(monitor['error'][:300])}</code>"])
    lines.extend(["", "خرابی Google Sheets نباید مسیر پاسخ Telegram را متوقف کند؛ تغییرات در outbox پایدار می‌مانند و worker دوباره تلاش می‌کند."])
    rows = []
    if (await run_blocking(_has_admin_permission, query.from_user.id, PERMISSION_SYSTEM_CONTROL)):
        rows.append([InlineKeyboardButton("🔄 Sync pending now", callback_data="gsmon_sync"), InlineKeyboardButton("🧱 Full snapshot", callback_data="gsmon_full")])
    rows.extend([
        [InlineKeyboardButton("🩺 Refresh health", callback_data="a_google_sheets_monitor")],
        [InlineKeyboardButton("↩️ System Center", callback_data="a_system_center")],
    ])
    await edit(query, "\n".join(lines), rows)


async def google_sheets_monitor_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    action = str(query.data or "")
    try:
        if action == "gsmon_sync":
            # Reuse the same serialization lock and both persistence generations
            # as the recurring worker so a manual repair cannot race the scheduler.
            from bot_runtime.runtime_jobs import google_sheets_secondary_job
            await google_sheets_secondary_job(None)
            message = "Sync worker اجرا شد."
        elif action == "gsmon_full":
            from bot_runtime.runtime_jobs import google_sheets_full_snapshot_job
            await google_sheets_full_snapshot_job(None)
            message = "Full snapshot اجرا شد."
        else:
            await query.answer("عملیات ناشناخته است.", show_alert=True)
            return
        await async_with_db(lambda db: audit(db, query.from_user.id, "google_sheets_manual_action", action))
        await query.answer(message)
    except Exception as exc:
        await query.answer(f"ناموفق: {str(exc)[:160]}", show_alert=True)
    await google_sheets_monitor_view(update, context)


def _runtime_jobs(context: ContextTypes.DEFAULT_TYPE) -> tuple[Any, ...]:
    queue = getattr(context.application, "job_queue", None)
    if queue is None:
        return ()
    try:
        return tuple(queue.jobs())
    except Exception:
        return ()


def _find_runtime_job(context: ContextTypes.DEFAULT_TYPE, token: str) -> Any | None:
    for job in _runtime_jobs(context):
        if job_token(str(getattr(job, "name", "") or "")) == str(token):
            return job
    return None


async def job_control_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    summary = summarize_jobs(_runtime_jobs(context), observability=runtime_observability_snapshot())
    lines = [
        "⚙️ <b>Job Control Center</b>",
        "",
        f"Total: <b>{summary['total']}</b> · enabled <b>{summary['enabled']}</b> · paused <b>{summary['paused']}</b>",
        "🛡 Jobهای حیاتی از Pause محافظت می‌شوند.",
    ]
    rows: list[list[InlineKeyboardButton]] = []
    for row in summary["rows"][:24]:
        icon = "🛡" if row["protected"] else ("🟢" if row["enabled"] else "⏸")
        lines.append(f"{icon} <code>{esc(row['name'])}</code> — {esc(row['status'])}")
        rows.append([InlineKeyboardButton(f"{icon} {row['name'][:42]}", callback_data=f"jobctl_view:{row['token']}")])
    if summary["total"] > 24:
        lines.append(f"\n… {summary['total'] - 24} job دیگر در Scheduler فعال است.")
    rows.extend([
        [InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_job_control")],
        [InlineKeyboardButton("↩️ System Center", callback_data="a_system_center")],
    ])
    await edit(query, "\n".join(lines), rows)


async def job_control_detail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    token = str(query.data or "").split(":", 1)[1]
    job = _find_runtime_job(context, token)
    if job is None:
        await query.answer("Job دیگر در Scheduler وجود ندارد؛ صفحه را تازه کنید.", show_alert=True)
        await job_control_view(update, context)
        return
    row = summarize_jobs([job], observability=runtime_observability_snapshot())["rows"][0]
    text = (
        "⚙️ <b>Job Detail</b>\n\n"
        f"Name: <code>{esc(row['name'])}</code>\n"
        f"State: <b>{esc(row['status'])}</b>\n"
        f"Scheduler: <b>{'enabled' if row['enabled'] else 'paused'}</b>\n"
        f"Protected: <b>{'yes' if row['protected'] else 'no'}</b>\n"
        f"Next run: <code>{esc(row.get('next_run_at') or 'not scheduled')}</code>\n"
        f"Failures: <b>{row['consecutive_failures']}</b>\n"
        f"Last error: <code>{esc(row.get('last_error') or 'none')}</code>"
    )
    buttons: list[list[InlineKeyboardButton]] = []
    if not row["protected"]:
        buttons.append([
            InlineKeyboardButton("▶️ Resume" if not row["enabled"] else "⏸ Pause", callback_data=f"jobctl_{'resume' if not row['enabled'] else 'pause'}:{token}"),
            InlineKeyboardButton("⚡ Run now", callback_data=f"jobctl_run:{token}"),
        ])
    else:
        buttons.append([InlineKeyboardButton("⚡ Run now", callback_data=f"jobctl_run:{token}")])
    buttons.extend([[InlineKeyboardButton("↩️ Job Center", callback_data="a_job_control")], [InlineKeyboardButton("🩺 System Center", callback_data="a_system_center")]])
    await edit(query, text, buttons)


async def job_control_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    raw = str(query.data or "")
    prefix, token = raw.split(":", 1)
    action = prefix.removeprefix("jobctl_")
    job = _find_runtime_job(context, token)
    if job is None:
        await query.answer("Job پیدا نشد؛ صفحه را تازه کنید.", show_alert=True)
        return
    name = str(getattr(job, "name", "") or "")
    if action in {"pause", "resume"}:
        if job_is_protected(name) and action == "pause":
            await query.answer("Job حیاتی قابل توقف نیست.", show_alert=True)
            return
        try:
            job.enabled = action == "resume"
            await async_with_db(lambda db: set_job_paused(db, name, action == "pause", actor_id=query.from_user.id, updated_at=utc_iso()))
            await async_with_db(lambda db: audit(db, query.from_user.id, f"job_{action}", name))
            await query.answer("انجام شد.")
        except Exception as exc:
            await query.answer(f"ناموفق: {str(exc)[:150]}", show_alert=True)
            return
    elif action == "run":
        try:
            await job.run(context.application)
            await async_with_db(lambda db: audit(db, query.from_user.id, "job_run_now", name))
            await query.answer("Job اجرا شد.")
        except Exception as exc:
            await query.answer(f"اجرای دستی ناموفق: {str(exc)[:150]}", show_alert=True)
            return
    await job_control_detail(update, context)


async def config_wizard_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    snapshot = config_wizard_snapshot(os.environ)
    lines = [
        "🧩 <b>Config Wizard</b>",
        "",
        f"Required readiness: <b>{snapshot['required_score']}%</b>",
        f"Overall completeness: <b>{snapshot['completeness_score']}%</b>",
        "هیچ مقدار Secret در این صفحه نمایش داده نمی‌شود.",
        "",
    ]
    for group in snapshot['groups']:
        icon = '✅' if group['ready'] else '❌'
        lines.append(
            f"{icon} <b>{esc(group['title'])}</b> — required {group['required_ready']}/{group['required_total']} · recommended {group['recommended_ready']}/{group['recommended_total']}"
        )
        for missing in group['missing_required'][:3]:
            lines.append(f"   • missing: <code>{esc(missing)}</code>")
    features = snapshot['features']
    lines.extend([
        "",
        f"Google Sheets: <b>{'on' if features['google_sheets'] else 'off'}</b> · Gemini: <b>{'on' if features['gemini'] else 'off'}</b> · WebApp: <b>{'on' if features['webapp'] else 'off'}</b>",
        f"Run mode: <code>{esc(features['run_mode'])}</code>",
    ])
    rows = [
        [InlineKeyboardButton("🔄 تازه‌سازی", callback_data="a_config_wizard")],
        [InlineKeyboardButton("🩺 System Center", callback_data="a_system_center")],
    ]
    await edit(query, "\n".join(lines), rows)


async def operations_intelligence_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    report = operations_command_center_snapshot(db, observability=runtime_observability_snapshot())
    memory = report["memory"]
    providers = report["providers"]
    healing = report["self_healing"]
    trend = report.get("memory_trend") or {}
    security = report.get("security") or {}
    business = report.get("business") or {}
    provider_costs = report.get("provider_costs") or {}
    budget = healing.get("recovery_budget") or {}
    mem_percent = memory.get("percent")
    mem_text = f"{float(mem_percent):.1f}%" if mem_percent is not None else "unknown"
    lines = [
        "🧠 <b>Operations Intelligence</b>", "",
        f"Memory: <b>{esc(memory.get('state'))}</b> · {mem_text} · {float(memory.get('rss_mb', 0) or 0):.1f} MB",
        f"Memory trend: <b>{float(trend.get('growth_mb_per_hour', 0) or 0):+.1f} MB/h</b> · leak {'⚠️ suspected' if trend.get('suspected_leak') else '✅ no'}",
        f"Self-healing: <b>{'ON' if healing.get('enabled') else 'OFF'}</b> · last <code>{esc(healing.get('last_run_at') or 'never')}</code>",
        f"Recovery budget: <b>{int(budget.get('used', 0) or 0)}/{int(budget.get('limit', 0) or 0)}</b> used · remaining <b>{int(budget.get('remaining', 0) or 0)}</b>",
        f"Security Sentinel: <b>{esc(security.get('state') or 'healthy')}</b> · risk <b>{int(security.get('risk_score', 0) or 0)}/100</b>",
        f"Providers: healthy <b>{int(providers.get('healthy', 0) or 0)}</b> · degraded <b>{int(providers.get('degraded', 0) or 0)}</b> · offline <b>{int(providers.get('offline', 0) or 0)}</b>",
        f"Provider estimated cost: <b>{float(provider_costs.get('estimated_total_cost', 0) or 0):.4f}</b>",
        f"Business: users <b>{int(business.get('users', 0) or 0)}</b> · VIP <b>{int(business.get('vip_records', 0) or 0)}</b> · signals <b>{int(business.get('signals', 0) or 0)}</b>",
        f"Jobs degraded/failed: <b>{int(report.get('jobs', {}).get('failed_or_degraded', 0) or 0)}</b>",
        f"Feature flags: <b>{int(report.get('feature_flags', {}).get('enabled', 0) or 0)}/{int(report.get('feature_flags', {}).get('total', 0) or 0)}</b> enabled",
    ]
    await edit(query, "\n".join(lines), [
        [InlineKeyboardButton("🩹 Run safe self-heal", callback_data="ops_heal_now", style="primary")],
        [InlineKeyboardButton("🚩 Feature Flags", callback_data="a_feature_flags"), InlineKeyboardButton("🧱 Migrations", callback_data="a_app_migrations")],
        [InlineKeyboardButton("🔄 Refresh", callback_data="a_ops_intelligence")],
        [InlineKeyboardButton("↩️ System Center", callback_data="a_system_center")],
    ])


async def operations_self_heal_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    try:
        result = await async_with_db(lambda db: run_safe_self_healing(db, force=True))
        await async_with_db(lambda db: audit(db, query.from_user.id, "safe_self_heal", str(result.get("status"))))
        await query.answer(f"Self-heal: {result.get('status')}", show_alert=False)
    except Exception as exc:
        await query.answer(f"Self-heal failed: {str(exc)[:120]}", show_alert=True)
    await operations_intelligence_view(update, context)


async def feature_flags_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    snapshot = feature_flag_snapshot(await async_snapshot())
    lines = ["🚩 <b>Feature Flags</b>", "", "تغییرات بلافاصله در runtime خوانده می‌شوند و بعد از Restart باقی می‌مانند."]
    rows: list[list[InlineKeyboardButton]] = []
    for item in snapshot["items"]:
        key = str(item["key"])
        enabled = bool(item["enabled"])
        rollout = int(item.get("rollout_percent", 100) or 100)
        lines.append(f"{'🟢' if enabled else '⚪️'} <code>{esc(key)}</code> · rollout <b>{rollout}%</b>")
        next_rollout = {0: 10, 10: 25, 25: 50, 50: 100, 100: 0}.get(rollout, 100)
        rows.append([
            InlineKeyboardButton(f"{'ON' if enabled else 'OFF'} · {key}", callback_data=f"ff_toggle:{key}"),
            InlineKeyboardButton(f"{rollout}% → {next_rollout}%", callback_data=f"ff_rollout:{key}:{next_rollout}"),
        ])
    rows.extend([[InlineKeyboardButton("🔄 Refresh", callback_data="a_feature_flags")], [InlineKeyboardButton("↩️ Operations", callback_data="a_ops_intelligence")]])
    await edit(query, "\n".join(lines), rows)


async def feature_flag_toggle_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    key = str(query.data or "").split(":", 1)[1]
    if key not in DEFAULT_FEATURE_FLAGS:
        await query.answer("Feature flag ناشناخته است.", show_alert=True)
        return
    db = await async_snapshot()
    current = feature_flag_snapshot(db)
    state = next((bool(row["enabled"]) for row in current["items"] if row["key"] == key), False)
    await async_with_db(lambda target: set_feature_flag(target, key, not state, actor_id=query.from_user.id))
    await query.answer(f"{key}: {'ON' if not state else 'OFF'}")
    await feature_flags_view(update, context)


async def feature_flag_rollout_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    try:
        _prefix, key, percent_raw = str(query.data or "").split(":", 2)
        percent = max(0, min(100, int(percent_raw)))
    except (TypeError, ValueError):
        await query.answer("Rollout نامعتبر است.", show_alert=True)
        return
    if key not in DEFAULT_FEATURE_FLAGS:
        await query.answer("Feature flag ناشناخته است.", show_alert=True)
        return
    await async_with_db(lambda target: set_feature_rollout(target, key, percent, actor_id=query.from_user.id))
    await query.answer(f"{key}: rollout {percent}%")
    await feature_flags_view(update, context)


async def migration_sandbox_action(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    name = str(query.data or "").split(":", 1)[1]
    try:
        result = simulate_migration(await async_snapshot(), name)
    except ValueError:
        await query.answer("Migration ناشناخته است.", show_alert=True)
        return
    await query.answer("Sandbox OK", show_alert=False)
    await edit(query, "🧪 <b>Migration Sandbox</b>\n\n" + f"Migration: <code>{esc(name)}</code>\n" + f"Status: <b>{esc(result.get('status'))}</b>\n" + f"Added keys: <code>{esc(', '.join(result.get('added_top_level_keys') or []) or '-')}</code>", [[InlineKeyboardButton("↩️ Migrations", callback_data="a_app_migrations")]])


async def app_migrations_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_SYSTEM_CONTROL):
        return
    query = update.callback_query
    await query.answer()
    status = migration_status(await async_snapshot())
    lines = ["🧱 <b>Application Migrations</b>", "", f"Applied: <b>{len(status['applied'])}</b> · Pending: <b>{len(status['pending'])}</b>"]
    lines.extend(f"✅ <code>{esc(name)}</code>" for name in status["applied"])
    lines.extend(f"⏳ <code>{esc(name)}</code>" for name in status["pending"])
    lines.extend(["", "Apply/Rollbackهای ساختاری از <code>python scripts/sentinel_migrate.py</code> اجرا می‌شوند. Sandbox فقط روی clone حافظه اجرا می‌شود و دیتابیس زنده را تغییر نمی‌دهد."])
    rows = [[InlineKeyboardButton(f"🧪 Sandbox · {name}", callback_data=f"migration_sandbox:{name}")] for name in status["available"]]
    rows.append([InlineKeyboardButton("↩️ Operations", callback_data="a_ops_intelligence")])
    await edit(query, "\n".join(lines), rows)


async def system_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    command = str(update.effective_message.text or '').split()[0].split('@')[0]
    permission = PERMISSION_INCIDENTS if command == '/errors' else PERMISSION_SYSTEM_HEALTH_VIEW
    if not await require_admin(update, permission):
        return
    metrics = runtime_observability_snapshot()
    readiness = readiness_snapshot()
    lines = ["🩺 <b>SENTINEL</b>", f"Uptime: {metrics['uptime_seconds']}s",
             f"Ready: {'yes' if readiness['ready'] else 'no'}"]
    for name, ok in readiness['checks'].items():
        lines.append(f"{'✅' if ok else '⚠️'} {esc(name)}")
    gauges = metrics['gauges']
    for name in ('telegram_last_update_timestamp', 'telegram_last_completed_timestamp', 'telegram_active_updates', 'database_last_success_timestamp',
                 'redis_last_success_timestamp', 'telegram_ptb_queue_depth', 'telegram_update_backlog'):
        lines.append(f"{esc(name)}: {esc(gauges.get(name, 'unknown'))}")
    jobs = metrics['jobs']
    failed = sum(row.get('status') in {'failed', 'degraded'} for row in jobs.values())
    lines.append(f"Failed jobs: {failed}")
    lines.append(f"Scheduler heartbeat: {esc(jobs.get('heartbeat', {}).get('last_success_at') or 'unknown')}")
    if command in {'/system', '/status'}:
        db = await async_snapshot()
        cutoff = utc_now() - timedelta(hours=24)
        active = sum(bool(parse_dt(row.get('last_seen_at')) and parse_dt(row['last_seen_at']) >= cutoff)
                     for row in db.get('users', {}).values())
        lines.append(f"Active users (24h): {active}")
    if command == '/errors':
        # Do not expose raw exception strings, URLs, tokens or user payloads.
        for row in metrics['recent_errors'][-10:]:
            lines.append(f"{esc(row.get('created_at'))} · {esc(row.get('component'))} · {esc(row.get('type'))}")
    await reply(update, '\n'.join(lines), [[InlineKeyboardButton('🏠 پنل مدیر', callback_data='admin_home')]])


__feature_exports__ = ("system_status_command", "system_center_view", "google_sheets_monitor_view", "google_sheets_monitor_action", "job_control_view", "job_control_detail", "job_control_action", "config_wizard_view", "operations_intelligence_view", "operations_self_heal_action", "feature_flags_view", "feature_flag_toggle_action", "feature_flag_rollout_action", "app_migrations_view", "migration_sandbox_action")
