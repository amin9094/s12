"""Dedicated private Telegram entry for Iran equity analyses, H4 / D1."""

from html import escape
import asyncio
import logging

from telegram import InlineKeyboardButton as B
from telegram import InlineKeyboardMarkup

from core.async_runtime import run_blocking
from services.iran_equity_desk_service import detail, legacy_detail, snapshot
from services.live_signal_service import permitted

logger = logging.getLogger(__name__)
QUICK_SYMBOLS = ('فولاد', 'فملی', 'شستا', 'خودرو', 'وبملت', 'شپنا')
QUERY_STATE = 93401


def source_error(error):
    from services.iran_equity_service import IranEquityUnavailable
    messages = {
        'IR_CASH_EQUITY_REQUIRED': 'این ابزار سهم نقدی پشتیبانی‌شده نیست؛ سهم دیگری انتخاب کنید.',
        'IR_EQUITY_CLASSIFICATION_UNVERIFIED': 'نوع ابزار از اطلاعات نماد تأیید نشد؛ تحلیل ساخته نشد.',
        'IR_EQUITY_INTRADAY_INCOMPLETE': 'ریزمعاملات کامل برای نمودار ۴ساعته دریافت نشد؛ تحلیل روزانه را امتحان کنید.',
        'IR_EQUITY_QUERY_INVALID': 'نام سهم را با حداقل دو حرف فارسی یا شناسهٔ معتبر وارد کنید.',
    }
    if isinstance(error, (IranEquityUnavailable, ValueError)) and str(error) in messages:
        return messages[str(error)]
    return 'دریافت اطلاعات بورس کامل نشد؛ اتصال منبع یا ذخیره‌سازی باید بررسی شود. می‌توانید دوباره تلاش کنید.'


async def search_start(update, context):
    from telegram.ext import ConversationHandler
    q = update.callback_query
    try:
        await run_blocking(permitted, q.from_user.id, timeout=5)
    except PermissionError:
        await q.answer('دسترسی ندارید', show_alert=True)
        return ConversationHandler.END
    await q.answer()
    await q.edit_message_text('نام سهم را بنویسید؛ مثلاً فولاد یا فملی.',
                             reply_markup=InlineKeyboardMarkup([[B('برگشت به بورس ایران', callback_data='ir:h')]]))
    return QUERY_STATE


async def search_input(update, context):
    from telegram.ext import ConversationHandler
    from services.iran_equity_service import search_instruments
    user = update.effective_user.id
    try:
        await run_blocking(permitted, user, timeout=5)
        async with asyncio.timeout(15):
            result = await search_instruments(update.effective_message.text)
        rows = search_rows(result)
        text = 'سهم و بازهٔ تحلیل را انتخاب کنید.' if result['items'] else 'سهمی پیدا نشد؛ نام دیگری جست‌وجو کنید.'
    except PermissionError:
        text, rows = 'دسترسی ندارید', []
    except Exception as exc:
        text, rows = source_error(exc), []
    rows += [[B('جست‌وجوی دوباره', callback_data='ir:search'), B('برگشت به بورس ایران', callback_data='ir:h')]]
    await update.effective_message.reply_text(text, reply_markup=InlineKeyboardMarkup(rows))
    return ConversationHandler.END


def search_rows(result):
    return [[B(row['symbol'][:30] + ' · روزانه', callback_data='ir:c:' + row['ins_code'] + ':1d'),
             B('۴ساعته', callback_data='ir:c:' + row['ins_code'] + ':4h')] for row in result['items'][:12]]


def register_search(application):
    from telegram.ext import CallbackQueryHandler, ConversationHandler, MessageHandler, filters
    application.add_handler(ConversationHandler(
        entry_points=[CallbackQueryHandler(search_start, pattern=r'^ir:search$')],
        states={QUERY_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, search_input)]},
        fallbacks=[], allow_reentry=True, per_message=False, name='iran_equity_search', persistent=True,
    ))


async def iran_equity_callback(update, context, *, route=None, already_answered=False):
    try:
        return await _iran_equity_callback(update, context, route=route, already_answered=already_answered)
    except Exception as exc:
        from telegram.error import BadRequest
        if isinstance(exc, BadRequest) and 'message is not modified' in str(exc).lower():
            return
        logger.exception('Iran equity desk action failed')
        await update.callback_query.edit_message_text(source_error(exc), reply_markup=InlineKeyboardMarkup([
            [B('تلاش دوباره', callback_data=route or update.callback_query.data)],
            [B('برگشت به بورس ایران', callback_data='ir:h'), B('مدیریت', callback_data='admin_home')],
        ]))


async def _iran_equity_callback(update, context, *, route=None, already_answered=False):
    q = update.callback_query
    user = q.from_user.id
    try:
        await run_blocking(permitted, user, timeout=5)
    except PermissionError:
        await q.answer("دسترسی ندارید", show_alert=True)
        return
    if not already_answered:
        from telegram.error import BadRequest
        try:
            await q.answer()
        except BadRequest:
            pass  # An old callback may still open a fresh, authorized desk.
    parts = (route or q.data).split(":")
    kind = parts[1]
    rows = []
    if kind == 's':
        from services.iran_equity_service import search_instruments
        index = int(parts[2])
        if not 0 <= index < len(QUICK_SYMBOLS):
            raise ValueError('IR_EQUITY_QUERY_INVALID')
        await q.edit_message_text('در حال جست‌وجوی ' + QUICK_SYMBOLS[index] + '…')
        async with asyncio.timeout(15):
            result = await search_instruments(QUICK_SYMBOLS[index])
        text = 'سهم و بازهٔ تحلیل را انتخاب کنید.' if result['items'] else 'سهمی پیدا نشد؛ نام دیگری جست‌وجو کنید.'
        rows = search_rows(result) + [[B('جست‌وجوی سهم دیگر', callback_data='ir:search'), B('برگشت', callback_data='ir:h')]]
    elif kind == 'c':
        from services.iran_equity_service import equity_chart
        from repositories.v2.iran_equity_analyses import IranEquityAnalyses
        await q.edit_message_text('در حال دریافت و بررسی دادهٔ همین سهم…')
        async with asyncio.timeout(60):
            result = await equity_chart(parts[2], timeframe=parts[3])
            await run_blocking(IranEquityAnalyses().save, result, timeout=10)
        a = result['analysis']
        labels = {'DAILY_REVIEW_AVAILABLE': 'تحلیل روزانه آماده است', 'H4_REVIEW_AVAILABLE': 'تحلیل ۴ساعته آماده است',
                  'HISTORICAL_OR_HALTED': 'داده قدیمی است یا نماد معامله نشده است',
                  'INDICATOR_WARMUP_INCOMPLETE': 'تاریخچه برای محاسبهٔ کامل کافی نیست'}
        text = f"بورس ایران / {result['symbol']} / {result['timeframe'].upper()}\nقیمت‌ها: ریال · تعدیل‌نشده\n{labels.get(a['state'], 'نیازمند بررسی داده')}\nآخرین روز معامله: {result['latest_trade_date']}"
        if a.get('trend'):
            text += f"\nروند: {a['trend']} · مومنتوم: {a.get('momentum', '—')}"
        for name, value in a.get('indicators', {}).items():
            text += f'\n{name}: {value}'
        text += '\n\nاین تحلیل اختصاصی ادمین است؛ انتشار عمومی ایجاد نمی‌کند.'
        rows = [[B('روزانه', callback_data=f'ir:c:{parts[2]}:1d'), B('۴ساعته', callback_data=f'ir:c:{parts[2]}:4h')],
                [B('جست‌وجوی سهم', callback_data='ir:search'), B('برگشت به بورس ایران', callback_data='ir:h')]]
    elif kind == "v":
        try:
            r = await run_blocking(legacy_detail, user, parts[2], timeout=5)
        except ValueError:
            return
        p = r["payload"]["plan"]
        text = f"سابقهٔ بورس ایران / {p['symbol']} · {p['timeframe']}\nوضعیت سابقه: {r['state']}\nEntry: {p['entry']} · SL: {p['stop']}"
        text += " · " + " · ".join(f"{k.upper()}: {p[k]}" for k in ("tp1", "tp2", "tp3") if p.get(k) is not None)
        text += "\n\nسابقهٔ بایگانی‌شده؛ از بخش سیگنال‌های بازار جداست."
        rows = [[B("برگشت به بورس ایران", callback_data="ir:h")]]
    elif kind == "a":
        try:
            r = await run_blocking(detail, user, parts[2], timeout=5)
        except ValueError:
            return
        p = r["payload"]
        a = p["analysis"]
        text = f"بورس ایران / {r['symbol']} / {r['timeframe'].upper()}\nوضعیت: {r['state']}\nقیمت‌ها: ریال\nآخرین روز بسته: {a.get('latest_closed_date', '—')}\nروند: {a.get('trend', '—')} · مومنتوم: {a.get('momentum', '—')}"
        for k, v in a.get("indicators", {}).items():
            text += f"\n{k}: {v}"
        text += "\n\nتحلیل اختصاصی بورس است؛ انتشار عمومی یا معامله ایجاد نمی‌کند."
        rows = [[B("برگشت به بورس ایران", callback_data="ir:h")]]
    elif kind in {"h", "t", "p"}:
        before = None
        legacy_before = None
        tf = None
        section = "all"
        if kind == "t":
            tf = parts[2]
        if kind == "p":
            page = context.user_data.get("iran_equity_pages", {}).get(parts[2])
            if not page:
                return
            tf, before, legacy_before, section = page
        try:
            d = await run_blocking(
                snapshot, user, timeframe=tf, before=before, legacy_before=legacy_before, section=section, timeout=10
            )
        except ValueError:
            return
        text = "🇮🇷 بورس ایران\nتحلیل‌های ۴ساعته و روزانه، مستقل از سیگنال‌های فارکس، طلا و کریپتو.\nنمودار و جست‌وجوی سهم: مینی‌اپ ← بخش مدیریت ← بورس ایران."
        rows = [[B('جست‌وجو و تحلیل سهم', callback_data='ir:search')]]
        rows.extend([[B(name, callback_data=f'ir:s:{index}') for index, name in enumerate(QUICK_SYMBOLS)][i:i+3]
                     for i in range(0, len(QUICK_SYMBOLS), 3)])
        rows.append([B("۴ساعته", callback_data="ir:t:4h"), B("روزانه", callback_data="ir:t:1d")])
        rows.extend(
            [
                [B(f"{r['symbol']} · {r['timeframe'].upper()} · {r['state']}", callback_data="ir:a:" + r["id"])]
                for r in d["items"]
            ]
        )
        if not d["items"]:
            text += "\nهنوز تحلیل ذخیره‌شده‌ای در این بخش نیست."
        rows.extend(
            [
                [
                    B(
                        f"سابقهٔ بورس / {r['payload']['plan']['symbol']} · {r['payload']['plan']['timeframe']}",
                        callback_data="ir:v:" + r["id"],
                    )
                ]
                for r in d["legacy_items"]
            ]
        )
        for label, cursor, is_legacy in [
            ("تحلیل‌های قدیمی‌تر", d["next_before"], False),
            ("سوابق قدیمی‌تر بورس", d["legacy_next_before"], True),
        ]:
            if not cursor:
                continue
            import uuid

            token = uuid.uuid4().hex[:8]
            pages = context.user_data.setdefault("iran_equity_pages", {})
            if len(pages) >= 20:
                pages.pop(next(iter(pages)))
            pages[token] = (
                tf,
                None if is_legacy else cursor,
                cursor if is_legacy else None,
                "legacy" if is_legacy else "analyses",
            )
            rows.append([B(label, callback_data="ir:p:" + token)])
        from bot_runtime.navigation import webapp_row

        app = webapp_row()
        if app:
            rows.append(app)
        rows.append([B("برگشت به مدیریت", callback_data="admin_home")])
    else:
        return
    await q.edit_message_text(escape(text[:3900]), parse_mode="HTML", reply_markup=InlineKeyboardMarkup(rows))
