"""Reachable Telegram workflows backed by the existing canonical services."""
from bot_runtime import shared as _shared

globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})
from core.domain import normalize_discount_tier
from modules.admin_work_queue import (
    accept_handoff,
    assign_work,
    can_access,
    handoff_work,
    palette_search,
    read_entity,
    reconcile_work_queue,
    work_item,
    work_items,
)
from modules.referral_milestones import claim_milestone, milestone_progress, remove_milestone, save_milestone
from modules.referral_ui import (
    CHOICES,
    LOCKED_FIELDS,
    REWARD_LABELS,
    TRIGGER_LABELS,
    has_claims,
    progress_line,
    reward_label,
)
from modules.ticket_context import resolve_context, ticket_context_view
from modules.vip_gifts import approve_gift_order, create_gift, gift_for_owner, redeem_gift

EXPERIENCE_INPUT = 'EXPERIENCE_INPUT'
_MILESTONE_FIELDS = {
 'title':'عنوان', 'description':'توضیح', 'trigger_type':'نوع هدف',
 'required_count':'تعداد دعوت یا مبلغ خرید لازم', 'reward_type':'نوع جایزه',
 'reward_value':'مقدار پاداش (امتیاز، روز، درصد تخفیف یا شناسه جایزه)',
 'enabled':'فعال باشد؟ بله / خیر', 'sort_order':'ترتیب نمایش (عدد)',
 'start_at':'زمان شروع میلادی مانند 2026-10-01 یا - برای بدون محدودیت',
 'expire_at':'زمان پایان میلادی یا - برای بدون محدودیت', 'max_claims':'حداکثر دریافت هر کاربر؛ صفر یعنی بدون سقف',
 'repeatable':'قابل تکرار باشد؟ بله / خیر',
}


async def referral_milestones_menu(update, context):
    q=update.callback_query;await q.answer();db=await async_snapshot();progress=milestone_progress(db,q.from_user.id)
    raw=str(q.data).partition(':')[2] if str(q.data).startswith('referral_milestones:') else ''
    page=min(int(raw) if raw.isdigit() else 0,max(0,(len(progress)-1)//5))
    lines=['👥 <b>مسیر پاداش دعوت دوستان</b>','دعوت‌های معتبر و خریدهای تأییدشدهٔ سرور، پیشرفت شما را ثبت می‌کنند.'];rows=[]
    for index,row in enumerate(progress[page*5:(page+1)*5],start=page*5+1):
        complete=(row['claimed']>0 and not row.get('repeatable')) or (row.get('max_claims') and row['claimed']>=row['max_claims'])
        status='✅ آمادهٔ دریافت' if row['claimable'] else '🏆 تکمیل‌شده' if complete else '🔒 در حال پیشرفت'
        lines += [f"\n<b>مرحلهٔ {index} · {esc(row['title'])}</b>",esc(str(row.get('description') or '')[:180]),
                  f"هدف: {int(row['required_count']):,} {esc(TRIGGER_LABELS[row['trigger_type']])}",
                  progress_line(row),f"🎁 جایزه: <b>{esc(reward_label(db,row))}</b>",status]
        if row['claimed']:lines.append(f"دریافت‌شده: {row['claimed']} بار")
        if row['claimable']:rows.append([InlineKeyboardButton(f"🎁 دریافت {row['title'][:35]}",callback_data=f"milestone_claim:{row['id']}:{row['claimed']+1}")])
    if not progress:lines.append('هنوز مرحلهٔ فعالی منتشر نشده است؛ پاداش‌های معمول دعوت همچنان برقرارند.')
    paging=[]
    if page:paging.append(InlineKeyboardButton('صفحه قبل',callback_data=f'referral_milestones:{page-1}'))
    if (page+1)*5<len(progress):paging.append(InlineKeyboardButton('صفحه بعد',callback_data=f'referral_milestones:{page+1}'))
    if paging:rows.append(paging)
    rows += [[InlineKeyboardButton('🎁 جایزه‌های من',callback_data='u_my_rewards'),InlineKeyboardButton('🔗 لینک دعوت من',callback_data='u_referral')]]
    await edit(q,'\n'.join(lines)[:3900],rows)


async def milestone_claim_handler(update, context):
    q=update.callback_query;_,mid,cycle=str(q.data).split(':')
    try:await async_with_db(lambda db:claim_milestone(db,q.from_user.id,mid,expected_cycle=int(cycle)))
    except (ValueError,PermissionError) as exc:
        await q.answer(str(exc),show_alert=True);return
    await q.answer('پاداش ثبت شد؛ در جایزه‌های من ببینید.')
    await referral_milestones_menu(update,context)


async def admin_milestones_menu(update,context):
    if not await require_admin(update,PERMISSION_REWARD_POINTS):return ConversationHandler.END
    q=update.callback_query;await q.answer();db=await async_snapshot()
    items=sorted([r for r in db.get('referral_milestones',{}).values() if not r.get('deleted_at')],key=lambda r:(r.get('sort_order',0),r['id']))
    raw=str(q.data).partition(':')[2];page=min(int(raw) if raw.isdigit() else 0,max(0,(len(items)-1)//10))
    rows=[[InlineKeyboardButton('➕ ساخت مرحلهٔ رفرال',callback_data='cw:mode:milestone')]]
    for index,row in enumerate(items[page*10:(page+1)*10],start=page*10+1):
        rows.append([InlineKeyboardButton(f"{'🟢' if row.get('enabled') else '⚪'} {index}. {row['title'][:35]} · {row['required_count']:,}",callback_data=f"milestone_edit:{row['id']}")])
    paging=[]
    if page:paging.append(InlineKeyboardButton('صفحه قبل',callback_data=f'a_milestones:{page-1}'))
    if (page+1)*10<len(items):paging.append(InlineKeyboardButton('صفحه بعد',callback_data=f'a_milestones:{page+1}'))
    if paging:rows.append(paging)
    rows += [[InlineKeyboardButton('🛡 بررسی دعوت‌های مشکوک',callback_data='refreview')]] if (await run_blocking(_has_admin_permission, q.from_user.id,PERMISSION_INCIDENTS)) else []
    rows += back('admin_home')
    await edit(q,'👥 <b>مراحل پاداش رفرال</b>\n\nهر مرحله یک هدف و جایزه دارد. آن را انتخاب کنید تا ویرایش، فعال/غیرفعال یا حذف کنید.\nپاداش فقط پس از بررسی شرایط در سرور صادر می‌شود.',rows)
    return ConversationHandler.END


def _milestone_summary(db,row):
    return (f"👥 <b>{esc(row['title'])}</b>\n{esc(row.get('description') or '')}\n\n"
            f"هدف: <b>{row['required_count']:,} {esc(TRIGGER_LABELS[row['trigger_type']])}</b>\n"
            f"جایزه: <b>{esc(reward_label(db,row))}</b>\n"
            f"وضعیت: {'فعال' if row.get('enabled') else 'غیرفعال'}\n"
            f"تکرار: {'بله' if row.get('repeatable') else 'فقط یک‌بار'}\n"
            f"حداکثر دریافت: {row.get('max_claims') or 'بدون سقف'}\n"
            f"شروع: {display_dt(row['start_at']) if row.get('start_at') else 'بدون محدودیت'}\n"
            f"پایان: {display_dt(row['expire_at']) if row.get('expire_at') else 'بدون انقضا'}")


async def milestone_edit_menu(update,context,milestone_id=None):
    if not await require_admin(update,PERMISSION_REWARD_POINTS):return
    q=update.callback_query;await q.answer();mid=str(milestone_id or str(q.data).split(':')[1]);db=await async_snapshot();row=db.get('referral_milestones',{}).get(mid)
    if not row or row.get('deleted_at'):
        await edit(q,'مرحله پیدا نشد.',back('a_milestones'));return
    locked=has_claims(db,mid)
    buttons=[InlineKeyboardButton('✏️ '+label.split(':')[0],callback_data=f'milestone_field:{mid}:{field}')
             for field,label in _MILESTONE_FIELDS.items() if field!='enabled' and not (locked and field in LOCKED_FIELDS)]
    rows=[[InlineKeyboardButton('⏸ غیرفعال کن' if row.get('enabled') else '▶️ فعال کن',callback_data=f"ms:enable:{mid}:{int(not bool(row.get('enabled')))}")]]
    rows += [buttons[i:i+2] for i in range(0,len(buttons),2)]
    rows += [[InlineKeyboardButton('🗑 حذف مرحله',callback_data=f'ms:remove:{mid}')]]+back('a_milestones')
    text=_milestone_summary(db,row)
    if locked:text+='\n\n🔒 این مرحله جایزه صادر کرده است؛ هدف و جایزهٔ تاریخی ثابت می‌ماند. برای هدف تازه، مرحلهٔ جدید بسازید.'
    await edit(q,text,rows)


async def _milestone_edit_preview(update,context,mid,changes):
    import copy
    db=await async_snapshot();original=db.get('referral_milestones',{}).get(str(mid))
    if not original or original.get('deleted_at'):raise ValueError('مرحله پیدا نشد.')
    preview=await run_blocking(lambda:save_milestone(copy.deepcopy(db),update.effective_user.id,changes,mid),timeout=30)
    token=uuid.uuid4().hex[:10]
    context.user_data['milestone_edit_preview']={'mid':str(mid),'changes':changes,'updated_at':original.get('updated_at'),'token':token}
    rows=[[InlineKeyboardButton('✅ ذخیرهٔ تغییر',callback_data=f'ms:save:{mid}:{token}'),InlineKeyboardButton('❌ انصراف',callback_data=f'milestone_edit:{mid}')]]
    text='👀 <b>پیش‌نمایش تغییر</b>\n\n'+_milestone_summary(db,preview)+'\n\nتا تأیید نهایی، چیزی تغییر نکرده است.'
    if update.callback_query:await edit(update.callback_query,text,rows)
    else:await reply(update,text,rows)


async def milestone_config_callback(update,context):
    if not await require_admin(update,PERMISSION_REWARD_POINTS):return ConversationHandler.END
    q=update.callback_query;await q.answer();parts=str(q.data).split(':');op=parts[1];mid=parts[2]
    try:
        if op=='enable':
            await async_with_db(lambda db:save_milestone(db,q.from_user.id,{'enabled':parts[3]=='1'},mid))
        elif op=='remove':
            await edit(q,'مرحله حذف شود؟ دریافت‌های قبلی و تاریخچهٔ پاداش محفوظ می‌ماند.',[[InlineKeyboardButton('✅ حذف',callback_data=f'ms:delete:{mid}'),InlineKeyboardButton('❌ انصراف',callback_data=f'milestone_edit:{mid}')]])
            return ConversationHandler.END
        elif op=='delete':
            await async_with_db(lambda db:remove_milestone(db,q.from_user.id,mid));return await admin_milestones_menu(update,context)
        elif op=='choice':
            field,value=parts[3:5];state=context.user_data.get('experience_input',{})
            if state.get('op')!='milestone_field' or state.get('mid')!=mid or state.get('field')!=field or value not in CHOICES.get(field,{}):
                raise ValueError('فرم تغییر منقضی شده است؛ دوباره باز کنید.')
            if field=='reward_type':
                state.update(field='reward_value',changes={'reward_type':value})
                await edit(q,'مقدار '+REWARD_LABELS[value]+' را وارد کنید:',[[InlineKeyboardButton('⬅️ مرحله',callback_data=f'milestone_edit:{mid}')]])
                return EXPERIENCE_INPUT
            parsed=value=='1' if field in {'enabled','repeatable'} else value
            await _milestone_edit_preview(update,context,mid,{field:parsed});context.user_data.pop('experience_input',None)
            return ConversationHandler.END
        elif op=='save':
            preview=context.user_data.get('milestone_edit_preview',{})
            if preview.get('mid')!=mid or preview.get('token')!=parts[3]:raise ValueError('پیش‌نمایش منقضی شده است.')
            def apply(db):
                row=db.get('referral_milestones',{}).get(mid)
                if not row or row.get('updated_at')!=preview.get('updated_at'):raise ValueError('مرحله تغییر کرده است؛ دوباره باز کنید.')
                return save_milestone(db,q.from_user.id,preview['changes'],mid)
            await async_with_db(apply);context.user_data.pop('milestone_edit_preview',None)
        else:raise ValueError('دکمه نامعتبر است.')
        await milestone_edit_menu(update,context,milestone_id=mid)
    except (ValueError,PermissionError,IndexError,KeyError) as exc:
        await edit(q,'❌ '+esc(str(exc)),back('a_milestones'))
    return ConversationHandler.END


async def gifts_menu(update, context):
    q = update.callback_query; await q.answer(); db = await async_snapshot()
    raw_page = str(q.data).partition(":")[2]
    page = int(raw_page) if raw_page.isdigit() else 0
    rows = [[InlineKeyboardButton('🎟 استفاده از کد هدیه', callback_data='gift_redeem_start')]]
    for plan in active_vip_plans(db, user_is_vip=is_vip(db,q.from_user.id)):
        rows.append([InlineKeyboardButton(f"🎁 {plan['name']} | {int(plan['price']):,} تومان", callback_data=f"gift_plan:{plan['id']}")])
    owned = sorted([g for g in db.get('vip_gifts', {}).values() if str(g['purchaser_user_id']) == str(q.from_user.id)], key=lambda g:int(g['gift_id']), reverse=True)
    page = min(page,max(0,(len(owned)-1)//10))
    for gift in owned[page*10:page*10+10]:
        rows.append([InlineKeyboardButton(f"هدیه #{gift['gift_id']} | {gift['status']}", callback_data=f"gift_view:{gift['gift_id']}")])
    if page:rows.append([InlineKeyboardButton('صفحه قبل',callback_data=f'u_gifts:{page-1}')])
    if (page+1)*10<len(owned):rows.append([InlineKeyboardButton('صفحه بعد',callback_data=f'u_gifts:{page+1}')])
    await edit(q, '🎁 <b>هدیه VIP</b>\nپلن هدیه را انتخاب کنید یا هدیه‌های خریداری‌شده را باز کنید.', rows + back('u_vip'))


async def gift_plan_menu(update, context):
    q = update.callback_query; await q.answer(); plan_id = q.data.split(':')[1]
    plan = get_vip_plan(await async_snapshot(), plan_id)
    if not plan or not plan.get('active', True):
        await edit(q, 'پلن در دسترس نیست.', back('u_gifts')); return
    nonce = uuid.uuid4().hex[:12]
    rows = [[InlineKeyboardButton('👤 ارسال مستقیم به کاربر', callback_data=f'gift_direct:{plan_id}:{nonce}')],
            [InlineKeyboardButton('🎟 کد هدیه', callback_data=f'gift_create:{plan_id}:{nonce}')],
            [InlineKeyboardButton('🔗 لینک هدیه', callback_data=f'gift_create:{plan_id}:{nonce}')]]
    await edit(q, f"🎁 {esc(plan['name'])}\nروش دریافت هدیه را انتخاب کنید:", rows + back('u_gifts'))


async def _show_gift(query, context, gift):
    gid = gift['gift_id']; rows = []; text = f"🎁 <b>هدیه #{gid}</b>\nوضعیت: {esc(gift['status'])}\nاعتبار: {gift['duration_days']} روز\nمهلت استفاده: {display_dt(gift['expires_at'])}"
    if gift['status'] in {'paid','active'}:
        username = effective_bot_username()
        text += f"\n\nکد هدیه:\n<code>{esc(gift['gift_token'])}</code>"
        if username:
            from urllib.parse import urlencode
            link = f"https://t.me/{username}?start=gift_{gift['gift_token']}"
            text += f"\nلینک هدیه:\n<code>{esc(link)}</code>"
            rows.append([InlineKeyboardButton('📤 ارسال هدیه', url='https://t.me/share/url?' + urlencode({'url':link}))])
    elif gift['status'] == 'pending_payment' and not gift.get('order_id'):
        rows.append([InlineKeyboardButton('💳 پرداخت هدیه', callback_data=f'gift_checkout:{gid}')])
    rows += back('u_gifts')
    await edit(query, text, rows)


async def gift_callback(update, context):
    q = update.callback_query; await q.answer(); parts = str(q.data).split(':'); action = parts[0]
    try:
        if action == 'gift_create':
            gift = await async_with_db(lambda db: create_gift(db,q.from_user.id,parts[1],request_key=parts[2]))
        else: gift = gift_for_owner(await async_snapshot(), q.from_user.id, parts[1])
        if action == 'gift_checkout':
            if gift['status'] != 'pending_payment' or gift.get('order_id'): raise ValueError('این هدیه در انتظار پرداخت جدید نیست.')
            context.user_data['buy_gift_id'] = gift['gift_id']; context.user_data['buy_plan_id'] = gift['plan_id']
            context.user_data.pop('buy_coupon', None); context.user_data.pop('buy_payment_method', None)
            methods = _available_payment_methods(await async_snapshot())
            rows = [[InlineKeyboardButton(_payment_method_label(method), callback_data=f'vip_pay_method:{method}')] for method in methods]
            await edit(q, '💳 روش پرداخت هدیه را انتخاب کنید.' if methods else 'روش پرداخت فعالی تنظیم نشده است.', rows + back('u_gifts')); return
        await _show_gift(q, context, gift)
    except (ValueError, PermissionError) as exc:
        await edit(q, esc(str(exc)), back('u_gifts'))


async def deliver_gift_access(context, user_id, gift):
    invite = await restore_vip_channel_access(context.bot, int(user_id), gift['vip_expires_at'])
    def store(db):
        row = db['vip_gifts'][gift['gift_id']]
        row['access_delivered_at'] = utc_iso()
        if str(user_id) in db.get('vip_users', {}): db['vip_users'][str(user_id)]['invite_link'] = invite
    await async_with_db(store)
    return invite


async def redeem_gift_for_update(update, context, token):
    try:
        gift = await async_with_db(lambda db: redeem_gift(db, update.effective_user.id, token))
    except (ValueError, PermissionError) as exc:
        await reply(update, esc(str(exc)), back('u_gifts')); return
    try:
        invite = await deliver_gift_access(context, update.effective_user.id, gift)
        await reply(update, f"✅ هدیه فعال شد.\nاعتبار: {display_dt(gift['vip_expires_at'])}\n{esc(invite or '')}", back('u_gifts'))
    except TelegramError:
        logger.warning('Gift channel delivery delayed gift_id=%s', gift['gift_id'])
        await reply(update, 'هدیه در حساب ثبت شد. تحویل دسترسی کانال موقتاً ناموفق بود؛ دوباره از همین کد استفاده کنید.', back('u_gifts'))


async def admin_work_queue_menu(update, context):
    if not await require_admin(update, allow_limited=True): return
    q = update.callback_query; await q.answer(); parts = str(q.data).split(':')
    selected = parts[1] if len(parts)>1 else 'all'; page = int(parts[2]) if len(parts)>2 and parts[2].isdigit() else 0
    from services.experience_state import reconcile_experience_work
    await run_blocking(reconcile_experience_work)
    items = await async_with_db(lambda db: work_items(db,q.from_user.id,selected))
    page = min(page, max(0,(len(items)-1)//10))
    rows = [[InlineKeyboardButton(f"{r['priority']} | {r['type']} #{r['reference_id']}",callback_data=f"work_view:{r['id']}")] for r in items[page*10:page*10+10]]
    choices = [('all','همه'),('mine','فقط من'),('unassigned','بدون مسئول'),('urgent','فوری'),('payment','پرداخت'),('ticket','تیکت'),('reward','جایزه'),('today','امروز'),('signal','سیگنال'),('errors','خطاها'),('completed','انجام‌شده')]
    buttons = [InlineKeyboardButton(label,callback_data=f'work_queue:{key}:0') for key,label in choices]
    rows += [buttons[i:i+4] for i in range(0,len(buttons),4)]
    if page: rows.append([InlineKeyboardButton('صفحه قبل',callback_data=f'work_queue:{selected}:{page-1}')])
    if (page+1)*10<len(items): rows.append([InlineKeyboardButton('صفحه بعد',callback_data=f'work_queue:{selected}:{page+1}')])
    await edit(q, f'📥 <b>کارهای منتظر اقدام</b>\nتعداد: {len(items)}', rows + back('admin_home'))


async def work_item_menu(update, context):
    q = update.callback_query; await q.answer(); action, ident = str(q.data).split(':',1)
    try:
        if action == 'ticket_work':
            if not await require_admin(update, PERMISSION_TICKETS): return
            queue = await async_with_db(reconcile_work_queue)
            item = queue.get(f'ticket:{ident}')
            if not item: raise ValueError('این تیکت کار باز ندارد.')
            ident = str(item['id'])
        if action == 'work_assign': await async_with_db(lambda db: assign_work(db,q.from_user.id,ident))
        db = await async_snapshot(); row = work_item(db,q.from_user.id,ident)
        lines = [f"📥 <b>کار #{row['id']}</b>",f"نوع: {row['type']} | شناسه: {esc(row['reference_id'])}",f"وضعیت: {row['status']}",f"مسئول: {esc(row.get('assigned_admin_id') or 'تعیین نشده')}"]
        history = [h for h in db.get('shift_handoffs',[]) if h.get('work_item_id') == row['id']]
        for h in history[-5:]: lines.append(f"واگذاری {h['from_admin_id']} ← {h['to_admin_id']} | {h['status']}\n{esc(str(h.get('note') or '')[:160])}")
        rows = [[InlineKeyboardButton('👤 تخصیص به من',callback_data=f'work_assign:{ident}'),InlineKeyboardButton('🔄 واگذاری',callback_data=f'handoff_start:{ident}')],
                [InlineKeyboardButton('📄 مشاهده مورد اصلی',callback_data=f"entity:{row['type']}:{row['reference_id']}")]]
        for h in history[-5:]:
            if h['to_admin_id'] == str(q.from_user.id) and h['status']=='pending': rows.append([InlineKeyboardButton('✅ پذیرش واگذاری',callback_data=f"handoff_accept:{h['id']}")])
        await edit(q,'\n'.join(lines), rows + back('work_queue'))
    except (ValueError,PermissionError) as exc: await edit(q,esc(str(exc)),back('work_queue'))


async def admin_entity_view(update, context):
    q = update.callback_query; await q.answer(); _,kind,reference = str(q.data).split(':',2)
    from services.experience_state import admin_entity
    try: row = await run_blocking(admin_entity,await async_snapshot(),q.from_user.id,kind,reference)
    except PermissionError as exc:
        await edit(q,esc(str(exc)),back('admin_home')); return
    if row is None:
        await edit(q,'مورد مرتبط دیگر در دسترس نیست.',back('work_queue')); return
    fields = ('id','order_id','title','name','symbol','subject','status','user_id','price','duration_days','expires_at','created_at','updated_at')
    text = '\n'.join(f'{esc(k)}: {esc(str(row[k])[:180])}' for k in fields if k in row)
    routes = {'payment':f'pending_detail:{reference}','ticket':f'ticket_a:{reference}','reward':'a_reward_requests','gift':'a_pending',
              'signal':'channel_schedules','published_signal':f'sig_result_view:{reference}','campaign':'a_campaigns','incident':'a_incidents','course':'a_edu',
              'approval':'a_approvals','automation':'a_automations','job':'a_automations',
              'user':f'crm_open:{reference}','vip':f'crm_open:{reference}','referral':f'crm_open:{reference}', 'coupon':f'public_discount_view:{reference}'}
    rows=[]
    if kind == 'ticket' and row.get('normalized_ticket'):
        for message in row.get('messages', [])[-5:]:
            text += f"\n\n{esc(message.get('sender_type'))}: {esc(str(message.get('body') or '')[:350])}"
        rows.append([InlineKeyboardButton('✍️ پاسخ به تیکت', callback_data=f'norm_ticket_reply:{reference}')])
        if row.get('status') != 'closed': rows.append([InlineKeyboardButton('🔒 بستن تیکت', callback_data=f'norm_ticket_close:{reference}')])
    elif kind in routes: rows.append([InlineKeyboardButton('باز کردن بخش مدیریت',callback_data=routes[kind])])
    await edit(q,f'📄 <b>{esc(kind)} #{esc(reference)}</b>\n{text}',rows+back('work_queue'))


async def normalized_ticket_close(update, context):
    q=update.callback_query
    if not await require_admin(update,PERMISSION_TICKETS):return
    from services.experience_state import update_normalized_ticket
    try:
        await run_blocking(update_normalized_ticket,q.from_user.id,str(q.data).split(':')[1],close=True)
        await q.answer('تیکت بسته شد.')
        await edit(q,'✅ تیکت بسته شد.',back('work_queue'))
    except (ValueError,PermissionError) as exc:await q.answer(str(exc),show_alert=True)


async def handoff_accept_handler(update, context):
    q=update.callback_query
    try:
        await async_with_db(lambda db: accept_handoff(db,q.from_user.id,q.data.split(':')[1]))
        await q.answer('واگذاری پذیرفته شد.')
    except (ValueError,PermissionError) as exc: await q.answer(str(exc),show_alert=True)


async def ticket_context_start(update, context):
    q=update.callback_query; await q.answer(); _,kind,reference=str(q.data).split(':',2)
    try:
        if await run_blocking(resolve_context,await async_snapshot(),q.from_user.id,kind,reference) is None: raise ValueError('مورد مرتبط دیگر در دسترس نیست.')
    except (ValueError,PermissionError) as exc:
        await edit(q,esc(str(exc)),back('u_support')); return ConversationHandler.END
    context.user_data['ticket_context']={'type':kind,'id':reference}
    context.user_data['ticket_category']='payment' if kind=='payment' else 'general'
    await edit(q,'🎫 مشکل خود را در یک پیام توضیح دهید. مورد مرتبط به تیکت متصل می‌شود.',back('u_support'))
    return TICKET_NEW_MESSAGE


async def ticket_context_handler(update, context):
    q=update.callback_query; await q.answer(); db=await async_snapshot()
    ticket=find_ticket(db,q.data.split(':')[1])
    if not ticket:
        await edit(q,'تیکت در دسترس نیست.',back('u_support')); return
    try: row=await run_blocking(ticket_context_view,db,q.from_user.id,ticket)
    except (ValueError,PermissionError) as exc:
        await edit(q,esc(str(exc)),back('u_support')); return
    parent=f"ticket_a:{ticket['id']}" if str(ticket['user_id']) != str(q.from_user.id) else f"ticket_u:{ticket['id']}"
    text='مورد مرتبط دیگر در دسترس نیست.' if row is None else '\n'.join(f'{esc(k)}: {esc(str(v)[:200])}' for k,v in row.items())
    buttons=[];kind=ticket.get('context_type');reference=ticket.get('context_id')
    if row is not None:
        if str(ticket['user_id'])==str(q.from_user.id):
            routes={'payment':f'user_payment:{reference}','signal':f'user_signal_view:{reference}','course':f'lesson:{reference}',
                    'reward':'u_my_rewards','vip':'u_vip','referral':'u_referral','competition':'u_contests','price_alert':'price_alert_list'}
        else:
            routes={'payment':f'entity:payment:{reference}','signal':f'entity:published_signal:{reference}','course':f'entity:course:{reference}',
                    'reward':f"a_user_rewards:{ticket['user_id']}",'vip':f"crm_open:{ticket['user_id']}",'referral':f"crm_open:{ticket['user_id']}",'competition':'a_contest'}
        if kind in routes:buttons.append([InlineKeyboardButton('📄 باز کردن بخش مرتبط',callback_data=routes[kind])])
    await edit(q,f"📎 {esc(ticket.get('context_type'))} #{esc(ticket.get('context_id'))}\n{text}",buttons+back(parent))


async def user_payments_menu(update, context):
    q=update.callback_query;await q.answer()
    action,_,reference=str(q.data).partition(':')
    if action=='user_payment':
        try:row=await run_blocking(resolve_context,await async_snapshot(),q.from_user.id,'payment',reference)
        except (ValueError,PermissionError):row=None
        if not row:
            await edit(q,'این پرداخت در دسترس نیست.',back('user_orders'));return
        text=f"💳 <b>پرداخت {esc(reference)}</b>\nوضعیت: {esc(row.get('status'))}\nمبلغ: {int(row.get('amount_toman',row.get('price',0)) or 0):,} تومان\nثبت: {display_dt(row.get('created_at'))}"
        await edit(q,text,back('user_orders'));return
    from services.experience_state import user_orders
    orders=await run_blocking(user_orders,q.from_user.id)
    page=min(int(reference) if reference.isdigit() else 0,max(0,(len(orders)-1)//8))
    rows=[[InlineKeyboardButton(f"{r['order_id']} | {r.get('status')}",callback_data=f"user_payment:{r['order_id']}")] for r in orders[page*8:page*8+8]]
    if page:rows.append([InlineKeyboardButton('صفحه قبل',callback_data=f'user_orders:{page-1}')])
    if (page+1)*8<len(orders):rows.append([InlineKeyboardButton('صفحه بعد',callback_data=f'user_orders:{page+1}')])
    await edit(q,'💳 <b>سفارش‌های من</b>' if orders else 'هنوز سفارشی ثبت نکرده‌اید.',rows+back('u_vip'))


async def experience_input_start(update, context):
    q=update.callback_query; await q.answer(); parts=str(q.data).split(':'); op=parts[0]
    state={'op':op,'request_key':str(q.id)}
    choices = []
    if op.startswith('milestone_'):
        if not await require_admin(update,PERMISSION_REWARD_POINTS): return ConversationHandler.END
        if op=='milestone_new': state.update(values={},field='title')
        else:
            state.update(mid=parts[1],field=parts[2])
            row=(await async_snapshot()).get('referral_milestones',{}).get(parts[1])
            if not row or row.get('deleted_at'):
                await edit(q,'مرحله پیدا نشد.',back('a_milestones'));return ConversationHandler.END
            if has_claims(await async_snapshot(),parts[1]) and parts[2] in LOCKED_FIELDS:
                await edit(q,'این مرحله جایزه صادر کرده؛ مرحلهٔ تازه بسازید.',back('a_milestones'));return ConversationHandler.END
            state['updated_at']=row.get('updated_at')
            choices=[[InlineKeyboardButton(label,callback_data=f'ms:choice:{parts[1]}:{parts[2]}:{value}')] for value,label in CHOICES.get(parts[2],{}).items()]
        prompt=_MILESTONE_FIELDS.get(state['field'])
        if not prompt: return ConversationHandler.END
    elif op=='gift_direct': state.update(plan=parts[1],request_key=parts[2]); prompt='شناسه عددی کاربری که ربات را استارت کرده وارد کنید:'
    elif op=='gift_redeem_start': prompt='کد هدیه یا لینک هدیه را بفرستید:'
    elif op=='palette_start':
        if not await require_admin(update, allow_limited=True): return ConversationHandler.END
        prompt='⚡ نام، نماد یا شناسه را جستجو کنید؛ مثال: user 12345، payment 725، ticket 62 یا XAUUSD'
    elif op=='norm_ticket_reply':
        if not await require_admin(update,PERMISSION_TICKETS):return ConversationHandler.END
        from services.experience_state import admin_entity
        row=await run_blocking(admin_entity,await async_snapshot(),q.from_user.id,'ticket',parts[1])
        if not row:
            await edit(q,'تیکت پیدا نشد.',back('work_queue'));return ConversationHandler.END
        state['reference']=parts[1];prompt='پاسخ تیکت را بنویسید:'
    elif op=='handoff_start':
        try:
            db=await async_snapshot(); row=work_item(db,q.from_user.id,parts[1])
        except (ValueError,PermissionError) as exc:
            await edit(q,esc(str(exc)),back('work_queue')); return ConversationHandler.END
        state.update(item=parts[1],field='target')
        targets=(await run_blocking(_admin_ids_for_permission, __import__('modules.admin_work_queue',fromlist=['SOURCES']).SOURCES[row['type']][2]))
        targets = [a for a in targets if str(a)!=str(q.from_user.id)]
        choices = [[InlineKeyboardButton(f'مدیر {a}', callback_data=f'handoff_target:{a}')] for a in targets]
        prompt='مدیر مقصد را انتخاب کنید یا شناسه او را بنویسید:' if targets else 'مدیر دیگری با مجوز این بخش تعریف نشده است.'
    else: return ConversationHandler.END
    context.user_data['experience_input']=state
    await edit(q,prompt,choices+[[InlineKeyboardButton('✖️ لغو',callback_data='cancel_current')]])
    return EXPERIENCE_INPUT


async def handoff_target_handler(update, context):
    q = update.callback_query; await q.answer()
    state = context.user_data.get('experience_input', {})
    try:
        if state.get('op') != 'handoff_start' or state.get('field') != 'target': raise ValueError('فرم واگذاری منقضی شده است.')
        target = str(q.data).split(':')[1]
        db = await async_snapshot(); row = work_item(db, q.from_user.id, state['item'])
        if target == str(q.from_user.id) or not can_access(db,target,row['type']): raise ValueError('مدیر مقصد مجاز نیست.')
        state.update(target=target,field='note')
        await edit(q,'توضیح تحویل کار را بنویسید (حداقل ۵ نویسه):',[[InlineKeyboardButton('✖️ لغو',callback_data='cancel_current')]])
    except (ValueError,PermissionError) as exc:
        await edit(q,esc(str(exc)),back('work_queue'))
        return ConversationHandler.END
    return EXPERIENCE_INPUT


def _milestone_value(field, text):
    if field in {'required_count','reward_value','sort_order','max_claims'}:
        value = int(text)
        if field in {'required_count','reward_value'} and not 1 <= value <= 1_000_000_000: raise ValueError('مقدار مثبت و معتبر وارد کنید.')
        if field == 'max_claims' and value < 0: raise ValueError('سقف دریافت نمی‌تواند منفی باشد.')
        return value
    if field in {'enabled','repeatable'}:
        if text.lower() not in {'بله','خیر','true','false','yes','no','1','0'}: raise ValueError('بله یا خیر وارد کنید.')
        return text.lower() in {'بله','true','yes','1'}
    if field in {'start_at','expire_at'}:
        if text == '-': return None
        if not parse_dt(text): raise ValueError('تاریخ معتبر میلادی یا - وارد کنید.')
        return text
    if field == 'trigger_type' and text not in {'referrals_joined','referrals_purchased','referral_revenue'}: raise ValueError('یکی از سه نوع هدف نمایش‌داده‌شده را وارد کنید.')
    if field == 'reward_type' and text not in {'points','vip_days','discount_coupon','reward_item'}: raise ValueError('یکی از چهار نوع پاداش نمایش‌داده‌شده را وارد کنید.')
    if field == 'title' and not text: raise ValueError('عنوان لازم است.')
    return text


async def experience_input_message(update, context):
    state=context.user_data.get('experience_input',{}); op=state.get('op'); text=str(update.effective_message.text or '').strip(); uid=update.effective_user.id
    try:
        if op in {'milestone_new','milestone_field'}:
            if not await require_admin(update,PERMISSION_REWARD_POINTS): return ConversationHandler.END
            field=state['field']; value=_milestone_value(field,text)
            if op=='milestone_field':
                changes={**state.get('changes',{}),field:value}
                await _milestone_edit_preview(update,context,state['mid'],changes)
                context.user_data.pop('experience_input',None)
                return ConversationHandler.END
            else:
                if field == 'reward_value':
                    kind = state['values']['reward_type']
                    if kind == 'vip_days' and value > 3650: raise ValueError('حداکثر ۳۶۵۰ روز مجاز است.')
                    if kind == 'discount_coupon': normalize_discount_tier(value)
                    if kind == 'reward_item' and not any(str(r.get('id')) == str(value) for r in (await async_snapshot()).get('settings',{}).get('rewardItems',[])): raise ValueError('شناسه جایزه موجود نیست.')
                if field == 'expire_at' and value and state['values'].get('start_at') and parse_dt(value) <= parse_dt(state['values']['start_at']): raise ValueError('پایان باید بعد از شروع باشد.')
                state['values'][field]=value; fields=list(_MILESTONE_FIELDS); index=fields.index(field)+1
                if index<len(fields):
                    state['field']=fields[index]
                    await reply(update,_MILESTONE_FIELDS[fields[index]],[[InlineKeyboardButton('✖️ لغو',callback_data='cancel_current')]])
                    return EXPERIENCE_INPUT
                await async_with_db(lambda db:save_milestone(db,uid,state['values']))
            await reply(update,'✅ مرحله ذخیره شد.',[[InlineKeyboardButton('🎯 مراحل معرفی',callback_data='a_milestones')]])
        elif op=='gift_direct':
            gift=await async_with_db(lambda db:create_gift(db,uid,state['plan'],text,state['request_key']))
            await reply(update,'هدیه ایجاد شد. پرداخت را تکمیل کنید.',[[InlineKeyboardButton('💳 پرداخت',callback_data=f"gift_checkout:{gift['gift_id']}")]])
        elif op=='gift_redeem_start':
            token=text.split('gift_',1)[-1] if 'gift_' in text else text
            await redeem_gift_for_update(update,context,token)
        elif op=='palette_start':
            if not await require_admin(update, allow_limited=True): return ConversationHandler.END
            from services.experience_state import search_palette
            found=await run_blocking(search_palette,uid,text)
            rows=[[InlineKeyboardButton(f"{r['type']} #{r['reference_id']} | {r['label'][:35]}",callback_data=f"entity:{r['type']}:{r['reference_id']}")] for r in found if len(f"entity:{r['type']}:{r['reference_id']}".encode())<=64]
            await reply(update,'⚡ نتایج جستجو' if rows else 'موردی در محدوده دسترسی شما پیدا نشد.',rows+back('admin_home'))
        elif op=='norm_ticket_reply':
            from services.experience_state import update_normalized_ticket
            await run_blocking(update_normalized_ticket,uid,state['reference'],body=text,request_key=state['request_key'])
            await reply(update,'✅ پاسخ ثبت شد و در تیکت کاربر قابل مشاهده است.',[[InlineKeyboardButton('مشاهده تیکت',callback_data=f"entity:ticket:{state['reference']}")]]+back('work_queue'))
        elif op=='handoff_start':
            if state['field']=='target':
                db=await async_snapshot(); row=work_item(db,uid,state['item'])
                if not can_access(db,text,row['type']): raise ValueError('شناسه مدیر مجاز نیست.')
                state.update(target=text,field='note')
                await reply(update,'توضیح تحویل کار را بنویسید (حداقل ۵ نویسه):',[[InlineKeyboardButton('✖️ لغو',callback_data='cancel_current')]])
                return EXPERIENCE_INPUT
            handoff=await async_with_db(lambda db:handoff_work(db,uid,state['item'],state['target'],text,state['request_key']))
            await reply(update,'✅ واگذاری ثبت شد.',[[InlineKeyboardButton('📥 مشاهده کار',callback_data=f"work_view:{handoff['work_item_id']}")]])
        else:
            await reply(update,'این فرم منقضی شده است.',back('home'))
    except (ValueError,PermissionError) as exc:
        await reply(update,esc(str(exc)),[[InlineKeyboardButton('✖️ لغو',callback_data='cancel_current')]])
        return EXPERIENCE_INPUT
    context.user_data.pop('experience_input',None)
    return ConversationHandler.END


async def experience_maintenance_job(context):
    from modules.referral_review import settle_qualifications
    await async_with_db(settle_qualifications)
    from modules.personal_notifications import queue_personal_notifications
    from modules.vip_gifts import reconcile_gifts
    await async_with_db(reconcile_gifts)
    from services.experience_state import reconcile_experience_work
    await run_blocking(reconcile_experience_work)
    await async_with_db(queue_personal_notifications)
    db=await async_snapshot()
    pending_gifts = [g for g in db.get('vip_gifts', {}).values() if g.get('status') == 'redeemed' and not g.get('recipient_notified_at')]
    for gift in pending_gifts[:5]:
        uid = gift['redeemed_by']
        try:
            invite = db.get('vip_users', {}).get(uid, {}).get('invite_link') if gift.get('access_delivered_at') else None
            if not invite: invite = await deliver_gift_access(context, uid, gift)
            await context.bot.send_message(int(uid), f"🎁 هدیه VIP شما فعال شد.\nاعتبار: {display_dt(gift['vip_expires_at'])}\n{invite or ''}")
            await async_with_db(lambda state, gid=gift['gift_id']: state['vip_gifts'][gid].update(recipient_notified_at=utc_iso()))
        except (TelegramError, ValueError):
            logger.warning('Gift access delivery deferred gift_id=%s', gift['gift_id'])
    for row in [h for h in db.get('shift_handoffs',[]) if h.get('entity_type') and h.get('status')=='pending' and not h.get('notification_sent_at')][:20]:
        if not can_access(db,row['to_admin_id'],row['entity_type']): continue
        try:
            await context.bot.send_message(int(row['to_admin_id']),f"🔄 کار #{row['work_item_id']} به شما واگذار شد.\n{row.get('note','')[:1000]}",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('📥 مشاهده و پذیرش',callback_data=f"work_view:{row['work_item_id']}")]]))
            def mark(state, ident=row['id']):
                h=next(h for h in state['shift_handoffs'] if h['id']==ident); h['notification_sent_at']=utc_iso()
            await async_with_db(mark)
        except TelegramError: logger.warning('Handoff notification failed handoff_id=%s',row['id'])


async def referral_fraud_menu(update, context):
    if not await require_admin_all(update, (PERMISSION_REWARD_POINTS, PERMISSION_INCIDENTS)):
        return
    query = update.callback_query
    data = str(getattr(query, 'data', '') or '')
    if query:
        await query.answer()
    parts = data.split(':')
    if len(parts) == 4 and parts[0] == 'refreview' and parts[1] in {'confirm', 'apply'}:
        _, action, uid, decision = parts
        if not uid.isdigit() or decision not in {'approved', 'rejected'}:
            return
        if action == 'confirm':
            label = 'تأیید' if decision == 'approved' else 'رد'
            await edit(query, f'تصمیم {label} برای دعوت کاربر {uid} ثبت شود؟', [
                [InlineKeyboardButton('✅ ثبت تصمیم', callback_data=f'refreview:apply:{uid}:{decision}')],
                [InlineKeyboardButton('⬅️ بازگشت', callback_data='refreview')]])
            return
        from modules.referral_review import review_referral
        try:
            await async_with_db(lambda db: review_referral(db, update.effective_user.id, uid, decision))
        except ValueError:
            pass  # stale repeated button; refresh current queue
    db = await async_snapshot()
    pending = [r for r in db.get('referral_qualification', {}).values() if r.get('status') == 'review']
    lines = [f'🛡 بررسی دعوت‌ها: {len(pending)} مورد', 'تأیید مدیر نیز مهلت ۲۴ ساعته را حذف نمی‌کند.']
    rows = []
    for row in pending[:10]:
        uid = row['user_id']
        lines.append(f"کاربر {esc(uid)} · معرف {esc(row['referrer_id'])} · دعوت‌های متوالی")
        rows.append([InlineKeyboardButton(f'تأیید {uid}', callback_data=f'refreview:confirm:{uid}:approved'),
                     InlineKeyboardButton(f'رد {uid}', callback_data=f'refreview:confirm:{uid}:rejected')])
    rows.append([InlineKeyboardButton('🏠 پنل مدیر', callback_data='admin_home')])
    if query:
        await edit(query, '\n'.join(lines), rows)
    else:
        await reply(update, '\n'.join(lines), rows)


__feature_exports__ = ('milestone_config_callback', 'referral_fraud_menu','EXPERIENCE_INPUT','referral_milestones_menu','milestone_claim_handler','admin_milestones_menu','milestone_edit_menu','gifts_menu','gift_plan_menu','gift_callback','redeem_gift_for_update','admin_work_queue_menu','work_item_menu','admin_entity_view','handoff_accept_handler','ticket_context_start','ticket_context_handler','experience_input_start','experience_input_message','handoff_target_handler','normalized_ticket_close','user_payments_menu','experience_maintenance_job')
