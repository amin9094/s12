"""Version-separated retrospective summaries. No tuning or live activation."""
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
from decimal import Decimal as D
from repositories.v2.common import json_load
from repositories.v2.paper_statistics import combine,contribution


def _summary(value):
    v=combine({},value);n=v['closed'];unknown=v['unresolved_positions']
    return {**v,'win_rate':v['wins']/n*100 if n else None,'average_r':str(D(v['r_sum'])/n) if n else None,
            'hypothetical_win_rate_bounds':{'lower':v['wins']/(n+unknown)*100,'upper':(v['wins']+unknown)/(n+unknown)*100,
               'assumption':'ALL_UNRESOLVED_LOSS_VS_ALL_UNRESOLVED_WIN_NOT_BOOKED'} if n+unknown else None}


def report(repo,strategy,*,from_ms,selection_end_ms,evaluation_end_ms,to_ms,profile_id=None,heldout_symbols=(),not_before_evidence_ms=None,implementation_hash=None):
    from modules.automated_market_scope import require_global_symbol
    from repositories.v2.live_signal_inbox import STRATEGIES
    if strategy not in STRATEGIES:raise ValueError('PAPER_STRATEGY_INVALID')
    if any(type(x) is not int for x in (from_ms,selection_end_ms,evaluation_end_ms,to_ms)) or not 0<=from_ms<selection_end_ms<evaluation_end_ms<=to_ms:
        raise ValueError('RESEARCH_PERIOD_INVALID')
    if len(heldout_symbols)>20 or any(not isinstance(x,str) for x in heldout_symbols):raise ValueError('HELDOUT_SYMBOLS_INVALID')
    for symbol in heldout_symbols:require_global_symbol(symbol)
    if profile_id is not None and (not isinstance(profile_id,str) or len(profile_id)>160):raise ValueError('PAPER_FILTER_INVALID')
    groups={};cursor=(from_ms,'');total=0;cross_boundary=0;predeclaration_excluded=0;implementation_excluded=0
    period_width=max(1,(to_ms-from_ms)//4)
    with repo.engine.transaction(read_only=True,repeatable_read=True) as c:
        while True:
            rows=c.execute('''SELECT t.id,t.created_ms,t.payload,r.engine FROM s9_strategy_paper_trades t JOIN s9_strategy_paper_runs r ON r.id=t.run_id
                WHERE r.engine IN (?,?) AND t.created_ms>=? AND t.created_ms<=? AND (t.created_ms>? OR (t.created_ms=? AND t.id>?))
                ORDER BY t.created_ms,t.id LIMIT 200''',(strategy,strategy+'~market',from_ms,to_ms,cursor[0],cursor[0],cursor[1])).fetchall()
            for row in rows:
                p=json_load(row['payload']);plan=p['plan'];profile=p.get('profile_id') or 'unclassified'
                if profile_id is not None and profile!=profile_id:continue
                if implementation_hash is not None and p.get('implementation_hash')!=implementation_hash:
                    implementation_excluded+=1;continue
                if (not_before_evidence_ms is not None and row['created_ms']>=selection_end_ms
                    and plan.get('evidence_cutoff_ms',-1)<not_before_evidence_ms):
                    predeclaration_excluded+=1;continue
                stamp=row['created_ms'];cut=selection_end_ms if stamp<selection_end_ms else evaluation_end_ms if stamp<evaluation_end_ms else to_ms
                cohort='SELECTION' if stamp<selection_end_ms else 'OUT_OF_SAMPLE' if stamp<evaluation_end_ms else 'FORWARD_OBSERVATION'
                # Do not let an outcome learned after a split leak into the
                # earlier selection/evaluation cohort. The live trade is intact.
                if p.get('closed_ms',cut+1)>cut and p.get('entered_ms') is not None:
                    p={**p,'state':'NEEDS_REVIEW','realized_usd':'0','unrealized_usd':'0'};cross_boundary+=1
                v=contribution(p);total+=1;dt=datetime.fromtimestamp(stamp/1000,timezone.utc)
                london=dt.astimezone(ZoneInfo('Europe/London'));ny=dt.astimezone(ZoneInfo('America/New_York'))
                sessions=[]
                if 8<=london.hour<17:sessions.append('LONDON_08_17_LOCAL')
                if 8<=ny.hour<17:sessions.append('NEW_YORK_08_17_LOCAL')
                if not sessions:sessions=['OUTSIDE_DEFINED_SESSIONS']
                dimensions=[('cohort',cohort),('instrument_group','HELD_OUT' if plan['symbol'] in heldout_symbols else 'SELECTION_SYMBOLS'),
                            ('cohort_instrument_group',cohort+'|'+('HELD_OUT' if plan['symbol'] in heldout_symbols else 'SELECTION_SYMBOLS')),
                            ('frozen_regime',str((p.get('market_regime') or {}).get('state','UNKNOWN_NOT_CAPTURED'))),
                            ('quarter',str(min(3,(stamp-from_ms)//period_width)+1)),('tehran_hour',str(dt.astimezone(ZoneInfo('Asia/Tehran')).hour))]
                dimensions.extend(('session',s) for s in sessions)
                for kind,label in dimensions:
                    key=(row['engine'],profile,str(p.get('implementation_hash') or 'LEGACY_UNRECORDED'),kind,label)
                    groups[key]=combine(groups.get(key),v)
            if len(rows)<200:break
            cursor=(rows[-1]['created_ms'],rows[-1]['id'])
    return {'strategy':strategy,'period':{'from_ms':from_ms,'selection_end_ms':selection_end_ms,'evaluation_end_ms':evaluation_end_ms,'to_ms':to_ms},
            'groups':[{'account':k[0],'profile_id':k[1],'implementation_hash':k[2],'dimension':k[3],'label':k[4],**_summary(v)} for k,v in sorted(groups.items())],
            'samples':total,'boundary_outcomes_not_used':cross_boundary,'automatic_activation':False,
            'predeclaration_inputs_excluded':predeclaration_excluded,
            'implementation_mismatch_excluded':implementation_excluded,
            'heldout_symbols':list(heldout_symbols),'instrument_selection_declared_after_trades':True,
            'validation_status':'RETROSPECTIVE_SPLIT_NOT_PROSPECTIVE_CERTIFICATION','minimum_closed_sample_for_descriptive_comparison':30,
            'timezone_policy':'IANA_LONDON_NEW_YORK_DST_TEHRAN','unknown_outcomes_unchanged':True}
