from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
import math
from zoneinfo import ZoneInfo

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import json_dump, json_load, new_id, utc_iso


class AccountRepository:
    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    def list_for_user(self, user_id: int | str, *, include_archived: bool = False) -> list[dict[str, Any]]:
        clauses = "user_id = ?" + ("" if include_archived else " AND archived = 0")
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                f"SELECT * FROM v8_trading_accounts WHERE {clauses} ORDER BY is_default DESC, created_at, id",  # nosec B608
                (str(user_id),),
            ).fetchall()
        return [self._decode(row) for row in rows]

    def get(self, user_id: int | str, account_id: str | int | None = None) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            if account_id is None:
                row = cursor.execute(
                    "SELECT * FROM v8_trading_accounts WHERE user_id = ? AND archived = 0 ORDER BY is_default DESC, created_at LIMIT 1",
                    (str(user_id),),
                ).fetchone()
            else:
                sql = "SELECT * FROM v8_trading_accounts WHERE user_id = ? AND id = ?"
                if self.engine.dialect.name == "postgres" and getattr(self.engine._unit_of_work, "cursor", None) is not None:
                    sql += " FOR UPDATE"
                row = cursor.execute(sql, (str(user_id), str(account_id))).fetchone()
        return self._decode(row) if row else None

    def upsert(self, user_id: int | str, values: dict[str, Any], *, account_id: str | int | None = None) -> dict[str, Any]:
        with self.engine.atomic():
            return self._upsert(user_id, values, account_id=account_id)

    def _upsert(self, user_id: int | str, values: dict[str, Any], *, account_id: str | int | None = None) -> dict[str, Any]:
        uid = str(user_id)
        current = self.get(uid, account_id) if account_id is not None else None
        if account_id is not None and current is None:
            with self.engine.transaction(read_only=True) as cursor:
                exists = cursor.execute("SELECT user_id FROM v8_trading_accounts WHERE id=?", (str(account_id),)).fetchone()
            if exists is not None:
                raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
        if values.get("id") is not None and str(values["id"]) != str(account_id or ""):
            raise ValueError("ACCOUNT_ID_IMMUTABLE")
        if values.get("user_id") is not None and str(values["user_id"]) != uid:
            raise ValueError("ACCOUNT_OWNER_IMMUTABLE")
        now = utc_iso()
        account = {
            "id": str(account_id or new_id("acct")),
            "user_id": uid,
            "name": "Primary Account",
            "type": "personal",
            "phase": "personal",
            "currency": "USD",
            "balance": 0.0,
            "equity": 0.0,
            "starting_balance": 0.0,
            "high_water_mark": 0.0,
            "floating_pnl": 0.0,
            "timezone": "UTC",
            "is_default": False,
            "archived": False,
            "rule_template_id": None,
            "data_source": "manual",
            "data_confidence": 0.5,
            "data_observed_at": now,
            "created_at": now,
            "updated_at": now,
        }
        if current:
            account.update(current)
        allowed = {"name", "type", "account_type", "phase", "currency", "balance", "equity", "starting_balance",
                   "high_water_mark", "floating_pnl", "timezone", "is_default", "archived", "rule_template_id",
                   "data_source", "data_confidence", "data_observed_at", "leverage", "default_risk_percent",
                   "max_daily_risk_percent", "max_open_risk_percent", "max_open_trades", "broker", "provider", "broker_account_reference", "mt5_server", "mt5_connector_id",
                   "risk_enabled", "max_daily_loss_percent", "max_total_loss_percent", "profit_target_percent"}
        account.update({k: v for k, v in values.items() if k in allowed and v is not None})
        account["name"] = str(account.get("name") or "Primary Account")[:80]
        account["type"] = str(account.get("type") or account.get("account_type") or "personal")
        account["phase"] = str(account.get("phase") or "personal")
        account["currency"] = str(account.get("currency") or "USD").upper()[:10]
        account["timezone"] = self._validate_timezone(str(account.get("timezone") or "UTC"))
        for key in ("balance", "equity", "starting_balance", "high_water_mark", "floating_pnl"):
            account[key] = float(account.get(key) or 0)
            if not math.isfinite(account[key]):
                raise ValueError("INVALID_ACCOUNT_VALUE")
        if account.get("data_observed_at"):
            self._local_date(str(account["data_observed_at"]), account["timezone"])
        account["high_water_mark"] = max(account["high_water_mark"], account["equity"], account["balance"])
        account["data_confidence"] = min(1.0, max(0.0, float(account.get("data_confidence") or 0.5)))
        account["updated_at"] = now
        if not current:
            existing = self.list_for_user(uid, include_archived=True)
            account["is_default"] = bool(account.get("is_default") or not existing)
        payload = dict(account)
        with self.engine.transaction() as cursor:
            if account["is_default"]:
                cursor.execute("UPDATE v8_trading_accounts SET is_default = 0 WHERE user_id = ?", (uid,))
            cursor.execute(
                """INSERT INTO v8_trading_accounts(
                    id,user_id,name,account_type,phase,currency,balance,equity,starting_balance,high_water_mark,
                    floating_pnl,timezone,is_default,archived,rule_template_id,data_source,data_confidence,
                    data_observed_at,created_at,updated_at,payload
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name,account_type=excluded.account_type,phase=excluded.phase,currency=excluded.currency,
                    balance=excluded.balance,equity=excluded.equity,starting_balance=excluded.starting_balance,
                    high_water_mark=excluded.high_water_mark,floating_pnl=excluded.floating_pnl,timezone=excluded.timezone,
                    is_default=excluded.is_default,archived=excluded.archived,rule_template_id=excluded.rule_template_id,
                    data_source=excluded.data_source,data_confidence=excluded.data_confidence,
                    data_observed_at=excluded.data_observed_at,updated_at=excluded.updated_at,payload=excluded.payload
                WHERE v8_trading_accounts.user_id=excluded.user_id""",
                (
                    account["id"],uid,account["name"],account["type"],account["phase"],account["currency"],
                    account["balance"],account["equity"],account["starting_balance"],account["high_water_mark"],
                    account["floating_pnl"],account["timezone"],int(bool(account["is_default"])),
                    int(bool(account["archived"])),account.get("rule_template_id"),account["data_source"],
                    account["data_confidence"],account.get("data_observed_at") or now,account["created_at"],now,
                    json_dump(payload),
                ),
            )
            if cursor.rowcount != 1:
                raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
        return account

    def archive(self, user_id: int | str, account_id: str | int) -> dict[str, Any]:
        account = self.get(user_id, account_id)
        if not account:
            raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
        account["archived"] = True
        account["is_default"] = False
        return self.upsert(user_id, account, account_id=account["id"])

    def record_equity(self, user_id: int | str, account_id: str | int, *, balance: float, equity: float,
                      floating_pnl: float = 0.0, source: str = "manual", confidence: float = 0.5,
                      observed_at: str | None = None, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        account = self.get(user_id, account_id)
        if not account:
            raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
        observed = observed_at or utc_iso()
        local_date = self._local_date(observed, account["timezone"])
        event_id = new_id("eq")
        high = max(float(account.get("high_water_mark") or 0), float(equity), float(balance))
        event = {
            "id": event_id, "user_id": str(user_id), "account_id": str(account_id), "balance": float(balance),
            "equity": float(equity), "floating_pnl": float(floating_pnl), "high_water_mark": high,
            "observed_at": observed, "account_local_date": local_date, "source": str(source),
            "confidence": min(1.0, max(0.0, float(confidence))), **(payload or {}),
        }
        with self.engine.transaction() as cursor:
            cursor.execute(
                """INSERT INTO v8_equity_events(id,user_id,account_id,balance,equity,floating_pnl,high_water_mark,
                    observed_at,account_local_date,source,confidence,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                (event_id,str(user_id),str(account_id),float(balance),float(equity),float(floating_pnl),high,
                 observed,local_date,str(source),event["confidence"],json_dump(event)),
            )
            cursor.execute(
                """UPDATE v8_trading_accounts SET balance=?,equity=?,floating_pnl=?,high_water_mark=?,
                    data_source=?,data_confidence=?,data_observed_at=?,updated_at=? WHERE id=? AND user_id=?""",
                (float(balance),float(equity),float(floating_pnl),high,str(source),event["confidence"],observed,
                 utc_iso(),str(account_id),str(user_id)),
            )
            existing = cursor.execute(
                "SELECT * FROM v8_daily_account_snapshots WHERE account_id=? AND local_date=?",
                (str(account_id), local_date),
            ).fetchone()
            if existing:
                cursor.execute(
                    """UPDATE v8_daily_account_snapshots SET lowest_equity=?,highest_equity=?,floating_pnl=?,
                       updated_at=?,source_event_id=?,payload=? WHERE account_id=? AND local_date=?""",
                    (min(float(existing["lowest_equity"]), float(equity)),
                     max(float(existing["highest_equity"]), float(equity)),float(floating_pnl),utc_iso(),event_id,
                     json_dump(event),str(account_id),local_date),
                )
            else:
                cursor.execute(
                    """INSERT INTO v8_daily_account_snapshots(account_id,local_date,opening_balance,opening_equity,
                       lowest_equity,highest_equity,realized_pnl,floating_pnl,updated_at,source_event_id,payload)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    (str(account_id),local_date,float(balance),float(equity),float(equity),float(equity),0.0,
                     float(floating_pnl),utc_iso(),event_id,json_dump(event)),
                )
        return event

    def daily_snapshot(self, account_id: str | int, local_date: str) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                "SELECT * FROM v8_daily_account_snapshots WHERE account_id=? AND local_date=?",
                (str(account_id), str(local_date)),
            ).fetchone()
        if not row:
            return None
        data = json_load(row.get("payload"), {}) or {}
        data.update({key: row[key] for key in row if key != "payload"})
        return data

    @staticmethod
    def _decode(row: dict[str, Any]) -> dict[str, Any]:
        data = json_load(row.get("payload"), {}) or {}
        data.update({
            "id": str(row["id"]), "user_id": str(row["user_id"]), "name": row["name"],
            "type": row["account_type"], "phase": row["phase"], "currency": row["currency"],
            "balance": float(row["balance"]), "equity": float(row["equity"]),
            "starting_balance": float(row["starting_balance"]), "high_water_mark": float(row["high_water_mark"]),
            "floating_pnl": float(row["floating_pnl"]), "timezone": row["timezone"],
            "is_default": bool(row["is_default"]), "archived": bool(row["archived"]),
            "rule_template_id": row.get("rule_template_id"), "data_source": row["data_source"],
            "data_confidence": float(row["data_confidence"]), "data_observed_at": row.get("data_observed_at"),
            "created_at": str(row["created_at"]), "updated_at": str(row["updated_at"]),
        })
        return data

    @staticmethod
    def _validate_timezone(value: str) -> str:
        try:
            ZoneInfo(value)
        except Exception as exc:
            raise ValueError("INVALID_TIMEZONE") from exc
        return value

    @staticmethod
    def _local_date(observed_at: str, timezone: str) -> str:
        value = datetime.fromisoformat(str(observed_at).replace("Z", "+00:00"))
        if value.tzinfo is None:
            value = value.replace(tzinfo=UTC)
        return value.astimezone(ZoneInfo(timezone)).date().isoformat()
