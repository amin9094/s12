"""Shared private-inbox scope without depending on queue or inbox readers."""

def global_inbox_scope(engine,alias=''):
    from modules.automated_market_scope import global_symbol_sql
    if alias not in {'','i.'}:raise ValueError('INVALID_INBOX_ALIAS')
    payload=alias+'payload'
    expression=f"CAST({payload} AS JSONB)->'plan'->>'symbol'" if engine.dialect.name=='postgres' else f"json_extract({payload},'$.plan.symbol')"
    clause,params=global_symbol_sql(expression)
    return f"{alias}market IN ('gold','forex','crypto','indices') AND {clause}",params

