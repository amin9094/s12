from __future__ import annotations

import hashlib
import time
from dataclasses import asdict

from core.storage.engine import normalized_engine
from modules.setup_lifecycle import LifecycleState, SetupPlan, observe_quote
from repositories.v2.common import content_hash, json_dump, json_load


class SetupRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def propose(
        self,
        plan: SetupPlan,
        *,
        proposed_ms: int,
        freshness_proof: dict,
        profile_id="unrecorded",
        sample_kind="unclassified",
    ):
        from modules.strategy_feedback import classify_plan

        plan.validate_current_policy()
        classification = classify_plan(plan, profile_id=profile_id, sample_kind=sample_kind)
        if not freshness_proof.get("untouched") or not freshness_proof.get("complete_coverage"):
            raise ValueError("FULL_ZONE_FRESHNESS_UNPROVEN")
        if int(freshness_proof.get("observed_through_ms", 0)) < proposed_ms or proposed_ms < plan.evidence_cutoff_ms:
            raise ValueError("PRETOUCH_PROPOSAL_TIMING_UNPROVEN")
        payload = {
            "plan": plan.as_dict(),
            "plan_hash": plan.plan_hash,
            "state": asdict(LifecycleState()),
            "freshness_proof": freshness_proof,
            "proposed_ms": proposed_ms,
            "admin_delivered_ms": None,
            "persisted_ms": int(time.time()*1000),
            "classification": classification,
        }
        with self.engine.transaction() as cursor:
            existing = cursor.execute(
                "SELECT id,payload FROM s9_setups WHERE engine=? AND symbol=? AND timeframe=? AND thesis_key=?",
                (plan.engine, plan.symbol, plan.timeframe, plan.thesis_key),
            ).fetchone()
            if existing:
                return {"id": existing["id"], "duplicate": True}
            from modules.strategies.identity import identity_detail,matches_legacy_identity
            detail=identity_detail(plan)
            if detail:
                # Old hashes contained window positions. Recover those from
                # the old immutable source IDs, within the current wave only.
                legacy_rows=cursor.execute(
                    'SELECT id,payload FROM s9_setups WHERE engine=? AND symbol=? AND timeframe=? AND proposed_ms>=?',
                    (plan.engine,plan.symbol,plan.timeframe,int(detail['first_causal_ms'])),
                ).fetchall()
                for legacy in legacy_rows:
                    old=SetupPlan.from_dict(json_load(legacy['payload'])['plan'])
                    if matches_legacy_identity(plan,old):
                        return {'id':legacy['id'],'duplicate':True}
            cursor.execute(
                """INSERT INTO s9_setups(id,thesis_key,engine,symbol,timeframe,plan_version,state_version,phase,proposed_ms,payload)
              VALUES(?,?,?,?,?,?,1,?,?,?)""",
                (
                    plan.setup_id,
                    plan.thesis_key,
                    plan.engine,
                    plan.symbol,
                    plan.timeframe,
                    plan.plan_version,
                    "PROPOSED_PRETOUCH",
                    proposed_ms,
                    json_dump(payload),
                ),
            )
        return {"id": plan.setup_id, "duplicate": False}

    def get(self, setup_id, cursor=None):
        if cursor is None:
            with self.engine.transaction(read_only=True) as active:
                return self.get(setup_id, active)
        row = cursor.execute("SELECT * FROM s9_setups WHERE id=?", (setup_id,)).fetchone()
        if row:
            row["payload"] = json_load(row["payload"])
        return row

    def list(self, *, symbol=None, timeframe=None, limit=50):
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                "SELECT * FROM s9_setups WHERE (?='' OR symbol=?) AND (?='' OR timeframe=?) ORDER BY proposed_ms DESC LIMIT ?",
                (symbol or "", symbol or "", timeframe or "", timeframe or "", max(1, min(int(limit), 100))),
            ).fetchall()
        return [{**row, "payload": json_load(row["payload"])} for row in rows]

    def feedback(self, *, symbol=None, timeframe=None, engine=None, limit=500):
        from modules.setup_lifecycle import ENGINES
        from modules.strategy_feedback import feedback_snapshot

        if engine and engine not in ENGINES:
            raise ValueError("FEEDBACK_ENGINE_INVALID")
        limit = max(1, min(int(limit), 2000))
        arguments = (symbol or "", symbol or "", timeframe or "", timeframe or "", engine or "", engine or "")
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                """SELECT * FROM s9_setups WHERE (?='' OR symbol=?) AND (?='' OR timeframe=?)
                AND (?='' OR engine=?) ORDER BY proposed_ms DESC,id DESC LIMIT ?""",
                (*arguments, limit + 1),
            ).fetchall()
            truncated = len(rows) > limit
            rows = rows[:limit]
            # Read evidence for exactly the sampled IDs. A later concurrent
            # insertion must not change the sample between the two queries.
            if rows:
                placeholders = ",".join("?" for _ in rows)
                # Interpolate generated placeholders only; all IDs are bound values.
                evidence_query = f"SELECT * FROM s9_setup_events WHERE setup_id IN ({placeholders}) AND event_type IN ('VERIFIED_ENTRY','MANUAL_ADMIN_ENTRY','TP1','TP2','TP3','TP4','TP5','TP6','TP7','TP8','TP9','TP10','SL','ADMIN_EXIT') ORDER BY event_ms,id"  # nosec B608
                events = cursor.execute(
                    evidence_query,
                    tuple(row["id"] for row in rows),
                ).fetchall()
            else:
                events = []
        by_setup = {}
        for event in events:
            by_setup.setdefault(event["setup_id"], []).append({**event, "payload": json_load(event["payload"])})
        material = [
            {**row, "payload": json_load(row["payload"]), "events": by_setup.get(row["id"], [])} for row in rows
        ]
        return {
            **feedback_snapshot(material),
            "coverage": {
                "sampled_setups": len(rows),
                "limit": limit,
                "truncated": truncated,
                "selection": "MOST_RECENT_PROPOSALS",
                "all_time": False,
            },
        }

    def record_admin_delivery(self, setup_id, *, delivered_ms, untouched_through_ms, proof=None):
        with self.engine.transaction() as cursor:
            row = self.get(setup_id, cursor)
            if not row:
                raise ValueError("SETUP_NOT_FOUND")
            payload = row["payload"]
            if payload["admin_delivered_ms"] is not None:
                return row
            if untouched_through_ms < delivered_ms:
                raise ValueError("ADMIN_DELIVERY_PRETOUCH_UNPROVEN")
            payload["admin_delivered_ms"] = delivered_ms
            if proof is not None:
                if not proof.get('untouched') or not proof.get('complete_coverage') or proof.get('observed_through_ms',0)<delivered_ms:
                    raise ValueError('ADMIN_DELIVERY_PROOF_INVALID')
                payload['admin_delivery_proof']=proof
            self._update(cursor, row, payload)
        return self.get(setup_id)

    @staticmethod
    def _update(cursor, row, payload):
        cursor.execute(
            "UPDATE s9_setups SET payload=?,phase=?,state_version=state_version+1 WHERE id=? AND state_version=?",
            (json_dump(payload), payload["state"]["phase"], row["id"], row["state_version"]),
        )
        if cursor.rowcount != 1:
            raise ValueError("SETUP_CONCURRENT_UPDATE")

    def observe(self, setup_id, quote, *, now_ms, meaningful_rejection=False, structural_invalidated=False, sequence_ordered=False):
        with self.engine.transaction() as cursor:
            row = self.get(setup_id, cursor)
            if not row:
                raise ValueError("SETUP_NOT_FOUND")
            payload = row["payload"]
            if payload.get('tracking_state') == 'NEEDS_REVIEW':
                raise ValueError('TRACKING_RECOVERY_REQUIRES_REVIEW')
            plan = SetupPlan.from_dict(payload["plan"])
            if plan.plan_hash != payload["plan_hash"]:
                raise ValueError("PLAN_IMMUTABILITY_VIOLATION")
            if payload["admin_delivered_ms"] is None:
                raise ValueError("ADMIN_DELIVERY_REQUIRED")
            previous = LifecycleState(**payload["state"])
            state = observe_quote(
                plan,
                previous,
                quote,
                now_ms=now_ms,
                meaningful_rejection=meaningful_rejection,
                structural_invalidated=structural_invalidated,
                sequence_ordered=sequence_ordered,
            )
            payload["state"] = asdict(state)
            self._update(cursor, row, payload)
            if state != previous:
                event_id = hashlib.sha256(f"{setup_id}:{quote.source_id}:{state.phase}".encode()).hexdigest()
                cursor.execute(
                    "INSERT INTO s9_setup_events(id,setup_id,event_type,event_ms,payload) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING",
                    (
                        event_id,
                        setup_id,
                        state.phase,
                        quote.event_ms,
                        json_dump({"quote": quote.as_dict(), "state": asdict(state)}),
                    ),
                )
        return state

    def approve(self, setup_id, *, version, actor, audience, event_id="SIGNAL", approved_ms=None):
        approved_ms = approved_ms or int(time.time() * 1000)
        with self.engine.transaction() as cursor:
            row = self.get(setup_id, cursor)
            if not row or row["plan_version"] != version:
                raise ValueError("STALE_PLAN_APPROVAL")
            payload = row["payload"]
            if not payload["admin_delivered_ms"]:
                raise ValueError("ADMIN_DELIVERY_REQUIRED")
            if event_id != "SIGNAL":
                event = cursor.execute(
                    "SELECT payload FROM s9_setup_events WHERE id=? AND setup_id=?", (event_id, setup_id)
                ).fetchone()
                if not event:
                    raise ValueError("EVENT_NOT_FOUND")
                event_hash = content_hash(json_load(event["payload"]))
            else:
                locked=SetupPlan.from_dict(payload["plan"])
                locked.validate_current_policy()
                from modules.setup_lifecycle import CURRENT_RULE_VERSION
                if locked.rule_version==CURRENT_RULE_VERSION and payload['state']['phase']!='PROPOSED_PRETOUCH':
                    raise ValueError('INITIAL_SIGNAL_MUST_PRECEDE_FIRST_TOUCH')
                if payload["state"]["phase"] in {"CANCELLED", "NEEDS_REVIEW"} or payload.get('tracking_state') == 'NEEDS_REVIEW':
                    raise ValueError("SETUP_NOT_PUBLICATION_ELIGIBLE")
                event_hash = payload["plan_hash"]
            key = hashlib.sha256(f"{setup_id}:{version}:{event_id}:{audience}".encode()).hexdigest()
            cursor.execute(
                """INSERT INTO s9_approvals(id,setup_id,plan_version,event_id,audience,actor,approved_ms,content_hash)
              VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(setup_id,plan_version,event_id,audience) DO NOTHING""",
                (key, setup_id, version, event_id, audience, str(actor), approved_ms, event_hash),
            )
        return key

    def manual_entry(self, setup_id, *, actor, reference_price, reason, confirmed_ms):
        from modules.canonical_market import price

        reference = price(reference_price)
        if not str(reason).strip():
            raise ValueError("MANUAL_ENTRY_REASON_REQUIRED")
        with self.engine.transaction() as cursor:
            row = self.get(setup_id, cursor)
            if not row:
                raise ValueError("SETUP_NOT_FOUND")
            payload = row["payload"]
            if not payload["admin_delivered_ms"] or confirmed_ms < max(
                payload["admin_delivered_ms"], row["proposed_ms"]
            ):
                raise ValueError("MANUAL_ENTRY_CANNOT_BE_BACKDATED")
            if payload["state"]["phase"] in {"VERIFIED_ENTRY", "MANUAL_ADMIN_ENTRY", "CANCELLED"}:
                raise ValueError("MANUAL_ENTRY_TRANSITION_FORBIDDEN")
            payload["state"] = {
                **payload["state"],
                "phase": "MANUAL_ADMIN_ENTRY",
                "entry_ms": confirmed_ms,
                "fresh_for_new_proposal": False,
                "reason": "ADMIN_MANUAL_ENTRY",
            }
            payload["manual_entry"] = {
                "actor": str(actor),
                "reference_price": str(reference),
                "reason": str(reason).strip(),
                "confirmed_ms": confirmed_ms,
                "is_broker_execution": False,
            }
            self._update(cursor, row, payload)
            event_id = content_hash(
                {"setup": setup_id, "type": "MANUAL_ADMIN_ENTRY", "time": confirmed_ms, "actor": str(actor)}
            )
            cursor.execute(
                "INSERT INTO s9_setup_events(id,setup_id,event_type,event_ms,payload) VALUES(?,?,?,?,?)",
                (event_id, setup_id, "MANUAL_ADMIN_ENTRY", confirmed_ms, json_dump(payload["manual_entry"])),
            )
        return event_id

    def record_admin_exit(self, setup_id, *, version, actor, percentage_original, reference_price, reason,
                          request_id, confirmed_ms, cost_in_initial_r=None):
        from decimal import Decimal, InvalidOperation
        from modules.canonical_market import price

        try:
            percentage = Decimal(str(percentage_original))
            cost = Decimal(str(cost_in_initial_r)) if cost_in_initial_r is not None else None
        except InvalidOperation:
            raise ValueError("ADMIN_EXIT_VALUES_INVALID") from None
        if not percentage.is_finite() or not 0 < percentage <= 100 or cost is not None and (not cost.is_finite() or cost < 0):
            raise ValueError("ADMIN_EXIT_VALUES_INVALID")
        reference = price(reference_price)
        if not str(reason).strip() or len(str(reason)) > 1000 or not 8 <= len(str(request_id)) <= 80:
            raise ValueError("ADMIN_EXIT_REASON_OR_REQUEST_REQUIRED")
        content = {"actor": str(actor), "percentage_original": str(percentage), "reference_price": str(reference),
                   "reason": str(reason).strip(), "cost_in_initial_r": str(cost) if cost is not None else None,
                   "request_id": str(request_id), "is_broker_execution": False}
        event_id = content_hash({"setup": setup_id, "request_id": str(request_id), "type": "ADMIN_EXIT"})
        with self.engine.transaction() as cursor:
            row = self.get(setup_id, cursor)
            if not row or row["plan_version"] != version:
                raise ValueError("STALE_PLAN_MANAGEMENT")
            payload = row["payload"]
            existing = cursor.execute("SELECT payload FROM s9_setup_events WHERE id=?", (event_id,)).fetchone()
            if existing:
                old = json_load(existing["payload"])
                if {key: old[key] for key in content} != content:
                    raise ValueError("ADMIN_EXIT_IDEMPOTENCY_CONFLICT")
                return event_id
            if payload["state"]["phase"] not in {"VERIFIED_ENTRY", "MANUAL_ADMIN_ENTRY"}:
                raise ValueError("ADMIN_EXIT_REQUIRES_ENTRY")
            exits = payload.setdefault("admin_exits", [])
            if confirmed_ms < max([payload["state"]["entry_ms"], *[item["confirmed_ms"] for item in exits]]):
                raise ValueError("ADMIN_EXIT_CANNOT_BE_BACKDATED")
            if sum(Decimal(item["percentage_original"]) for item in exits) + percentage > 100:
                raise ValueError("ADMIN_EXIT_EXCEEDS_INITIAL_VOLUME")
            event = {**content, "confirmed_ms": int(confirmed_ms)}
            exits.append({**event, "event_id": event_id})
            self._update(cursor, row, payload)
            cursor.execute("INSERT INTO s9_setup_events(id,setup_id,event_type,event_ms,payload) VALUES(?,?,?,?,?)",
                           (event_id, setup_id, "ADMIN_EXIT", int(confirmed_ms), json_dump(event)))
        return event_id

    def detect_outcomes(self, setup_id, quote, *, now_ms, sequence_ordered=False):
        with self.engine.transaction() as cursor:
            row = self.get(setup_id, cursor)
            if not row:
                raise ValueError("SETUP_NOT_FOUND")
            payload = row["payload"]
            if payload.get('tracking_state') == 'NEEDS_REVIEW':
                raise ValueError('TRACKING_RECOVERY_REQUIRES_REVIEW')
            plan = SetupPlan.from_dict(payload["plan"])
            state = payload["state"]
            if state["phase"] not in {"VERIFIED_ENTRY", "MANUAL_ADMIN_ENTRY"} or not state["entry_ms"]:
                raise ValueError("ENTRY_REQUIRED_BEFORE_TP_SL")
            if payload.get("outcome_closed"):
                return []
            if (quote.symbol, quote.provider, quote.venue, quote.product, quote.tick_size) != (
                plan.symbol,
                plan.provider,
                plan.venue,
                plan.product,
                plan.tick_size,
            ):
                raise ValueError("QUOTE_MARKET_MISMATCH")
            boundary=max(state["entry_ms"],state["last_quote_ms"])
            if not quote.fresh(now_ms) or quote.event_ms < boundary or (quote.event_ms == boundary and
                (not sequence_ordered or quote.source_id == state.get('last_quote_id'))):
                raise ValueError("OUTCOME_QUOTE_STALE_OR_UNORDERED")
            executable = quote.bid if plan.direction == "BUY" else quote.ask
            sign = 1 if plan.direction == "BUY" else -1
            outcomes = payload.setdefault("detected_outcomes", {})
            found = []
            levels = (
                [("SL", plan.stop)]
                if sign * (executable - plan.stop) <= 0
                else [
                    (label, target)
                    for label, target in [(f"TP{i}",getattr(plan,f"tp{i}")) for i in range(1,11)]
                    if target is not None and sign * (executable - target) >= 0
                ]
            )
            for kind, level in levels:
                if kind in outcomes:
                    continue
                event_id = content_hash({"setup": setup_id, "version": plan.plan_version, "kind": kind})
                event = {
                    "level": str(level),
                    "quote": quote.as_dict(),
                    "entry_kind": state["phase"],
                    "observed_ms": quote.event_ms,
                }
                cursor.execute(
                    "INSERT INTO s9_setup_events(id,setup_id,event_type,event_ms,payload) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING",
                    (event_id, setup_id, kind, quote.event_ms, json_dump(event)),
                )
                outcomes[kind] = event_id
                found.append(event_id)
                if kind == "SL" or kind == next(f"TP{i}" for i in range(10,0,-1) if getattr(plan,f"tp{i}") is not None):
                    payload["outcome_closed"] = True
            payload["state"] = {**state, "last_quote_ms": quote.event_ms, 'last_quote_id':quote.source_id}
            self._update(cursor, row, payload)
        return found

    def active_tracking(self, *, symbol=None, provider=None, limit=300):
        with self.engine.transaction(read_only=True) as cursor:
            rows=cursor.execute("SELECT * FROM s9_setups WHERE phase IN ('PROPOSED_PRETOUCH','FIRST_TOUCH_IN_PROGRESS','VERIFIED_ENTRY','MANUAL_ADMIN_ENTRY') AND (?='' OR symbol=?) ORDER BY proposed_ms LIMIT ?",
                                (symbol or '',symbol or '',max(1,min(500,int(limit))))).fetchall()
        result=[]
        for row in rows:
            payload=json_load(row['payload'])
            if payload.get('outcome_closed') or payload.get('tracking_state')=='NEEDS_REVIEW':
                continue
            if provider and payload['plan']['provider']!=provider:
                continue
            result.append({**row,'payload':payload})
        return result

    def admin_events(self, setup_id):
        with self.engine.transaction(read_only=True) as cursor:
            rows=cursor.execute('SELECT id,event_type,event_ms FROM s9_setup_events WHERE setup_id=? ORDER BY event_ms,id',(setup_id,)).fetchall()
            approvals=cursor.execute('SELECT event_id,audience FROM s9_approvals WHERE setup_id=?',(setup_id,)).fetchall()
        return [{**row,'approved_audiences':[a['audience'] for a in approvals if a['event_id']==row['id']]} for row in rows]

    def cancel_pending(self, setup_id, *, version, actor, reason, request_id, confirmed_ms):
        if not isinstance(reason,str) or not reason.strip() or len(reason)>1000 or not isinstance(request_id,str) or not 8<=len(request_id)<=128:
            raise ValueError('CANCEL_REASON_AND_REQUEST_ID_REQUIRED')
        detail={'actor':str(actor),'reason':reason.strip(),'request_id':request_id,'plan_version':version}
        event_id=content_hash({'setup':setup_id,'cancel_request':request_id})
        with self.engine.transaction() as cursor:
            row=self.get(setup_id,cursor)
            if not row or row['plan_version']!=version:
                raise ValueError('STALE_PLAN_CANCELLATION')
            old=cursor.execute('SELECT payload FROM s9_setup_events WHERE id=?',(event_id,)).fetchone()
            if old:
                if json_load(old['payload'])!=detail:
                    raise ValueError('CANCEL_REQUEST_ID_REUSED')
                return event_id
            payload=row['payload']
            if payload['state'].get('entry_ms') or payload['state']['phase']=='CANCELLED' or confirmed_ms<row['proposed_ms']:
                raise ValueError('PENDING_CANCELLATION_TRANSITION_FORBIDDEN')
            payload['state']={**payload['state'],'phase':'CANCELLED','reason':'ADMIN_PENDING_CANCELLATION'}
            self._update(cursor,row,payload)
            cursor.execute('INSERT INTO s9_setup_events(id,setup_id,event_type,event_ms,payload) VALUES(?,?,?,?,?)',
                           (event_id,setup_id,'CANCELLED',confirmed_ms,json_dump(detail)))
        return event_id

    def require_tracking_review(self, setup_id, *, reason, now_ms):
        with self.engine.transaction() as cursor:
            row=self.get(setup_id,cursor)
            if not row:
                return
            payload=row['payload']
            if payload.get('tracking_state')=='NEEDS_REVIEW' or payload.get('outcome_closed'):
                return
            payload['tracking_state']='NEEDS_REVIEW'
            payload['tracking_reason']=reason
            if payload['state']['phase'] not in {'VERIFIED_ENTRY','MANUAL_ADMIN_ENTRY','CANCELLED'}:
                payload['state']={**payload['state'],'phase':'NEEDS_REVIEW','reason':reason}
            self._update(cursor,row,payload)
            event_id=content_hash({'setup':setup_id,'gap_reason':reason,'time':now_ms})
            cursor.execute('INSERT INTO s9_setup_events(id,setup_id,event_type,event_ms,payload) VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING',
                           (event_id,setup_id,'NEEDS_REVIEW',now_ms,json_dump({'reason':reason})))

    def public_overlay(self, setup_id, *, audience="miniapp"):
        with self.engine.transaction(read_only=True) as cursor:
            row = self.get(setup_id, cursor)
            if not row:
                return None
            payload = row["payload"]
            approval = cursor.execute(
                "SELECT content_hash FROM s9_approvals WHERE setup_id=? AND plan_version=? AND event_id=? AND audience=?",
                (setup_id, row["plan_version"], "SIGNAL", audience),
            ).fetchone()
            if not approval or approval["content_hash"] != payload["plan_hash"]:
                return None
            # Only plan, not unapproved subsequent observations/state/rejection reasons.
            return {
                "id": setup_id,
                "plan": payload["plan"],
                "proposed_ms": row["proposed_ms"],
                "public_events": self._public_events(cursor, setup_id, audience),
            }

    @staticmethod
    def _public_events(cursor, setup_id, audience):
        rows = cursor.execute(
            """SELECT e.id,e.event_type,e.event_ms,e.payload,a.content_hash FROM s9_setup_events e
           JOIN s9_approvals a ON a.event_id=e.id AND a.setup_id=e.setup_id
           WHERE e.setup_id=? AND a.audience=? ORDER BY e.event_ms""",
            (setup_id, audience),
        ).fetchall()
        return [
            {"id": row["id"], "type": row["event_type"], "event_ms": row["event_ms"]}
            for row in rows
            if content_hash(json_load(row["payload"])) == row["content_hash"]
        ]
