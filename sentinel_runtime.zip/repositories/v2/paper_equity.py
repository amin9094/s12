"""Contemporaneous sampled account marks, never a reconstructed price path."""
import time
from decimal import Decimal as D
from repositories.v2.common import json_load,json_dump


def record(engine,now_ms=None):
    now_ms=int(time.time()*1000) if now_ms is None else now_ms
    with engine.transaction(repeatable_read=True) as c:
        runs=c.execute('SELECT id,revision,payload FROM s9_strategy_paper_runs WHERE active=1').fetchall()
        for run in runs:
            rows=c.execute("SELECT id,state,payload FROM s9_strategy_paper_trades WHERE run_id=? AND state IN ('OPEN','NEEDS_REVIEW','RESET_ARCHIVED')",(run['id'],)).fetchall()
            unrealized=D(0);unknown=[];quote_times=[]
            for r in rows:
                p=json_load(r['payload'])
                if p.get('entered_ms') is None:continue
                q=p.get('last_quote') or {}
                fresh=all(type(q.get(k)) is int and 0<=now_ms-q[k]<=5000 for k in ('event_ms','received_ms'))
                if r['state']!='OPEN' or not fresh:unknown.append(r['id']);continue
                unrealized+=D(p.get('unrealized_usd','0'));quote_times.append(q['event_ms'])
            balance=D(json_load(run['payload'])['balance']);complete=not unknown
            # Unknown account samples break the line. They cannot establish a
            # new peak or an invented drawdown across an unobserved interval.
            p={'balance_usd':str(balance),'unrealized_usd':str(unrealized) if complete else None,
               'equity_usd':str(balance+unrealized) if complete else None,'unknown_positions':unknown,
               'account_revision':run['revision'],'oldest_quote_ms':min(quote_times) if quote_times else None,
               'valuation_policy':'RECORDED_QUOTES_MAX_5_SECONDS_AGE','sampled_not_continuous_path':True}
            c.execute('INSERT INTO s9_paper_equity VALUES(?,?,?,?) ON CONFLICT DO NOTHING',(run['id'],now_ms,int(complete),json_dump(p)))


def page(repo,account,run_id,*,before_ms=None):
    with repo.engine.transaction(read_only=True,repeatable_read=True) as c:
        run=c.execute('SELECT id FROM s9_strategy_paper_runs WHERE id=? AND engine=?',(run_id,account)).fetchone()
        if not run:raise ValueError('PAPER_RUN_NOT_FOUND')
        rows=c.execute('SELECT at_ms,complete,payload FROM s9_paper_equity WHERE run_id=? AND at_ms<? ORDER BY at_ms DESC LIMIT 200',(run_id,before_ms if before_ms is not None else 2**63-1)).fetchall()
    return {'run_id':run_id,'items':[{**r,'payload':json_load(r['payload'])} for r in reversed(rows)],
            'next_before_ms':rows[-1]['at_ms'] if len(rows)==200 else None,
            'scope':'OBSERVED_CYCLE_SAMPLES_WITH_GAPS_NOT_FULL_INTRATRADE_MAXIMUM'}
