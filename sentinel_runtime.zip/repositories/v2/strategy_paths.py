"""Immutable strategy variants, explicit selections and preserved $5000 runs."""
from dataclasses import asdict
from decimal import Decimal
import time
from uuid import uuid4
from core.storage.engine import normalized_engine
from modules.signal_execution import account_key
from repositories.v2.common import json_dump,json_load,content_hash
from repositories.v2.live_signal_inbox import STRATEGIES
from repositories.v2.strategy_paper import StrategyPaperRepository


def parameters_registry():
    from modules.strategy_engines import Parameters
    from modules.strategy_experiments import research_profiles
    base=Parameters()
    return {p.profile_id:p for p in (base,*research_profiles(base))}


def parameter_snapshot(profile):
    return {k:str(v) if isinstance(v,Decimal) else v for k,v in asdict(profile).items()}


def effective_configuration(strategy,config):
    relevant={'indicators':{'adx_trend','swing_left','swing_right','stop_buffer_atr'},
              'sweep_fvg':{'displacement_atr','min_fvg_atr','swing_left','swing_right','stop_buffer_atr'},
              'order_block':{'displacement_atr','volume_ratio','swing_left','swing_right','stop_buffer_atr'},
              'fibonacci_pullback':{'adx_trend','swing_left','swing_right','stop_buffer_atr'}}
    return {k:v for k,v in config.items() if k!='profile_id' and (strategy=='custom' or k in relevant[strategy])}


def strategy_enabled(strategy,engine=None):
    if strategy not in STRATEGIES:raise ValueError('PAPER_STRATEGY_INVALID')
    with (engine or normalized_engine()).transaction(read_only=True) as c:
        row=c.execute('SELECT enabled FROM s9_strategy_switches WHERE engine=?',(strategy,)).fetchone()
    return row is None or bool(row['enabled'])


class StrategyPaths:
    def __init__(self,engine=None):self.engine=engine or normalized_engine()

    def _guard(self,c,strategy):
        if strategy not in STRATEGIES:raise ValueError('PAPER_STRATEGY_INVALID')
        c.execute("INSERT INTO s9_strategy_switches(engine,enabled,revision,payload) VALUES(?,1,1,'{}') ON CONFLICT(engine) DO NOTHING",(strategy,))
        sql='SELECT * FROM s9_strategy_switches WHERE engine=?'
        if self.engine.dialect.name=='postgres':sql+=' FOR UPDATE'
        return c.execute(sql,(strategy,)).fetchone()

    def active(self,strategy):
        with self.engine.transaction(read_only=True) as c:
            row=c.execute('SELECT * FROM s9_strategy_paths WHERE engine=? AND active=1',(strategy,)).fetchone()
        return self.decode(row) if row else None

    def ensure(self,strategy,*,custom_config=None):
        current=self.active(strategy)
        if current:return current
        repo=StrategyPaperRepository(self.engine)
        runs={mode:repo.active(account_key(strategy,mode)) for mode in ('PENDING','MARKET')}
        if strategy=='custom':
            from modules.custom_strategy import parse_settings
            config=parse_settings(custom_config or {}).dto();profile=parse_settings(config).profile_id
        else:
            registered=parameters_registry()
            profile=runs['PENDING']['payload'].get('profile_id')
            profile=profile if profile in registered else next(iter(registered))
            config=parameter_snapshot(registered[profile])
        with self.engine.atomic() as c:
            self._guard(c,strategy)
            existing=self.active(strategy)
            if existing:return existing
            candidates=c.execute('SELECT * FROM s9_strategy_paths WHERE engine=?',(strategy,)).fetchall()
            for candidate in candidates:
                if json_load(candidate['payload'])['profile_id']==profile:
                    c.execute('UPDATE s9_strategy_paths SET active=1,revision=revision+1 WHERE id=?',(candidate['id'],))
                    return self.active(strategy)
            identifier=uuid4().hex
            payload={'name':'مسیر A — تنظیم فعلی','profile_id':profile,'configuration':config,
                     'created_by':'bootstrap','activations':[{'at_ms':int(time.time()*1000),'actor':'bootstrap',
                     'runs':{mode:r['id'] for mode,r in runs.items()}}]}
            c.execute('INSERT INTO s9_strategy_paths(id,engine,active,revision,created_ms,payload) VALUES(?,?,1,1,?,?)',
                      (identifier,strategy,int(time.time()*1000),json_dump(payload)))
        return self.active(strategy)

    def create(self,strategy,*,name,profile_id=None,custom_config=None,actor):
        if strategy not in STRATEGIES:raise ValueError('PAPER_STRATEGY_INVALID')
        if not isinstance(name,str) or not 1<=len(name.strip())<=60 or any(ord(c)<32 for c in name):raise ValueError('STRATEGY_PATH_NAME_INVALID')
        if strategy=='custom':
            from modules.custom_strategy import parse_settings
            config=parse_settings(custom_config).dto();profile=parse_settings(config).profile_id
        else:
            registered=parameters_registry()
            if not isinstance(profile_id,str) or profile_id not in registered:raise ValueError('STORED_RESEARCH_PROFILE_INVALID')
            profile=profile_id;config=parameter_snapshot(registered[profile])
        with self.engine.atomic() as c:
            self._guard(c,strategy)
            count=c.execute('SELECT COUNT(*) AS n FROM s9_strategy_paths WHERE engine=?',(strategy,)).fetchone()['n']
            if count>=50:raise ValueError('STRATEGY_PATH_LIMIT')
            rows=c.execute('SELECT payload FROM s9_strategy_paths WHERE engine=?',(strategy,)).fetchall()
            clean=effective_configuration(strategy,config)
            if any(effective_configuration(strategy,json_load(r['payload'])['configuration'])==clean for r in rows):raise ValueError('STRATEGY_PATH_ALREADY_EXISTS')
            identifier=uuid4().hex;now=int(time.time()*1000)
            payload={'name':name.strip(),'profile_id':profile,'configuration':config,'created_by':str(actor),'activations':[]}
            c.execute('INSERT INTO s9_strategy_paths VALUES(?,?,0,1,?,?)',(identifier,strategy,now,json_dump(payload)))
        return {'id':identifier,'profile_id':profile,'activated':False}

    def select(self,strategy,identifier,*,expected_active_id,expected_revision,actor):
        repo=StrategyPaperRepository(self.engine)
        with self.engine.atomic() as c:
            self._guard(c,strategy)
            active=self.active(strategy)
            target=c.execute('SELECT * FROM s9_strategy_paths WHERE id=? AND engine=?',(identifier,strategy)).fetchone()
            if not target:raise ValueError('STRATEGY_PATH_NOT_FOUND')
            if active and active['id']==identifier:return {'id':identifier,'changed':False,'history_preserved':True}
            if not active or active['id']!=expected_active_id or active['revision']!=expected_revision:
                raise ValueError('STRATEGY_PATH_CHANGED')
            payload=json_load(target['payload']);runs={}
            for mode in ('PENDING','MARKET'):
                key=account_key(strategy,mode);old=repo.active(key)
                runs[mode]=repo.reset(key,actor=actor,expected_run_id=old['id'],profile_id=payload['profile_id'])['run_id']
            c.execute('UPDATE s9_strategy_paths SET active=0,revision=revision+1 WHERE id=?',(active['id'],))
            payload['activations'].append({'at_ms':int(time.time()*1000),'actor':str(actor),'runs':runs})
            c.execute('UPDATE s9_strategy_paths SET active=1,revision=revision+1,payload=? WHERE id=?',
                      (json_dump(payload),identifier))
        return {'id':identifier,'changed':True,'runs':runs,'starting_balance':'5000','history_preserved':True,'applies_to':'FUTURE_SIGNALS_ONLY'}

    def control(self,strategy,*,enabled,revision,actor):
        if type(enabled) is not bool or type(revision) is not int:raise ValueError('STRATEGY_CONTROL_INVALID')
        with self.engine.atomic() as c:
            row=self._guard(c,strategy)
            if row['revision']!=revision:raise ValueError('STRATEGY_PATH_CHANGED')
            c.execute('UPDATE s9_strategy_switches SET enabled=?,revision=revision+1,payload=? WHERE engine=?',
                      (int(enabled),json_dump({'actor':str(actor),'changed_ms':int(time.time()*1000)}),strategy))
        return {'enabled':enabled,'revision':revision+1,'open_trades_continue_tracking':True}

    def snapshot(self,strategy,*,from_ms=0,to_ms=None):
        from repositories.v2.paper_statistics import combine,contribution
        if type(from_ms) is not int or from_ms<0 or to_ms is not None and (type(to_ms) is not int or to_ms<from_ms):
            raise ValueError('PAPER_PERIOD_INVALID')
        end=int(time.time()*1000) if to_ms is None else to_ms
        if end<from_ms or end>int(time.time()*1000):raise ValueError('PAPER_PERIOD_INVALID')
        with self.engine.transaction(read_only=True,repeatable_read=True) as c:
            rows=c.execute('SELECT * FROM s9_strategy_paths WHERE engine=? ORDER BY created_ms,id',(strategy,)).fetchall()
            switch=c.execute('SELECT * FROM s9_strategy_switches WHERE engine=?',(strategy,)).fetchone()
            items=[self.decode(r) for r in rows];profiles={p['payload']['profile_id']:p for p in items}
            for p in items:p['results']={m:combine({}, {}) for m in ('PENDING','MARKET')}
            cursor=(from_ms,'')
            while True:
                trades=c.execute('''SELECT t.* FROM s9_strategy_paper_trades t JOIN s9_strategy_paper_runs r ON r.id=t.run_id
                    WHERE r.engine IN (?,?) AND t.created_ms>=? AND t.created_ms<=?
                    AND (t.created_ms>? OR (t.created_ms=? AND t.id>?)) ORDER BY t.created_ms,t.id LIMIT 200''',
                    (strategy,account_key(strategy,'MARKET'),from_ms,end,cursor[0],cursor[0],cursor[1])).fetchall()
                for row in trades:
                    data=json_load(row['payload']);path=profiles.get(data.get('profile_id'))
                    if path:
                        mode=data.get('execution_mode','PENDING')
                        path['results'][mode]=combine(path['results'][mode],contribution(data))
                if len(trades)<200:break
                cursor=(trades[-1]['created_ms'],trades[-1]['id'])
        for path in items:
            for summary in path['results'].values():
                summary.update(sample_size=summary['closed'],win_rate=summary['wins']/summary['closed']*100 if summary['closed'] else None,
                    average_r=str(Decimal(summary['r_sum'])/summary['closed']) if summary['closed'] else None,
                    costs_complete=summary['costs_unknown']==0,
                    net_realized_usd=summary['realized_usd'] if summary['costs_unknown']==0 and not summary['unresolved_positions'] and summary['closed'] else None)
        return {'engine':strategy,'items':items,'from_ms':from_ms,'to_ms':end,'enabled':bool(switch['enabled']) if switch else True,
                'control_revision':switch['revision'] if switch else 1,'automatic_selection':False,
                'comparison_basis':'RECORDED_PROFILES_IN_SHARED_CALENDAR_WINDOW_NOT_IDENTICAL_MARKET_COHORTS',
                'unclassified_records_excluded':True,'is_broker_performance':False}

    @staticmethod
    def decode(row):return {**row,'payload':json_load(row['payload'])}
