"""Durable preparation time and immutable, separately authorized delivery intents."""

import time
from hashlib import sha256

from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load


class StrategyLiveRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def prepare(self, plan, *, epoch, profile_id, historical_proof):
        with self.engine.transaction() as cursor:
            old = cursor.execute('SELECT * FROM s9_preparations WHERE id=?',(plan.setup_id,)).fetchone()
            if old:
                return {**old,'payload':json_load(old['payload']),'duplicate':True}
            # Capture actual preparation time INSIDE the write operation, after
            # the full immutable plan exists. Never substitute analysis cutoff.
            now = int(time.time()*1000)
            payload = {'plan':plan.as_dict(),'plan_hash':plan.plan_hash,'epoch':epoch,'profile_id':profile_id,
                       'historical_proof':historical_proof}
            cursor.execute('INSERT INTO s9_preparations(id,state,prepared_ms,payload) VALUES(?,?,?,?)',
                           (plan.setup_id,'PENDING',now,json_dump(payload)))
        return {'id':plan.setup_id,'state':'PENDING','prepared_ms':now,'payload':payload,'duplicate':False}

    def finish_preparation(self, key, state, detail):
        if state not in {'PROMOTED','NEEDS_REVIEW'}:
            raise ValueError('PREPARATION_STATE_INVALID')
        with self.engine.transaction() as cursor:
            row=cursor.execute('SELECT payload FROM s9_preparations WHERE id=? AND state=?',(key,'PENDING')).fetchone()
            if row:
                payload=json_load(row['payload'])
                payload['finalized_ms']=int(time.time()*1000)
                payload['finalization']=detail
                cursor.execute('UPDATE s9_preparations SET state=?,payload=? WHERE id=? AND state=?',
                               (state,json_dump(payload),key,'PENDING'))

    def interrupt_pending(self, *, before_ms, reason):
        result=[]
        with self.engine.transaction() as cursor:
            rows=cursor.execute("SELECT * FROM s9_preparations WHERE state='PENDING' AND prepared_ms<? ORDER BY prepared_ms LIMIT 500",(before_ms,)).fetchall()
            for row in rows:
                payload=json_load(row['payload'])
                payload['finalization']={'reason':reason}
                payload['finalized_ms']=int(time.time()*1000)
                cursor.execute("UPDATE s9_preparations SET state='NEEDS_REVIEW',payload=? WHERE id=? AND state='PENDING'",(json_dump(payload),row['id']))
                if cursor.rowcount:
                    result.append({**row,'payload':payload})
        return result

    def enqueue(self, *, setup_id, version, event_id, audience, target_id, content_hash, actor=None):
        key=sha256(json_dump([setup_id,version,event_id,audience,str(target_id)]).encode()).hexdigest()[:32]
        with self.engine.transaction() as cursor:
            cursor.execute('''INSERT INTO s9_deliveries(id,setup_id,plan_version,event_id,audience,target_id,content_hash,state,ready_ms,payload)
                              VALUES(?,?,?,?,?,?,?,'PENDING',?,?) ON CONFLICT(setup_id,plan_version,event_id,audience,target_id) DO NOTHING''',
                           (key,setup_id,version,event_id,audience,str(target_id),content_hash,int(time.time()*1000),json_dump({'actor':actor})))
        return key

    def claim(self, *, limit=1):
        from uuid import uuid4
        now = int(time.time()*1000)
        result=[]
        with self.engine.transaction() as cursor:
            old=cursor.execute("SELECT * FROM s9_deliveries WHERE state='SENDING' LIMIT 200").fetchall()
            for row in old:
                payload=json_load(row['payload'])
                claimed=payload.get('claimed_ms')
                if claimed is not None and now-int(claimed)<600000:
                    continue
                # Legacy/in-flight requests are ambiguous. Only a claimed job
                # with durable proof that send never started can be retried.
                state=('FAILED' if row['attempts']>=3 else 'PENDING') if claimed is not None and not payload.get('delivery_started_ms') else 'UNCERTAIN'
                payload.update(detail='WORKER_LEASE_EXPIRED',claim_token=None)
                cursor.execute("UPDATE s9_deliveries SET state=?,payload=? WHERE id=? AND state='SENDING' AND payload=?",
                               (state,json_dump(payload),row['id'],row['payload']))
            rows=cursor.execute("SELECT * FROM s9_deliveries WHERE state='PENDING' AND ready_ms<=? AND attempts<3 ORDER BY ready_ms,id LIMIT ?",
                                (now,max(1,min(5,int(limit))))).fetchall()
            for row in rows:
                payload=json_load(row['payload'])
                payload.update(claim_token=uuid4().hex,claimed_ms=now,delivery_started_ms=None)
                cursor.execute("UPDATE s9_deliveries SET state='SENDING',attempts=attempts+1,payload=? WHERE id=? AND state='PENDING'",
                               (json_dump(payload),row['id']))
                if cursor.rowcount:
                    result.append({**row,'state':'SENDING','attempts':row['attempts']+1,'payload':payload})
        return result

    def start_delivery(self,key,claim_token):
        with self.engine.transaction() as cursor:
            sql="SELECT payload FROM s9_deliveries WHERE id=? AND state='SENDING'"
            if self.engine.dialect.name=='postgres':sql+=' FOR UPDATE'
            row=cursor.execute(sql,(key,)).fetchone()
            payload=json_load(row['payload']) if row else {}
            if not claim_token or payload.get('claim_token')!=claim_token:
                raise ValueError('DELIVERY_LEASE_CHANGED')
            if int(time.time()*1000)-int(payload.get('claimed_ms',0))>=600000:
                raise ValueError('DELIVERY_LEASE_EXPIRED')
            payload['delivery_started_ms']=int(time.time()*1000)
            cursor.execute("UPDATE s9_deliveries SET payload=? WHERE id=? AND state='SENDING'",(json_dump(payload),key))

    def finish_delivery(self,key,state,*,message_id=None,retry_seconds=0,detail='',verification=None,claim_token=None):
        if state not in {'SENT','PENDING','UNCERTAIN','REVOKED','FAILED'}:
            raise ValueError('DELIVERY_STATE_INVALID')
        with self.engine.transaction() as cursor:
            sql="SELECT payload,attempts FROM s9_deliveries WHERE id=? AND state='SENDING'"
            if self.engine.dialect.name=='postgres':sql+=' FOR UPDATE'
            row=cursor.execute(sql,(key,)).fetchone()
            if not row:raise ValueError('DELIVERY_CLAIM_MISSING')
            payload=json_load(row['payload'])
            if not claim_token or payload.get('claim_token')!=claim_token:
                raise ValueError('DELIVERY_LEASE_CHANGED')
            payload.update(message_id=message_id,detail=detail,finished_ms=int(time.time()*1000))
            if verification is not None:payload['verification']=verification
            if state=='PENDING' and row['attempts']>=3:state='FAILED'
            ready=int(time.time()*1000)+int(max(0,min(3600,float(retry_seconds)))*1000)
            cursor.execute("UPDATE s9_deliveries SET state=?,ready_ms=?,payload=? WHERE id=? AND state='SENDING'",
                           (state,ready,json_dump(payload),key))
