from __future__ import annotations

import hashlib
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any

from config import SETTINGS
from core.sensitive_data import protect_secret_value, unprotect_secret_value
from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import json_dump, json_load, new_id, utc_iso


class MT5ConnectorRepository:
    """Durable pairing and credential storage for read-only MT5 connectors."""

    def __init__(self, engine: DatabaseEngine | None = None):
        self.engine = engine or normalized_engine()

    @staticmethod
    def _parse(value: str) -> datetime:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)

    @staticmethod
    def _code_hash(code: str) -> str:
        normalized = str(code or "").strip().upper().replace(" ", "")
        return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

    @staticmethod
    def _token_hash(token: str) -> str:
        return hashlib.sha256(str(token or "").encode("utf-8")).hexdigest()

    @staticmethod
    def _mask_login(value: str) -> str:
        text = str(value or "")
        if len(text) <= 4:
            return "*" * len(text)
        return f"{text[:2]}{'*' * max(2, len(text) - 4)}{text[-2:]}"

    def create_pairing(
        self,
        user_id: int | str,
        account_id: int | str,
        *,
        ttl_minutes: int = 15,
        label: str = "",
    ) -> dict[str, Any]:
        uid, aid = str(user_id), str(account_id)
        now = datetime.now(UTC)
        expires = now + timedelta(minutes=max(5, min(int(ttl_minutes), 60)))
        # 64 bits of entropy while still easy to type into MetaTrader.
        raw = secrets.token_hex(8).upper()
        code = f"SNT-{raw[:4]}-{raw[4:8]}-{raw[8:12]}-{raw[12:]}"
        row_id = new_id("pair")
        payload = {
            "id": row_id,
            "user_id": uid,
            "account_id": aid,
            "label": str(label or "")[:80],
            "expires_at": expires.isoformat(),
            "created_at": now.isoformat(),
        }
        with self.engine.transaction() as cursor:
            account = cursor.execute(
                "SELECT id FROM v8_trading_accounts WHERE id=? AND user_id=? AND archived=0",
                (aid, uid),
            ).fetchone()
            if not account:
                raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
            cursor.execute(
                "UPDATE v8_mt5_pairing_codes SET expires_at=? WHERE user_id=? AND account_id=? AND consumed_at IS NULL",
                (now.isoformat(), uid, aid),
            )
            cursor.execute(
                """INSERT INTO v8_mt5_pairing_codes(id,user_id,account_id,code_hash,expires_at,consumed_at,connector_id,created_at,payload)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (row_id, uid, aid, self._code_hash(code), expires.isoformat(), None, None, now.isoformat(), json_dump(payload)),
            )
        return {**payload, "code": code, "ttl_seconds": int((expires - now).total_seconds())}

    def consume_pairing(self, code: str, metadata: dict[str, Any]) -> dict[str, Any]:
        now = datetime.now(UTC)
        code_hash = self._code_hash(code)
        platform = str(metadata.get("platform") or "MT5").upper()[:16]
        if platform != "MT5":
            raise ValueError("CONNECTOR_PLATFORM_UNSUPPORTED")
        login = str(metadata.get("account_login") or "").strip()[:64]
        broker = str(metadata.get("broker") or metadata.get("company") or "Unknown Broker").strip()[:120]
        server_name = str(metadata.get("server_name") or metadata.get("server") or "").strip()[:120]
        account_name = str(metadata.get("account_name") or "").strip()[:120]
        terminal_build = str(metadata.get("terminal_build") or "")[:32]
        connector_version = str(metadata.get("connector_version") or "")[:32]
        if not login or not server_name:
            raise ValueError("MT5_ACCOUNT_METADATA_REQUIRED")

        token = secrets.token_urlsafe(32)
        connector_secret = secrets.token_urlsafe(48)
        encrypted_secret = protect_secret_value(connector_secret, SETTINGS.sensitive_data_key)
        if not encrypted_secret:
            raise RuntimeError("SENSITIVE_DATA_KEY_REQUIRED")
        connector_id = new_id("mt5")
        with self.engine.transaction() as cursor:
            select_sql = "SELECT * FROM v8_mt5_pairing_codes WHERE code_hash=?"
            if self.engine.dialect.name == "postgres":
                select_sql += " FOR UPDATE"
            pairing = cursor.execute(select_sql, (code_hash,)).fetchone()
            if not pairing or pairing.get("consumed_at"):
                raise ValueError("PAIRING_CODE_INVALID")
            if self._parse(str(pairing["expires_at"])) < now:
                raise ValueError("PAIRING_CODE_EXPIRED")
            uid, aid = str(pairing["user_id"]), str(pairing["account_id"])
            account = cursor.execute(
                "SELECT id FROM v8_trading_accounts WHERE id=? AND user_id=? AND archived=0",
                (aid, uid),
            ).fetchone()
            if not account:
                raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
            existing = cursor.execute(
                """SELECT id FROM v8_mt5_connectors
                   WHERE user_id=? AND account_id=? AND account_login=? AND server_name=?""",
                (uid, aid, login, server_name),
            ).fetchone()
            if existing:
                connector_id = str(existing["id"])
                cursor.execute(
                    """UPDATE v8_mt5_connectors SET platform=?,broker=?,account_name=?,token_hash=?,secret_payload=?,status='online',
                       readonly_mode=1,last_seen_at=?,revoked_at=NULL,updated_at=?,payload=? WHERE id=?""",
                    (
                        platform, broker, account_name, self._token_hash(token), encrypted_secret,
                        now.isoformat(), now.isoformat(),
                        json_dump({"terminal_build": terminal_build, "connector_version": connector_version, "paired_at": now.isoformat()}),
                        connector_id,
                    ),
                )
            else:
                cursor.execute(
                    """INSERT INTO v8_mt5_connectors(id,user_id,account_id,platform,account_login,broker,server_name,account_name,
                       token_hash,secret_payload,status,readonly_mode,last_seen_at,last_snapshot_at,last_event_at,revoked_at,
                       created_at,updated_at,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        connector_id, uid, aid, platform, login, broker, server_name, account_name,
                        self._token_hash(token), encrypted_secret, "online", 1, now.isoformat(), None, None, None,
                        now.isoformat(), now.isoformat(),
                        json_dump({"terminal_build": terminal_build, "connector_version": connector_version, "paired_at": now.isoformat()}),
                    ),
                )
            cursor.execute(
                "UPDATE v8_mt5_pairing_codes SET consumed_at=?,connector_id=? WHERE id=?",
                (now.isoformat(), connector_id, str(pairing["id"])),
            )
        return {
            "connector_id": connector_id,
            "user_id": uid,
            "account_id": aid,
            "device_token": token,
            "connector_secret": connector_secret,
            "readonly_mode": True,
            "server_time": now.isoformat(),
        }

    def authenticate(self, connector_id: str, device_token: str) -> dict[str, Any]:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute("SELECT * FROM v8_mt5_connectors WHERE id=?", (str(connector_id),)).fetchone()
        if not row or str(row.get("status") or "") == "revoked" or row.get("revoked_at"):
            raise PermissionError("CONNECTOR_REVOKED")
        if not secrets.compare_digest(str(row.get("token_hash") or ""), self._token_hash(device_token)):
            raise PermissionError("CONNECTOR_AUTH_INVALID")
        payload = json_load(row.get("payload"), {}) or {}
        payload.update({key: row.get(key) for key in row if key != "payload"})
        payload["connector_secret"] = unprotect_secret_value(str(row.get("secret_payload") or ""), SETTINGS.sensitive_data_key)
        if not payload["connector_secret"]:
            raise PermissionError("CONNECTOR_AUTH_INVALID")
        return payload

    def consume_nonce(self, connector_id: str, nonce: str, *, ttl_seconds: int = 600) -> None:
        now = datetime.now(UTC)
        expires = now + timedelta(seconds=max(60, min(int(ttl_seconds), 3600)))
        clean = str(nonce or "").strip()[:128]
        if len(clean) < 12:
            raise PermissionError("CONNECTOR_NONCE_INVALID")
        with self.engine.transaction() as cursor:
            cursor.execute("DELETE FROM v8_mt5_nonces WHERE expires_at<?", (now.isoformat(),))
            try:
                cursor.execute(
                    "INSERT INTO v8_mt5_nonces(connector_id,nonce,received_at,expires_at) VALUES(?,?,?,?)",
                    (str(connector_id), clean, now.isoformat(), expires.isoformat()),
                )
            except Exception as exc:
                raise PermissionError("CONNECTOR_REPLAY_DETECTED") from exc

    def touch(self, connector_id: str, *, snapshot: bool = False, event: bool = False, payload: dict[str, Any] | None = None) -> None:
        now = utc_iso()
        assignments = ["last_seen_at=?", "updated_at=?", "status='online'"]
        params: list[Any] = [now, now]
        if snapshot:
            assignments.append("last_snapshot_at=?")
            params.append(now)
        if event:
            assignments.append("last_event_at=?")
            params.append(now)
        if payload is not None:
            assignments.append("payload=?")
            params.append(json_dump(payload))
        params.append(str(connector_id))
        with self.engine.transaction() as cursor:
            cursor.execute(f"UPDATE v8_mt5_connectors SET {','.join(assignments)} WHERE id=?", params)  # nosec B608

    def list_for_user(self, user_id: int | str, account_id: int | str | None = None) -> list[dict[str, Any]]:
        clauses = ["user_id=?"]
        params: list[Any] = [str(user_id)]
        if account_id not in {None, ""}:
            clauses.append("account_id=?")
            params.append(str(account_id))
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute(
                f"SELECT * FROM v8_mt5_connectors WHERE {' AND '.join(clauses)} ORDER BY updated_at DESC",  # nosec B608
                params,
            ).fetchall()
        return [self._public(row) for row in rows]

    def get(self, connector_id: str) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute("SELECT * FROM v8_mt5_connectors WHERE id=?", (str(connector_id),)).fetchone()
        return self._public(row) if row else None

    def revoke(self, user_id: int | str, connector_id: str) -> dict[str, Any]:
        now = utc_iso()
        with self.engine.transaction() as cursor:
            cursor.execute(
                """UPDATE v8_mt5_connectors SET status='revoked',revoked_at=?,updated_at=?
                   WHERE id=? AND user_id=?""",
                (now, now, str(connector_id), str(user_id)),
            )
            if cursor.rowcount != 1:
                raise ValueError("MT5_CONNECTOR_NOT_FOUND")
        return self.get(connector_id) or {"id": str(connector_id), "status": "revoked"}

    def rename(self, user_id: int | str, connector_id: str, name: str) -> dict[str, Any]:
        clean = str(name or "").strip()[:120]
        if len(clean) < 2:
            raise ValueError("CONNECTOR_NAME_REQUIRED")
        now = utc_iso()
        with self.engine.transaction() as cursor:
            cursor.execute(
                "UPDATE v8_mt5_connectors SET account_name=?,updated_at=? WHERE id=? AND user_id=? AND status!='revoked'",
                (clean, now, str(connector_id), str(user_id)),
            )
            if cursor.rowcount != 1:
                raise ValueError("MT5_CONNECTOR_NOT_FOUND")
        return self.get(connector_id) or {}

    def event_exists(self, connector_id: str, external_id: str, event_type: str, checksum: str) -> bool:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                "SELECT id FROM v8_mt5_events WHERE connector_id=? AND external_id=? AND event_type=? AND checksum=?",
                (str(connector_id), str(external_id), str(event_type), str(checksum)),
            ).fetchone()
        return bool(row)

    def record_event(
        self,
        connector: dict[str, Any],
        *,
        external_id: str,
        event_type: str,
        occurred_at: str,
        checksum: str,
        payload: dict[str, Any],
    ) -> bool:
        try:
            with self.engine.transaction() as cursor:
                cursor.execute(
                    """INSERT INTO v8_mt5_events(id,connector_id,user_id,account_id,external_id,event_type,occurred_at,checksum,payload)
                       VALUES(?,?,?,?,?,?,?,?,?)""",
                    (
                        new_id("mt5evt"), str(connector["id"]), str(connector["user_id"]), str(connector["account_id"]),
                        str(external_id), str(event_type), str(occurred_at), str(checksum), json_dump(payload),
                    ),
                )
            return True
        except Exception:
            return False

    def latest_snapshot(self, account_id: int | str) -> dict[str, Any] | None:
        with self.engine.transaction(read_only=True) as cursor:
            row = cursor.execute(
                "SELECT payload FROM v8_broker_snapshots WHERE account_id=? ORDER BY observed_at DESC LIMIT 1",
                (str(account_id),),
            ).fetchone()
        return json_load((row or {}).get("payload"), None)

    def _public(self, row: dict[str, Any]) -> dict[str, Any]:
        payload = json_load(row.get("payload"), {}) or {}
        now = datetime.now(UTC)
        last_seen = str(row.get("last_seen_at") or "")
        age_seconds: int | None = None
        if last_seen:
            try:
                age_seconds = max(0, int((now - self._parse(last_seen)).total_seconds()))
            except ValueError:
                age_seconds = None
        stored_status = str(row.get("status") or "offline")
        live_status = "revoked" if stored_status == "revoked" else "online" if age_seconds is not None and age_seconds <= 90 else "stale" if age_seconds is not None and age_seconds <= 600 else "offline"
        return {
            "id": str(row["id"]),
            "user_id": str(row["user_id"]),
            "account_id": str(row["account_id"]),
            "platform": str(row.get("platform") or "MT5"),
            "account_login_masked": self._mask_login(str(row.get("account_login") or "")),
            "broker": str(row.get("broker") or ""),
            "server_name": str(row.get("server_name") or ""),
            "account_name": str(row.get("account_name") or ""),
            "status": live_status,
            "readonly_mode": bool(row.get("readonly_mode")),
            "last_seen_at": row.get("last_seen_at"),
            "last_snapshot_at": row.get("last_snapshot_at"),
            "last_event_at": row.get("last_event_at"),
            "age_seconds": age_seconds,
            "created_at": row.get("created_at"),
            "updated_at": row.get("updated_at"),
            "connector_version": payload.get("connector_version"),
            "terminal_build": payload.get("terminal_build"),
            "revoked_at": row.get("revoked_at"),
        }
