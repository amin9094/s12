from __future__ import annotations

from collections.abc import Iterable
from typing import Any


def register_handlers(application: Any, handlers: Iterable[Any], *, group: int | None = None) -> None:
    """Register a batch of Telegram handlers through one tested boundary."""
    for handler in handlers:
        if group is None:
            application.add_handler(handler)
        else:
            application.add_handler(handler, group=group)


def register_callback_routes(application: Any, callback_handler_type: Any, routes: Iterable[tuple[str, Any]]) -> int:
    """Register callback routes and return their count for diagnostics/tests."""
    count = 0
    for pattern, callback in routes:
        application.add_handler(callback_handler_type(callback, pattern=pattern))
        count += 1
    return count


def resolve_named(namespace: dict[str, Any], names: Iterable[str]) -> list[Any]:
    """Resolve declared handler names and fail fast when a route is missing."""
    resolved: list[Any] = []
    for name in names:
        value = namespace.get(str(name))
        if value is None:
            raise RuntimeError(f"handler is not defined: {name}")
        resolved.append(value)
    return resolved


def register_command_plan(application: Any, command_handler_type: Any, namespace: dict[str, Any], routes: Iterable[tuple[str, str]]) -> int:
    count = 0
    for command, callback_name in routes:
        callback = namespace.get(callback_name)
        if callback is None:
            raise RuntimeError(f"command handler is not defined: {callback_name}")
        application.add_handler(command_handler_type(command, callback))
        count += 1
    return count


def register_guard_plan(
    application: Any,
    callback_handler_type: Any,
    message_handler_type: Any,
    all_filter: Any,
    namespace: dict[str, Any],
    guards: Iterable[tuple[str, str, int]],
) -> int:
    count = 0
    for callback_name, message_name, group in guards:
        callback = namespace.get(callback_name)
        message = namespace.get(message_name)
        if callback is None or message is None:
            raise RuntimeError(f"guard handler is not defined: {callback_name}/{message_name}")
        application.add_handler(callback_handler_type(callback), group=group)
        application.add_handler(message_handler_type(all_filter, message), group=group)
        count += 2
    return count
