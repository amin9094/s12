from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_admin_workspace_is_simplified_but_keeps_full_capabilities() -> None:
    source = (ROOT / "webapp" / "src" / "shell-events.js").read_text(encoding="utf-8")
    assert "مرکز مدیریت ساده و عملیاتی" in source
    assert "همه ابزارهای ادمین" in source
    assert "data-admin-command-center" in source
    assert "data-integration-reconcile" in source
    assert "data-miniapp-toggle" in source
    assert "data-admin-order" in source
    assert "data-admin-ticket" in source
    assert "ابزارها و جزئیات پیشرفته" in source
    # The confusing always-visible permission matrix was removed from the main workspace.
    assert "تمام دسترسی‌های فعال این مدیر" not in source


def test_admin_workspace_preserves_daily_operational_paths() -> None:
    source = (ROOT / "webapp" / "src" / "shell-events.js").read_text(encoding="utf-8")
    required = {
        "adminOrders",
        "adminTickets",
        "adminTemplates",
        "adminIntegration",
        "adminSignalJobs",
        "adminCapabilities",
    }
    assert required.issubset({token.strip("'") for token in source.split() if token.strip("',") in required} | required)
    for marker in ("safe('adminOrders'", "safe('adminTickets'", "safe('adminCapabilities'", "safe('adminSignalJobs'"):
        assert marker in source
