"""Bounded process-lifetime counters with no URLs, queries, keys or user IDs."""
import threading,time
from urllib.parse import urlsplit
_LOCK=threading.Lock();_COUNTS={};_START=int(time.time()*1000)
PROVIDERS={'api.binance.com':'binance','api.bybit.com':'bybit','www.okx.com':'okx','api.kraken.com':'kraken',
           'api.twelvedata.com':'twelve_data','query1.finance.yahoo.com':'yahoo','api.coingecko.com':'coingecko'}


def record(url,success,elapsed_ms):
    provider=PROVIDERS.get(urlsplit(url).hostname,'other_market_provider')
    with _LOCK:
        row=_COUNTS.setdefault(provider,{'provider':provider,'http_attempts':0,'success':0,'failure':0,'elapsed_ms':0,'cache_hits':0,'shared_inflight_hits':0})
        row['http_attempts']+=1;row['success' if success else 'failure']+=1;row['elapsed_ms']+=max(0,int(elapsed_ms))


def cache(provider,*,inflight=False):
    if provider not in set(PROVIDERS.values()):provider='automatic_provider_selection'
    with _LOCK:
        row=_COUNTS.setdefault(provider,{'provider':provider,'http_attempts':0,'success':0,'failure':0,'elapsed_ms':0,'cache_hits':0,'shared_inflight_hits':0})
        row['shared_inflight_hits' if inflight else 'cache_hits']+=1


def snapshot():
    with _LOCK:return {'since_process_ms':_START,'items':[dict(v) for v in _COUNTS.values()],
        'scope':'CANONICAL_HISTORY_HTTP_WRAPPER_AND_SHARED_HISTORY_CACHE_NOT_WEBSOCKETS','durable':False}
