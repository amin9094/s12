"""Publish invalidations using the canonical store's own committing cursor."""
import hashlib
import json
from core.membership_bridge import _table_exists


def project_invalidations(cursor,before,after,*,postgres=False):
    changed={k:v for k,v in after.get('signal_publication_invalidations',{}).items()
             if k not in before.get('signal_publication_invalidations',{})}
    if not changed or not _table_exists(cursor,postgres,'v8_signals'):return
    def execute(sql,params):cursor.execute(sql.replace('?','%s') if postgres else sql,params)
    if postgres:cursor.execute("SELECT pg_advisory_xact_lock(hashtextextended('signal-numbering',0))")
    for key,row in changed.items():
        execute('SELECT payload FROM v8_signals WHERE id=?',(str(row['id']),))
        old=cursor.fetchone()
        payload={**(json.loads(old[0]) if old else {}),**row}
        previous=json.loads(old[0]) if old else {}
        now=str(row['updated_at']);identifier=str(row['id'])
        execute('''INSERT INTO v8_signals(id,display_number,symbol,side,status,market_category,created_at,updated_at,payload)
          VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at,payload=excluded.payload''',
          (identifier,int(row.get('display_number') or 0),str(row['symbol']),str(row['side']).upper(),'needs_review',
           str(row.get('market_category') or 'forex'),str(row.get('created_at') or now),now,json.dumps(payload,ensure_ascii=False)))
        if _table_exists(cursor,postgres,'v8_signal_revisions'):
            canonical=lambda value:json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),default=str)
            digest=lambda value:hashlib.sha256(canonical(value).encode()).hexdigest()
            execute('SELECT COUNT(*) FROM v8_signal_revisions WHERE signal_id=?',(identifier,))
            revision=int(cursor.fetchone()[0])+1
            execute("""INSERT INTO v8_signal_revisions(id,signal_id,revision_number,changed_at,changed_by,change_type,
                previous_hash,current_hash,changed_fields,payload) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (hashlib.sha256(('invalidation:'+key).encode()).hexdigest()[:32],identifier,revision,now,'publication_guard','invalidated',
                 digest(previous) if previous else None,digest(payload),canonical(['status','publication_valid','publication_reason']),
                 canonical({'before':previous,'after':payload,'reason':'DELIVERY_PREENTRY_UNPROVEN'})))
        event_id='idem:'+hashlib.sha256(('publication-invalid:'+key).encode()).hexdigest()
        execute('''INSERT INTO v8_events(event_id,user_id,event_type,entity_type,entity_id,created_at,payload)
          VALUES(?,'*','signal.updated','signal',?,?,?) ON CONFLICT(event_id) DO NOTHING''',
          (event_id,identifier,now,json.dumps({'signal_id':identifier,'status':'needs_review','publication_valid':False})))
