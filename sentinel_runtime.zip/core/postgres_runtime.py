"""Shared, bounded PostgreSQL connection policy and credential-safe diagnostics."""

from __future__ import annotations

import os
import re
from urllib.parse import urlsplit


def normalize_database_url(value: str) -> str:
    value = str(value or "").strip()
    if not value:
        return ""
    if any(marker in value for marker in ("${{", "{{", "}}")):
        raise ValueError("DATABASE_URL_UNRESOLVED_REFERENCE")
    if value[:1] in {'"', "'"} or any(ch.isspace() for ch in value):
        raise ValueError("DATABASE_URL_INVALID_WHITESPACE_OR_QUOTES")
    if value.startswith("postgres://"):
        value = "postgresql://" + value[len("postgres://") :]
    if not value.startswith("postgresql://"):
        raise ValueError("DATABASE_URL_INVALID_SCHEME")
    try:
        parsed = urlsplit(value)
        if not parsed.hostname or not parsed.path.lstrip("/") or parsed.fragment:
            raise ValueError()
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            raise ValueError()
    except ValueError:
        raise ValueError("DATABASE_URL_INVALID_ENDPOINT") from None
    return value


def env_number(name: str, default: float, low: float, high: float, *, legacy: str = "") -> float:
    raw = os.getenv(name) or (os.getenv(legacy) if legacy else None) or str(default)
    try:
        value = float(raw)
        if not low <= value <= high:
            raise ValueError()
    except ValueError:
        raise ValueError(f"{name}_INVALID_RANGE") from None
    return value


def pool_policy(*, legacy_max: str = "") -> dict:
    minimum = int(env_number("DB_POOL_MIN_SIZE", 1, 0, 30))
    maximum = int(env_number("DB_POOL_MAX_SIZE", 10, 1, 30, legacy=legacy_max))
    if maximum < minimum:
        raise ValueError("DB_POOL_MAX_SIZE_BELOW_MIN_SIZE")
    return {
        "min_size": minimum,
        "max_size": maximum,
        "timeout": env_number("DB_POOL_TIMEOUT_SECONDS", 10, 0.1, 120, legacy="POSTGRES_POOL_ACQUIRE_TIMEOUT_SECONDS"),
        "max_waiting": int(env_number("DB_POOL_MAX_WAITING", 64, 1, 10000)),
        "max_lifetime": env_number("DB_POOL_MAX_LIFETIME_SECONDS", 1800, 30, 86400),
        "max_idle": env_number("DB_POOL_MAX_IDLE_SECONDS", 300, 1, 3600),
        "reconnect_timeout": env_number("DB_POOL_RECONNECT_TIMEOUT_SECONDS", 30, 1, 120),
    }


def connection_kwargs(*, autocommit: bool, application_name: str) -> dict:
    statement = int(env_number("DB_STATEMENT_TIMEOUT_MS", 15000, 1000, 120000, legacy="POSTGRES_STATEMENT_TIMEOUT_MS"))
    lock = int(env_number("DB_LOCK_TIMEOUT_MS", 5000, 250, 30000, legacy="POSTGRES_LOCK_TIMEOUT_MS"))
    return {
        "autocommit": autocommit,
        "connect_timeout": int(env_number("DB_CONNECT_TIMEOUT_SECONDS", 10, 1, 60)),
        "application_name": application_name,
        "keepalives_idle": 30,
        "keepalives_interval": 10,
        "keepalives_count": 3,
        "tcp_user_timeout": 15000,
        "options": f"-c statement_timeout={statement} -c lock_timeout={lock}",
    }


def redact_error(value: object) -> str:
    text = str(value)
    text = re.sub(r"(?i)(postgres(?:ql)?(?:\+\w+)?://)[^\s\"\']+", r"\1[REDACTED]", text)
    text = re.sub(r"(?i)((?:password|apikey|api_key|token|secret)\s*[=:]\s*)[^\s&;]+", r"\1[REDACTED]", text)
    for key, secret in os.environ.items():
        if any(word in key for word in ("TOKEN", "SECRET", "PASSWORD", "API_KEY")) and len(secret) >= 8:
            text = text.replace(secret, "[REDACTED]")
    return text


def error_code(error: BaseException) -> str:
    seen = set()
    current = error
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        state = str(getattr(current, "sqlstate", "") or "")
        if state.startswith("28"):
            return "DB_AUTH_FAILED"
        if state == "3D000":
            return "DB_DATABASE_MISSING"
        if state == "42501":
            return "DB_PERMISSION_DENIED"
        if state in {"42P01", "42703"}:
            return "DB_SCHEMA_MISMATCH"
        if state in {"55P03", "40P01"}:
            return "DB_LOCK_OR_DEADLOCK"
        message = str(current).lower()
        if "ssl" in message or "certificate" in message:
            return "DB_TLS_FAILED"
        if "name resolution" in message or "translate host" in message:
            return "DB_DNS_FAILED"
        if "password authentication failed" in message:
            return "DB_AUTH_FAILED"
        if "connection refused" in message or "network is unreachable" in message:
            return "DB_CONNECTION_FAILED"
        if current.__class__.__name__ == "PoolTimeout":
            return "DB_POOL_ACQUIRE_TIMEOUT"
        current = current.__cause__ or current.__context__
    return "DB_STARTUP_FAILED"
