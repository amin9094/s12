"""Privacy changes on the canonical store's committing cursor.

Never open a second database connection here: a deletion and its normalized
projections must commit or roll back together, including on SQLite.
"""
from __future__ import annotations

import json

from core.membership_bridge import _table_exists

# Explicit ownership inventory; identifiers below are constants, never input.
RETAINED_USER_TABLES = (
    "v8_trading_accounts", "v8_positions", "v8_position_pnl_events",
    "v8_equity_events", "v8_broker_snapshots",
    "v8_receipts", "v8_checkout_quotes",
    "v8_vip_orders", "v8_vip_entitlements", "v8_tickets", "v8_journal_entries",
    "v8_events", "v8_mt5_connectors", "v8_mt5_events", "v8_prop_alerts",
)
REMOVED_USER_TABLES = (
    "v8_user_preferences", "v8_idempotency", "v8_mt5_pairing_codes",
    "v8_risk_daily_plans", "v8_risk_checkins",
)


def anonymize_normalized_user(cursor, uid: str, pseudonym: str, *, postgres=False) -> None:
    def execute(sql, params=()):
        cursor.execute(sql.replace("?", "%s") if postgres else sql, params)

    exists = {table for table in (*RETAINED_USER_TABLES, *REMOVED_USER_TABLES,
                                  "v8_ticket_messages", "v8_mt5_nonces",
                                  "v8_daily_account_snapshots", "v8_prop_rule_evaluations")
              if _table_exists(cursor, postgres, table)}
    if "v8_ticket_messages" in exists and "v8_tickets" in exists:
        execute("""UPDATE v8_ticket_messages SET body=?,payload='{}',
                   sender_id=CASE WHEN sender_id=? THEN ? ELSE sender_id END
                   WHERE ticket_id IN (SELECT id FROM v8_tickets WHERE user_id=?)""",
                ("[حذف‌شده توسط کاربر]", uid, pseudonym, uid))
    if "v8_mt5_nonces" in exists and "v8_mt5_connectors" in exists:
        execute("DELETE FROM v8_mt5_nonces WHERE connector_id IN (SELECT id FROM v8_mt5_connectors WHERE user_id=?)", (uid,))
    if "v8_daily_account_snapshots" in exists and "v8_trading_accounts" in exists:
        execute("UPDATE v8_daily_account_snapshots SET payload='{}' WHERE account_id IN (SELECT id FROM v8_trading_accounts WHERE user_id=?)", (uid,))
    if "v8_prop_rule_evaluations" in exists:
        execute("UPDATE v8_prop_rule_evaluations SET user_id=?,hard_blocks='[]',warnings='[]',metrics='{}' WHERE user_id=?", (pseudonym, uid))
    overrides = {
        "v8_trading_accounts": "name='[deleted]',archived=1,is_default=0,",
        "v8_broker_snapshots": "account_reference='[deleted]',",
        "v8_tickets": "subject='[deleted]',",
        "v8_mt5_connectors": "status='revoked',secret_payload='',account_login=id,broker='',server_name='',account_name='',",
    }
    for table in RETAINED_USER_TABLES:
        if table not in exists:
            continue
        # Preserve indexed economic columns, not opaque blobs that may contain
        # broker credentials, raw statements, free text or profile details.
        execute(f"UPDATE {table} SET {overrides.get(table, '')}user_id=?,payload=? WHERE user_id=?",  # nosec B608 -- constant inventory
                (pseudonym, json.dumps({"user_id": pseudonym, "privacy_anonymized": True}), uid))
    for table in REMOVED_USER_TABLES:
        if table in exists:
            execute(f"DELETE FROM {table} WHERE user_id=?", (uid,))  # nosec B608 -- constant inventory
