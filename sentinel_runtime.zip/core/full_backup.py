"""Complete database + immutable local blob backups, restored only into isolation.

No running database is overwritten. PostgreSQL restoration requires a separate
empty database. Secrets belong to the deployment's key inventory, never the zip.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import shutil
import sqlite3
import subprocess  # nosec B404
import tempfile
import time
import zipfile
from pathlib import Path, PurePosixPath
from core.logging_context import operation_id

from core.backup_service import (
    STREAM_MAGIC, _backup_stamp, _decrypt_file_stream, _encrypt_file_stream,
    _file_sha256, _pg_env, _write_metadata, backup_metadata,
    create_operational_backup, create_postgres_dump_backup,
)

FORMAT = 'SENTINEL_COMPLETE_V1'
MAX_BYTES = 20_000_000_000


def storage_roots(settings):
    mount = os.getenv('PERSISTENT_DATA_DIR') or os.getenv('RAILWAY_VOLUME_MOUNT_PATH') or os.getenv('VOLUME_MOUNT_PATH')
    base = Path(mount) if mount else settings.db_file.parent
    return {name: Path(path).expanduser().resolve() for name, path in {
        'support_attachments': os.getenv('SUPPORT_ATTACHMENT_STORAGE_DIR') or base/'support_attachments',
        'payment_receipts': os.getenv('RECEIPT_STORAGE_DIR') or base/'payment_receipts',
        'signal_templates': os.getenv('SIGNAL_TEMPLATE_STORAGE_DIR') or base/'signal_templates',
        'ai_admin_assets': base/'ai_admin_assets',
        'generated_ads': getattr(settings, 'gemini_generated_ads_dir', base/'generated_ads'),
    }.items()}


def _identifier(value):
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', value):
        raise ValueError('BACKUP_SCHEMA_IDENTIFIER_INVALID')
    return '"'+value+'"'


def database_signature(connection, dialect):
    """Bounded-memory, order-independent hashes of every application table."""
    cursor = connection.cursor()
    if dialect == 'sqlite':
        tables = [r[0] for r in cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    else:
        cursor.execute("SELECT tablename FROM pg_tables WHERE schemaname='public'")
        tables = [r[0] for r in cursor.fetchall()]
    result = {}
    for table in sorted(tables):
        total = count = 0
        offset = 0
        while True:
            query = f'SELECT * FROM {_identifier(table)} LIMIT 200 OFFSET '  # nosec B608 -- validated schema identifiers
            cursor.execute(query + ('?' if dialect == 'sqlite' else '%s'), (offset,))
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]
            for row in rows:
                data = json.dumps(dict(zip(columns, row)), sort_keys=True, separators=(',', ':'),
                                  ensure_ascii=False, default=lambda v: {'bytes':v.hex()} if isinstance(v,bytes) else str(v))
                total = (total + int(hashlib.sha256(data.encode()).hexdigest(), 16)) % (1 << 256)
                count += 1
            if len(rows) < 200:
                break
            offset += 200
        result[table] = {'rows':count, 'row_hash_sum':format(total, '064x')}
    cursor.close()
    return result


def create_complete_backup(settings, *, roots=None):
    folder = Path(settings.backup_dir)
    folder.mkdir(parents=True, exist_ok=True)
    roots = storage_roots(settings) if roots is None else {k:Path(v).resolve() for k,v in roots.items()}
    stamp = _backup_stamp()
    target = folder/f'sentinel-complete-{stamp}.zip'
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix='.complete-', dir=folder) as directory:
        stage = Path(directory)
        manifest = {'operation_id':operation_id('backup:'+stamp),'format':FORMAT, 'created_at':stamp, 'key_version':getattr(settings,'backup_key_version','v1'),
                    'dialect':'postgres' if settings.database_url else 'sqlite',
                    'roots':{k:str(v) for k,v in roots.items()}, 'files':{},
                    'external_objects_included':False,
                    'external_object_storage_configured':bool(os.getenv('RECEIPT_S3_BUCKET')),
                    'required_secrets':['SENSITIVE_DATA_KEY']}
        if settings.database_url:
            import psycopg
            with psycopg.connect(settings.database_url) as connection:
                with connection.cursor() as c:
                    c.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
                    c.execute('SELECT pg_export_snapshot()')
                    snapshot = c.fetchone()[0]
                manifest['tables'] = database_signature(connection, 'postgres')
                database = create_postgres_dump_backup(settings.database_url, stage, snapshot=snapshot)
        else:
            if not Path(settings.db_file).is_file():
                raise ValueError('BACKUP_DATABASE_MISSING')
            database = create_operational_backup(Path(settings.db_file), stage)
            with sqlite3.connect(database) as connection:
                manifest['tables'] = database_signature(connection, 'sqlite')
        raw = stage/'complete.zip'
        with zipfile.ZipFile(raw,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
            def add(file, name):
                before = _file_sha256(file)
                archive.write(file, name)
                if before != _file_sha256(file):
                    raise ValueError('BACKUP_FILE_CHANGED_DURING_CAPTURE')
                manifest['files'][name] = {'size':file.stat().st_size,'sha256':before}
            manifest['database_member'] = 'database/source.dump' if settings.database_url else 'database/source.sqlite3'
            add(database, manifest['database_member'])
            for label, root in roots.items():
                if not re.fullmatch('[a-z_]{1,50}', label):
                    raise ValueError('BACKUP_ROOT_LABEL_INVALID')
                if not root.exists():
                    continue
                for file in sorted(root.rglob('*')):
                    if file.is_symlink():
                        raise ValueError('BACKUP_SYMLINK_REJECTED')
                    if file.is_file():
                        add(file, f'blobs/{label}/{file.relative_to(root).as_posix()}')
            manifest['capture_seconds'] = round(time.monotonic()-started,3)
            from datetime import UTC,datetime
            archive.writestr(zipfile.ZipInfo('manifest.json',datetime.now(UTC).timetuple()[:6]),
                             json.dumps(manifest,ensure_ascii=False,sort_keys=True))
        secret = settings.backup_encryption_key
        if secret:
            target = target.with_suffix('.zip.enc')
            _encrypt_file_stream(raw,target,secret)
        else:
            os.chmod(raw,0o600)
            os.replace(raw,target)
        _write_metadata(target,source=FORMAT,plaintext_sha256=_file_sha256(raw) if raw.exists() else _file_sha256(target),
                        encrypted=bool(secret),key_version=getattr(settings,'backup_key_version','v1'))
    return target


@contextlib.contextmanager
def verified_bundle(path, *, encryption_key='', previous_keys=()):
    path = Path(path).resolve()
    expected = backup_metadata(path).get('sha256')
    if expected and _file_sha256(path) != expected:
        raise ValueError('BACKUP_HASH_MISMATCH')
    with tempfile.TemporaryDirectory(prefix='sentinel-verify-') as temp:
        candidate = path
        with path.open('rb') as source:
            encrypted = source.read(len(STREAM_MAGIC)) == STREAM_MAGIC
        if encrypted:
            for key in dict.fromkeys([encryption_key,*previous_keys]):
                if not key:
                    continue
                try:
                    candidate = Path(temp)/'plain.zip'
                    _decrypt_file_stream(path,candidate,key)
                    break
                except Exception:
                    candidate = path
            if candidate == path:
                raise ValueError('BACKUP_DECRYPTION_FAILED')
        with zipfile.ZipFile(candidate) as archive:
            if sum(i.file_size for i in archive.infolist()) > MAX_BYTES:
                raise ValueError('BACKUP_TOO_LARGE')
            if archive.getinfo('manifest.json').file_size > 20_000_000:
                raise ValueError('BACKUP_MANIFEST_TOO_LARGE')
            manifest = json.loads(archive.read('manifest.json'))
            if manifest.get('format') != FORMAT or manifest.get('dialect') not in {'sqlite','postgres'}:
                raise ValueError('BACKUP_FORMAT_INVALID')
            if set(archive.namelist()) != set(manifest['files'])|{'manifest.json'} or len(archive.namelist())!=len(set(archive.namelist())):
                raise ValueError('BACKUP_MEMBERS_INVALID')
            for name, meta in manifest['files'].items():
                parts = PurePosixPath(name)
                if parts.is_absolute() or '..' in parts.parts or '\\' in name or not name.startswith(('blobs/','database/')):
                    raise ValueError('BACKUP_PATH_INVALID')
                digest = hashlib.sha256()
                with archive.open(name) as source:
                    while chunk := source.read(1024*1024):
                        digest.update(chunk)
                if archive.getinfo(name).file_size != meta['size'] or digest.hexdigest()!=meta['sha256']:
                    raise ValueError('BACKUP_MEMBER_HASH_MISMATCH')
            yield archive,manifest


def restore_complete_backup(path, destination, *, encryption_key='', previous_keys=(), postgres_url=''):
    """Reconstruct an isolated data tree; reject all existing targets."""
    destination = Path(destination).resolve()
    if destination.exists():
        raise ValueError('RESTORE_REQUIRES_NEW_DIRECTORY')
    destination.parent.mkdir(parents=True,exist_ok=True)
    with verified_bundle(path,encryption_key=encryption_key,previous_keys=previous_keys) as (archive,manifest):
        with tempfile.TemporaryDirectory(prefix='.restore-',dir=destination.parent) as directory:
            stage = Path(directory)
            for name in manifest['files']:
                target = stage/name
                target.parent.mkdir(parents=True,exist_ok=True)
                with archive.open(name) as src, target.open('wb') as dst:
                    shutil.copyfileobj(src,dst,1024*1024)
            database = stage/manifest['database_member']
            if manifest['dialect']=='sqlite':
                with sqlite3.connect(database) as connection:
                    if connection.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or connection.execute('PRAGMA foreign_key_check').fetchone():
                        raise ValueError('RESTORE_DATABASE_INTEGRITY_FAILED')
                    actual = database_signature(connection,'sqlite')
            else:
                if not postgres_url:
                    raise ValueError('RESTORE_REQUIRES_ISOLATED_POSTGRES_URL')
                from config import SETTINGS
                # Compare connection identity; credentials and options cannot disguise the same target.
                def identity(url):
                    e=_pg_env(url);return tuple(e.get(k,'') for k in ('PGHOST','PGPORT','PGDATABASE'))
                if SETTINGS.database_url and identity(postgres_url)==identity(SETTINGS.database_url):
                    raise ValueError('RESTORE_PRODUCTION_DATABASE_REJECTED')
                import psycopg
                with psycopg.connect(postgres_url) as connection:
                    if database_signature(connection,'postgres'):
                        raise ValueError('RESTORE_REQUIRES_EMPTY_DATABASE')
                subprocess.run(['pg_restore','--exit-on-error','--single-transaction','--no-owner','--no-privileges',  # nosec B603 B607
                                '--dbname',_pg_env(postgres_url)['PGDATABASE'],str(database)],
                               env=_pg_env(postgres_url),check=True,timeout=600,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
                with psycopg.connect(postgres_url) as connection:
                    actual=database_signature(connection,'postgres')
            if actual!=manifest['tables']:
                raise ValueError('RESTORE_TABLE_CONTENT_MISMATCH')
            mapping={old:str(destination/'blobs'/name) for name,old in manifest['roots'].items()}
            # Retain exact data hashes; path rebinding is an explicit separate operation at activation.
            (stage/'RESTORE_PATH_MAP.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2))
            (stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
            os.replace(stage,destination)
    return {'restore_drill':'passed','verification_level':'DATABASE_AND_LOCAL_FILES_RESTORED',
            'database_restored':True,'tables_verified':len(actual),'files_verified':len(manifest['files']),
            'external_objects_verified':not manifest.get('external_object_storage_configured'),
            'activation_required':True,'path_map':str(destination/'RESTORE_PATH_MAP.json')}


def verify_complete_backup(path, *, encryption_key='', previous_keys=(), postgres_url=''):
    started=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='sentinel-drill-') as directory:
        with verified_bundle(path,encryption_key=encryption_key,previous_keys=previous_keys) as (_,manifest):
            if manifest['dialect']=='postgres' and not postgres_url:
                from core.utils import utc_iso
                return {'restore_drill':'archive_verified','verification_level':'ARCHIVE_ONLY',
                        'database_restored':False,'files_verified':len(manifest['files']),
                        'tested_at':utc_iso(),'duration_seconds':round(time.monotonic()-started,3)}
        result=restore_complete_backup(path,Path(directory)/'data',encryption_key=encryption_key,
                                      previous_keys=previous_keys,postgres_url=postgres_url)
    from core.utils import utc_iso
    return {**result,'tested_at':utc_iso(),'duration_seconds':round(time.monotonic()-started,3)}


def activate_restored_paths(destination, *, postgres_url=''):
    """Rebind ONLY path-valued legacy metadata in a verified isolated restore."""
    root=Path(destination).resolve()
    manifest=json.loads((root/'manifest.json').read_text())
    mapping=json.loads((root/'RESTORE_PATH_MAP.json').read_text())
    for value in mapping.values():
        if not Path(value).is_relative_to(root/'blobs'):
            raise ValueError('RESTORE_PATH_MAP_INVALID')
    from core.db import SQLiteStore,PostgresStore
    if manifest['dialect']=='postgres':
        if not postgres_url:
            raise ValueError('RESTORE_REQUIRES_ISOLATED_POSTGRES_URL')
        from config import SETTINGS
        if SETTINGS.database_url and _pg_env(SETTINGS.database_url)==_pg_env(postgres_url):
            raise ValueError('RESTORE_PRODUCTION_DATABASE_REJECTED')
        store=PostgresStore(postgres_url,root/'activation_backups')
    else:
        store=SQLiteStore(root/manifest['database_member'],root/'activation_backups')
    payload=store._read()
    def rebind(value,key=''):
        if isinstance(value,dict):return {k:rebind(v,k) for k,v in value.items()}
        if isinstance(value,list):return [rebind(v,key) for v in value]
        if isinstance(value,str) and (key.endswith('_path') or key in {'path','background'}):
            for old,new in sorted(mapping.items(),key=lambda pair:-len(pair[0])):
                if value==old or value.startswith(old+'/'):
                    return new+value[len(old):]
        return value
    store.write(rebind(payload))
    return {'paths_activated':True,'directory':str(root),'environment_roots':{
        'SUPPORT_ATTACHMENT_STORAGE_DIR':str(root/'blobs/support_attachments'),
        'RECEIPT_STORAGE_DIR':str(root/'blobs/payment_receipts'),
        'SIGNAL_TEMPLATE_STORAGE_DIR':str(root/'blobs/signal_templates')}}


async def perform_complete_backup(settings):
    """Single entry point for CLI and scheduler; records truthful verification."""
    from core.async_runtime import run_blocking
    from core.async_db import async_with_db
    from core.backup_service import prune_operational_backups,upload_external_backup
    from core.utils import utc_iso
    path=await run_blocking(create_complete_backup,settings,timeout=600)
    drill=await run_blocking(verify_complete_backup,path,encryption_key=settings.backup_encryption_key,
                            previous_keys=getattr(settings,'backup_previous_keys',()),timeout=300)
    uploaded=await upload_external_backup(path,settings.external_backup_url) if settings.external_backup_url else False
    await run_blocking(prune_operational_backups,settings.backup_dir,keep=30,timeout=30)
    def record(db):
        stamp=utc_iso();ops=db.setdefault('operations',{})
        ops.update(last_operational_backup_at=stamp,last_operational_backup_file=path.name,
                   last_external_backup_uploaded=uploaded,last_backup_verification=drill,
                   last_archive_verified_at=drill['tested_at'])
        if drill.get('database_restored'):
            ops.update(last_restore_drill_at=drill['tested_at'],last_restore_drill_status='passed',
                       last_restore_drill_file=path.name,last_restore_duration_seconds=drill['duration_seconds'])
        history=db.setdefault('backup_history',[])
        history.append({'created_at':stamp,'file':path.name,'restore_drill':drill['restore_drill'],
                        'verification_level':drill['verification_level'],'external_uploaded':uploaded,
                        'source':'complete_backup','operation_id':operation_id(path.stem)})
        del history[:-100]
    await async_with_db(record)
    return path


def backup_health(db):
    from core.utils import parse_dt,utc_now
    ops=db.get('operations',{});now=utc_now()
    def age(key):
        value=parse_dt(ops.get(key));return max(0,int((now-value).total_seconds())) if value else None
    rpo=max(300,int(os.getenv('BACKUP_RPO_SECONDS','86400')))
    rto=max(30,int(os.getenv('BACKUP_RTO_SECONDS','1800')))
    backup_age=age('last_operational_backup_at')
    return {'backup_age_seconds':backup_age,'restore_age_seconds':age('last_restore_drill_at'),
            'rpo_target_seconds':rpo,'rto_target_seconds':rto,
            'within_rpo':backup_age is not None and backup_age<=rpo,
            'restore_duration_seconds':ops.get('last_restore_duration_seconds'),
            'verification':ops.get('last_backup_verification'),
            'measured_not_guaranteed':True}
