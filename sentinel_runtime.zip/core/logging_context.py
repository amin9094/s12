from __future__ import annotations

import contextvars
from contextlib import contextmanager
import hashlib
import json
import logging
import re
from datetime import UTC, datetime
from typing import Any

_CORRELATION_ID: contextvars.ContextVar[str] = contextvars.ContextVar("sentinel_correlation_id", default="")
_SECRET_PATTERNS = (
    re.compile(r"(?i)(bot[_-]?token|api[_-]?key|secret|password|authorization)\s*[=:]\s*([^\s,;]+)"),
    re.compile(r"\b\d{12,19}\b"),
)


def set_correlation_id(value: str) -> contextvars.Token[str]:
    clean = str(value or "").strip()[:128]
    return _CORRELATION_ID.set(clean)


def reset_correlation_id(token: contextvars.Token[str]) -> None:
    _CORRELATION_ID.reset(token)


def correlation_id() -> str:
    return _CORRELATION_ID.get()


def operation_id(fallback: str = '') -> str:
    """Use the initiating request identity, including across durable queues."""
    return correlation_id() or str(fallback)[:128]


@contextmanager
def operation_scope(value: str):
    token = set_correlation_id(value or correlation_id())
    try:
        yield correlation_id()
    finally:
        reset_correlation_id(token)


def redact(value: Any) -> str:
    text = str(value)
    # Bot API URLs contain the credential as a path component, including in
    # third-party HTTP logs and exception text. Mask before numeric hashing.
    text = re.sub(r"(?<![0-9])[0-9]{5,20}(?::|%3[aA])[A-Za-z0-9_-]{20,}", "[REDACTED]", text)
    text = re.sub(r"(?i)(authorization[\"\']?\s*[:=]\s*[\"\']?)(?:bearer|basic)\s+[^\s,;\"\']+", r"\1[REDACTED]", text)
    text = re.sub(r"(://)[^/\s@]+:[^/\s@]+@", r"\1[REDACTED]@", text)
    text = re.sub(r"gift_[A-Za-z0-9_-]{20,64}", "gift_[REDACTED]", text)
    text = re.sub(r"(?i)(gift[_-]?(?:token|code)|coupon[_-]?(?:code|secret))([\"\']?\s*[:=]\s*[\"\']?)[A-Za-z0-9_-]+", r"\1\2[REDACTED]", text)
    for pattern in _SECRET_PATTERNS:
        if pattern.pattern.startswith("\\b"):
            text = pattern.sub(lambda match: f"card:{hashlib.sha256(match.group(0).encode()).hexdigest()[:10]}", text)
        else:
            text = pattern.sub(lambda match: f"{match.group(1)}=[REDACTED]", text)
    return text


def redact_metadata(value: Any) -> Any:
    """Preserve incident structure without retaining credentials in values."""
    if isinstance(value, dict):
        sensitive = {"bot_token", "api_key", "secret", "password", "authorization", "token", "access_token", "refresh_token"}
        return {key: "[REDACTED]" if str(key).lower().replace("-", "_") in sensitive else redact_metadata(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact_metadata(item) for item in value]
    return redact(value) if isinstance(value, str) else value


class RedactingFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        # A Filter only transforms record.msg; traceback and exc_text are
        # appended later by Formatter and must also be redacted.
        return redact(super().format(record))


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            record.msg = redact(record.getMessage())
            record.args = ()
        except Exception:
            record.msg = "[log redaction failed]"
            record.args = ()
        record.correlation_id = correlation_id() or "-"
        return True


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": redact(record.getMessage()),
            "correlation_id": getattr(record, "correlation_id", "-") or "-",
        }
        if record.exc_info:
            payload["exception"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
