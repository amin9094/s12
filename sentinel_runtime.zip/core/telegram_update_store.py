from __future__ import annotations

import json
import os
import time
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import json_dump
from modules.security_sentinel import record_security_event


class UpdateReplayConflict(RuntimeError):
    """Raised when the same Telegram update_id is replayed with a different payload."""



def _max_attempts() -> int:
    return max(1, min(20, int(os.getenv("TELEGRAM_UPDATE_MAX_ATTEMPTS", "5") or 5)))


def persist(update_id: int | str, payload: dict[str, Any], engine: DatabaseEngine | None = None) -> str:
    """Persist an update before Telegram receives HTTP 200.

    Returns ``new``, ``retry`` or ``duplicate``. A completed/in-flight update is
    never inserted twice, while failed updates may be retried up to the bounded
    attempt limit.
    """
    db = engine or normalized_engine()
    uid = str(int(update_id))
    now = time.time()
    encoded = json_dump(payload)
    with db.transaction() as cursor:
        row = cursor.execute(
            "SELECT status,attempts,updated_at,payload FROM v8_telegram_updates WHERE update_id=?",
            (uid,),
        ).fetchone()
        if not row:
            cursor.execute(
                """INSERT INTO v8_telegram_updates(
                    update_id,status,payload,attempts,queued_at,claimed_at,completed_at,updated_at,last_error,worker_id
                ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (uid, "queued", encoded, 0, now, None, None, now, None, None),
            )
            return "new"
        status = str(row.get("status") or "")
        attempts = int(row.get("attempts") or 0)
        previous_payload = str(row.get("payload") or "")
        if previous_payload and previous_payload != encoded:
            record_security_event(
                "telegram_update_replay_conflict",
                severity="high",
                subject=uid,
                metadata={"status": status, "attempts": attempts},
            )
            raise UpdateReplayConflict(f"update_id {uid} replayed with a different payload")
        if status in {"done", "queued", "processing", "dead"}:
            return "duplicate"
        if status == "failed" and attempts < _max_attempts():
            cursor.execute(
                """UPDATE v8_telegram_updates SET status='queued',payload=?,queued_at=?,claimed_at=NULL,
                   completed_at=NULL,updated_at=?,last_error=NULL,worker_id=NULL WHERE update_id=?""",
                (encoded, now, now, uid),
            )
            return "retry"
        return "duplicate"


def worker_inflight(worker_id: str, *, stale_seconds: float, engine=None) -> int:
    """Count leased work, including tasks already drained from PTB's queue."""
    db = engine or normalized_engine()
    with db.transaction(read_only=True) as cursor:
        row = cursor.execute(
            "SELECT COUNT(*) AS count FROM v8_telegram_updates WHERE worker_id=? "
            "AND status='processing' AND claimed_at>=?",
            (worker_id, time.time() - stale_seconds),
        ).fetchone()
    return int(row['count'])


def claim_pending(
    worker_id: str,
    *,
    limit: int = 50,
    stale_seconds: float = 120.0,
    retry_delay_seconds: float = 5.0,
    engine: DatabaseEngine | None = None,
) -> list[dict[str, Any]]:
    db = engine or normalized_engine()
    size = max(1, min(200, int(limit)))
    now = time.time()
    stale_before = now - max(5.0, float(stale_seconds))
    retry_before = now - max(0.0, float(retry_delay_seconds))
    max_attempts = _max_attempts()
    with db.transaction() as cursor:
        # Fail closed before selecting work: an update that already exhausted its
        # retry budget must never be re-claimed after a process crash, graceful
        # worker release, or a legacy/manual status change.
        cursor.execute(
            """UPDATE v8_telegram_updates
               SET status='dead',completed_at=?,updated_at=?,
                   last_error=COALESCE(last_error,'RETRY_LIMIT_EXCEEDED'),worker_id=NULL
               WHERE status IN ('queued','failed') AND attempts >= ?""",
            (now, now, max_attempts),
        )
        cursor.execute(
            """UPDATE v8_telegram_updates
               SET status='dead',completed_at=?,updated_at=?,
                   last_error=COALESCE(last_error,'STALE_PROCESSING_RETRY_LIMIT_EXCEEDED'),worker_id=NULL
               WHERE status='processing' AND attempts >= ? AND COALESCE(claimed_at,0) < ?""",
            (now, now, max_attempts, stale_before),
        )

        sql = """SELECT update_id,payload,status,attempts FROM v8_telegram_updates
                 WHERE (status='queued' AND attempts < ?)
                    OR (status='processing' AND attempts < ? AND COALESCE(claimed_at,0) < ?)
                    OR (status='failed' AND attempts < ? AND updated_at < ?)
                 ORDER BY queued_at,update_id LIMIT ?"""
        if db.dialect.name == "postgres":
            sql += " FOR UPDATE SKIP LOCKED"
        rows = cursor.execute(
            sql,
            (max_attempts, max_attempts, stale_before, max_attempts, retry_before, size),
        ).fetchall()
        claimed: list[dict[str, Any]] = []
        for row in rows:
            update_id = str(row["update_id"])
            attempts = int(row.get("attempts") or 0) + 1
            cursor.execute(
                """UPDATE v8_telegram_updates SET status='processing',attempts=?,claimed_at=?,updated_at=?,worker_id=?
                   WHERE update_id=?""",
                (attempts, now, now, str(worker_id)[:120], update_id),
            )
            try:
                payload = json.loads(str(row.get("payload") or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                payload = {}
            claimed.append({"update_id": update_id, "payload": payload, "attempts": attempts})
        return claimed


def mark_done(update_id: int | str, engine: DatabaseEngine | None = None) -> None:
    db = engine or normalized_engine()
    now = time.time()
    with db.transaction() as cursor:
        cursor.execute(
            """UPDATE v8_telegram_updates SET status='done',completed_at=?,updated_at=?,last_error=NULL,worker_id=NULL
               WHERE update_id=?""",
            (now, now, str(int(update_id))),
        )


def mark_failed(update_id: int | str, error_code: str, engine: DatabaseEngine | None = None) -> str:
    db = engine or normalized_engine()
    now = time.time()
    uid = str(int(update_id))
    with db.transaction() as cursor:
        row = cursor.execute("SELECT attempts FROM v8_telegram_updates WHERE update_id=?", (uid,)).fetchone() or {}
        status = "dead" if int(row.get("attempts") or 0) >= _max_attempts() else "failed"
        cursor.execute(
            """UPDATE v8_telegram_updates SET status=?,updated_at=?,last_error=?,worker_id=NULL WHERE update_id=?""",
            (status, now, str(error_code or "PROCESSING_FAILED")[:160], uid),
        )
    return status


def release_worker(worker_id: str, engine: DatabaseEngine | None = None) -> int:
    db = engine or normalized_engine()
    now = time.time()
    max_attempts = _max_attempts()
    with db.transaction() as cursor:
        cursor.execute(
            """UPDATE v8_telegram_updates
               SET status=CASE WHEN attempts >= ? THEN 'dead' ELSE 'queued' END,
                   claimed_at=NULL,
                   completed_at=CASE WHEN attempts >= ? THEN ? ELSE completed_at END,
                   updated_at=?,
                   last_error=CASE WHEN attempts >= ?
                                   THEN COALESCE(last_error,'WORKER_RELEASE_RETRY_LIMIT_EXCEEDED')
                                   ELSE last_error END,
                   worker_id=NULL
               WHERE status='processing' AND worker_id=?""",
            (max_attempts, max_attempts, now, now, max_attempts, str(worker_id)[:120]),
        )
        return max(0, int(cursor.rowcount or 0))


def backlog(engine: DatabaseEngine | None = None) -> dict[str, int]:
    db = engine or normalized_engine()
    with db.transaction(read_only=True) as cursor:
        rows = cursor.execute(
            "SELECT status,COUNT(*) AS total FROM v8_telegram_updates GROUP BY status"
        ).fetchall()
    result = {str(row.get("status") or "unknown"): int(row.get("total") or 0) for row in rows}
    result["pending"] = sum(result.get(name, 0) for name in ("queued", "processing", "failed"))
    with db.transaction(read_only=True) as cursor:
        oldest = cursor.execute(
            "SELECT MIN(queued_at) AS oldest FROM v8_telegram_updates WHERE status IN ('queued','processing','failed')"
        ).fetchone() or {}
    oldest_at = float(oldest.get("oldest") or 0)
    result["oldest_pending_age_seconds"] = max(0, int(time.time() - oldest_at)) if oldest_at else 0
    return result


def cleanup(retention_days: int = 7, engine: DatabaseEngine | None = None) -> int:
    db = engine or normalized_engine()
    cutoff = time.time() - max(1, int(retention_days)) * 86400
    with db.transaction() as cursor:
        cursor.execute(
            "DELETE FROM v8_telegram_updates WHERE status IN ('done','dead') AND updated_at < ?",
            (cutoff,),
        )
        return max(0, int(cursor.rowcount or 0))
