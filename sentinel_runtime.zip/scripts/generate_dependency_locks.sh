#!/bin/sh
set -eu
python -m piptools compile --resolver=backtracking --generate-hashes --strip-extras=false \
  --output-file=requirements.lock.txt requirements.in
python -m piptools compile --resolver=backtracking --generate-hashes --strip-extras=false \
  --constraint=requirements.lock.txt --output-file=requirements-dev.lock.txt requirements-dev.in
python scripts/mark_dependency_lock_complete.py
python scripts/verify_dependency_lock.py --require-hashes
