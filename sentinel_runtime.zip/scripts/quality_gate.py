#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import io
import json
import os
import re
import shutil
import signal
import subprocess  # nosec B404 -- fixed internal quality commands only
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from defusedxml.common import DefusedXmlException
from defusedxml.ElementTree import ParseError
from defusedxml.ElementTree import parse as parse_xml

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.quality_utils import (
    automated_test_count,
    configured_image_digest,
    mt5_acceptance_details,
    production_acceptance_errors,
    source_fingerprint,
)

ARTIFACTS = ROOT / "quality-artifacts"
FULL_COVERAGE_SOURCE = "bot_runtime,core,modules,services,repositories,handlers,jobs,ui"
from scripts.quality_policy import CRITICAL_TARGETS as CRITICAL_TARGETS

CANDIDATE_TESTS = [
    "tests/test_r35_signal_audit.py",
    "tests/test_r34_independent_markets.py",
    "tests/test_r33_live_release.py",
    "tests/test_r32_full_audit_repairs.py",
    # Candidate releases execute the complete deterministic offline suite.
    # This keeps the proof tied to the exact Railway source archive.
    "tests/test_admin_miniapp_simplified_ui.py",
    "tests/test_back_label_and_full_module_parity_v8156.py",
    "tests/test_back_navigation_admin_parity_v8154.py",
    "tests/test_button_palette_contract.py",
    "tests/test_crm_welcome_idempotency.py",
    "tests/test_deterministic_back_v8157.py",
    "tests/test_gemini_ai_admin_finance_boundaries_v8170.py",
    "tests/test_gemini_ai_governance_v8180.py",
    "tests/test_idempotency_finalizer.py",
    "tests/test_journal_signal_deduplication.py",
    "tests/test_keyboard_unified_menu.py",
    "tests/test_legacy_portfolio_integrity.py",
    "tests/test_manual_payment_contracts.py",
    "tests/test_manual_payment_repository.py",
    "tests/test_manual_payment_resilience.py",
    "tests/test_manual_payment_state_machine.py",
    "tests/test_market_watchlist_health.py",
    "tests/test_miniapp_action_service_contracts.py",
    "tests/test_miniapp_back_navigation_cleanup.py",
    "tests/test_miniapp_feature_actions.py",
    "tests/test_miniapp_full_english_localization.py",
    "tests/test_miniapp_read_admin_contracts.py",
    "tests/test_miniapp_read_integration.py",
    "tests/test_miniapp_server_security_routes.py",
    "tests/test_miniapp_telegram_bridge.py",
    "tests/test_mt5_prop_guardian_risk_coach_v8160.py",
    "tests/test_normalized_trading_repositories.py",
    "tests/test_operations_governance_health.py",
    "tests/test_payment_pricing_consistency.py",
    "tests/test_price_provider_consensus.py",
    "tests/test_r9_gemini_navigation_miniapp.py",
    "tests/test_r28_admin_command_os.py",
    "tests/test_railway_clean_bundle_build.py",
    "tests/test_release_regressions.py",
    "tests/test_reply_keyboard_back_safety.py",
    "tests/test_runtime_restore_bootstrap.py",
    "tests/test_signal_period_lifecycle.py",
    "tests/test_single_source_storage_v8150.py",
    "tests/test_uiux_theme_contracts.py",
    "tests/test_v819_production_hardening.py",
    "tests/test_v820_gemini_full_admin_control.py",
    "tests/test_v821_security_and_signal_hardening.py",
    "tests/test_v821_signal_lab_knowledge_and_queue.py",
    "tests/test_v8221_signal_template_delivery_toggle.py",
    "tests/test_v8223_gemini_chat_recovery.py",
    "tests/test_v8226_gemini_education_menu.py",
    "tests/test_signal_media_album.py",
    "tests/test_v8230_critical_coverage_r20.py",
    "tests/test_v8231_r22_checkout_gemini_navigation.py",
    "tests/test_v8232_navigation_payments_calculator_r25.py",
    "tests/test_operations_intelligence.py",
    "tests/test_resilience_experience.py",
    "tests/test_webapp_frontend_backend_contracts.py",
]

COVERAGE_TESTS = [
    "tests/test_operations_intelligence.py",
    "tests/test_resilience_experience.py",
    "tests/test_v8230_critical_coverage_r20.py",
    "tests/test_r28_admin_command_os.py",
    "tests/test_miniapp_action_service_contracts.py",
    "tests/test_miniapp_read_integration.py",
    "tests/test_miniapp_server_security_routes.py",
    "tests/test_normalized_trading_repositories.py",
    "tests/test_market_watchlist_health.py",
    "tests/test_price_provider_consensus.py",
    "tests/test_v8231_r22_checkout_gemini_navigation.py",
]


def node_executable() -> str:
    configured = os.getenv("SENTINEL_NODE_BINARY", "").strip()
    for candidate in (configured, shutil.which("node") or ""):
        if candidate and Path(candidate).is_file():
            return candidate
    raise RuntimeError("Node.js is required for Mini App validation")


def _prepare_test_bundle() -> int:
    """Keep recovery/build tests on this working tree, never an older release.

    This is an unvalidated test fixture. Only the finalizer and release builder
    may turn the passing checks into a bound release proof and final archive.
    """
    from scripts.build_release import runtime_files, update_runtime_checksum, write_zip

    bundle = ROOT / "sentinel_runtime.zip"
    if not (ROOT / "restore_runtime.py").is_file():
        raise RuntimeError("quality validation requires the runtime bootstrap")
    write_zip(bundle, runtime_files())
    update_runtime_checksum(bundle)
    return 0


def _junit_totals(path: Path) -> tuple[int, int, int, int] | None:
    """Return (tests, failures, errors, skipped) only for a complete JUnit XML."""
    try:
        if not path.is_file() or not 0 < path.stat().st_size <= 16 * 1024 * 1024:
            return None
        root = parse_xml(path, forbid_dtd=True).getroot()
    except (OSError, ParseError, DefusedXmlException):
        return None
    suites = [root] if root.tag.rsplit("}", 1)[-1] == "testsuite" else list(root.findall(".//testsuite"))
    if not suites:
        return None
    # A testsuites root normally contains aggregate attributes. Otherwise sum
    # only leaf suites to avoid double-counting nested aggregates.
    if root.tag.rsplit("}", 1)[-1] == "testsuites" and root.attrib.get("tests") is not None:
        candidates = [root]
    else:
        leaves = [suite for suite in suites if not list(suite.findall("./testsuite"))]
        candidates = leaves or suites
    def total(name: str) -> int:
        values = [item.attrib.get(name, "0") for item in candidates]
        if any(not re.fullmatch(r"[0-9]{1,9}", value) for value in values):
            raise ValueError("invalid JUnit count")
        return sum(int(value) for value in values)
    try:
        counts = total("tests"), total("failures"), total("errors"), total("skipped")
    except ValueError:
        return None
    return counts if sum(counts[1:]) <= counts[0] else None


def run(
    label: str,
    command: list[str],
    *,
    required: bool = True,
    timeout: int = 120,
    completion_junit: Path | None = None,
) -> dict[str, Any]:
    """Run a quality command and reap its complete process tree.

    Some integration tests finish and write a complete JUnit report but keep a
    helper thread or subprocess alive during interpreter teardown. For pytest,
    a complete JUnit document is the authoritative completion signal: after it
    appears, the isolated process group is terminated and the result is derived
    from that report. This avoids false Railway timeouts without accepting a
    partial or failed test run.
    """
    print(f"[quality] {label}", flush=True)
    child_env = os.environ.copy()
    child_env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    if completion_junit is not None:
        completion_junit.unlink(missing_ok=True)
    completed_from_junit: tuple[int, int, int, int] | None = None
    timed_out = False
    with tempfile.TemporaryFile(mode="w+b") as stdout_file, tempfile.TemporaryFile(mode="w+b") as stderr_file:
        process = subprocess.Popen(  # nosec B603
            command,
            cwd=ROOT,
            env=child_env,
            stdout=stdout_file,
            stderr=stderr_file,
            start_new_session=(os.name != "nt"),
        )
        deadline = time.monotonic() + timeout
        while True:
            polled = process.poll()
            if polled is not None:
                returncode = polled
                break
            if completion_junit is not None:
                junit = _junit_totals(completion_junit)
                if junit is not None and junit[0] > 0:
                    completed_from_junit = junit
                    returncode = 0 if junit[1] == 0 and junit[2] == 0 else 1
                    break
            if time.monotonic() >= deadline:
                timed_out = True
                returncode = 124
                break
            time.sleep(0.2)
        # Always terminate the isolated group after the direct command exits or
        # the JUnit completion signal arrives, so no helper can retain log FDs.
        if process.poll() is None:
            if os.name != "nt":
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                    time.sleep(0.1)
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            if os.name != "nt":
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
            process.wait(timeout=10)
        stdout_file.seek(0)
        stderr_file.seek(0)
        stdout = stdout_file.read().decode("utf-8", errors="replace")
        stderr = stderr_file.read().decode("utf-8", errors="replace")
    if completed_from_junit is not None:
        tests, failures, errors, skipped = completed_from_junit
        passed = max(0, tests - failures - errors - skipped)
        stdout = stdout.rstrip() + f"\n{passed} passed, {skipped} skipped, {failures + errors} failed (JUnit-complete)\n"
    if stdout:
        print(stdout.rstrip())
    if stderr:
        print(stderr.rstrip(), file=sys.stderr)
    result = {
        "ok": returncode == 0,
        "returncode": returncode,
        "command": command,
        "stdout": stdout[-20_000:],
        "stderr": stderr[-20_000:],
    }
    if timed_out:
        raise RuntimeError(f"{label} exceeded {timeout} seconds before producing a complete result")
    if required and returncode:
        raise RuntimeError(f"{label} failed with exit code {returncode}")
    return result



def run_direct(label: str, command: list[str], *, required: bool = True, timeout: int = 45) -> dict[str, Any]:
    """Run a short command with ordinary captured output.

    Coverage's reporting command does not spawn integration workers. Keeping it
    outside the process-group runner avoids rare descriptor hand-offs from a
    previously completed pytest coverage session on CI/Railway.
    """
    print(f"[quality] {label}", flush=True)
    child_env = os.environ.copy()
    child_env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    try:
        completed = subprocess.run(  # nosec B603 -- fixed internal quality commands only
            command,
            cwd=ROOT,
            env=child_env,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"{label} exceeded {timeout} seconds") from exc
    if completed.stdout:
        print(completed.stdout.rstrip())
    if completed.stderr:
        print(completed.stderr.rstrip(), file=sys.stderr)
    result = {
        "ok": completed.returncode == 0,
        "returncode": completed.returncode,
        "command": command,
        "stdout": completed.stdout[-20_000:],
        "stderr": completed.stderr[-20_000:],
    }
    if required and completed.returncode:
        raise RuntimeError(f"{label} failed with exit code {completed.returncode}")
    return result


def coverage_report_inprocess(
    label: str,
    *,
    threshold: int,
    morfs: list[str] | None = None,
    write_artifacts: bool = False,
) -> dict[str, Any]:
    """Read the completed coverage data without starting another process.

    On some CI/Railway hosts a finished pytest worker can leave an inherited
    coverage descriptor around briefly. Starting ``coverage report`` as a new
    process may then wait forever even though the data file is complete. The
    Coverage API reads the same data deterministically in-process.
    """
    print(f"[quality] {label}", flush=True)
    from coverage import Coverage

    coverage_file = ROOT / ".coverage"
    if not coverage_file.is_file():
        raise RuntimeError("coverage data file is missing")
    cov = Coverage(data_file=str(coverage_file))
    cov.load()
    buffer = io.StringIO()
    percent = float(cov.report(morfs=morfs, file=buffer, skip_empty=True))
    rounded = int(percent + 0.5)
    if write_artifacts:
        xml_path = ARTIFACTS / "coverage.xml"
        cov.xml_report(outfile=str(xml_path))
        root = parse_xml(xml_path, forbid_dtd=True).getroot()
        compact = {
            "meta": {"format": 3, "version": "compact-cobertura-summary", "branch_coverage": True},
            "files": {},
            "totals": {
                "covered_lines": int(root.attrib.get("lines-covered", "0") or 0),
                "num_statements": int(root.attrib.get("lines-valid", "0") or 0),
                "percent_covered": rounded,
                "percent_covered_display": str(rounded),
                "covered_branches": int(root.attrib.get("branches-covered", "0") or 0),
                "num_branches": int(root.attrib.get("branches-valid", "0") or 0),
            },
        }
        (ARTIFACTS / "coverage.json").write_text(json.dumps(compact, indent=2) + "\n", encoding="utf-8")
    stdout = f"{rounded}\n"
    result = {
        "ok": rounded >= int(threshold),
        "returncode": 0 if rounded >= int(threshold) else 2,
        "command": ["in-process", "coverage-report"],
        "stdout": stdout,
        "stderr": "" if rounded >= int(threshold) else f"Coverage {rounded}% is below fail-under={threshold}%",
    }
    print(stdout.rstrip())
    if not result["ok"]:
        raise RuntimeError(f"{label} failed: {result['stderr']}")
    return result


def run_inprocess(label: str, check) -> dict[str, Any]:
    """Run deterministic AST/file checks in-process.

    Railway/CI runners can keep inherited descriptors or child processes alive
    after integration tests. Pure Python checks do not need a subprocess, and
    running them in-process avoids spurious ``context canceled``/timeout
    failures without weakening the validation.
    """
    print(f"[quality] {label}", flush=True)
    try:
        returncode = int(check() or 0)
        stdout = f"{label} completed"
        stderr = ""
    except Exception as exc:
        returncode = 1
        stdout = ""
        stderr = f"{type(exc).__name__}: {exc}"
    result = {
        "ok": returncode == 0,
        "returncode": returncode,
        "command": ["in-process", label],
        "stdout": stdout,
        "stderr": stderr,
    }
    if stderr:
        print(stderr, file=sys.stderr)
    if returncode:
        raise RuntimeError(f"{label} failed with exit code {returncode}")
    return result

def _module_available(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def _git_commit() -> str:
    configured = str(os.getenv("GITHUB_SHA") or os.getenv("RAILWAY_GIT_COMMIT_SHA") or "").strip()
    if configured:
        return configured
    git = shutil.which("git")
    if not git:
        return "unavailable"
    result = subprocess.run(  # nosec B603
        [git, "rev-parse", "HEAD"], cwd=ROOT, text=True, capture_output=True, check=False,
    )
    return result.stdout.strip() if result.returncode == 0 else "unavailable"


def _pip_version() -> str:
    result = subprocess.run(  # nosec B603
        [sys.executable, "-m", "pip", "--version"], text=True, capture_output=True, check=False,
    )
    return result.stdout.strip() or "unavailable"


def _coverage_percent(output: str) -> int:
    match = re.search(r"TOTAL\s+\d+\s+\d+(?:\s+\d+\s+\d+)?\s+(\d+)%", output)
    if match:
        return int(match.group(1))
    compact = re.search(r"(?:^|\n)\s*(\d+(?:\.\d+)?)\s*(?:%|$)", output.strip())
    return int(float(compact.group(1))) if compact else 0


def _test_totals(output: str) -> tuple[int, int, int]:
    passed = re.search(r"(\d+) passed", output)
    skipped = re.search(r"(\d+) skipped", output)
    failed = re.search(r"(\d+) failed", output)
    return (
        int(passed.group(1)) if passed else 0,
        int(skipped.group(1)) if skipped else 0,
        int(failed.group(1)) if failed else 0,
    )


def _collected_total(output: str) -> int:
    match = re.search(r"(\d+) tests? collected", output)
    if match:
        return int(match.group(1))
    # ``pytest --collect-only -qq`` emits compact ``path: count`` lines. This
    # keeps release logs bounded even as the suite grows and avoids flooding
    # CI/terminal transports with every node id.
    compact_counts = [
        int(match.group(1))
        for line in output.splitlines()
        if (match := re.fullmatch(r"[^\r\n]+\.py:\s+(\d+)\s*", line.strip()))
    ]
    if compact_counts:
        return sum(compact_counts)
    node_ids = [line for line in output.splitlines() if "::test" in line and not line.lstrip().startswith(("<", "="))]
    return len(node_ids)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proof", type=Path, default=ROOT / "QUALITY_PROOF.json")
    parser.add_argument("--release-channel", choices=("candidate", "production"), default="candidate")
    parser.add_argument("--known-handlers", type=int, default=0)
    parser.add_argument("--full-suite", action="store_true")
    parser.add_argument("--enforce-production-thresholds", action="store_true")
    parser.add_argument("--allow-postbuild-attestation", action="store_true")
    parser.add_argument("--candidate-line-threshold", type=int, default=13)
    parser.add_argument("--candidate-critical-threshold", type=int, default=75)
    args = parser.parse_args()
    production = args.release_channel == "production"
    full_suite = production or args.full_suite
    strict_thresholds = production or args.enforce_production_thresholds
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    results: dict[str, dict[str, Any]] = {}
    # Materialize deterministic Mini App assets before binding the quality run
    # to the source fingerprint. Otherwise the gate itself could modify a
    # deployable asset after the fingerprint was captured and either create a
    # false source-change failure or, worse, certify a different asset set.
    results["webapp_assets"] = run(
        "build Mini App assets",
        [sys.executable, "scripts/build_webapp_assets.py"],
    )
    results["runtime_test_bundle"] = run_inprocess("refresh runtime test bundle", _prepare_test_bundle)
    # Bind the entire quality run to one immutable source fingerprint. Without
    # this guard, a file changed after pytest but before finalization could be
    # included in the proof without having been executed by the recorded test
    # run. The finalizer verifies this exact value again before writing proof.
    source_sha256_before = source_fingerprint(ROOT)

    compile_targets = [
        str(ROOT / name) for name in (
            "main.py", "bot.py", "config.py", "bot_runtime", "core", "modules", "services",
            "repositories", "handlers", "jobs", "scripts", "ui", "tests",
        ) if (ROOT / name).exists()
    ]
    async_test_count = sum(
        path.read_text(encoding="utf-8").count("@pytest.mark.asyncio")
        for path in (ROOT / "tests").glob("test_*.py")
    )
    if full_suite and async_test_count and not _module_available("pytest_asyncio"):
        raise RuntimeError(
            f"pytest-asyncio is required: {async_test_count} coroutine tests would otherwise be skipped"
        )

    results["compile"] = run("compile", [sys.executable, "-m", "compileall", "-q", *compile_targets])

    # Every release channel executes the complete deterministic offline suite.
    # Candidate proofs may no longer omit newer/legacy test modules.
    test_targets: list[str] = []
    coverage_targets: list[str] = []
    collect_command = [sys.executable, "-m", "pytest", "--collect-only", "-qq", *test_targets]
    results["pytest_collect"] = run("pytest collection", collect_command)
    # pytest.ini already supplies ``-q``. Adding another quiet flag suppresses
    # the final "N passed" summary and made the gate believe zero tests ran.
    junit_path = ARTIFACTS / "junit.xml"
    pytest_command = [
        sys.executable, str(ROOT / "scripts" / "pytest_isolated_runner.py"), *test_targets,
        f"--junitxml={junit_path}",
    ]
    test_timeout = max(420, min(1800, int(os.getenv("SENTINEL_TEST_TIMEOUT_SECONDS", "1200") or 1200)))
    results["pytest"] = run("pytest", pytest_command, timeout=test_timeout)

    deferred: dict[str, dict[str, Any]] = {}
    telegram_available = _module_available("telegram")
    ruff_available = _module_available("ruff")
    bandit_available = _module_available("bandit")
    if not telegram_available:
        deferred["telegram_runtime_tests"] = {
            "status": "not_exercised",
            "reason": "python-telegram-bot was unavailable; the test suite did not exercise the real Telegram runtime",
        }

    if production or telegram_available:
        results["application_build"] = run("application build check", [sys.executable, "main.py", "--check"])
    else:
        deferred["application_build"] = {"status": "not_run", "reason": "python-telegram-bot unavailable locally"}

    # Candidate images must block on correctness defects, not on the large
    # legacy formatting/import backlog. Production releases still enforce the
    # complete Ruff, Bandit and Mypy profiles. This prevents Railway candidate
    # builds from failing on hundreds of auto-fixable style findings while
    # retaining hard checks for syntax errors, invalid control flow and
    # undefined names.
    if production:
        results["ruff"] = run("Ruff full", [sys.executable, "-m", "ruff", "check", "."])
    elif ruff_available:
        results["ruff"] = run(
            "Ruff critical correctness",
            [
                sys.executable, "-m", "ruff", "check", ".",
                "--select", "E9,F63,F7,F82",
            ],
        )
        deferred["ruff_full_profile"] = {
            "status": "candidate_scope",
            "reason": "full style/import cleanup is enforced for production releases",
        }
    else:
        deferred["ruff"] = {"status": "not_run", "reason": "Ruff unavailable locally"}

    if production or bandit_available:
        results["bandit"] = run(
            "Bandit",
            [sys.executable, "-m", "bandit", "-q", "-r", "main.py", "bot.py", "config.py", "core", "modules", "services", "repositories", "bot_runtime", "handlers", "jobs", "scripts", "ui"],
            timeout=240,
        )
    else:
        deferred["bandit_full_profile"] = {
            "status": "candidate_scope",
            "reason": "the built-in security scan remains blocking; full Bandit is production-only",
        }

    if production:
        results["mypy"] = run(
            "Mypy focused type check",
            [sys.executable, "-m", "mypy", "core/async_runtime.py", "core/connection_limits.py", "core/storage/engine.py", "modules/receipt_storage.py", "scripts/quality_utils.py", "scripts/release_gate.py"],
        )
    else:
        deferred["mypy_full_profile"] = {
            "status": "candidate_scope",
            "reason": "focused Mypy enforcement is reserved for production releases",
        }

    lock_status = json.loads((ROOT / "DEPENDENCY_LOCK_STATUS.json").read_text(encoding="utf-8"))
    if not lock_status.get("complete_transitive_lock") or not lock_status.get("hashes_required"):
        deferred["dependency_hash_lock"] = {
            "status": "incomplete",
            "reason": "generate a complete Python 3.12 transitive lock with hashes before production",
        }
    results["dependency_lock"] = run(
        "dependency lock",
        [sys.executable, "scripts/verify_dependency_lock.py", *(["--require-hashes"] if production else [])],
    )
    from circular_import_check import main as circular_import_main
    from dependency_boundary_check import main as dependency_boundary_main
    from security_scan import main as security_scan_main

    results["dependency_boundaries"] = run_inprocess("dependency boundaries", dependency_boundary_main)
    results["circular_imports"] = run_inprocess("circular imports", circular_import_main)
    results["security_scan"] = run_inprocess("built-in security scan", security_scan_main)
    smoke_artifact = ARTIFACTS / "standalone_smokes.json"

    def _generate_smoke_artifact() -> int:
        from scripts.manual_payment_smoke import run_manual_payment_smoke
        from scripts.ops.load_smoke import run_load_smoke
        from scripts.staging_smoke import offline_contract

        payload = {
            "offline": offline_contract(),
            "load": run_load_smoke(operations=24, workers=8),
            "manual_payment": run_manual_payment_smoke(operations=60),
        }
        smoke_artifact.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return 0

    results["standalone_smokes"] = run_inprocess(
        "generate standalone smoke artifacts",
        _generate_smoke_artifact,
    )
    results["performance_budgets"] = run(
        "performance budgets",
        [sys.executable, "scripts/performance_smoke.py"],
        timeout=120,
    )

    def _smoke_artifact_check() -> int:
        if not smoke_artifact.is_file():
            raise RuntimeError("standalone smoke artifact is missing")
        payload = json.loads(smoke_artifact.read_text(encoding="utf-8"))
        offline = payload.get("offline") if isinstance(payload.get("offline"), dict) else {}
        load = payload.get("load") if isinstance(payload.get("load"), dict) else {}
        payment = payload.get("manual_payment") if isinstance(payload.get("manual_payment"), dict) else {}
        if not offline.get("version") or int(offline.get("schema_version", 0) or 0) < 1:
            raise RuntimeError("offline staging contract artifact is incomplete")
        if load.get("status") != "passed" or int(load.get("successes", 0)) != 24:
            raise RuntimeError(f"load smoke artifact failed: {load}")
        if payment.get("status") != "passed" or int(payment.get("approved", 0)) != 60:
            raise RuntimeError(f"manual payment smoke artifact failed: {payment}")
        return 0

    results["offline_smoke"] = run_inprocess("offline staging smoke artifact", _smoke_artifact_check)
    results["load_smoke"] = run_inprocess("normalized concurrency load smoke artifact", _smoke_artifact_check)
    results["javascript"] = run("Mini App JavaScript", [node_executable(), "scripts/check_miniapp_js.js"])

    docker_attested = str(os.getenv("SENTINEL_DOCKER_BUILD_STATUS") or "").lower() == "passed"
    image_digest = configured_image_digest()
    if not docker_attested:
        deferred["docker_build_no_cache"] = {
            "status": "not_run",
            "reason": "Docker is unavailable or the post-build attestation has not been recorded",
        }
    if not image_digest:
        deferred["docker_image_digest"] = {"status": "not_recorded", "reason": "image digest is assigned after image build"}

    acceptance_path = ARTIFACTS / "production_acceptance.json"
    acceptance = {}
    if acceptance_path.is_file():
        try:
            acceptance = json.loads(acceptance_path.read_text(encoding="utf-8"))
        except Exception:
            acceptance = {}
    expected_version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    acceptance_errors = production_acceptance_errors(
        acceptance, version=expected_version, source_sha256=source_sha256_before, image_digest=image_digest,
    )
    if acceptance_errors:
        deferred["external_production_acceptance"] = {
            "status": "not_attested",
            "reason": "; ".join(acceptance_errors),
        }
    mt5_evidence = mt5_acceptance_details(ROOT)
    if mt5_evidence.get("ok") is not True:
        deferred["mt5_ex5_compile_and_demo"] = {
            "status": "not_attested",
            "reason": "; ".join(mt5_evidence.get("errors") or []),
        }

    allowed_postbuild = {"docker_build_no_cache", "docker_image_digest"} if args.allow_postbuild_attestation else set()
    blocking_deferred = set(deferred) - allowed_postbuild
    if production and blocking_deferred:
        raise RuntimeError(f"production proof cannot contain deferred validations: {', '.join(sorted(blocking_deferred))}")

    discovered = _collected_total(results["pytest_collect"]["stdout"] + results["pytest_collect"]["stderr"])
    if discovered <= 0:
        discovered = automated_test_count(ROOT)
    passed, skipped, failed = _test_totals(results["pytest"]["stdout"] + results["pytest"]["stderr"])
    junit_totals = _junit_totals(junit_path)
    if junit_totals is not None:
        total, failures, errors, skipped = junit_totals
        failed = failures + errors
        passed = max(0, total - skipped - failed)
    executed = passed + skipped + failed
    if full_suite and executed < discovered:
        raise RuntimeError(f"pytest executed {executed} of {discovered} discovered tests")

    build_text = (results.get("application_build") or {}).get("stdout", "")
    handlers_match = re.search(r"handlers=(\d+)", str(build_text))
    handler_count = int(handlers_match.group(1)) if handlers_match else max(0, int(args.known_handlers))
    handler_source = "application_build" if handlers_match else ("known_baseline" if handler_count else "not_verified")
    overall_threshold = 40 if strict_thresholds else max(0, int(args.candidate_line_threshold))
    critical_threshold = 85 if strict_thresholds else max(0, int(args.candidate_critical_threshold))
    stage = {
        "proof_path": str(args.proof.resolve()),
        "release_channel": args.release_channel,
        "results": results,
        "deferred_validation": deferred,
        "dependency_lock": lock_status,
        "docker_image_digest": image_digest or None,
        "commit_sha": _git_commit(),
        "pip": _pip_version(),
        "source_sha256_before": source_sha256_before,
        "discovered": discovered,
        "executed": executed,
        "passed": passed,
        "skipped": skipped,
        "failed": failed,
        "handler_count": handler_count,
        "handler_source": handler_source,
        "telegram_test_runtime": "real_python_telegram_bot" if telegram_available else "not_exercised",
        "candidate_thresholds": {
            "line_coverage_percent": int(args.candidate_line_threshold),
            "critical_path_coverage_percent": int(args.candidate_critical_threshold),
        },
        "overall_threshold": overall_threshold,
        "critical_threshold": critical_threshold,
        "test_targets": coverage_targets,
    }
    stage_path = ARTIFACTS / "quality_stage.json"
    stage_path.write_text(json.dumps(stage, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("[quality] coverage execution and final proof", flush=True)
    # Run the finalizer in a fresh isolated process instead of replacing this
    # interpreter with os.execv. Some container/PTY runtimes keep the exec'd
    # process attached after its coverage child has exited, which makes Railway
    # report a false build timeout even though every test passed. The finalizer
    # already terminates with os._exit, so a close-fds process group gives the
    # same isolation while allowing the quality-gate parent to reap it cleanly.
    command = [sys.executable, str(ROOT / "scripts" / "finalize_quality_proof.py"), "--state", str(stage_path)]
    timeout_seconds = max(180, min(3000, int(os.getenv("SENTINEL_QUALITY_FINALIZER_TIMEOUT", "1560") or 1560)))
    process = subprocess.Popen(  # nosec B603 -- fixed internal finalizer command
        command,
        cwd=ROOT,
        close_fds=True,
        start_new_session=(os.name != "nt"),
    )
    try:
        returncode = int(process.wait(timeout=timeout_seconds))
    except subprocess.TimeoutExpired as exc:
        if os.name != "nt":
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        else:
            process.kill()
        process.wait(timeout=10)
        raise RuntimeError(f"quality finalizer exceeded {timeout_seconds} seconds") from exc
    if returncode:
        raise RuntimeError(f"quality finalizer failed with exit code {returncode}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"QUALITY GATE FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
