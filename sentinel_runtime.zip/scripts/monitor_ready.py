#!/usr/bin/env python3
"""Independent readiness monitor; run outside the bot's process/container."""
from __future__ import annotations
import argparse
import json
import logging
import time
from urllib.error import URLError
from urllib.request import Request,urlopen
from urllib.parse import urlsplit


def probe(base_url: str, timeout: float = 8) -> tuple[bool,str]:
    parts=urlsplit(base_url)
    if parts.scheme not in {'http','https'} or not parts.hostname or parts.username or parts.password:
        raise ValueError('Use an HTTP(S) base URL without credentials')
    try:
        with urlopen(Request(base_url.rstrip('/')+'/ready',headers={'Accept':'application/json'}),timeout=timeout) as response:  # nosec B310 -- validated HTTP(S) only
            data=json.loads(response.read(65536))
        payload=data.get('data',data)
        ready=bool(payload.get('ready',False))
        return ready,'ready' if ready else 'readiness_failed'
    except (OSError,URLError,ValueError) as exc:
        return False,type(exc).__name__


def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument('base_url')
    parser.add_argument('--minutes',type=int,default=80)
    parser.add_argument('--interval',type=int,default=15)
    parser.add_argument('--failure-limit',type=int,default=3)
    args=parser.parse_args()
    if not 1<=args.minutes<=1440 or not 5<=args.interval<=60 or not 1<=args.failure_limit<=10:parser.error('Invalid bounded monitoring settings')
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    deadline=time.monotonic()+args.minutes*60
    failures=0
    unhealthy=False
    try:
        while time.monotonic()<deadline:
            healthy,reason=probe(args.base_url)
            failures=0 if healthy else failures+1
            logging.log(logging.INFO if healthy else logging.ERROR,'Readiness=%s reason=%s consecutive=%s',healthy,reason,failures)
            if failures>=args.failure_limit:unhealthy=True
            time.sleep(min(args.interval,max(0,deadline-time.monotonic())))
    except KeyboardInterrupt:
        return 130
    return 1 if unhealthy else 0


if __name__=='__main__':raise SystemExit(main())
