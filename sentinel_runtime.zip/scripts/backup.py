#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config import SETTINGS  # noqa: E402
from core.db import load_db  # noqa: E402


async def _run() -> Path:
    from core.full_backup import perform_complete_backup
    if not SETTINGS.database_url and not SETTINGS.db_file.is_file():
        load_db()
    return await perform_complete_backup(SETTINGS)


def main() -> int:
    target = asyncio.run(_run())
    print(f"Backup created: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
