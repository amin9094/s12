#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core import google_sheets_backup as sheets  # noqa: E402


def main() -> int:
    cfg = sheets.config()
    result: dict[str, object] = {
        "enabled": bool(cfg.enabled),
        "configured": bool(sheets.is_configured()),
        "spreadsheet_id_present": bool(cfg.spreadsheet_id),
        "service_account_email": sheets.service_account_email(),
        "write_failover": bool(cfg.write_failover),
        "auto_reconcile": bool(cfg.auto_reconcile),
        "projection_enabled": bool(cfg.projection_enabled),
        "timeout_seconds": cfg.timeout_seconds,
        "max_retries": cfg.max_retries,
        "pending_sections": sorted(sheets.pending_sections()),
        "normalized_pending_tables": sorted(sheets.normalized_pending_tables()),
    }
    if not result["configured"]:
        result["health"] = False
        result["error"] = "Google Sheets is not fully configured"
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2
    try:
        result["health"] = bool(sheets.healthcheck())
        if result["health"]:
            result["raw_backup_metadata"] = sheets.raw_backup_metadata()
    except Exception as exc:
        result["health"] = False
        result["error"] = f"{exc.__class__.__name__}: {str(exc)[:500]}"
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    return 0 if result.get("health") else 1


if __name__ == "__main__":
    raise SystemExit(main())
