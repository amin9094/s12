/* Execute the real desk code against a small DOM adapter; no synthetic live attestation. */
'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'../webapp/src/iran-equities.js'),'utf8');
function environment(){
    const elements=new Map(),calls=[],toasts=[];
    const element=selector=>{
        if(!elements.has(selector))elements.set(selector,{value:'',hidden:false,textContent:'',innerHTML:'',disabled:false,
            querySelectorAll:()=>[],addEventListener:()=>{}});
        return elements.get(selector);
    };
    element('#iranEquityQuery').value='فولاد';
    const c={console,URLSearchParams,Map,setTimeout,clearTimeout,document:{querySelectorAll:()=>[],removeEventListener:()=>{}},
        state:{lang:'fa',resources:{overview:{admin_available:true,admin:{role:'owner'}}},modalGeneration:0},
        $:element,esc:v=>String(v??''),toast:(...args)=>toasts.push(args),
        openModal:()=>{c.state.modalGeneration++;element('#modalLayer').hidden=false;},
        request:async url=>{calls.push(url);return url.includes('/search?')?{items:[{ins_code:'46348559193224090',symbol:'فولاد',title:'نمونه'}]}:{items:[],legacy_items:[]};},
        acceptChartSource:()=>{},loadChartLibrary:async()=>{throw new Error('synthetic chart library outage');}};
    vm.createContext(c);vm.runInContext(source,c);
    return {c,element,calls,toasts};
}
(async()=>{
    let e=environment();await e.c.iranEquitiesDesk();
    assert(e.calls.some(url=>url.includes('/search?')),'opening an empty desk must run search');
    assert(e.element('#iranEquityResults').innerHTML.includes('46348559193224090'),'InsCode must remain exact');
    assert.strictEqual(e.element('#iranEquitySearch button').disabled,false);
    e=environment();e.c.state.resources.overview={admin_available:false};await e.c.iranEquitiesDesk();
    assert.strictEqual(e.calls.length,0);assert(e.toasts[0][0].includes('مجوز'));
    e=environment();e.c.request=async()=>{throw {code:'TSETMC_SOURCE_UNAVAILABLE'};};await e.c.iranEquitiesDesk();
    assert(e.element('#iranEquityStatus').textContent.includes('اتصال سرور'));
    assert.strictEqual(e.element('#iranEquitySearch button').disabled,false);
    e=environment();await e.c.iranEquitiesDesk();
    e.c.request=async()=>({ins_code:'46348559193224090',symbol:'فولاد',timeframe:'1d',currency:'IRR',
        adjustment:'UNADJUSTED',provider:'tsetmc',product:'iran_cash_equity',venue:'TSE',
        latest_trade_date:'2026-10-14',bars:[],analysis:{state:'DAILY_REVIEW_AVAILABLE',trend:'UP',indicators:{rsi14:60}}});
    await e.c.openIranEquityChart('46348559193224090',()=>true,'1d');
    assert(e.element('#iranEquityAnalysis').innerHTML.includes('تحلیل روزانه آماده است'));
    assert(e.element('#iranEquityStatus').textContent.includes('نمودار بارگیری نشد'));
    assert(e.element('#iranEquityStatus').textContent.includes('تحلیل'));
    e=environment();let resolveDesk;
    e.c.request=url=>url.includes('/desk?')?new Promise(r=>{resolveDesk=r;}):Promise.resolve({items:[]});
    await e.c.iranEquitiesDesk();e.c.state.modalGeneration++;
    e.element('#iranAnalysisHistory').textContent='new modal';resolveDesk({items:[],legacy_items:[]});
    await new Promise(r=>setTimeout(r,0));assert.strictEqual(e.element('#iranAnalysisHistory').textContent,'new modal');
    process.stdout.write('Iran equity UI contracts passed (5 scenarios)\n');
})().catch(error=>{console.error(error);process.exitCode=1;});
