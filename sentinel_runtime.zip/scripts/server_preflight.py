#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    from config import SETTINGS
    from core.storage.engine import normalized_engine
    from core.storage.migration import migration_status
    from core.shared_cache import shared_cache_healthcheck
    from modules.receipt_storage import receipt_storage_status

    SETTINGS.validate()
    engine = normalized_engine()
    engine.ensure_schema()
    database = engine.healthcheck()
    migration = migration_status(engine)
    receipts = receipt_storage_status()
    cache = asyncio.run(shared_cache_healthcheck(require_redis=bool(SETTINGS.redis_url)))
    checks = {
        'configuration': True,
        'database': bool(database),
        'migration': bool(migration.get('complete')),
        'receipt_storage': bool(receipts.get('healthy')) and (
            not SETTINGS.webapp_api_enabled or bool(receipts.get('persistent'))
        ),
        'redis': bool(cache.get('healthy')) and (
            not SETTINGS.redis_url or cache.get('backend') == 'redis'
        ),
    }
    payload = {
        'ok': all(checks.values()),
        'version': SETTINGS.release_version,
        'run_mode': SETTINGS.run_mode,
        'checks': checks,
        'migration_state': migration.get('state'),
        'receipt_backend': receipts.get('backend'),
        'cache_backend': cache.get('backend'),
    }
    print(json.dumps(payload, ensure_ascii=False))
    return 0 if payload['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
