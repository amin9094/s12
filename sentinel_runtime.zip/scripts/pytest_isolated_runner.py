#!/usr/bin/env python3
"""Run pytest to completion, then terminate the isolated worker deterministically.

Unlike treating a newly-written JUnit file as an early success signal, this
wrapper waits for ``pytest.main`` to return after fixture/plugin teardown. Any
teardown failure therefore affects the exit code before ``os._exit`` prevents
unrelated non-daemon runtime threads from hanging CI.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import pytest


def main() -> int:
    return int(pytest.main(sys.argv[1:]) or 0)


if __name__ == "__main__":
    code = 1
    try:
        code = main()
    finally:
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        finally:
            os._exit(code)
