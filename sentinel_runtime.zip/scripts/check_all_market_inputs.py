#!/usr/bin/env python3
"""Read-only source audit of every configured symbol/timeframe, not execution readiness."""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


async def inspect(timeframes):
    from core.http_client import close_http_client
    from modules.canonical_market import TIMEFRAMES
    from services import canonical_market_service as market
    from services.market_data_issues import safe_market_error
    from services.iran_equity_service import equity_chart
    report = {'kind':'REAL_READ_ONLY_ALL_CHART_INPUT_AUDIT', 'started_ms':int(time.time()*1000),
              'chart_checks':[], 'iran_equities':[], 'messages_sent':0, 'orders_sent':0,
              'execution_eligible':False, 'deployment_only_remaining':False}
    semaphore=asyncio.Semaphore(3)
    try:
        universe=await market.universe()
        report['universe']=universe
        symbols=universe['core_symbols']+[r['symbol'] for r in universe['crypto_top20']]
        async def check(symbol,tf):
            row={'symbol':symbol,'timeframe':tf}
            async with semaphore:
                try:
                    async with asyncio.timeout(25):
                        bars=await market.historical_bars(symbol,tf,limit=120)
                    last=bars[-1]; now=int(time.time()*1000)
                    row.update(state='AVAILABLE',provider=last.provider,venue=last.venue,product=last.product,
                               bars=len(bars),closed_bars=sum(b.is_closed for b in bars),
                               last_candle_close=str(last.close),last_candle_start_ms=last.start_ms,
                               current_candles=0<=now-last.start_ms<=2*TIMEFRAMES[tf],
                               volume_kind=last.volume_kind,quality_flags=sorted({f for b in bars for f in b.quality_flags}),
                               bid_ask_state='NOT_CERTIFIED_BY_CANDLES',observed_ms=now)
                except Exception as exc:
                    row.update(state='UNAVAILABLE',reason=safe_market_error(exc))
            return row
        report['chart_checks']=await asyncio.gather(*(check(s,tf) for s in symbols for tf in timeframes))
        # Direct unkeyed REST tickers are snapshots, never continuous pre-touch proof.
        try:
            data=await market._request('https://www.okx.com/api/v5/market/tickers',{'instType':'SPOT'})
            directory={r['instId']:r for r in data.get('data',[]) if isinstance(r,dict) and r.get('instId')}
            quotes=[]
            from modules.canonical_market import price
            for item in universe['crypto_top20']:
                symbol=item['symbol'];native=symbol[:-4]+'-USDT';raw=directory.get(native)
                if not raw:
                    try:
                        pair=market.kraken_rest_pair(symbol)
                        result=await market._request('https://api.kraken.com/0/public/Ticker',{'pair':pair})
                        items=list((result.get('result') or {}).values())
                        if result.get('error') or len(items)!=1:raise ValueError('KRAKEN_TICKER_INVALID')
                        bid,ask=price(items[0]['b'][0]),price(items[0]['a'][0])
                        quotes.append({'symbol':symbol,'provider':'kraken','venue':'kraken_spot_USDT','product':'spot',
                                       'bid':str(bid),'ask':str(ask),'state':'UNTIMESTAMPED_SNAPSHOT',
                                       'exchange_event_ms':None,'observed_ms':int(time.time()*1000),
                                       'continuous_pretouch_proof':False})
                    except Exception:
                        quotes.append({'symbol':symbol,'state':'SNAPSHOT_UNAVAILABLE'})
                    continue
                bid,ask=price(raw.get('bidPx')),price(raw.get('askPx'));stamp=int(raw['ts']);now=int(time.time()*1000)
                quotes.append({'symbol':symbol,'provider':'okx','venue':'okx_spot_USDT','product':'spot',
                               'bid':str(bid),'ask':str(ask),'event_ms':stamp,
                               'state':'FRESH_SNAPSHOT' if bid<=ask and 0<=now-stamp<=5000 else 'STALE_OR_INVALID',
                               'continuous_pretouch_proof':False})
            report['crypto_quote_snapshots']=quotes
        except Exception as exc:
            report['crypto_quote_snapshots_error']=safe_market_error(exc)
        for tf in ('4h','1d'):
            try:
                async with asyncio.timeout(28):result=await equity_chart('46348559193224090',timeframe=tf)
                report['iran_equities'].append({'timeframe':tf,'state':'AVAILABLE','bars':len(result['bars']),
                                                'analysis_state':result['state']})
            except Exception:
                report['iran_equities'].append({'timeframe':tf,'state':'UNAVAILABLE',
                                                'reason':'TSETMC_SOURCE_OR_CONTRACT_UNAVAILABLE'})
        report['charts_available']=sum(r['state']=='AVAILABLE' for r in report['chart_checks'])
        report['charts_requested']=len(report['chart_checks'])
        report['all_requested_charts_available']=(len(universe['crypto_top20'])==20
            and all(r['state']=='AVAILABLE' and r.get('current_candles') for r in report['chart_checks'])
            and all(r['state']=='AVAILABLE' for r in report['iran_equities']))
        report['all_requested_inputs_available']=False  # No continuous feed audit is made here.
        report['finished_ms']=int(time.time()*1000)
        return report
    finally:
        await close_http_client()


def main():
    from modules.canonical_market import TIMEFRAMES
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--timeframes',nargs='+',choices=list(TIMEFRAMES),default=list(TIMEFRAMES))
    args=parser.parse_args()
    report=asyncio.run(inspect(args.timeframes))
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['all_requested_inputs_available'] else 2


if __name__=='__main__':
    raise SystemExit(main())
