#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import platform
import re
import os
import subprocess  # nosec B404
import signal
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from quality_utils import source_fingerprint

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from scripts.quality_policy import CRITICAL_TARGETS

MARKER_PATTERN = re.compile(r"SENTINEL_COVERAGE_RESULT=(\{[^\n]+\})")




def _run_isolated(command: list[str], *, timeout: int) -> subprocess.CompletedProcess[bytes]:
    """Run a coverage worker in its own process group and kill descendants on timeout.

    Coverage/integration helpers may briefly outlive pytest. Killing only the
    direct child can leave inherited terminal descriptors open and make the
    release process appear hung. This helper always owns and reaps the full tree.
    """
    process = subprocess.Popen(  # nosec B603 -- fixed internal quality command
        command, cwd=ROOT, close_fds=True,
        start_new_session=(os.name != "nt"),
    )
    try:
        returncode = process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name != "nt":
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        else:
            process.kill()
        process.wait(timeout=10)
        raise
    finally:
        if os.name != "nt":
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
    return subprocess.CompletedProcess(command, returncode)

def _coverage_result(percent: int, scope: str) -> dict[str, Any]:
    return {
        "ok": True,
        "returncode": 0,
        "command": ["coverage-worker", scope],
        "stdout": f"{int(percent)}\n",
        "stderr": "",
    }


def _run_coverage_worker_inprocess(arguments: list[str]) -> int:
    """Run only the compact report phase in this clean finalizer process."""
    import coverage_gate_worker

    previous = list(sys.argv)
    try:
        sys.argv = ["coverage_gate_worker.py", *arguments]
        return int(coverage_gate_worker.main() or 0)
    finally:
        sys.argv = previous


def _combine_parallel_coverage() -> bool:
    """Combine safely flushed parallel data after a forced pytest teardown."""
    fragments = list(ROOT.glob(".coverage.*"))
    if not fragments:
        return (ROOT / ".coverage").is_file()
    from coverage import Coverage

    cov = Coverage(data_file=str(ROOT / ".coverage"))
    cov.combine(data_paths=[str(ROOT)], strict=False)
    cov.save()
    return (ROOT / ".coverage").is_file()


def finalize_state(state_path: Path) -> int:
    state_path = state_path if state_path.is_absolute() else ROOT / state_path
    state = json.loads(state_path.read_text(encoding="utf-8"))

    coverage_result_path = ROOT / "quality-artifacts" / "coverage_result.json"
    coverage_result_path.unlink(missing_ok=True)
    coverage_file = ROOT / ".coverage"
    # Data timestamps cannot attest that instrumented tests passed. Always run
    # a fresh worker, including a retry after a failed finalization.
    command = [
        sys.executable,
        str(ROOT / "scripts" / "coverage_gate_worker.py"),
        "--overall-threshold",
        str(int(state["overall_threshold"])),
        "--critical-threshold",
        str(int(state["critical_threshold"])),
        "--result-file",
        str(coverage_result_path),
        *[str(item) for item in state.get("test_targets", [])],
    ]
    # Coverage runs in an isolated worker that terminates with os._exit after
    # writing artifacts. This prevents helper threads from keeping the quality
    # finalizer alive after a fully passing test run.
    returncode: int | None = None
    # Run the full instrumented suite in a separate process group. Some
    # integration helpers keep interpreter teardown alive after Coverage.py
    # has flushed a valid parallel data file. A bounded outer timeout turns
    # that into a deterministic recovery path instead of a hanging release.
    worker_timeout = max(90, min(2400, int(os.getenv("SENTINEL_COVERAGE_WORKER_TIMEOUT", "1500") or 1500)))
    try:
        completed = _run_isolated(command, timeout=worker_timeout)
        returncode = int(completed.returncode)
    except subprocess.TimeoutExpired:
        returncode = 124
    if not coverage_file.is_file():
        _combine_parallel_coverage()
    # A coverage data file is not proof that the instrumented tests passed.
    # coverage_gate_worker returns non-zero for any pytest failure (and only
    # converts a forced teardown to success after proving a complete passing
    # run). Never replace that failure with a successful report-only phase.
    if returncode:
        raise RuntimeError(f"coverage test worker failed with exit code {returncode}")

    # Only a successful current worker may use the report-only path.
    if not coverage_result_path.is_file():
        if not coverage_file.is_file() and not _combine_parallel_coverage():
            raise RuntimeError(f"coverage worker failed with exit code {returncode} before writing coverage data")
        report_arguments = [
            "--report-phase",
            "--overall-threshold",
            str(int(state["overall_threshold"])),
            "--critical-threshold",
            str(int(state["critical_threshold"])),
            "--result-file",
            str(coverage_result_path),
        ]
        returncode = _run_coverage_worker_inprocess(report_arguments)
    if returncode:
        raise RuntimeError(f"coverage report worker failed with exit code {returncode}")
    if not coverage_result_path.is_file():
        raise RuntimeError("coverage worker did not write its result artifact")
    coverage = json.loads(coverage_result_path.read_text(encoding="utf-8"))
    coverage_result_path.unlink(missing_ok=True)

    results = state["results"]
    results["coverage_run"] = {
        "ok": True,
        "returncode": 0,
        "command": command,
        "stdout": MARKER_PATTERN.pattern + json.dumps(coverage, separators=(",", ":")),
        "stderr": "",
    }
    results["coverage"] = _coverage_result(int(coverage["overall"]), "overall")
    results["critical_coverage"] = _coverage_result(int(coverage["critical"]), "critical")
    coverage_exists = (ROOT / ".coverage").is_file()
    results["coverage_data"] = {
        "ok": coverage_exists,
        "returncode": 0 if coverage_exists else 1,
        "command": ["coverage-data"],
        "stdout": "",
        "stderr": "" if coverage_exists else "coverage data file is missing",
    }

    current_source_sha256 = source_fingerprint(ROOT)
    expected_source_sha256 = str(state.get("source_sha256_before") or "").strip()
    if not expected_source_sha256:
        raise RuntimeError("quality stage did not record its starting source fingerprint")
    if current_source_sha256 != expected_source_sha256:
        raise RuntimeError(
            "release source changed during quality validation; discard this run and rerun the complete quality gate"
        )

    proof = {
        "version": (ROOT / "VERSION").read_text(encoding="utf-8").strip(),
        "release_channel": state["release_channel"],
        "created_at": datetime.now(UTC).isoformat(),
        "source_sha256": current_source_sha256,
        "commit_sha": state["commit_sha"],
        "docker_image_digest": state.get("docker_image_digest") or None,
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "python_implementation": platform.python_implementation(),
        "pip": state["pip"],
        "dependency_lock": state["dependency_lock"],
        "automated_tests_discovered": int(state["discovered"]),
        "automated_tests_executed": int(state["executed"]),
        "tests_passed": int(state["passed"]),
        "tests_skipped": int(state["skipped"]),
        "tests_failed": int(state["failed"]),
        "telegram_handlers": int(state["handler_count"]),
        "telegram_handlers_source": state["handler_source"],
        "telegram_test_runtime": state["telegram_test_runtime"],
        "line_coverage_percent": int(coverage["overall"]),
        "critical_path_coverage_percent": int(coverage["critical"]),
        "critical_coverage_targets": list(CRITICAL_TARGETS),
        "candidate_thresholds": state["candidate_thresholds"],
        "production_thresholds": {"line_coverage_percent": 40, "critical_path_coverage_percent": 85},
        "validation": {name: bool(result.get("ok")) for name, result in results.items()},
        "deferred_validation": state["deferred_validation"],
        "artifacts": {
            "junit": "quality-artifacts/junit.xml",
            "coverage_xml": "quality-artifacts/coverage.xml",
            "coverage_json": "quality-artifacts/coverage.json",
        },
    }
    if not proof["validation"] or not all(proof["validation"].values()):
        failed = sorted(name for name, ok in proof["validation"].items() if not ok)
        raise RuntimeError(f"quality proof contains failed validation: {', '.join(failed)}")

    proof_path = Path(state["proof_path"])
    if not proof_path.is_absolute():
        proof_path = ROOT / proof_path
    proof_path.parent.mkdir(parents=True, exist_ok=True)
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    state_path.unlink(missing_ok=True)
    print(
        f"QUALITY GATE OK channel={proof['release_channel']} "
        f"executed={proof['automated_tests_executed']}/{proof['automated_tests_discovered']} "
        f"coverage={proof['line_coverage_percent']}% "
        f"critical={proof['critical_path_coverage_percent']}%",
        flush=True,
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args()
    return finalize_state(args.state)


if __name__ == "__main__":
    exit_code = 0
    try:
        exit_code = int(main() or 0)
    except Exception as exc:
        print(f"QUALITY FINALIZATION FAILED: {exc}", file=sys.stderr, flush=True)
        exit_code = 1
    finally:
        sys.stdout.flush(); sys.stderr.flush()
        os._exit(exit_code)
