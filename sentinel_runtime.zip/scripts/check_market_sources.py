#!/usr/bin/env python3
"""Read-only, small-quota probes. Reports capabilities without credentials."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


async def probe():
    from services.canonical_market_service import historical_bars, universe

    rows = []
    for symbol in ("XAUUSD", "US30", "US100", "EURUSD", "GBPUSD", "BTCUSD"):
        try:
            bars = await historical_bars(symbol, "5m", limit=2)
            bar = bars[-1]
            rows.append(
                {
                    "symbol": symbol,
                    "ok": True,
                    "provider": bar.provider,
                    "venue": bar.venue,
                    "product": bar.product,
                    "bars": len(bars),
                    "volume_kind": bar.volume_kind,
                    "bid_ask": "not_proven_by_ohlc",
                    "timestamp_ms": bar.start_ms,
                }
            )
        except Exception as exc:
            rows.append({"symbol": symbol, "ok": False, "error": str(exc)[:160], "error_type": type(exc).__name__})
    try:
        ranking = await universe()
    except Exception:
        ranking = {"crypto_ranking_state": "UNAVAILABLE"}
    from core.http_client import close_http_client

    await close_http_client()
    return {"probes": rows, "universe": ranking, "verified_entry_capability": "REQUIRES_MATCHING_BID_ASK_FEED"}


if __name__ == "__main__":
    print(json.dumps(asyncio.run(probe()), ensure_ascii=False))
