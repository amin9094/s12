#!/usr/bin/env python3
"""Build the direct-source Railway artifact without nested runtime archives."""
from __future__ import annotations

import argparse
import hashlib
import shutil
import stat
import subprocess  # nosec B404
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

FIXED_ZIP_TIME = (2026, 7, 25, 0, 0, 0)
RUNTIME_DIRS = (
    "bot_runtime", "core", "modules", "services", "repositories", "handlers",
    "jobs", "ui", "scripts", "assets", "webapp", "nginx", "systemd",
)
ROOT_FILES = (
    ".dockerignore", ".env.example", "Dockerfile", "Dockerfile.dockerignore",
    "Procfile", "railway.toml", "docker-compose.yml", "main.py", "bot.py",
    "config.py", "requirements.txt", "requirements.lock.txt",
    "DEPENDENCY_LOCK_STATUS.json", "VERSION", "README.md",
    "QUALITY_PROOF.json", "RELEASE_MANIFEST.json", "RELEASE_NOTES_V8.12.0_FA.md",
)
EXCLUDED_DIRS = {
    ".git", ".pytest_cache", ".ruff_cache", ".audit-cache", "__pycache__",
    "tests", ".github", "quality-artifacts", "htmlcov", "logs", "backups",
    "preview", ".venv", "venv",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".sqlite", ".sqlite3", ".db", ".log", ".tmp", ".zip"}
EXCLUDED_NAMES = {
    ".coverage", "sentinel_runtime.zip", "sentinel_runtime.zip.sha256",
    "restore_runtime.py", "SHA256SUMS.txt",
}


def _is_excluded_directory(name: str) -> bool:
    return name in EXCLUDED_DIRS or name.startswith(".venv")


def _allowed(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(_is_excluded_directory(part) for part in relative.parts):
        return False
    if path.name in EXCLUDED_NAMES or path.suffix.lower() in EXCLUDED_SUFFIXES:
        return False
    if relative.parts[:2] == ("data", "backups"):
        return False
    if relative.parts and relative.parts[0] == "data":
        return relative.as_posix() == "data/database.json"
    if relative.as_posix().startswith("assets/ui_stickers/preview/"):
        return False
    return True


def _runtime_files() -> list[Path]:
    files = [ROOT / name for name in ROOT_FILES if (ROOT / name).is_file()]
    files.append(ROOT / "data" / "database.json")
    for directory in RUNTIME_DIRS:
        base = ROOT / directory
        if base.is_dir():
            files.extend(path for path in base.rglob("*") if path.is_file() and _allowed(path))
    return sorted(set(files), key=lambda item: item.relative_to(ROOT).as_posix())


def _lean_dockerfile() -> bytes:
    source = (ROOT / "Dockerfile").read_text(encoding="utf-8")
    marker = "FROM python:3.12-slim-bookworm AS runtime\n"
    if source.count(marker) != 1:
        raise RuntimeError("unsupported runtime Docker stage")
    # The lean artifact is a direct-source runtime image. Quality is checked
    # before packaging; it cannot COPY from a bootstrap stage absent from ZIP.
    source = "# syntax=docker/dockerfile:1.7\n# Direct-source runtime; quality validated before packaging.\n" + marker + source.split(marker, 1)[1]
    source = source.replace("COPY --from=quality /app/requirements.lock.txt /tmp/requirements.lock.txt", "COPY requirements.lock.txt /tmp/requirements.lock.txt", 1)
    source = source.replace("COPY --from=quality /app /app", "COPY . /app", 1)
    source = source.replace("RUN test -s /app/.quality-stage-passed \\\n && python -m compileall", "RUN python -m compileall", 1)
    source = source.replace(
        "# the checksum-verified fallback bundle remain available.\n",
        "# all runtime source trees remain available; no nested fallback archive is required.\n",
    )
    source = source.replace(
        "RUN python restore_runtime.py --target /app \\\n    && python -m compileall -q \\\n",
        "RUN python -m compileall -q \\\n",
        1,
    )
    source = source.replace(
        "    && chown -R sentinel:sentinel /app \\\n    && rm -f /app/sentinel_runtime.zip /app/sentinel_runtime.zip.sha256\n",
        "    && chown -R sentinel:sentinel /app\n",
        1,
    )
    if "--from=quality" in source or "COPY restore_runtime.py" in source or ".quality-stage-passed" in source:
        raise RuntimeError("lean Dockerfile still depends on the excluded bootstrap stage")
    return source.encode("utf-8")


def _lean_dockerignore() -> bytes:
    # The bootstrap allowlist from the outer release would hide every direct
    # runtime file. The lean ZIP already admits only reviewed runtime sources.
    return b""".git
tests
quality-artifacts
logs
backups
__pycache__
**/__pycache__
*.pyc
**/*.pyc
.venv*
venv
.env*
!.env.example
**/*.sqlite
**/*.sqlite3
**/*.db
**/*.log
**/*.tmp
"""


def _write_zip(target: Path) -> None:
    import json

    from scripts.quality_utils import source_fingerprint
    proof = json.loads((ROOT / "QUALITY_PROOF.json").read_text(encoding="utf-8"))
    validations = proof.get("validation")
    if (proof.get("source_sha256") != source_fingerprint(ROOT)
            or not isinstance(validations, dict) or not validations
            or not all(value is True for value in validations.values())):
        raise RuntimeError("lean release requires a passing proof for the current source")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.unlink(missing_ok=True)
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in _runtime_files():
            relative = path.relative_to(ROOT).as_posix()
            if relative == "Dockerfile":
                payload = _lean_dockerfile()
            elif relative in {".dockerignore", "Dockerfile.dockerignore"}:
                payload = _lean_dockerignore()
            else:
                payload = path.read_bytes()
            info = zipfile.ZipInfo(relative, FIXED_ZIP_TIME)
            executable = bool(path.stat().st_mode & stat.S_IXUSR)
            info.external_attr = ((0o755 if executable else 0o644) & 0xFFFF) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, payload, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(temporary) as archive:
        broken = archive.testzip()
        if broken:
            raise RuntimeError(f"corrupt ZIP member: {broken}")
        names = set(archive.namelist())
        forbidden = [name for name in names if name.endswith(".zip") or "quality-artifacts/" in name or "__pycache__/" in name]
        if forbidden:
            raise RuntimeError(f"forbidden release members: {forbidden[:5]}")
        required = {
            "main.py", "bot.py", "Dockerfile", "railway.toml", "VERSION",
            "core/miniapp_server.py", "services/unified_support_service.py",
            "services/journal_pdf_service.py", "webapp/index.html",
            "webapp/assets/media/sentinel-loading.mp4",
        }
        missing = sorted(required - names)
        if missing:
            raise RuntimeError("missing runtime files: " + ", ".join(missing))
    temporary.replace(target)


def _verify_extracted(target: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="sentinel-lean-release-") as temp_dir:
        temp = Path(temp_dir)
        with zipfile.ZipFile(target) as archive:
            archive.extractall(temp)
        subprocess.run(  # nosec B603
            [sys.executable, "-m", "compileall", "-q", "main.py", "bot.py", "config.py", "bot_runtime", "core", "modules", "services", "repositories", "handlers", "jobs", "ui", "scripts"],
            cwd=temp, check=True, timeout=120,
        )
        node = shutil.which("node")
        if not node:
            raise RuntimeError("Node.js is required to verify a lean release")
        for js in sorted((temp / "webapp").rglob("*.js")):
            subprocess.run([node, "--check", str(js)], check=True, stdout=subprocess.DEVNULL, timeout=20)  # nosec B603
        code = (
            "import os,sys,telegram; "
            f"os.chdir({str(temp)!r}); sys.path.insert(0,{str(temp)!r}); "
            "import main; main.run_build_check()"
        )
        completed = subprocess.run([sys.executable, "-c", code], cwd=temp, text=True, capture_output=True, timeout=90)  # nosec B603
        if completed.returncode:
            raise RuntimeError(completed.stderr or completed.stdout)
        if "BUILD CHECK OK" not in completed.stdout:
            raise RuntimeError("extracted release did not complete application build check")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output if args.output.is_absolute() else ROOT / args.output
    _write_zip(output)
    _verify_extracted(output)
    digest = _sha256(output)
    print(f"LEAN RELEASE OK: {output}; bytes={output.stat().st_size}; sha256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
