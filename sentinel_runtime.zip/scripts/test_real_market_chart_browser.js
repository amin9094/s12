/* Render captured public source responses through the actual chart UI/library.
 * Source retrieval is separate; this does not test Telegram auth or WebView. */
const fs=require('fs');
const path=require('path');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');

async function main(){
  const file=process.argv[2];
  if(!file)throw new Error('CAPTURED_PUBLIC_CHART_JSON_REQUIRED');
  const capture=JSON.parse(fs.readFileSync(file,'utf8'));
  const rows=capture.items || [];
  if(!rows.length || rows.some(r=>!r.provider || !r.bars?.length))throw new Error('INCOMPLETE_REAL_SOURCE_CAPTURE');
  const browser=await chromium.launch({headless:true,executablePath:process.env.SENTINEL_TEST_BROWSER_PATH || undefined,args:['--no-sandbox']});
  try{
    const page=await browser.newPage({viewport:{width:412,height:915}}),errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    const html=`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><style>${fs.readFileSync(path.join(root,'webapp/src/styles.css'),'utf8')}</style></head>
      <body><div id="modalLayer" hidden><h2 id="modalTitle"></h2><span id="modalEyebrow"></span><div id="modalBody"></div></div>
      <script>
        const state={lang:'fa',modalGeneration:0,resources:{overview:{admin_available:false}}},tg={colorScheme:'dark'};
        const $=s=>document.querySelector(s),esc=v=>String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
        function openModal(e,t,b,a=[]){disposeMarketChart();state.modalGeneration++;$('#modalLayer').hidden=false;$('#modalTitle').textContent=t;$('#modalEyebrow').textContent=e;$('#modalBody').innerHTML=b;state.modalActions=a;}
        function closeModal(){disposeMarketChart();state.modalGeneration++;$('#modalLayer').hidden=true;}
        async function request(url){
          if(url.includes('/setups'))return {admin:false,items:[]};
          if(url.includes('/universe'))return {core_symbols:[],crypto_top20:[]};
          const args=new URL(url,'https://sentinel.test').searchParams;
          return (await fetch('/capture/'+args.get('symbol'))).json();
        }
      </script><script src="/live-chart.js"></script></body></html>`;
    await page.route('https://sentinel.test/**',async route=>{
      const url=new URL(route.request().url());
      if(url.pathname==='/harness')return route.fulfill({contentType:'text/html',body:html});
      if(url.pathname==='/live-chart.js')return route.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'webapp/src/live-chart.js'),'utf8')});
      if(url.pathname.endsWith('klinecharts-10.0.3.min.js'))return route.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'webapp/assets/vendor/klinecharts-10.0.3.min.js'),'utf8')});
      const item=rows.find(r=>url.pathname==='/capture/'+r.symbol);
      if(item)return route.fulfill({contentType:'application/json',body:JSON.stringify(item)});
      return route.fulfill({status:404,body:''});
    });
    await page.goto('https://sentinel.test/harness');
    const checks=[];
    for(const row of rows){
      await page.evaluate(r=>openMarketChart(r.symbol,r.timeframe,r.provider),row);
      await page.waitForFunction(n=>activeMarketChart?.chart?.getDataList().length===n,row.bars.length);
      const result=await page.evaluate(()=>({count:activeMarketChart.chart.getDataList().length,
        provider:activeMarketChart.provider,venue:activeMarketChart.venue,product:activeMarketChart.product,
        emaPane:activeMarketChart.chart.getIndicators().find(row=>row.name==='EMA')?.paneId,
        last:activeMarketChart.chart.getDataList().at(-1),height:$('#liveMarketChart').getBoundingClientRect().height,
        canvasCount:$('#liveMarketChart').querySelectorAll('canvas').length}));
      if(result.provider!==row.provider || result.venue!==row.venue || result.product!==row.product ||
         result.last.timestamp!==row.bars.at(-1).timestamp || result.last.close!==row.bars.at(-1).close || result.height<350 || !result.canvasCount || result.emaPane!=='candle_pane')throw new Error('REAL_SERIES_RENDER_MISMATCH');
      checks.push({symbol:row.symbol,provider:row.provider,product:row.product,bars:result.count,canvas_count:result.canvasCount,height:result.height});
    }
    await page.evaluate(()=>closeModal());
    if(errors.length)throw new Error(errors.join('; '));
    console.log(JSON.stringify({ok:true,data_kind:capture.kind,retrieval_observed_ms:capture.observed_ms,
      checks,scope:'LOCAL_BROWSER_RENDER_OF_CAPTURED_REAL_PUBLIC_RESPONSES',telegram_webview:'NOT_TESTED',signal_delivery:'NOT_TESTED'}));
  }finally{await browser.close();}
}
main().catch(e=>{console.error(e);process.exit(1);});
