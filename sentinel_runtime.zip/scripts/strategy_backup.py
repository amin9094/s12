#!/usr/bin/env python3
"""Consistent strategy-only backup and restore into an EMPTY database.

No broker/Telegram side effects. Full application/credential backups remain the
existing operational backup's responsibility. Never infer quotes lost offline.
"""
import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from core.storage.market_schema import market_table_names
from core.storage.schema import SCHEMA_REVISION
from repositories.v2.common import json_dump

TABLES=market_table_names()


def export_snapshot(engine,destination,*,include_quotes=False):
    names=[n for n in TABLES if include_quotes or n not in {'s9_quote_archive','s9_quote_archive_sessions'}]
    target=Path(destination);target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_suffix(target.suffix+'.partial')
    manifest={'schema_revision':SCHEMA_REVISION,'scope':'STRATEGY_ONLY','quotes_included':include_quotes,'tables':{}}
    try:
        with engine.transaction(read_only=True,repeatable_read=True) as c,zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
            for table in names:
                digest=hashlib.sha256();count=0
                with z.open(table+'.jsonl','w') as stream:
                    while True:
                        rows=c.execute(f'SELECT * FROM {table} LIMIT 200 OFFSET ?',(count,)).fetchall()  # nosec B608 -- immutable schema-owned whitelist
                        for row in rows:
                            line=(json_dump(row)+'\n').encode();stream.write(line);digest.update(line)
                        count+=len(rows)
                        if len(rows)<200:break
                manifest['tables'][table]={'rows':count,'sha256':digest.hexdigest()}
            z.writestr(zipfile.ZipInfo('manifest.json',(2026,1,1,0,0,0)),json_dump(manifest))
        temp.replace(target)
    except BaseException:
        temp.unlink(missing_ok=True);raise
    return manifest


def restore_snapshot(source,engine):
    with zipfile.ZipFile(source) as z:
        m=json.loads(z.read('manifest.json'))
        if m.get('scope')!='STRATEGY_ONLY' or m.get('schema_revision')!=SCHEMA_REVISION or not set(m['tables'])<=set(TABLES):raise ValueError('STRATEGY_BACKUP_SCHEMA_INVALID')
        expected=set(TABLES)-({'s9_quote_archive','s9_quote_archive_sessions'} if not m.get('quotes_included') else set())
        if set(m['tables'])!=expected:raise ValueError('STRATEGY_BACKUP_INCOMPLETE')
        if sum(i.file_size for i in z.infolist())>2_000_000_000:raise ValueError('STRATEGY_BACKUP_TOO_LARGE')
        for table,v in m['tables'].items():
            digest=hashlib.sha256();count=0
            with z.open(table+'.jsonl') as stream:
                for line in stream:digest.update(line);count+=1
            if count!=v['rows'] or digest.hexdigest()!=v['sha256']:raise ValueError('STRATEGY_BACKUP_CHECKSUM_INVALID')
        with engine.transaction() as c:
            for table in TABLES:
                if c.execute(f'SELECT 1 AS found FROM {table} LIMIT 1').fetchone():raise ValueError('RESTORE_REQUIRES_EMPTY_STRATEGY_DATABASE')  # nosec B608
            for table in TABLES:
                if table not in m['tables']:continue
                with z.open(table+'.jsonl') as stream:
                    for line in stream:
                        row=json.loads(line);columns=list(row)
                        if not columns or any(not re.fullmatch('[a-z_][a-z0-9_]*',key) for key in columns):raise ValueError('STRATEGY_BACKUP_COLUMN_INVALID')
                        c.execute(f"INSERT INTO {table}({','.join(columns)}) VALUES({','.join('?' for _ in columns)})",tuple(row[k] for k in columns))  # nosec B608 -- schema-owned table; validated identifiers and bound values
    return {'restored':True,'quotes_included':m['quotes_included'],'restart_continuity_not_assumed':True}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);parser.add_argument('--include-quotes',action='store_true');args=parser.parse_args()
    from core.storage.engine import normalized_engine
    result=export_snapshot(normalized_engine(),args.output,include_quotes=args.include_quotes)
    print(json_dump({'saved':True,'tables':len(result['tables']),'quotes_included':result['quotes_included']}))


if __name__=='__main__':main()
