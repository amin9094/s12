#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "Run this script as root: sudo bash scripts/install-systemd.sh" >&2
  exit 1
fi

APP_DIR=${APP_DIR:-/opt/sentinel}
SERVICE_USER=${SERVICE_USER:-sentinel}
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if command -v apt-get >/dev/null 2>&1; then
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    python3 python3-venv python3-pip fonts-dejavu-core ca-certificates rsync
fi

id "$SERVICE_USER" >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
mkdir -p "$APP_DIR"

# Preserve mutable production state across upgrades. Never overwrite a live
# database, logs, virtualenv, or secret .env with files from a release archive.
if [[ "$SOURCE_DIR" != "$APP_DIR" ]]; then
  rsync -a --delete \
    --exclude='.env' --exclude='.venv' --exclude='data/' --exclude='logs/' \
    "$SOURCE_DIR"/ "$APP_DIR"/
fi

mkdir -p "$APP_DIR/data/backups" "$APP_DIR/logs"
if [[ ! -f "$APP_DIR/data/database.json" && -f "$SOURCE_DIR/data/database.json" ]]; then
  install -m 0600 -o "$SERVICE_USER" -g "$SERVICE_USER" \
    "$SOURCE_DIR/data/database.json" "$APP_DIR/data/database.json"
fi
if [[ ! -f "$APP_DIR/.env" ]]; then
  install -m 0640 -o root -g "$SERVICE_USER" "$APP_DIR/.env.example" "$APP_DIR/.env"
fi

python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

# Application code and secrets are immutable to the service account. Only
# runtime state directories are writable by the bot.
chown -R root:root "$APP_DIR"
chmod -R u=rwX,go=rX "$APP_DIR"
chown root:"$SERVICE_USER" "$APP_DIR/.env"
chmod 0640 "$APP_DIR/.env"
chown -R "$SERVICE_USER:$SERVICE_USER" "$APP_DIR/data" "$APP_DIR/logs"
find "$APP_DIR/data" "$APP_DIR/logs" -type d -exec chmod 0700 {} +
find "$APP_DIR/data" "$APP_DIR/logs" -type f -exec chmod 0600 {} +

install -m 0644 "$APP_DIR/systemd/sentinel-bot.service" /etc/systemd/system/sentinel-bot.service
install -m 0644 "$APP_DIR/systemd/sentinel-backup.service" /etc/systemd/system/sentinel-backup.service
install -m 0644 "$APP_DIR/systemd/sentinel-backup.timer" /etc/systemd/system/sentinel-backup.timer
systemctl daemon-reload
systemctl enable sentinel-bot sentinel-backup.timer

echo "Edit $APP_DIR/.env"
echo "Then verify: sudo -u $SERVICE_USER $APP_DIR/.venv/bin/python $APP_DIR/scripts/preflight.py --online"
echo "Start services: systemctl start sentinel-bot sentinel-backup.timer"
