from __future__ import annotations

from collections import Counter, defaultdict
from datetime import UTC, datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso

TASK_STATUSES = {"active", "paused", "closed", "archived"}
SUBMISSION_STATUSES = {"pending", "approved", "rejected"}
TASK_PRIORITIES = {"low", "normal", "high", "critical"}
TASK_CATEGORIES = {
    "signals",
    "market_research",
    "risk",
    "content",
    "campaign",
    "retention",
    "sales_support",
    "operations",
}

QUALITY_CHECKS = ("evidence", "complete", "measurable", "accurate")


def ensure_kpi_trader_state(db: dict[str, Any]) -> None:
    db.setdefault("kpi_trader_tasks", [])
    db.setdefault("kpi_trader_submissions", [])
    db.setdefault("kpi_trader_score_ledger", [])
    db.setdefault("kpi_business_outcomes", [])
    settings = db.setdefault("kpi_trader_settings", {})
    if not isinstance(settings, dict):
        settings = {}
        db["kpi_trader_settings"] = settings
    settings.setdefault("enabled", True)
    settings.setdefault("review_required", True)
    settings.setdefault("evidence_required", True)
    settings.setdefault("owner_review_only", False)
    settings.setdefault("allow_manual_score_adjustment", True)
    settings.setdefault("default_due_days", 7)
    settings.setdefault("max_task_points", 1000)
    settings.setdefault("monthly_points_budget", 100000)
    settings.setdefault("reminder_hours", [24, 3])
    settings.setdefault("quality_gate_required", True)
    settings.setdefault("quality_gate_min_score", 80)
    settings.setdefault("max_active_tasks_per_trader", 10)
    ids = db.setdefault("next_ids", {})
    ids.setdefault("kpi_task", 1)
    ids.setdefault("kpi_submission", 1)
    ids.setdefault("kpi_score", 1)
    ids.setdefault("kpi_business_outcome", 1)


def _next_reference(db: dict[str, Any], key: str, prefix: str) -> str:
    ensure_kpi_trader_state(db)
    ids = db["next_ids"]
    value = max(1, int(ids.get(key, 1) or 1))
    ids[key] = value + 1
    return f"{prefix}-{value:06d}"


def _normalized_ids(values: list[int | str] | tuple[int | str, ...] | None) -> list[str]:
    output: list[str] = []
    for value in values or []:
        text = str(value or "").strip()
        if text.isdigit() and int(text) > 0 and text not in output:
            output.append(text)
    return output


def _clean_text(value: Any, *, maximum: int, required: bool = False) -> str:
    text = " ".join(str(value or "").replace("\x00", "").split()).strip()
    if required and not text:
        raise ValueError("required text is missing")
    return text[:maximum]


def kpi_settings(db: dict[str, Any]) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    return db["kpi_trader_settings"]


def update_kpi_settings(
    db: dict[str, Any],
    *,
    actor_id: int | str,
    enabled: bool | None = None,
    evidence_required: bool | None = None,
    owner_review_only: bool | None = None,
    allow_manual_score_adjustment: bool | None = None,
    default_due_days: int | None = None,
    max_task_points: int | None = None,
    monthly_points_budget: int | None = None,
    quality_gate_required: bool | None = None,
    quality_gate_min_score: int | None = None,
    max_active_tasks_per_trader: int | None = None,
) -> dict[str, Any]:
    settings = kpi_settings(db)
    bool_updates = {
        "enabled": enabled,
        "evidence_required": evidence_required,
        "owner_review_only": owner_review_only,
        "allow_manual_score_adjustment": allow_manual_score_adjustment,
        "quality_gate_required": quality_gate_required,
    }
    for key, value in bool_updates.items():
        if value is not None:
            settings[key] = bool(value)
    if default_due_days is not None:
        due_days_value = int(default_due_days)
        if not 0 <= due_days_value <= 365:
            raise ValueError("default due days must be between 0 and 365")
        settings["default_due_days"] = due_days_value
    if max_task_points is not None:
        task_points_value = int(max_task_points)
        if not 1 <= task_points_value <= 10000:
            raise ValueError("maximum task points must be between 1 and 10000")
        settings["max_task_points"] = task_points_value
    if monthly_points_budget is not None:
        monthly_budget_value = int(monthly_points_budget)
        if not 1 <= monthly_budget_value <= 10_000_000:
            raise ValueError("monthly points budget must be between 1 and 10000000")
        settings["monthly_points_budget"] = monthly_budget_value
    if quality_gate_min_score is not None:
        gate_score_value = int(quality_gate_min_score)
        if not 0 <= gate_score_value <= 100:
            raise ValueError("quality gate score must be between 0 and 100")
        settings["quality_gate_min_score"] = gate_score_value
    if max_active_tasks_per_trader is not None:
        active_task_limit_value = int(max_active_tasks_per_trader)
        if not 1 <= active_task_limit_value <= 100:
            raise ValueError("active task limit must be between 1 and 100")
        settings["max_active_tasks_per_trader"] = active_task_limit_value
    settings["updated_by"] = str(actor_id)
    settings["updated_at"] = utc_iso()
    return settings


def monthly_points_awarded(
    db: dict[str, Any], *, now: datetime | None = None
) -> int:
    ensure_kpi_trader_state(db)
    current = now or datetime.now(UTC)
    month_start = datetime(current.year, current.month, 1, tzinfo=UTC)
    return sum(
        int(row.get("points", 0) or 0)
        for row in db["kpi_trader_score_ledger"]
        if isinstance(row, dict)
        and (parse_dt(row.get("created_at")) or datetime.min.replace(tzinfo=UTC))
        >= month_start
    )


def create_task(
    db: dict[str, Any],
    *,
    title_fa: str,
    title_en: str,
    description_fa: str,
    description_en: str,
    points: int,
    created_by: int | str,
    due_at: str | None = None,
    assignee_ids: list[int | str] | tuple[int | str, ...] | None = None,
    category: str = "signals",
    priority: str = "normal",
    required_count: int = 1,
) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    category = str(category or "signals").strip().lower()
    priority = str(priority or "normal").strip().lower()
    if category not in TASK_CATEGORIES:
        raise ValueError("invalid KPI task category")
    if priority not in TASK_PRIORITIES:
        raise ValueError("invalid KPI task priority")
    points = int(points)
    required_count = int(required_count)
    settings = kpi_settings(db)
    max_task_points = max(1, int(settings.get("max_task_points", 1000) or 1000))
    if not 1 <= points <= max_task_points:
        raise ValueError(f"task points must be between 1 and {max_task_points}")
    if not 1 <= required_count <= 10000:
        raise ValueError("required count must be between 1 and 10000")
    due = parse_dt(due_at)
    if due_at and not due:
        raise ValueError("invalid task due date")
    if not due:
        default_due_days = max(
            0, min(int(settings.get("default_due_days", 7) or 0), 365)
        )
        if default_due_days:
            due = datetime.now(UTC) + timedelta(days=default_due_days)
    if due and due <= datetime.now(UTC):
        raise ValueError("task due date must be in the future")
    now = utc_iso()
    task = {
        "id": _next_reference(db, "kpi_task", "KPI"),
        "title_fa": _clean_text(title_fa, maximum=160, required=True),
        "title_en": _clean_text(title_en, maximum=160, required=True),
        "description_fa": _clean_text(description_fa, maximum=2000),
        "description_en": _clean_text(description_en, maximum=2000),
        "category": category,
        "priority": priority,
        "points": points,
        "required_count": required_count,
        "assignee_ids": _normalized_ids(assignee_ids),
        "status": "active",
        "due_at": due.isoformat() if due else None,
        "created_by": str(created_by),
        "created_at": now,
        "updated_at": now,
        "completed_at": None,
    }
    db["kpi_trader_tasks"].append(task)
    return task


def task_by_id(db: dict[str, Any], task_id: str) -> dict[str, Any] | None:
    ensure_kpi_trader_state(db)
    target = str(task_id or "").strip().upper()
    return next(
        (
            row
            for row in db["kpi_trader_tasks"]
            if isinstance(row, dict) and str(row.get("id") or "").upper() == target
        ),
        None,
    )


def submission_by_id(db: dict[str, Any], submission_id: str) -> dict[str, Any] | None:
    ensure_kpi_trader_state(db)
    target = str(submission_id or "").strip().upper()
    return next(
        (
            row
            for row in db["kpi_trader_submissions"]
            if isinstance(row, dict) and str(row.get("id") or "").upper() == target
        ),
        None,
    )


def task_is_overdue(task: dict[str, Any], *, now: datetime | None = None) -> bool:
    due = parse_dt(task.get("due_at"))
    return bool(
        due
        and due < (now or datetime.now(UTC))
        and str(task.get("status") or "") == "active"
    )


def task_available_to_trader(task: dict[str, Any], trader_id: int | str) -> bool:
    assigned = _normalized_ids(task.get("assignee_ids") if isinstance(task.get("assignee_ids"), list) else [])
    return not assigned or str(trader_id) in assigned


def list_tasks_for_trader(
    db: dict[str, Any],
    trader_id: int | str,
    *,
    include_closed: bool = False,
) -> list[dict[str, Any]]:
    ensure_kpi_trader_state(db)
    statuses = TASK_STATUSES if include_closed else {"active"}
    rows = [
        row
        for row in db["kpi_trader_tasks"]
        if isinstance(row, dict)
        and str(row.get("status") or "") in statuses
        and task_available_to_trader(row, trader_id)
    ]
    rows.sort(
        key=lambda row: (
            0 if task_is_overdue(row) else 1,
            str(row.get("due_at") or "9999"),
            str(row.get("created_at") or ""),
        )
    )
    return rows


def trader_task_submission(
    db: dict[str, Any], task_id: str, trader_id: int | str
) -> dict[str, Any] | None:
    ensure_kpi_trader_state(db)
    matches = [
        row
        for row in db["kpi_trader_submissions"]
        if isinstance(row, dict)
        and str(row.get("task_id") or "") == str(task_id)
        and str(row.get("trader_id") or "") == str(trader_id)
    ]
    matches.sort(key=lambda row: str(row.get("submitted_at") or ""), reverse=True)
    return matches[0] if matches else None


def submit_task(
    db: dict[str, Any],
    *,
    task_id: str,
    trader_id: int | str,
    note: str = "",
    evidence: dict[str, Any] | None = None,
) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    if not bool(kpi_settings(db).get("enabled", True)):
        raise ValueError("KPI Trader is disabled")
    task = task_by_id(db, task_id)
    if not task or str(task.get("status") or "") != "active":
        raise ValueError("task is not active")
    if not task_available_to_trader(task, trader_id):
        raise PermissionError("task is not assigned to this trader")
    active_limit = max(
        1, int(kpi_settings(db).get("max_active_tasks_per_trader", 10) or 10)
    )
    active_count = sum(
        1
        for row in db["kpi_trader_submissions"]
        if isinstance(row, dict)
        and str(row.get("trader_id") or "") == str(trader_id)
        and str(row.get("status") or "") == "pending"
    )
    if active_count >= active_limit:
        raise ValueError("active KPI task limit has been reached")
    current = trader_task_submission(db, str(task["id"]), trader_id)
    if current and str(current.get("status") or "") in {"pending", "approved"}:
        raise ValueError("task already has a pending or approved submission")
    if (
        bool(kpi_settings(db).get("evidence_required", True))
        and not evidence
        and not str(note or "").strip()
    ):
        raise ValueError("task evidence is required")
    submission = {
        "id": _next_reference(db, "kpi_submission", "KPS"),
        "task_id": str(task["id"]),
        "trader_id": str(trader_id),
        "status": "pending",
        "note": _clean_text(note, maximum=2000),
        "evidence": dict(evidence or {}),
        "submitted_at": utc_iso(),
        "reviewed_at": None,
        "reviewed_by": None,
        "review_note": "",
        "points_awarded": 0,
        "resubmission_of": str(current.get("id")) if current else None,
        "quality_gate": {
            "checks": {key: False for key in QUALITY_CHECKS},
            "reviewed_by": None,
            "reviewed_at": None,
        },
    }
    db["kpi_trader_submissions"].append(submission)
    return submission


def quality_gate_snapshot(
    db: dict[str, Any], submission_id: str, *, now: datetime | None = None
) -> dict[str, Any]:
    """Return a deterministic quality score used by both UI and approval logic."""
    ensure_kpi_trader_state(db)
    submission = submission_by_id(db, submission_id)
    if not submission:
        raise ValueError("submission not found")
    gate = submission.setdefault("quality_gate", {})
    checks = gate.setdefault("checks", {})
    normalized = {key: bool(checks.get(key, False)) for key in QUALITY_CHECKS}
    task = task_by_id(db, str(submission.get("task_id") or "")) or {}
    due = parse_dt(task.get("due_at"))
    submitted = parse_dt(submission.get("submitted_at"))
    on_time = not due or bool(submitted and submitted <= due)
    score = sum(20 for value in normalized.values() if value) + (20 if on_time else 0)
    minimum = max(
        0, min(100, int(kpi_settings(db).get("quality_gate_min_score", 80) or 80))
    )
    ready = all(normalized.values()) and score >= minimum
    return {
        "submission_id": str(submission["id"]),
        "checks": normalized,
        "on_time": on_time,
        "score": score,
        "minimum_score": minimum,
        "ready": ready,
        "reviewed_by": gate.get("reviewed_by"),
        "reviewed_at": gate.get("reviewed_at"),
    }


def toggle_quality_check(
    db: dict[str, Any], *, submission_id: str, check: str, actor_id: int | str
) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    check = str(check or "").strip().lower()
    if check not in QUALITY_CHECKS:
        raise ValueError("invalid quality check")
    submission = submission_by_id(db, submission_id)
    if not submission:
        raise ValueError("submission not found")
    if str(submission.get("status") or "") != "pending":
        raise ValueError("only pending submissions can be checked")
    gate = submission.setdefault("quality_gate", {})
    checks = gate.setdefault("checks", {})
    checks[check] = not bool(checks.get(check, False))
    gate["reviewed_by"] = str(actor_id)
    gate["reviewed_at"] = utc_iso()
    return quality_gate_snapshot(db, submission_id)


def record_task_business_outcome(
    db: dict[str, Any],
    *,
    task_id: str,
    actor_id: int | str,
    revenue: int = 0,
    sales: int = 0,
    renewals: int = 0,
    leads: int = 0,
    note: str = "",
) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    task = task_by_id(db, task_id)
    if not task:
        raise ValueError("task not found")
    values = {
        "revenue": int(revenue),
        "sales": int(sales),
        "renewals": int(renewals),
        "leads": int(leads),
    }
    if any(value < 0 for value in values.values()):
        raise ValueError("business outcome values cannot be negative")
    if not any(values.values()):
        raise ValueError("at least one business outcome is required")
    row = {
        "id": _next_reference(db, "kpi_business_outcome", "KBO"),
        "task_id": str(task["id"]),
        "actor_id": str(actor_id),
        **values,
        "note": _clean_text(note, maximum=500),
        "created_at": utc_iso(),
    }
    db["kpi_business_outcomes"].append(row)
    return row


def task_business_totals(db: dict[str, Any], task_id: str) -> dict[str, int]:
    ensure_kpi_trader_state(db)
    rows = [
        row
        for row in db["kpi_business_outcomes"]
        if isinstance(row, dict) and str(row.get("task_id") or "") == str(task_id)
    ]
    return {
        key: sum(int(row.get(key, 0) or 0) for row in rows)
        for key in ("revenue", "sales", "renewals", "leads")
    }


def review_submission(
    db: dict[str, Any],
    *,
    submission_id: str,
    reviewer_id: int | str,
    approved: bool,
    note: str = "",
    owner_id: int | str | None = None,
) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    if bool(kpi_settings(db).get("owner_review_only", False)) and (
        owner_id is None or str(reviewer_id) != str(owner_id)
    ):
        raise PermissionError("only the primary administrator can review KPI submissions")
    submission = submission_by_id(db, submission_id)
    if not submission:
        raise ValueError("submission not found")
    if str(submission.get("status") or "") != "pending":
        raise ValueError("submission has already been reviewed")
    if str(submission.get("trader_id") or "") == str(reviewer_id):
        raise PermissionError("traders cannot review their own submissions")
    task = task_by_id(db, str(submission.get("task_id") or ""))
    if not task:
        raise ValueError("task not found")
    quality = quality_gate_snapshot(db, submission_id)
    if approved and bool(kpi_settings(db).get("quality_gate_required", True)) and not quality["ready"]:
        raise ValueError("quality gate must be completed before approval")
    now = utc_iso()
    submission["status"] = "approved" if approved else "rejected"
    submission["reviewed_at"] = now
    submission["reviewed_by"] = str(reviewer_id)
    submission["review_note"] = _clean_text(note, maximum=1000)
    submission["quality_score"] = int(quality["score"])
    submission["points_awarded"] = (
        max(1, round(int(task.get("points", 0) or 0) * quality["score"] / 100))
        if approved
        else 0
    )
    if approved:
        settings = kpi_settings(db)
        budget = max(
            1, int(settings.get("monthly_points_budget", 100000) or 100000)
        )
        projected = monthly_points_awarded(db) + int(submission["points_awarded"])
        if projected > budget:
            submission["status"] = "pending"
            submission["reviewed_at"] = None
            submission["reviewed_by"] = None
            submission["review_note"] = ""
            submission["points_awarded"] = 0
            raise ValueError("monthly KPI points budget would be exceeded")
        ledger = {
            "id": _next_reference(db, "kpi_score", "KPL"),
            "task_id": str(task["id"]),
            "submission_id": str(submission["id"]),
            "trader_id": str(submission["trader_id"]),
            "points": int(submission["points_awarded"]),
            "category": str(task.get("category") or "operations"),
            "awarded_by": str(reviewer_id),
            "created_at": now,
        }
        db["kpi_trader_score_ledger"].append(ledger)
    return submission


def adjust_trader_score(
    db: dict[str, Any],
    *,
    trader_id: int | str,
    points: int,
    actor_id: int | str,
    reason: str,
) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    settings = kpi_settings(db)
    if not bool(settings.get("allow_manual_score_adjustment", True)):
        raise PermissionError("manual KPI score adjustment is disabled")
    uid = str(trader_id or "").strip()
    if not uid.isdigit() or int(uid) <= 0:
        raise ValueError("invalid trader id")
    value = int(points)
    maximum = max(1, int(settings.get("max_task_points", 1000) or 1000))
    if value == 0 or abs(value) > maximum:
        raise ValueError(f"score adjustment must be between -{maximum} and {maximum}, excluding zero")
    clean_reason = _clean_text(reason, maximum=500, required=True)
    if value > 0:
        budget = max(
            1, int(settings.get("monthly_points_budget", 100000) or 100000)
        )
        if monthly_points_awarded(db) + value > budget:
            raise ValueError("monthly KPI points budget would be exceeded")
    ledger = {
        "id": _next_reference(db, "kpi_score", "KPL"),
        "task_id": None,
        "submission_id": None,
        "trader_id": uid,
        "points": value,
        "category": "manual_adjustment",
        "awarded_by": str(actor_id),
        "reason": clean_reason,
        "source": "owner_adjustment",
        "created_at": utc_iso(),
    }
    db["kpi_trader_score_ledger"].append(ledger)
    return ledger


def set_task_status(
    db: dict[str, Any], task_id: str, status: str, actor_id: int | str
) -> dict[str, Any]:
    task = task_by_id(db, task_id)
    status = str(status or "").strip().lower()
    if not task:
        raise ValueError("task not found")
    if status not in TASK_STATUSES:
        raise ValueError("invalid task status")
    task["status"] = status
    task["updated_at"] = utc_iso()
    task["updated_by"] = str(actor_id)
    task["completed_at"] = utc_iso() if status in {"closed", "archived"} else None
    return task


def kpi_trader_dashboard(db: dict[str, Any], trader_id: int | str) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    uid = str(trader_id)
    submissions = [
        row
        for row in db["kpi_trader_submissions"]
        if isinstance(row, dict) and str(row.get("trader_id") or "") == uid
    ]
    ledger = [
        row
        for row in db["kpi_trader_score_ledger"]
        if isinstance(row, dict) and str(row.get("trader_id") or "") == uid
    ]
    now = datetime.now(UTC)
    month_start = datetime(now.year, now.month, 1, tzinfo=UTC)
    approved = [row for row in submissions if row.get("status") == "approved"]
    pending = [row for row in submissions if row.get("status") == "pending"]
    rejected = [row for row in submissions if row.get("status") == "rejected"]
    reviewed = len(approved) + len(rejected)
    on_time = 0
    for row in approved:
        task = task_by_id(db, str(row.get("task_id") or ""))
        due = parse_dt(task.get("due_at")) if task else None
        submitted = parse_dt(row.get("submitted_at"))
        if not due or (submitted and submitted <= due):
            on_time += 1
    category_points: dict[str, int] = defaultdict(int)
    for row in ledger:
        category_points[str(row.get("category") or "operations")] += int(
            row.get("points", 0) or 0
        )
    available = list_tasks_for_trader(db, uid)
    quality_scores = [int(row.get("quality_score", 0) or 0) for row in approved]
    task_ids = {
        str(row.get("task_id") or "") for row in submissions if row.get("task_id")
    }
    business_rows = [
        row
        for row in db.get("kpi_business_outcomes", [])
        if isinstance(row, dict) and str(row.get("task_id") or "") in task_ids
    ]
    return {
        "trader_id": uid,
        "points_total": sum(int(row.get("points", 0) or 0) for row in ledger),
        "points_month": sum(
            int(row.get("points", 0) or 0)
            for row in ledger
            if (parse_dt(row.get("created_at")) or datetime.min.replace(tzinfo=UTC))
            >= month_start
        ),
        "submitted": len(submissions),
        "approved": len(approved),
        "pending": len(pending),
        "rejected": len(rejected),
        "approval_rate": round(len(approved) / max(1, reviewed) * 100, 2),
        "on_time_rate": round(on_time / max(1, len(approved)) * 100, 2),
        "quality_score": round(sum(quality_scores) / max(1, len(quality_scores)), 2),
        "business": {
            key: sum(int(row.get(key, 0) or 0) for row in business_rows)
            for key in ("revenue", "sales", "renewals", "leads")
        },
        "available_tasks": len(available),
        "overdue_tasks": sum(1 for row in available if task_is_overdue(row)),
        "category_points": dict(category_points),
        "recent_submissions": sorted(
            submissions, key=lambda row: str(row.get("submitted_at") or ""), reverse=True
        )[:10],
    }


def kpi_team_dashboard(db: dict[str, Any]) -> dict[str, Any]:
    ensure_kpi_trader_state(db)
    trader_ids = {
        str(row.get("trader_id") or "")
        for row in db["kpi_trader_submissions"]
        if isinstance(row, dict) and row.get("trader_id")
    }
    trader_ids.update(
        str(row.get("trader_id") or "")
        for row in db["kpi_trader_score_ledger"]
        if isinstance(row, dict) and row.get("trader_id")
    )
    dashboards = [kpi_trader_dashboard(db, uid) for uid in trader_ids if uid]
    dashboards.sort(
        key=lambda row: (int(row["points_total"]), float(row["approval_rate"])),
        reverse=True,
    )
    tasks = [row for row in db["kpi_trader_tasks"] if isinstance(row, dict)]
    submissions = [row for row in db["kpi_trader_submissions"] if isinstance(row, dict)]
    return {
        "active_tasks": sum(1 for row in tasks if row.get("status") == "active"),
        "overdue_tasks": sum(1 for row in tasks if task_is_overdue(row)),
        "pending_reviews": sum(1 for row in submissions if row.get("status") == "pending"),
        "approved_submissions": sum(
            1 for row in submissions if row.get("status") == "approved"
        ),
        "rejected_submissions": sum(
            1 for row in submissions if row.get("status") == "rejected"
        ),
        "points_awarded": sum(
            int(row.get("points", 0) or 0)
            for row in db["kpi_trader_score_ledger"]
            if isinstance(row, dict)
        ),
        "tasks_by_category": dict(
            Counter(str(row.get("category") or "operations") for row in tasks)
        ),
        "traders": dashboards,
    }


def due_reminder_candidates(
    db: dict[str, Any], *, now: datetime | None = None
) -> list[dict[str, Any]]:
    ensure_kpi_trader_state(db)
    current = now or datetime.now(UTC)
    candidates: list[dict[str, Any]] = []
    for task in db["kpi_trader_tasks"]:
        if not isinstance(task, dict) or task.get("status") != "active":
            continue
        due = parse_dt(task.get("due_at"))
        if not due:
            continue
        remaining = due - current
        if timedelta(0) <= remaining <= timedelta(hours=24):
            candidates.append(task)
    return candidates


def claim_due_reminders(
    db: dict[str, Any], *, now: datetime | None = None
) -> list[dict[str, Any]]:
    """Claim each reminder once so multiple Railway replicas cannot duplicate it."""
    ensure_kpi_trader_state(db)
    current = now or datetime.now(UTC)
    configured = db["kpi_trader_settings"].get("reminder_hours", [24, 3])
    reminder_hours = sorted(
        {
            max(1, int(value))
            for value in configured
            if str(value).strip().lstrip("-").isdigit()
        },
        reverse=True,
    ) or [24, 3]
    claimed: list[dict[str, Any]] = []
    for task in db["kpi_trader_tasks"]:
        if not isinstance(task, dict) or task.get("status") != "active":
            continue
        due = parse_dt(task.get("due_at"))
        if not due:
            continue
        sent = {
            str(value)
            for value in task.get("reminders_sent", [])
            if str(value).strip()
        }
        remaining_hours = (due - current).total_seconds() / 3600
        reminder_key = ""
        if remaining_hours < 0:
            reminder_key = "overdue"
        else:
            eligible = [
                hours
                for hours in reminder_hours
                if remaining_hours <= hours and f"due_{hours}h" not in sent
            ]
            if eligible:
                selected = min(eligible)
                reminder_key = f"due_{selected}h"
                # If the worker was offline during an earlier threshold, do not
                # flood the trader with all missed reminders at once.
                sent.update(
                    f"due_{hours}h"
                    for hours in reminder_hours
                    if remaining_hours <= hours
                )
        if not reminder_key or reminder_key in sent:
            if not reminder_key:
                continue
            # The selected key may already have been included while suppressing
            # missed thresholds; it is still the one reminder claimed now.
        sent.add(reminder_key)
        task["reminders_sent"] = sorted(sent)
        task["updated_at"] = utc_iso()
        claimed.append(
            {
                "task": dict(task),
                "reminder_key": reminder_key,
                "remaining_hours": remaining_hours,
            }
        )
    return claimed
