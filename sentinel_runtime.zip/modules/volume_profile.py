"""Prelocked, source-bound profiles. OHLCV profiles are explicitly estimates.

No price-only candles, missing volume, or sampled REST quote counts are volume.
The bin allocation is reproducible and must be validated per research profile;
it is not exchange order flow, aggressor delta, or exact executed-volume-at-price.
"""

from __future__ import annotations

from decimal import Decimal as D, ROUND_CEILING, ROUND_FLOOR
from hashlib import sha256

from modules.canonical_market import Candle, price, validate_series
from repositories.v2.common import json_dump


def anchored_profile(candles: tuple[Candle, ...], *, start_ms, end_ms, cutoff_ms, tick_size, rows=64, parent_bars=(), review_only=False):
    if not 0 < start_ms < end_ms <= cutoff_ms or not 8 <= rows <= 256:
        raise ValueError("VOLUME_PROFILE_LOCKED_WINDOW_INVALID")
    tick = price(tick_size)
    bars = [b for b in candles if start_ms <= b.start_ms and b.end_ms <= end_ms]
    if not bars or bars[0].start_ms != start_ms or bars[-1].end_ms != end_ms:
        raise ValueError("VOLUME_PROFILE_WINDOW_COVERAGE_MISSING")
    validate_series(bars, now_ms=cutoff_ms, allow_open=False)
    if any(b.available_ms > cutoff_ms or b.quality_flags and not review_only for b in bars):
        raise ValueError("VOLUME_PROFILE_EVIDENCE_INVALID")
    if any(a.end_ms != b.start_ms for a, b in zip(bars, bars[1:])):
        raise ValueError("VOLUME_PROFILE_COVERAGE_GAP")
    kind = bars[0].volume_kind
    allowed = {"reported_tick_proxy"} if review_only else {"traded", "tick_proxy"}
    if kind not in allowed or any(b.volume is None or b.volume_kind != kind for b in bars):
        raise ValueError("VOLUME_PROFILE_NATIVE_VOLUME_UNAVAILABLE")
    if review_only and any(b.provider != 'biquote' or b.product != 'indicative' or not b.quality_flags for b in bars):
        raise ValueError('REPORTED_PROFILE_REVIEW_SCOPE_INVALID')
    for parent in parent_bars:
        children = [b for b in bars if parent.start_ms <= b.start_ms and b.end_ms <= parent.end_ms]
        if not children or children[0].start_ms != parent.start_ms or children[-1].end_ms != parent.end_ms:
            raise ValueError("VOLUME_PROFILE_PARENT_COVERAGE_MISSING")
        identity = (parent.symbol, parent.provider, parent.venue, parent.product)
        if any((b.symbol, b.provider, b.venue, b.product) != identity for b in children):
            raise ValueError("VOLUME_PROFILE_PARENT_MARKET_MISMATCH")
        reconstructed = (children[0].open, max(b.high for b in children), min(b.low for b in children), children[-1].close)
        if reconstructed != (parent.open, parent.high, parent.low, parent.close):
            raise ValueError("VOLUME_PROFILE_PARENT_PRICE_DISAGREEMENT")
        if parent.volume_kind != kind or parent.volume is None or sum(b.volume for b in children) != parent.volume:
            raise ValueError("VOLUME_PROFILE_PARENT_VOLUME_DISAGREEMENT")
    # Quantize bin width to native ticks without changing the locked wave window.
    low, high = min(b.low for b in bars), max(b.high for b in bars)
    base = (low / tick).to_integral_value(rounding=ROUND_FLOOR) * tick
    width = max(tick, ((high - base) / rows / tick).to_integral_value(rounding=ROUND_CEILING) * tick)
    count = max(1, int(((high - base) / width).to_integral_value(rounding=ROUND_CEILING)))
    weights = [D(0)] * count
    for bar in bars:
        if bar.volume == 0:
            continue
        if bar.high == bar.low:
            index = min(count - 1, max(0, int((bar.close - base) / width)))
            weights[index] += bar.volume
            continue
        # A labeled estimate from actual OHLCV, never invented executions.
        for index in range(count):
            overlap = max(D(0), min(bar.high, base + (index + 1) * width) - max(bar.low, base + index * width))
            weights[index] += bar.volume * overlap / (bar.high - bar.low)
    if not weights or sum(weights) <= 0:
        raise ValueError("VOLUME_PROFILE_ZERO_NATIVE_VOLUME")
    # Ties select the lower bin ex ante, not whichever price later wins.
    poc_index = max(range(count), key=lambda i: (weights[i], -i))
    poc = (base + (D(poc_index) + D(".5")) * width) / tick
    poc = poc.to_integral_value() * tick
    if not low <= poc <= high:
        raise ValueError("VOLUME_PROFILE_POC_GRID_OUTSIDE_OBSERVED_RANGE")
    evidence = {
        "kind": "POC", "price": str(poc), "volume_kind": kind,
        "method": "REPORTED_OHLCV_REVIEW_ESTIMATE" if review_only else "NATIVE_OHLCV_PRICE_BIN_ESTIMATE", "is_exact_trade_at_price": False,
        "input_timeframe": bars[0].timeframe, "start_ms": start_ms, "end_ms": end_ms,
        "window_locked_ms": cutoff_ms, "available_ms": max(b.available_ms for b in bars),
        "symbol": bars[0].symbol, "provider": bars[0].provider, "venue": bars[0].venue,
        "product": bars[0].product, "bin_width": str(width), "rows": count,
        "reported_total_volume" if review_only else "native_total_volume": str(sum(b.volume for b in bars)),
        "source_ids": [b.source_id for b in bars],
        "proxy_label_fa": "برآورد پژوهشی POC از حجم تیک گزارش‌شده؛ حجم بومی تأیید نشده" if review_only else "پروفایل فعالیت قیمت بر پایه حجم تیک" if kind == "tick_proxy" else "پروفایل برآوردی از حجم واقعی کندل‌ها",
    }
    evidence["source_id"] = "profile:" + sha256(json_dump(evidence).encode()).hexdigest()
    return evidence
