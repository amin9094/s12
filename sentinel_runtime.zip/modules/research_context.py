"""Versioned round-trip of actual strategy inputs, with their availability times."""
from dataclasses import asdict,fields
from decimal import Decimal as D
from functools import lru_cache
import hashlib
from pathlib import Path
from modules.canonical_market import Candle,Quote
from modules.strategies.common import Context,Parameters
from modules.goldbach_confirmation import GoldbachSettings
from modules.custom_strategy import parse_settings


@lru_cache(maxsize=1)
def implementation_hash():
    root=Path(__file__).resolve().parents[1];digest=hashlib.sha256()
    files=list((root/'modules/strategies').rglob('*.py'))
    files += [root/'modules'/name for name in ('indicator_suite.py','custom_strategy.py','goldbach_confirmation.py',
        'volume_profile.py','entry_selection.py','signal_execution.py','signal_plan_policy.py','signal_targets.py',
        'strategy_engines.py','admin_review_proposals.py')]
    for path in sorted(set(files)):
        digest.update(path.relative_to(root).as_posix().encode());digest.update(path.read_bytes())
    return digest.hexdigest()


def encode(context):
    return {'version':1,'context_type':'review' if getattr(context,'review_only',False) else 'native',
            'implementation_hash':implementation_hash(),'input':asdict(context)}


def parameters(raw):
    defaults=Parameters()
    return Parameters(**{f.name:D(str(raw[f.name])) if isinstance(getattr(defaults,f.name),D) else raw[f.name] for f in fields(Parameters)})


def decode(bundle):
    if bundle.get('version')!=1:raise ValueError('RESEARCH_INPUT_VERSION_INVALID')
    p=dict(bundle['input'])
    p['candles']=tuple(Candle.from_dict(x) for x in p['candles'])
    p['profile_candles']=tuple(Candle.from_dict(x) for x in p['profile_candles'])
    p['parameters']=parameters(p['parameters'])
    p['engine_parameters']=tuple((k,parameters(v)) for k,v in p['engine_parameters'])
    p['liquidity_parameters']=parameters(p['liquidity_parameters']) if p['liquidity_parameters'] else None
    for key in ('tick_size','spread','pip_size'):p[key]=D(p[key]) if p[key] is not None else None
    gb=dict(p['goldbach_settings']);gb['shift']=D(gb['shift']);gb['price_unit']=D(gb['price_unit']) if gb['price_unit'] is not None else None
    p['goldbach_settings']=GoldbachSettings(**gb)
    p['custom_settings']=parse_settings(p['custom_settings']) if p['custom_settings'] is not None else None
    p['indicator_selection']=tuple(p['indicator_selection']) if p['indicator_selection'] is not None else None
    for key in ('value_factors','ob_departure_proofs'):p[key]=tuple(p[key])
    if p['current_quote']:
        quote=dict(p['current_quote']);quote['quality_flags']=tuple(quote['quality_flags']);p['current_quote']=Quote(**quote)
    if bundle['context_type']=='review':
        from modules.admin_review_proposals import AdminReviewContext
        result=AdminReviewContext(**p)
    else:result=Context(**p)
    result.validate();return result
