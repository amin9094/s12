from __future__ import annotations

from collections import Counter
from decimal import Decimal, InvalidOperation
from typing import Any

from core.db import next_id
from core.utils import utc_iso

DEFAULT_RECONCILIATION_SETTINGS: dict[str, Any] = {
    "enabled": True,
    "min_confirmations": {"TRC20": 20, "ERC20": 12, "BEP20": 15},
    "underpayment_tolerance_percent": 0.25,
    "overpayment_requires_review_percent": 10.0,
    "auto_approve_verified": False,
}


def reconciliation_settings(db: dict[str, Any]) -> dict[str, Any]:
    settings = db.setdefault("payment_reconciliation_settings", {})
    if not isinstance(settings, dict):
        settings = {}
        db["payment_reconciliation_settings"] = settings
    for key, value in DEFAULT_RECONCILIATION_SETTINGS.items():
        settings.setdefault(key, value.copy() if isinstance(value, dict) else value)
    return settings


def _decimal(value: Any) -> Decimal:
    try:
        result = Decimal(str(value or "0"))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("0")
    return result if result.is_finite() else Decimal("0")


def reconcile_order(
    db: dict[str, Any],
    order: dict[str, Any],
    *,
    actor_id: int | str = "system",
) -> dict[str, Any]:
    settings = reconciliation_settings(db)
    method = str(order.get("payment_method") or "card").lower()
    network = str(order.get("payment_network") or order.get("network") or "").upper()
    verification = str(order.get("verification_status") or "")
    expected = _decimal(order.get("usdt_amount") or order.get("expected_amount"))
    received = _decimal(order.get("verified_amount") or order.get("received_amount"))
    confirmations = int(order.get("confirmation_count", 0) or 0)
    minimum = int(settings.get("min_confirmations", {}).get(network, 1) or 1)
    difference = received - expected
    difference_percent = float(difference / expected * 100) if expected > 0 else 0.0
    issues: list[str] = []
    status = "matched"

    if method == "usdt":
        if verification not in {"verified", "approved"}:
            issues.append("transaction_not_verified")
        if confirmations < minimum:
            issues.append("insufficient_confirmations")
        tolerance = float(settings.get("underpayment_tolerance_percent", 0.25) or 0.25)
        if difference_percent < -abs(tolerance):
            issues.append("underpayment")
        if difference_percent > float(settings.get("overpayment_requires_review_percent", 10) or 10):
            issues.append("large_overpayment")
        if issues:
            status = "review_required"
    elif method == "card" and not order.get("receipt_file_id"):
        issues.append("receipt_missing")
        status = "review_required"

    txid = str(order.get("transaction_hash") or "").lower().removeprefix("0x")
    if txid:
        duplicates = [
            row
            for row in db.get("vip_orders", [])
            if isinstance(row, dict)
            and row is not order
            and str(row.get("transaction_hash") or "").lower().removeprefix("0x") == txid
        ]
        if duplicates:
            issues.append("duplicate_txid")
            status = "blocked"

    result = {
        "id": next_id(db, "payment_reconciliation"),
        "order_id": str(order.get("order_id") or ""),
        "user_id": str(order.get("user_id") or ""),
        "payment_method": method,
        "network": network,
        "status": status,
        "issues": issues,
        "expected_amount": format(expected, "f"),
        "received_amount": format(received, "f"),
        "difference_amount": format(difference, "f"),
        "difference_percent": round(difference_percent, 4),
        "confirmations": confirmations,
        "required_confirmations": minimum,
        "actor_id": str(actor_id),
        "created_at": utc_iso(),
    }
    db.setdefault("payment_reconciliations", []).append(result)
    db["payment_reconciliations"] = db["payment_reconciliations"][-50_000:]
    order["reconciliation_status"] = status
    order["reconciliation_issues"] = list(issues)
    order["reconciled_at"] = result["created_at"]
    return result


def reconciliation_summary(db: dict[str, Any]) -> dict[str, Any]:
    orders = [row for row in db.get("vip_orders", []) if isinstance(row, dict)]
    rows = [row for row in db.get("payment_reconciliations", []) if isinstance(row, dict)]
    latest_by_order: dict[str, dict[str, Any]] = {}
    for row in rows:
        latest_by_order[str(row.get("order_id") or "")] = row
    counts = Counter(str(row.get("status") or "unknown") for row in latest_by_order.values())
    return {
        "orders_total": len(orders),
        "pending_orders": sum(
            1 for row in orders if str(row.get("status") or "") in {"pending", "approving", "awaiting_payment"}
        ),
        "matched": counts.get("matched", 0),
        "review_required": counts.get("review_required", 0),
        "blocked": counts.get("blocked", 0),
        "unreconciled": sum(1 for row in orders if str(row.get("order_id") or "") not in latest_by_order),
        "latest": list(reversed(rows[-20:])),
    }

