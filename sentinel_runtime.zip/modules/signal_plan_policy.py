"""Read-only entry checks for locked strategy snapshots, including old queues.

This is a publication rule, not a migration: it never rewrites a historical
entry, stop, target, hash or paper result. Market freshness is checked separately.
"""
from decimal import Decimal, InvalidOperation

POLICY = 'locked-entry-geometry-indicator-stop-suite15-v3'
ENTRY_ENGINES = {'indicators', 'sweep_fvg', 'order_block', 'fibonacci_pullback','custom'}


def _number(value):
    if isinstance(value, bool):
        raise ValueError('SIGNAL_PRICE_INVALID')
    try:
        result = Decimal(str(value))
        if not result.is_finite() or result <= 0:
            raise ValueError('SIGNAL_PRICE_INVALID')
        return result
    except (InvalidOperation, TypeError):
        raise ValueError('SIGNAL_PRICE_INVALID') from None


def validate_locked_signal_plan(plan, *, custom_scope=False):
    from modules.signal_execution import mode_of,validate_market
    if isinstance(plan,dict) and mode_of(plan)=='MARKET':
        validate_market(plan)
        return {'policy':POLICY,'allowed':True,'freshness_checked':False,'execution_mode':'MARKET'}
    if not isinstance(plan, dict) or plan.get('engine') not in ENTRY_ENGINES or plan.get('direction') not in {'BUY', 'SELL'}:
        raise ValueError('SIGNAL_ENTRY_CLASSIFICATION_INVALID')
    try:
        low, high, entry, stop, tp1, tp2 = (_number(plan[key]) for key in
                                          ('zone_low', 'zone_high', 'entry', 'stop', 'tp1', 'tp2'))
        quantum = _number(plan.get('tick_size', plan.get('calculation_quantum')))
        third = _number(plan['tp3']) if plan.get('tp3') is not None else None
    except KeyError:
        raise ValueError('SIGNAL_LEVELS_INCOMPLETE') from None
    sign = Decimal(1) if plan['direction'] == 'BUY' else Decimal(-1)
    if not low < high or not low <= entry <= high:
        raise ValueError('SIGNAL_ENTRY_ZONE_INVALID')
    boundary = low if sign == 1 else high
    if sign * (boundary - stop) <= 0:
        raise ValueError('SIGNAL_STOP_INSIDE_ORIGINAL_ZONE')
    if sign * (tp1 - entry) <= 0 or sign * (tp2 - tp1) <= 0 or (third is not None and sign * (third - tp2) <= 0):
        raise ValueError('SIGNAL_TARGET_ORDER_INVALID')
    from modules.signal_targets import validate,pairs
    validate(plan)
    if abs(tp1 - entry) < 2 * abs(entry - stop):
        raise ValueError('SIGNAL_TP1_BELOW_2R')
    try:
        off_grid=any(value % quantum for value in (entry,stop,*(_number(value) for _,value in pairs(plan))))
    except ArithmeticError:
        raise ValueError('SIGNAL_PRICE_GRID_UNREPRESENTABLE') from None
    if off_grid:
        raise ValueError('SIGNAL_LEVEL_OFF_PRICE_GRID')
    risk=next((f.get('detail',{}) for f in plan.get('evidence',()) if f.get('kind')=='native_grid_risk'),{})
    if risk.get('floor_policy')=='STRUCTURE_PLUS_ATR_SPREAD_TICK_V1':
        atr=_number(risk.get('atr'))
        floor=_number(risk.get('minimum_risk_distance'))
        try:
            spread=Decimal(str(risk['spread']))
            if not spread.is_finite() or spread<0:raise ValueError('SIGNAL_STOP_SPREAD_INVALID')
        except (KeyError,InvalidOperation,TypeError):raise ValueError('SIGNAL_STOP_SPREAD_INVALID') from None
        if floor<max(atr,spread*3,quantum*4) or abs(entry-stop)<floor:raise ValueError('SIGNAL_STOP_VOLATILITY_FLOOR_REQUIRED')
    if plan['engine']=='custom':
        from modules.custom_strategy import validate_plan
        validate_locked_signal_plan(validate_plan(plan),custom_scope=True)
    if plan['engine'] == 'indicators':
        _indicator_stop(plan, entry, stop, boundary, quantum, sign,custom_scope=custom_scope)
    structure = [f for f in plan.get('evidence',()) if f.get('kind')=='structural_stop']
    if structure:
        if len(structure)!=1:
            raise ValueError('STRUCTURAL_STOP_EVIDENCE_INVALID')
        proof=structure[0].get('detail') or {}
        cutoff=plan.get('evidence_cutoff_ms')
        if (proof.get('selection_policy')!='LATEST_CONFIRMED_SWING_WITH_CAUSAL_INVALIDATION_V1'
                or type(cutoff) is not int or type(proof.get('swing_available_ms')) is not int
                or not 0<=proof['swing_available_ms']<=cutoff
                or type(structure[0].get('available_ms')) is not int
                or not 0<=structure[0]['available_ms']<=cutoff
                or proof.get('target_levels_moved') is not False
                or _number(proof.get('stop'))!=stop):
            raise ValueError('STRUCTURAL_STOP_EVIDENCE_INVALID')
        protected=_number(proof.get('protected_boundary'))
        padding=_number(proof.get('buffer'))
        floor=_number(proof.get('minimum_risk_distance'))
        if (sign*(protected-stop)<padding or sign*(boundary-stop)<padding
                or abs(entry-stop)<floor):
            raise ValueError('STRUCTURAL_STOP_PROTECTION_INSUFFICIENT')
    return {'policy': POLICY, 'allowed': True, 'freshness_checked': False}


def _indicator_stop(plan, entry, stop, boundary, quantum, sign, *, custom_scope=False):
    evidence = plan.get('evidence', [])
    facts = [f for f in evidence if isinstance(f, dict) and f.get('kind') == 'all_directional_indicators'] if isinstance(evidence, (tuple, list)) else []
    if len(facts) != 1 or not isinstance(facts[0].get('detail'), dict):
        raise ValueError('INDICATOR_STOP_EVIDENCE_RESCAN_REQUIRED')
    detail = facts[0]['detail']
    votes = detail.get('directional_agreement', {})
    from modules.indicator_suite import DEFAULT_SELECTION, SUITE_VERSION
    expected=set(DEFAULT_SELECTION)
    if not custom_scope and detail.get('indicator_suite_version')!=SUITE_VERSION:
        raise ValueError('INDICATOR_SUITE_RESCAN_REQUIRED')
    if detail.get('custom_selection') is True:
        if not custom_scope:raise ValueError('CUSTOM_INDICATOR_SELECTION_SCOPE_INVALID')
        expected=set(detail.get('selected_indicators',()))
        if not expected or expected-set(DEFAULT_SELECTION):raise ValueError('INDICATOR_SELECTION_INVALID')
    if not isinstance(votes, dict) or set(votes) != expected or any(v is not True for v in votes.values()):
        raise ValueError('INDICATOR_ALL_DIRECTIONAL_CONFIRMATIONS_REQUIRED')
    protection = detail.get('stop_protection', {})
    if not isinstance(protection, dict) or protection.get('method') != 'CONFIRMED_STRUCTURE_ATR_SPREAD_FLOOR':
        raise ValueError('INDICATOR_STOP_EVIDENCE_RESCAN_REQUIRED')
    atr = _number(detail.get('atr'))
    minimum = _number(protection.get('minimum_risk_distance'))
    buffer = _number(protection.get('buffer'))
    swing = _number(protection.get('protective_swing'))
    spread = Decimal(0)
    if protection.get('spread_at_proposal') is not None:
        try:
            spread = Decimal(str(protection['spread_at_proposal']))
            if not spread.is_finite() or spread < 0:
                raise ValueError('INDICATOR_STOP_SPREAD_INVALID')
        except (InvalidOperation, TypeError):
            raise ValueError('INDICATOR_STOP_SPREAD_INVALID') from None
    cutoff = plan.get('evidence_cutoff_ms')
    available = protection.get('swing_available_ms')
    fact_time = facts[0].get('available_ms')
    if (type(cutoff) is not int or type(available) is not int or type(fact_time) is not int
            or not 0 <= available <= cutoff or not 0 <= fact_time <= cutoff):
        raise ValueError('INDICATOR_STOP_FUTURE_OR_MISSING_EVIDENCE')
    if detail.get('ema_periods') != [20, 50, 100] or detail.get('ema_type') != 'EMA' or detail.get('atr_is_directional_vote') is not False:
        raise ValueError('INDICATOR_CONFIRMATION_MODEL_RESCAN_REQUIRED')
    if protection.get('target_levels_moved') is not False:
        raise ValueError('INDICATOR_STRUCTURAL_TARGET_PROOF_REQUIRED')
    if (minimum < max(atr, 3 * spread, 4 * quantum) or buffer < max(2 * spread, 2 * quantum)
            or abs(entry - stop) < minimum or sign * (entry - swing) <= 0
            or sign * (swing - stop) < buffer or sign * (boundary - stop) < buffer):
        raise ValueError('INDICATOR_STOP_PROTECTION_INSUFFICIENT')


def entry_eligibility(plan):
    try:
        return validate_locked_signal_plan(plan)
    except (ValueError, ArithmeticError) as exc:
        return {'policy': POLICY, 'allowed': False, 'reason': str(exc),
                'freshness_checked': False, 'requires_rescan': True}


def assert_current_stop(plan,closed,spread):
    """Old queued prices are immutable; unsuitable stops must not publish."""
    from modules.strategies.common import indicators
    quantum=_number(plan.get('tick_size',plan.get('calculation_quantum')))
    floor=max(indicators(closed)['atr'],spread*3,quantum*4)
    if abs(_number(plan['entry'])-_number(plan['stop']))<floor:
        raise ValueError('STOP_NO_LONGER_PROTECTS_CURRENT_VOLATILITY')
