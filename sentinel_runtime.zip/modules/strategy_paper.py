from modules.signal_targets import TARGET_KEYS
"""Prospective R-normalized paper ledger. No broker orders or retrospective fills."""
from copy import deepcopy
from decimal import Decimal as D


def _open_market(trade,tick,balance):
    from modules.signal_execution import validate_market,market_detail
    p=deepcopy(trade);validate_market(p['plan'])
    if p['state']!='WAITING':raise ValueError('PAPER_MARKET_FRESH_ENTRY_REQUIRED')
    saved=market_detail(p['plan'])['quote']
    if any(tick[k]!=saved[k] for k in ('id','epoch','bid','ask','event_ms','received_ms')):
        raise ValueError('PAPER_MARKET_ANALYSIS_QUOTE_CHANGED')
    balance=D(balance);entry,stop=D(p['plan']['entry']),D(p['plan']['stop'])
    if not balance.is_finite() or balance<=0:
        p.update(state='CANCELLED',reason='PAPER_NO_POSITIVE_CAPITAL');return p
    distance=abs(entry-stop);risk=balance/100;quantity=risk/distance
    sign=D(1) if p['plan']['direction']=='BUY' else D(-1)
    close=D(tick['bid'] if sign==1 else tick['ask'])
    p.update(state='OPEN',entered_ms=tick['event_ms'],fill_price=str(entry),remaining='1',
             entry_balance_usd=str(balance),risk_usd=str(risk),risk_percent='1',risk_distance=str(distance),
             quantity=str(quantity),quantity_unit='VIRTUAL_USD_PER_PRICE_UNIT',sizing_policy='ONE_PERCENT_ENTRY_BALANCE_V2',
             unrealized_usd=str(quantity*sign*(close-entry)))
    p['events'].append({'type':'ENTRY','execution_mode':'MARKET','at_ms':tick['event_ms'],'price':str(entry),
        'observed_price':str(entry),'risk_usd':str(risk),'quantity':str(quantity),'entry_balance_usd':str(balance)})
    return p


def _advance(trade, tick):
    p=deepcopy(trade)
    if p['state'] not in {'WAITING','OPEN'}: return p, D(0)
    if tick['epoch']!=p['epoch']:
        p.update(state='NEEDS_REVIEW',reason='SOURCE_SESSION_CHANGED');return p,D(0)
    if tick['id']==p['last_tick_id']: return p,D(0)
    if tick['received_ms']<p['last_received_ms'] or tick['event_ms']<p['last_event_ms']:
        p.update(state='NEEDS_REVIEW',reason='QUOTE_ORDER_UNKNOWN');return p,D(0)
    if tick['received_ms']-p['last_received_ms']>5000:
        p.update(state='NEEDS_REVIEW',reason='QUOTE_COVERAGE_GAP');return p,D(0)
    bid,ask=D(tick['bid']),D(tick['ask'])
    if not bid.is_finite() or not ask.is_finite() or bid<=0 or ask<bid:raise ValueError('PAPER_QUOTE_INVALID')
    p.update(last_tick_id=tick['id'],last_received_ms=tick['received_ms'],last_event_ms=tick['event_ms'],
             last_quote={k:tick[k] for k in ('bid','ask','event_ms','received_ms')})
    if tick['received_ms']<p.get('armed_ms',0):return p,D(0)
    entry,stop=D(p['plan']['entry']),D(p['plan']['stop'])
    sign=D(1) if p['plan']['direction']=='BUY' else D(-1)
    executable=ask if sign==1 else bid
    close=bid if sign==1 else ask
    if p['state']=='WAITING':
        if sign*(close-stop)<=0:
            p.update(state='CANCELLED',reason='INVALIDATION_BEFORE_PAPER_ENTRY');return p,D(0)
        breakout=p['plan']['submodel']=='range_breakout'
        crossed=sign*(executable-entry)>=0 if breakout else sign*(executable-entry)<=0
        if not crossed: return p,D(0)
        # A sampled price jumping across a limit or stop cannot prove the fill.
        if abs(executable-entry)>max(D(p['plan'].get('tick_size',p['plan'].get('calculation_quantum','0')))*2,abs(entry-stop)*D('.1')):
            p.update(state='NEEDS_REVIEW',reason='ENTRY_GAP_FILL_UNPROVEN');return p,D(0)
        fill=executable if breakout else entry
        if 'entry_balance_usd' in p:
            balance=D(p['entry_balance_usd'])
            if not balance.is_finite() or balance<=0:
                p.update(state='CANCELLED',reason='PAPER_NO_POSITIVE_CAPITAL');return p,D(0)
            # Freeze risk at entry, including the accepted breakout fill distance.
            distance=abs(fill-stop)
            if distance<=0:raise ValueError('PAPER_RISK_DISTANCE_INVALID')
            if sign*(D(p['plan']['tp1'])-fill)<distance*2:
                p.update(state='NEEDS_REVIEW',reason='ACTUAL_FILL_TP1_BELOW_2R');return p,D(0)
            risk=balance/100
            p.update(risk_usd=str(risk),risk_percent='1',risk_distance=str(distance),
                     quantity=str(risk/distance),quantity_unit='VIRTUAL_USD_PER_PRICE_UNIT',
                     sizing_policy='ONE_PERCENT_ENTRY_BALANCE_V2')
        p.update(state='OPEN',entered_ms=tick['event_ms'],fill_price=str(fill),remaining='1')
        p['unrealized_usd']=str(D(p.get('quantity',str(D(p['risk_usd'])/abs(fill-stop))))*sign*(close-fill))
        p['events'].append({'type':'ENTRY','at_ms':tick['event_ms'],'price':str(fill),
                            'observed_price':str(executable),'risk_usd':p['risk_usd'],
                            'quantity':p.get('quantity'),'entry_balance_usd':p.get('entry_balance_usd')})
        # Never infer entry and target/SL order in the same sample.
        return p,D(0)
    risk=D(p['risk_usd']);distance=D(p.get('risk_distance',str(abs(entry-stop))));delta=D(0)
    if sign*(close-stop)<=0:
        # Stop uses the observed bid/ask, including adverse gaps.
        portion=D(p['remaining']);delta=risk*portion*sign*(close-D(p['fill_price']))/distance
        p.update(state='CLOSED',remaining='0',closed_ms=tick['event_ms'],reason='SL')
        p['events'].append({'type':'SL','at_ms':tick['event_ms'],'price':str(close),'portion':str(portion),'pnl':str(delta)})
    else:
        targets=[D(p['plan'][k]) for k in TARGET_KEYS if p['plan'].get(k) is not None]
        for i,target in enumerate(targets):
            if i<len(p['targets_hit']) or sign*(close-target)<0: continue
            portion=D(p['remaining']) if i==len(targets)-1 else D(p['remaining'])/2
            # A limit TP is recorded at its locked level, never a better fill.
            pnl=risk*portion*sign*(target-D(p['fill_price']))/distance
            delta+=pnl;p['remaining']=str(D(p['remaining'])-portion);p['targets_hit'].append(i+1)
            p['events'].append({'type':f'TP{i+1}','at_ms':tick['event_ms'],'price':str(target),'portion':str(portion),'pnl':str(pnl)})
        if D(p['remaining'])==0:p.update(state='CLOSED',closed_ms=tick['event_ms'],reason='ALL_TARGETS')
    p['realized_usd']=str(D(p['realized_usd'])+delta)
    if p['state']=='OPEN':
        p['unrealized_usd']=str(risk*D(p['remaining'])*sign*(close-D(p['fill_price']))/distance)
    else:p['unrealized_usd']='0'
    return p,delta


def _close_manually(trade,tick,actor):
    """Close a proven open remainder at the same validated executable quote."""
    p=deepcopy(trade)
    if p['state']!='OPEN' or p['last_tick_id']!=tick['id'] or p['epoch']!=tick['epoch']:
        raise ValueError('PAPER_MANUAL_CLOSE_UNPROVEN')
    bid,ask=D(tick['bid']),D(tick['ask'])
    if not bid.is_finite() or not ask.is_finite() or bid<=0 or ask<bid:raise ValueError('PAPER_QUOTE_INVALID')
    sign=D(1) if p['plan']['direction']=='BUY' else D(-1)
    price=D(tick['bid'] if sign==1 else tick['ask'])
    distance=D(p.get('risk_distance',str(abs(D(p['plan']['entry'])-D(p['plan']['stop'])))))
    portion=D(p['remaining'])
    delta=D(p['risk_usd'])*portion*sign*(price-D(p['fill_price']))/distance
    p.update(state='CLOSED',remaining='0',closed_ms=tick['event_ms'],reason='ADMIN_CLOSE',
             realized_usd=str(D(p['realized_usd'])+delta),unrealized_usd='0')
    p['events'].append({'type':'ADMIN_CLOSE','at_ms':tick['event_ms'],'price':str(price),
                        'portion':str(portion),'pnl':str(delta),'actor':str(actor)})
    return p,delta


def open_market(trade,tick,balance):
    from modules.paper_costs import entry
    p=_open_market(trade,tick,balance)
    from modules.paper_excursions import observe
    return observe(entry(p,tick)[0],tick)


def advance(trade,tick):
    from modules.paper_costs import after
    p,gross_delta=_advance(trade,tick)
    p,cost_delta=after(trade,p,tick,gross_delta)
    from modules.paper_excursions import observe
    return observe(p,tick),gross_delta+cost_delta


def close_manually(trade,tick,actor):
    from modules.paper_costs import after
    p,gross_delta=_close_manually(trade,tick,actor)
    p,cost_delta=after(trade,p,tick,gross_delta)
    from modules.paper_excursions import observe
    return observe(p,tick),gross_delta+cost_delta
