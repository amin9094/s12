from __future__ import annotations

from typing import Any

from core.utils import utc_iso

ADMIN_UI_MODES = {"basic", "advanced"}

BASIC_CATEGORY_CALLBACKS: dict[str, set[str]] = {
    "trading": {
        "a_signal",
        "a_signal_results",
        "sig_tpl_home",
        "sig_exposure",
        "a_channel_center",
    },
    "content": {
        "a_market_intel",
        "a_announcement",
        "a_edu",
        "a_faq",
    },
    "sales": {
        "a_pending",
        "a_reconciliation",
        "a_vip_settings",
        "a_disc",
        "a_campaigns",
    },
    "users": {
        "a_users",
        "a_crm",
        "a_tickets",
        "a_rules",
    },
    "analytics": {
        "a_mission_control",
        "a_dashboard",
        "a_trust_center",
        "a_provider_health",
    },
    "system": {
        "a_control_center",
        "a_system_center",
        "a_features",
        "a_incidents",
        "a_backups",
        "a_admins",
    },
}


def admin_ui_preferences(db: dict[str, Any], admin_id: int | str) -> dict[str, Any]:
    rows = db.setdefault("operations", {}).setdefault("admin_ui_preferences", {})
    key = str(int(admin_id))
    row = rows.setdefault(
        key,
        {
            "mode": "basic",
            "favorites": [],
            "updated_at": None,
        },
    )
    if row.get("mode") not in ADMIN_UI_MODES:
        row["mode"] = "basic"
    row.setdefault("favorites", [])
    return row


def admin_ui_mode(db: dict[str, Any], admin_id: int | str) -> str:
    return str(admin_ui_preferences(db, admin_id).get("mode") or "basic")


def set_admin_ui_mode(
    db: dict[str, Any],
    admin_id: int | str,
    mode: str,
) -> dict[str, Any]:
    clean = str(mode or "").strip().lower()
    if clean not in ADMIN_UI_MODES:
        raise ValueError("حالت پنل معتبر نیست.")
    row = admin_ui_preferences(db, admin_id)
    row["mode"] = clean
    row["updated_at"] = utc_iso()
    return dict(row)


def callback_visible_in_mode(
    category: str,
    callback: str,
    mode: str,
) -> bool:
    if mode == "advanced":
        return True
    allowed = BASIC_CATEGORY_CALLBACKS.get(str(category), set())
    return not allowed or str(callback) in allowed
