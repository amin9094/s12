from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any

from core.db import next_id
from core.utils import utc_iso

MAX_TICKETS = 1000
MAX_OPEN_PER_USER = 3
MAX_MESSAGES_PER_TICKET = 100
MAX_MESSAGE_LENGTH = 4000
MAX_FAQS = 200
ALLOWED_ATTACHMENT_TYPES = {"photo", "document", "video", "voice", "audio"}


def _clean_text(value: Any, *, max_length: int) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError("متن نمی‌تواند خالی باشد.")
    return text[:max_length]


def normalize_attachment(value: dict[str, Any] | None) -> dict[str, Any] | None:
    if not value:
        return None
    kind = str(value.get("type") or "").lower()
    file_id = str(value.get("file_id") or "").strip()
    storage_id = str(value.get("storage_id") or "").strip()
    if kind not in ALLOWED_ATTACHMENT_TYPES or not (file_id or storage_id):
        return None
    return {
        "type": kind,
        "file_id": file_id[:512],
        "storage_id": storage_id[:160],
        "download_url": str(value.get("download_url") or "")[:500],
        "file_unique_id": str(value.get("file_unique_id") or "")[:256],
        "file_name": str(value.get("file_name") or "")[:255],
        "mime_type": str(value.get("mime_type") or "")[:120],
        "file_size": max(0, int(value.get("file_size", 0) or 0)),
        "caption": str(value.get("caption") or "")[:1000],
    }


def ticket_attachment_transport(value: dict[str, Any] | None) -> tuple[str, str] | None:
    """Return the Telegram send method/media argument name and stored file id."""
    attachment = normalize_attachment(value)
    if not attachment:
        return None
    kind = str(attachment["type"])
    return kind, str(attachment["file_id"])


def add_internal_note(db: dict[str, Any], ticket_id: int | str, admin_id: int | str, text: str) -> dict[str, Any]:
    ticket = find_ticket(db, ticket_id)
    if not ticket:
        raise ValueError("تیکت پیدا نشد.")
    note = {
        "admin_id": str(int(admin_id)),
        "text": _clean_text(text, max_length=2000),
        "created_at": utc_iso(),
    }
    notes = db.setdefault("support_internal_notes", {}).setdefault(str(int(ticket_id)), [])
    notes.append(note)
    db["support_internal_notes"][str(int(ticket_id))] = notes[-100:]
    return note


def internal_notes(db: dict[str, Any], ticket_id: int | str) -> list[dict[str, Any]]:
    rows = db.get("support_internal_notes", {}).get(str(int(ticket_id)), [])
    return [dict(item) for item in rows if isinstance(item, dict)]


def create_canned_reply(db: dict[str, Any], title: str, text: str, admin_id: int | str) -> dict[str, Any]:
    rows = db.setdefault("support_canned_replies", [])
    item = {
        "id": max((int(row.get("id", 0) or 0) for row in rows if isinstance(row, dict)), default=0) + 1,
        "title": _clean_text(title, max_length=80),
        "text": _clean_text(text, max_length=4000),
        "active": True,
        "created_by": str(int(admin_id)),
        "created_at": utc_iso(),
    }
    rows.append(item)
    db["support_canned_replies"] = rows[-500:]
    return item


def canned_replies(db: dict[str, Any], *, active_only: bool = True) -> list[dict[str, Any]]:
    rows = [dict(item) for item in db.get("support_canned_replies", []) if isinstance(item, dict)]
    if active_only:
        rows = [item for item in rows if item.get("active", True)]
    return rows


def create_ticket(
    db: dict[str, Any],
    user_id: int | str,
    text: str,
    *,
    subject: str = "پشتیبانی",
    category: str = "general",
    priority: str = "normal",
    attachment: dict[str, Any] | None = None,
    context_type: str = "",
    context_id: str = "",
) -> dict[str, Any]:
    uid = str(int(user_id))
    tickets = db.setdefault("tickets", [])
    open_count = sum(1 for item in tickets if isinstance(item, dict) and str(item.get("user_id")) == uid and str(item.get("status") or "open").lower() in {"open", "pending", "answered"})
    from modules.admin_control_center import module_state

    support_controls = module_state(db, "support")
    configured_max = int(support_controls.get("max_open", MAX_OPEN_PER_USER) or MAX_OPEN_PER_USER)
    configured_max = max(1, min(50, configured_max))
    if open_count >= configured_max:
        raise ValueError(f"حداکثر {configured_max} تیکت باز می‌توانید داشته باشید.")
    now = utc_iso()
    category_value = str(category or "general").lower()
    if category_value not in {"general", "account", "payment", "signal", "education", "technical"}:
        category_value = "general"
    priority_value = str(priority or "normal").lower()
    if priority_value not in {"low", "normal", "high", "urgent"}:
        priority_value = "normal"
    sla_hours = {
        "low": max(1, int(support_controls.get("sla_normal_h", 24) or 24) * 3),
        "normal": max(1, int(support_controls.get("sla_normal_h", 24) or 24)),
        "high": max(1, int(support_controls.get("sla_urgent_h", 2) or 2) * 4),
        "urgent": max(1, int(support_controls.get("sla_urgent_h", 2) or 2)),
    }[priority_value]
    sla_due_at = (datetime.now(UTC) + timedelta(hours=sla_hours)).isoformat()
    ticket = {
        "id": next_id(db, "ticket"),
        "user_id": uid,
        "subject": _clean_text(subject, max_length=200),
        "status": "open",
        "category": category_value,
        "priority": priority_value,
        "assigned_admin": "",
        "waiting_for": "admin",
        "sla_due_at": sla_due_at,
        "first_response_at": None,
        "satisfaction": None,
        "messages": [
            {
                "sender": "user",
                "sender_id": uid,
                "text": _clean_text(text, max_length=MAX_MESSAGE_LENGTH),
                "attachment": normalize_attachment(attachment),
                "created_at": now,
            }
        ],
        "created_at": now,
        "updated_at": now,
        "closed_at": None,
    }
    if context_type:
        from modules.ticket_context import attach_context
        attach_context(db, ticket, context_type, context_id)
    tickets.append(ticket)
    db["tickets"] = tickets[-MAX_TICKETS:]
    return ticket


def find_ticket(db: dict[str, Any], ticket_id: int | str) -> dict[str, Any] | None:
    try:
        wanted = int(ticket_id)
    except (TypeError, ValueError):
        return None
    return next((item for item in db.get("tickets", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == wanted), None)


def append_ticket_message(
    db: dict[str, Any],
    ticket_id: int | str,
    sender: str,
    sender_id: int | str,
    text: str,
    attachment: dict[str, Any] | None = None,
) -> dict[str, Any]:
    ticket = find_ticket(db, ticket_id)
    if not ticket:
        raise ValueError("تیکت پیدا نشد.")
    if str(ticket.get("status") or "open").lower() == "closed":
        raise ValueError("این تیکت بسته شده است.")
    sender_value = "admin" if str(sender).lower() == "admin" else "user"
    if sender_value == "user" and str(ticket.get("user_id")) != str(int(sender_id)):
        raise PermissionError("این تیکت متعلق به شما نیست.")
    now = utc_iso()
    messages = ticket.setdefault("messages", [])
    messages.append(
        {
            "sender": sender_value,
            "sender_id": str(int(sender_id)),
            "text": _clean_text(text, max_length=MAX_MESSAGE_LENGTH),
            "attachment": normalize_attachment(attachment),
            "created_at": now,
        }
    )
    ticket["messages"] = messages[-MAX_MESSAGES_PER_TICKET:]
    ticket["updated_at"] = now
    ticket["waiting_for"] = "user" if sender_value == "admin" else "admin"
    ticket["status"] = "answered" if sender_value == "admin" else "pending"
    ticket["closed_at"] = None
    if sender_value == "admin" and not ticket.get("first_response_at"):
        ticket["first_response_at"] = now
        ticket["assigned_admin"] = str(int(sender_id))
    return ticket


def set_ticket_status(db: dict[str, Any], ticket_id: int | str, status: str) -> dict[str, Any]:
    ticket = find_ticket(db, ticket_id)
    if not ticket:
        raise ValueError("تیکت پیدا نشد.")
    normalized = str(status).lower()
    if normalized not in {"open", "pending", "answered", "closed"}:
        raise ValueError("وضعیت تیکت نامعتبر است.")
    now = utc_iso()
    ticket["status"] = normalized
    ticket["updated_at"] = now
    ticket["closed_at"] = now if normalized == "closed" else None
    if normalized == "closed":
        ticket["waiting_for"] = "closed"
    elif normalized == "answered":
        ticket["waiting_for"] = "user"
    else:
        ticket["waiting_for"] = "admin"
    return ticket


def set_ticket_priority(db: dict[str, Any], ticket_id: int | str, priority: str) -> dict[str, Any]:
    ticket = find_ticket(db, ticket_id)
    if not ticket:
        raise ValueError("تیکت پیدا نشد.")
    value = str(priority or "normal").lower()
    if value not in {"low", "normal", "high", "urgent"}:
        raise ValueError("اولویت نامعتبر است.")
    ticket["priority"] = value
    hours = {"low": 72, "normal": 24, "high": 8, "urgent": 2}[value]
    ticket["sla_due_at"] = (datetime.now(UTC) + timedelta(hours=hours)).isoformat()
    ticket["updated_at"] = utc_iso()
    return ticket


def assign_ticket(db: dict[str, Any], ticket_id: int | str, admin_id: int | str) -> dict[str, Any]:
    ticket = find_ticket(db, ticket_id)
    if not ticket:
        raise ValueError("تیکت پیدا نشد.")
    ticket["assigned_admin"] = str(int(admin_id))
    ticket["updated_at"] = utc_iso()
    return ticket


def set_ticket_satisfaction(db: dict[str, Any], ticket_id: int | str, user_id: int | str, score: int) -> dict[str, Any]:
    ticket = find_ticket(db, ticket_id)
    if not ticket or str(ticket.get("user_id")) != str(int(user_id)):
        raise PermissionError("این تیکت متعلق به شما نیست.")
    value = int(score)
    if value not in {1, 2, 3, 4, 5}:
        raise ValueError("امتیاز نامعتبر است.")
    ticket["satisfaction"] = value
    ticket["satisfaction_at"] = utc_iso()
    return ticket


def user_tickets(db: dict[str, Any], user_id: int | str) -> list[dict[str, Any]]:
    uid = str(int(user_id))
    rows = [item for item in db.get("tickets", []) if isinstance(item, dict) and str(item.get("user_id")) == uid]
    return sorted(rows, key=lambda item: (item.get("updated_at") or "", int(item.get("id", 0) or 0)), reverse=True)


def admin_tickets(db: dict[str, Any], *, status: str | None = None) -> list[dict[str, Any]]:
    rows = [item for item in db.get("tickets", []) if isinstance(item, dict)]
    if status:
        rows = [item for item in rows if item.get("status") == status]
    return sorted(rows, key=lambda item: (item.get("updated_at") or "", int(item.get("id", 0) or 0)), reverse=True)



def normalize_faq(item: dict[str, Any], position: int = 0) -> dict[str, Any]:
    item.setdefault("id", position or 0)
    item.setdefault("q", str(item.get("question") or ""))
    item.setdefault("a", str(item.get("answer") or ""))
    item.setdefault("category", "عمومی")
    item.setdefault("active", True)
    item.setdefault("position", position or int(item.get("id", 0) or 0))
    item.setdefault("views", 0)
    item.setdefault("helpful", 0)
    item.setdefault("not_helpful", 0)
    item.setdefault("created_at", utc_iso())
    item.setdefault("updated_at", item.get("created_at"))
    return item


def ensure_faqs(db: dict[str, Any]) -> list[dict[str, Any]]:
    rows = db.setdefault("faq", [])
    for index, item in enumerate(rows, start=1):
        if isinstance(item, dict):
            normalize_faq(item, index)
    return rows

def create_faq(
    db: dict[str, Any],
    question: str,
    answer: str,
    *,
    category: str = "عمومی",
    active: bool = True,
) -> dict[str, Any]:
    from modules.admin_control_center import module_state

    faqs = ensure_faqs(db)
    maximum = int(module_state(db, "faq").get("max_items", MAX_FAQS) or MAX_FAQS)
    if len(faqs) >= maximum:
        raise ValueError("حداکثر تعداد سوالات متداول ثبت شده است.")
    now = utc_iso()
    item = {
        "id": next_id(db, "faq"),
        "q": _clean_text(question, max_length=300),
        "a": _clean_text(answer, max_length=4000),
        "category": _clean_text(category or "عمومی", max_length=80),
        "active": bool(active),
        "position": len(faqs) + 1,
        "views": 0,
        "helpful": 0,
        "not_helpful": 0,
        "created_at": now,
        "updated_at": now,
    }
    faqs.append(item)
    return item


def find_faq(db: dict[str, Any], faq_id: int | str) -> dict[str, Any] | None:
    ensure_faqs(db)
    try:
        wanted = int(faq_id)
    except (TypeError, ValueError):
        return None
    return next((item for item in db.get("faq", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == wanted), None)



def update_faq(
    db: dict[str, Any],
    faq_id: int | str,
    *,
    question: str | None = None,
    answer: str | None = None,
    category: str | None = None,
) -> dict[str, Any]:
    item = find_faq(db, faq_id)
    if not item:
        raise ValueError("سؤال متداول پیدا نشد")
    if question is not None:
        item["q"] = _clean_text(question, max_length=300)
    if answer is not None:
        item["a"] = _clean_text(answer, max_length=4000)
    if category is not None:
        item["category"] = _clean_text(category or "عمومی", max_length=80)
    item["updated_at"] = utc_iso()
    return item


def toggle_faq(db: dict[str, Any], faq_id: int | str) -> dict[str, Any]:
    item = find_faq(db, faq_id)
    if not item:
        raise ValueError("سؤال متداول پیدا نشد")
    item["active"] = not bool(item.get("active", True))
    item["updated_at"] = utc_iso()
    return item


def record_faq_view(db: dict[str, Any], faq_id: int | str) -> dict[str, Any]:
    item = find_faq(db, faq_id)
    if not item or not item.get("active", True):
        raise ValueError("سؤال متداول در دسترس نیست")
    item["views"] = int(item.get("views", 0) or 0) + 1
    return item


def record_faq_feedback(db: dict[str, Any], faq_id: int | str, user_id: int | str, helpful: bool) -> dict[str, Any]:
    item = find_faq(db, faq_id)
    if not item or not item.get("active", True):
        raise ValueError("سؤال متداول در دسترس نیست")
    feedback = db.setdefault("faq_feedback", {}).setdefault(str(item["id"]), {})
    uid = str(user_id)
    previous = feedback.get(uid)
    new_value = "yes" if helpful else "no"
    if previous == new_value:
        return item
    if previous == "yes":
        item["helpful"] = max(0, int(item.get("helpful", 0) or 0) - 1)
    elif previous == "no":
        item["not_helpful"] = max(0, int(item.get("not_helpful", 0) or 0) - 1)
    feedback[uid] = new_value
    key = "helpful" if helpful else "not_helpful"
    item[key] = int(item.get(key, 0) or 0) + 1
    return item


def search_faqs(db: dict[str, Any], query: str, *, active_only: bool = True, limit: int = 20) -> list[dict[str, Any]]:
    ensure_faqs(db)
    needle = str(query or "").strip().casefold()
    rows = []
    for item in db.get("faq", []):
        if not isinstance(item, dict):
            continue
        if active_only and not item.get("active", True):
            continue
        haystack = f"{item.get('q', '')} {item.get('a', '')} {item.get('category', '')}".casefold()
        if not needle or needle in haystack:
            rows.append(item)
    rows.sort(
        key=lambda item: (
            -int(item.get("helpful", 0) or 0),
            -int(item.get("views", 0) or 0),
            int(item.get("position", item.get("id", 0)) or 0),
        )
    )
    return rows[: max(1, int(limit))]

def delete_faq(db: dict[str, Any], faq_id: int | str) -> dict[str, Any] | None:
    item = find_faq(db, faq_id)
    if not item:
        return None
    db["faq"] = [row for row in db.get("faq", []) if row is not item]
    return item


def find_canned_reply(db: dict[str, Any], reply_id: int | str) -> dict[str, Any] | None:
    try:
        wanted = int(reply_id)
    except (TypeError, ValueError):
        return None
    return next(
        (item for item in db.get("support_canned_replies", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == wanted),
        None,
    )


def delete_canned_reply(db: dict[str, Any], reply_id: int | str) -> dict[str, Any] | None:
    item = find_canned_reply(db, reply_id)
    if not item:
        return None
    db["support_canned_replies"] = [row for row in db.get("support_canned_replies", []) if row is not item]
    return item


def toggle_canned_reply(db: dict[str, Any], reply_id: int | str) -> dict[str, Any]:
    item = find_canned_reply(db, reply_id)
    if not item:
        raise ValueError("پاسخ آماده پیدا نشد")
    item["active"] = not bool(item.get("active", True))
    item["updated_at"] = utc_iso()
    return item
