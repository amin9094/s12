"""Explicit instrument specifications only; no invented broker fees or lots.

Absent specifications retain the historical virtual USD/R experiment and mark
net costs unknown. Complete future-only profiles enable lot-step sizing and
commission/elapsed-time financing. Rates are USD per lot, supplied by admin.
"""
from decimal import Decimal as D,ROUND_FLOOR
from copy import deepcopy

FIELDS=('usd_per_quote_currency','contract_size','min_volume','volume_step','commission_usd_per_lot_side','financing_usd_per_lot_day')


def parse(value):
    if value is None:return None
    if not isinstance(value,dict) or set(value)!=set(FIELDS):raise ValueError('PAPER_COST_SPEC_INCOMPLETE')
    result={}
    for key in FIELDS:
        if isinstance(value[key],bool):raise ValueError('PAPER_COST_SPEC_INVALID')
        v=D(str(value[key]))
        if not v.is_finite() or (v<=0 if key in FIELDS[:4] else v<0 if key=='commission_usd_per_lot_side' else False):raise ValueError('PAPER_COST_SPEC_INVALID')
        result[key]=str(v)
    return result


def entry(p,tick):
    if p.get('entered_ms') is None or p.get('costs_initialized'):return p,D(0)
    spec=p.get('cost_model');p['costs_initialized']=True
    p.update(gross_realized_usd=p.get('realized_usd','0'),costs_usd='0',fees_included=spec is not None,
             cost_status='KNOWN_CONFIGURED_ESTIMATE' if spec is not None else 'UNKNOWN_NOT_ZERO')
    if spec is None:return p,D(0)
    spec=parse(spec);budget=D(p['risk_usd']);distance=D(p['risk_distance'])
    rate=D(spec['usd_per_quote_currency']);contract=D(spec['contract_size']);step=D(spec['volume_step'])
    commission=D(spec['commission_usd_per_lot_side'])
    lots=(budget/(distance*rate*contract+commission*2)/step).to_integral_value(rounding=ROUND_FLOOR)*step
    if lots<D(spec['min_volume']):
        p.update(state='CANCELLED',reason='CONFIGURED_MIN_VOLUME_EXCEEDS_RISK_BUDGET',remaining='0',unrealized_usd='0')
        p.pop('entered_ms',None);p.pop('fill_price',None);p['events']=[e for e in p['events'] if e.get('type')!='ENTRY'];return p,D(0)
    qty=lots*contract*rate;risk=qty*distance;fee=lots*commission
    p.update(risk_budget_usd=str(budget),risk_usd=str(risk),quantity=str(qty),contract_volume=str(lots),
             round_trip_stop_risk_with_commission_usd=str(risk+2*fee),last_cost_ms=tick['event_ms'])
    sign=1 if p['plan']['direction']=='BUY' else -1;close=D(tick['bid'] if sign==1 else tick['ask'])
    p['unrealized_usd']=str(qty*sign*(close-D(p['fill_price'])))
    for e in p['events']:
        if e.get('type')=='ENTRY':e.update(risk_usd=str(risk),quantity=str(qty),contract_volume=str(lots))
    return charge(p,fee,tick['event_ms'],'ENTRY_COMMISSION')


def charge(p,amount,at_ms,reason):
    previous_costs=D(p.get('costs_usd','0'))
    p['costs_usd']=str(previous_costs+amount)
    p['realized_usd']=str(D(p.get('realized_usd','0'))-amount)
    if amount:
        # Exact running totals remain authoritative. Financing events are a
        # bounded daily display ledger, never one JSON event per quote.
        period=at_ms//86400000*86400000
        last=p['events'][-1] if p['events'] else {}
        if (reason=='ELAPSED_FINANCING' and last.get('type')=='COST'
            and last.get('reason')==reason and last.get('period_start_ms')==period):
            last.update(pnl=str(D(last['costs_before_usd'])-D(p['costs_usd'])),through_ms=at_ms)
        else:
            event={'type':'COST','reason':reason,'at_ms':at_ms,'pnl':str(-amount)}
            if reason=='ELAPSED_FINANCING':
                event.update(period_start_ms=period,through_ms=at_ms,costs_before_usd=str(previous_costs),
                             pnl=str(previous_costs-D(p['costs_usd'])))
            p['events'].append(event)
    return p,-amount


def after(old,p,tick,gross_delta):
    if old.get('entered_ms') is None:return entry(p,tick)
    p['gross_realized_usd']=str(D(old.get('gross_realized_usd',old['realized_usd']))+gross_delta)
    spec=p.get('cost_model')
    if spec is None:return p,D(0)
    # Unknown continuity is never bridged to charge or close a position.
    if p['state']=='NEEDS_REVIEW':return p,D(0)
    lots=D(p['contract_volume']);previous_remaining=D(old['remaining'])
    elapsed=max(0,tick['event_ms']-old.get('last_cost_ms',old['entered_ms']))
    financing=lots*previous_remaining*D(spec['financing_usd_per_lot_day'])*D(elapsed)/D(86400000)
    exit_fee=lots*(previous_remaining-D(p['remaining']))*D(spec['commission_usd_per_lot_side'])
    p['last_cost_ms']=tick['event_ms']
    p,delta=charge(p,financing,tick['event_ms'],'ELAPSED_FINANCING')
    p,d=charge(p,exit_fee,tick['event_ms'],'EXIT_COMMISSION')
    return p,delta+d
