from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.utils import parse_dt, utc_iso

DEFAULT_TEAM_RULES: dict[str, Any] = {
    # Legacy compatibility only. Admin signal publication is intentionally
    # unrestricted by count, streak, cooldown or daily-loss policy.
    "enabled": False,
    "timezone": "Asia/Tehran",
    "max_daily_signals": 0,
    "max_weekly_signals": 0,
    "max_daily_forex": 0,
    "max_daily_crypto": 0,
    "max_consecutive_stops": 0,
    "cooldown_minutes": 0,
    "max_daily_loss_r": 0.0,
    "minimum_rr": 0.0,
    "override_requires_primary_admin": True,
    "updated_at": None,
    "updated_by": None,
}

STOP_STATUSES = {"stop", "stopped", "sl", "stop_loss", "loss"}
FINAL_STATUSES = STOP_STATUSES | {"tp", "tp1", "tp2", "tp3", "target", "target_complete", "manual_close", "closed", "cancelled", "expired", "no_entry", "be", "break_even"}


@dataclass(frozen=True)
class TeamSignalGate:
    ok: bool
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    metrics: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "errors": list(self.errors), "warnings": list(self.warnings), "metrics": dict(self.metrics)}


def team_rules(db: dict[str, Any]) -> dict[str, Any]:
    row = db.get("signal_team_rules") if isinstance(db.get("signal_team_rules"), dict) else {}
    result = dict(DEFAULT_TEAM_RULES)
    result.update({key: value for key, value in row.items() if key in result})
    # Stored values from older releases are retained for migration compatibility
    # but can never become publication gates again.
    result["enabled"] = False
    for key in (
        "max_daily_signals", "max_weekly_signals", "max_daily_forex",
        "max_daily_crypto", "max_consecutive_stops", "cooldown_minutes",
    ):
        result[key] = 0
    result["max_daily_loss_r"] = 0.0
    result["minimum_rr"] = 0.0
    return result


def update_team_rules(db: dict[str, Any], actor_id: int | str, changes: dict[str, Any]) -> dict[str, Any]:
    allowed = set(DEFAULT_TEAM_RULES) - {"updated_at", "updated_by"}
    unknown = sorted(set(changes) - allowed)
    if unknown:
        raise ValueError("UNKNOWN_SIGNAL_TEAM_RULE:" + ",".join(unknown))
    result = team_rules(db)
    for key, value in changes.items():
        if key == "enabled":
            result[key] = False
        elif key == "override_requires_primary_admin":
            result[key] = bool(value)
        elif key == "timezone":
            try:
                ZoneInfo(str(value))
            except ZoneInfoNotFoundError as exc:
                raise ValueError("INVALID_SIGNAL_TEAM_TIMEZONE") from exc
            result[key] = str(value)
        elif key in {"max_daily_signals", "max_weekly_signals", "max_daily_forex", "max_daily_crypto", "max_consecutive_stops", "cooldown_minutes"}:
            int(value)  # validate legacy clients without re-enabling a ceiling
            result[key] = 0
        elif key == "max_daily_loss_r":
            float(value)  # validate legacy clients without re-enabling a ceiling
            result[key] = 0.0
        elif key == "minimum_rr":
            # Accepted for compatibility with older clients, intentionally
            # normalized to zero because R/R is no longer a publication gate.
            result[key] = 0.0
    result["updated_at"] = utc_iso()
    result["updated_by"] = str(actor_id)
    db["signal_team_rules"] = result
    return dict(result)


def _local_date(value: Any, timezone: ZoneInfo) -> datetime | None:
    parsed = parse_dt(value)
    return parsed.astimezone(timezone) if parsed else None


def _signal_time(row: dict[str, Any]) -> Any:
    return row.get("published_at") or row.get("created_at") or row.get("sent_at") or row.get("scheduled_at")


def _result_time(row: dict[str, Any]) -> Any:
    return row.get("result_at") or row.get("closed_at") or row.get("updated_at") or _signal_time(row)


def _status(row: dict[str, Any]) -> str:
    return str(row.get("result") or row.get("status") or row.get("lifecycle_status") or "").strip().lower()


def _market(row: dict[str, Any]) -> str:
    value = str(row.get("market_category") or row.get("market") or "").lower()
    symbol = str(row.get("symbol") or "").upper()
    if value in {"crypto", "forex"}:
        return value
    return "crypto" if symbol.endswith(("USDT", "USDC", "BTC", "ETH")) else "forex"


def _all_signals(db: dict[str, Any]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    result: list[dict[str, Any]] = []
    for section in ("signals", "signal_archive"):
        for row in db.get(section, []) or []:
            if not isinstance(row, dict):
                continue
            key = str(row.get("id") or row.get("signal_id") or f"{section}:{len(result)}")
            if key in seen:
                continue
            seen.add(key)
            result.append(row)
    return result


def _loss_r(row: dict[str, Any]) -> float:
    for key in ("result_r", "realized_r", "r_multiple", "pnl_r"):
        try:
            value = float(row.get(key))
        except (TypeError, ValueError):
            continue
        return value
    return -1.0 if _status(row) in STOP_STATUSES else 0.0


def evaluate_team_signal_gate(
    db: dict[str, Any],
    payload: dict[str, Any],
    *,
    now: datetime | None = None,
    override: bool = False,
) -> TeamSignalGate:
    """Compatibility gate: team publication ceilings are disabled for admins.

    Historical releases enforced daily/weekly counts, per-market counts,
    consecutive-stop cooldowns and daily loss-R. Those values may still exist
    in persisted databases, so this function remains callable but never blocks
    signal creation, scheduling or publication.
    """
    rules = team_rules(db)
    return TeamSignalGate(
        True,
        (),
        (),
        {
            "enabled": False,
            "enforcement": "disabled_for_admin_signal_publication",
            "market": _market(payload),
            "rules": rules,
            "override": bool(override),
        },
    )
