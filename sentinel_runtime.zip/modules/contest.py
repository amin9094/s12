from __future__ import annotations

import copy
import math
import uuid
from decimal import Decimal
from modules.contest_policy import entry_guard,exact_number,award_row
from datetime import timedelta
from typing import Any

from core.domain import add_points, record_event
from core.utils import parse_dt, utc_iso, utc_now

MAX_CONTEST_MINUTES = 43_200  # 30 days
MAX_HISTORY = 500
MAX_RECENT_CLOSED_PRICE = 20


def _finite(value: float) -> float:
    number = float(value)
    if not math.isfinite(number) or number<=0:
        raise ValueError("عدد مسابقه معتبر نیست")
    return number


def _duration(value: int) -> int:
    minutes = int(value)
    if not 1 <= minutes <= MAX_CONTEST_MINUTES:
        raise ValueError("مدت مسابقه باید بین ۱ دقیقه و ۳۰ روز باشد.")
    return minutes




def _reward(value: int, *, name: str = "امتیاز") -> int:
    points = int(value)
    if not 0 <= points <= 100_000:
        raise ValueError(f"{name} باید بین صفر تا ۱۰۰٬۰۰۰ باشد.")
    return points


def _mark_due(contest: dict[str, Any]) -> bool:
    """Move an active contest to awaiting_result when due or malformed.

    A missing/broken deadline is fail-closed: new entries stop instead of leaving
    a contest active forever. The administrator can still settle it manually.
    """
    if contest.get("status") != "active":
        return False
    raw_end = contest.get("ends_at")
    end = parse_dt(raw_end)
    if end is None:
        contest.update(
            {
                "status": "awaiting_result",
                "active": False,
                "deadline_error": "invalid_or_missing_ends_at",
                "deadline_detected_at": utc_iso(),
            }
        )
        return True
    if end <= utc_now():
        contest.update({"status": "awaiting_result", "active": False, "deadline_detected_at": utc_iso()})
        return True
    return False


def refresh_price_contests(db: dict[str, Any]) -> list[dict[str, Any]]:
    changed: list[dict[str, Any]] = []
    for contest in db.setdefault("contests", []):
        if isinstance(contest, dict) and _mark_due(contest):
            changed.append(contest)
    return changed


def get_open_price_contest(db: dict[str, Any]) -> dict[str, Any] | None:
    refresh_price_contests(db)
    return next(
        (item for item in reversed(db.get("contests", [])) if isinstance(item, dict) and item.get("status") == "active"),
        None,
    )


def get_unsettled_price_contest(db: dict[str, Any]) -> dict[str, Any] | None:
    refresh_price_contests(db)
    return next(
        (
            item
            for item in reversed(db.get("contests", []))
            if isinstance(item, dict) and item.get("status") in {"active", "awaiting_result"}
        ),
        None,
    )


def _prune_price_contests(db: dict[str, Any]) -> None:
    rows = [item for item in db.get("contests", []) if isinstance(item, dict)]
    unsettled = [item for item in rows if item.get("status") in {"active", "awaiting_result"}]
    closed = [item for item in rows if item.get("status") not in {"active", "awaiting_result"}]
    db["contests"] = unsettled + closed[-MAX_RECENT_CLOSED_PRICE:]


def start_price_contest(
    db: dict[str, Any],
    symbol: str,
    duration_minutes: int,
    *,
    question: str = "",
    photo_file_id: str | None = None,
    reward_points: int = 5,
) -> dict[str, Any]:
    if get_unsettled_price_contest(db):
        raise ValueError("یک مسابقه قیمت تسویه‌نشده وجود دارد.")
    clean_symbol = str(symbol).upper().strip()
    if not 2 <= len(clean_symbol) <= 24:
        raise ValueError("نماد مسابقه باید بین ۲ تا ۲۴ کاراکتر باشد.")
    now = utc_now()
    contest = {
        "id": f"price_{uuid.uuid4().hex[:10]}",
        "type": "price",
        "symbol": clean_symbol,
        "status": "active",
        "active": True,
        "created_at": utc_iso(now),
        "ends_at": utc_iso(now + timedelta(minutes=_duration(duration_minutes))),
        "participants": {},
        "question": str(question or "").strip()[:1000],
        "photo_file_id": photo_file_id,
        "final_price": None,
        "results": [],
        "reward_points": _reward(reward_points, name="امتیاز مسابقه قیمت"),
    }
    db.setdefault("contests", []).append(contest)
    _prune_price_contests(db)
    return contest


def add_price_guess(db: dict[str, Any], user_id: int | str, guess: float, *, contest_id: str | None = None) -> str:
    contest = get_open_price_contest(db)
    if not contest:
        return "NO_ACTIVE"
    guard=entry_guard(db,contest,user_id,contest_id)
    if guard:return guard
    uid = str(user_id)
    participants = contest.setdefault("participants", {})
    from core.domain import is_vip
    audience = contest.get('eligible_group', 'everyone')
    if audience=='selected' and uid not in set(map(str,contest.get('allowed_user_ids',[]))):return 'NOT_ELIGIBLE'
    if (audience=='vip' and not is_vip(db,uid)) or (audience=='nonvip' and is_vip(db,uid)) or (audience=='referral' and not db.get('users',{}).get(uid,{}).get('referred_by')):
        return 'NOT_ELIGIBLE'
    if int(contest.get('max_participants',0)) and len(participants)>=int(contest['max_participants']) and uid not in participants:
        return 'FULL'
    if uid in participants:
        return "ALREADY"
    participants[uid] = {"guess": _finite(exact_number(guess,contest.get("price_tick"))), "guess_text":exact_number(guess,contest.get("price_tick")), "submitted_at": utc_iso()}
    return "OK"


def _rank_by_diff(results: list[dict[str, Any]], reward_by_rank: dict[int, int]) -> None:
    rank = 0
    last_diff: Decimal | None = None
    for index, row in enumerate(results, start=1):
        if last_diff is None or Decimal(row.get("diff_text",str(row["diff"]))) != last_diff:
            rank = index
            last_diff = Decimal(row.get("diff_text",str(row["diff"])))
        row["rank"] = rank
        row["points"] = reward_by_rank.get(rank, 0)


def end_price_contest(db: dict[str, Any], final_price: float) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    contest = get_unsettled_price_contest(db)
    if not contest:
        return None, []
    final_text=exact_number(final_price,contest.get("price_tick"))
    final = _finite(final_text)
    results: list[dict[str, Any]] = []
    for uid, payload in contest.get("participants", {}).items():
        if not isinstance(payload, dict):
            continue
        guess = _finite(payload.get("guess"))
        results.append({"uid": str(uid), "guess": guess, "guess_text":payload.get("guess_text",str(guess)), "diff": abs(guess - final), "diff_text":format(abs(Decimal(payload.get("guess_text",str(guess)))-Decimal(final_text)),"f")})
    results.sort(key=lambda row: (Decimal(row["diff_text"]), Decimal(row["guess_text"]), row["uid"]))
    reward_points = _reward(contest.get("reward_points", 5), name="امتیاز مسابقه قیمت")
    reward_by_rank = {int(k):_reward(v) for k,v in contest.get("reward_by_rank", {1:reward_points}).items()}
    if contest.get("tie_handling")=="earliest":
        results.sort(key=lambda row:(Decimal(row["diff_text"]),str(contest["participants"][row["uid"]].get("submitted_at") or ""), row["uid"]))
        for rank,row in enumerate(results,1):row.update(rank=rank,points=reward_by_rank.get(rank,0))
    else:
        _rank_by_diff(results, reward_by_rank)
    for row in results:
        award_row(db,contest,row,'price')

    contest.update(
        {
            "status": "closed",
            "active": False,
            "final_price": final,
            "final_price_text":final_text,
            "closed_at": utc_iso(),
            "results": results,
        }
    )
    _archive_contest(db, contest, "price")
    _prune_price_contests(db)
    return contest, results


def _refresh_timed_contest(contest: dict[str, Any]) -> bool:
    return _mark_due(contest)


def _notification_due(contest: dict[str, Any]) -> bool:
    if contest.get("deadline_notified_at"):
        return False
    now = utc_now()
    claimed_at = parse_dt(contest.get("deadline_notification_claimed_at"))
    if claimed_at and claimed_at > now - timedelta(minutes=5):
        return False
    retry_at = parse_dt(contest.get("deadline_notification_next_retry_at"))
    return retry_at is None or retry_at <= now


def refresh_all_contests(db: dict[str, Any]) -> list[dict[str, Any]]:
    """Refresh deadlines and return notification candidates without marking success."""
    refresh_price_contests(db)
    candidates: list[dict[str, Any]] = []
    for contest in db.get("contests", []):
        if (
            isinstance(contest, dict)
            and contest.get("status") == "awaiting_result"
            and _notification_due(contest)
        ):
            contest["deadline_notification_claimed_at"] = utc_iso()
            candidates.append({"type": "price", "id": contest.get("id"), "symbol": contest.get("symbol", "")})
    for key, label in (("chart_contest", "chart"), ("candle_contest", "candle"), ("news_direction_contest", "news_direction")):
        contest = db.get(key, {})
        if not isinstance(contest, dict):
            continue
        _refresh_timed_contest(contest)
        if contest.get("status") == "awaiting_result" and _notification_due(contest):
            contest["deadline_notification_claimed_at"] = utc_iso()
            candidates.append({"type": label, "id": contest.get("id"), "symbol": contest.get("symbol", "")})
    return candidates


def _locate_contest(db: dict[str, Any], kind: str, contest_id: str) -> dict[str, Any] | None:
    if kind == "price":
        return next(
            (item for item in db.get("contests", []) if isinstance(item, dict) and str(item.get("id")) == str(contest_id)),
            None,
        )
    key = {"chart": "chart_contest", "candle": "candle_contest", "news_direction": "news_direction_contest"}.get(kind)
    contest = db.get(key, {}) if key else {}
    if isinstance(contest, dict) and str(contest.get("id")) == str(contest_id):
        return contest
    return None


def mark_deadline_notification_result(
    db: dict[str, Any],
    kind: str,
    contest_id: str,
    *,
    success: bool,
    error: str = "",
) -> None:
    contest = _locate_contest(db, kind, contest_id)
    if not contest:
        return
    if success:
        contest.update(
            {
                "deadline_notified_at": utc_iso(),
                "deadline_notification_next_retry_at": None,
                "deadline_notification_last_error": None,
                "deadline_notification_claimed_at": None,
            }
        )
        return
    attempts = int(contest.get("deadline_notification_attempts", 0) or 0) + 1
    delay_minutes = min(360, 2 ** min(attempts, 8))
    contest.update(
        {
            "deadline_notification_attempts": attempts,
            "deadline_notification_next_retry_at": utc_iso(utc_now() + timedelta(minutes=delay_minutes)),
            "deadline_notification_last_error": str(error)[:300],
            "deadline_notification_claimed_at": None,
        }
    )


def _archive_contest(db: dict[str, Any], contest: dict[str, Any], kind: str) -> None:
    history = db.setdefault("contest_history", [])
    contest_id = str(contest.get("id") or "")
    if contest_id and any(str(item.get("id")) == contest_id for item in history if isinstance(item, dict)):
        return
    snapshot = copy.deepcopy(contest)
    snapshot["type"] = kind
    history.append(snapshot)
    db["contest_history"] = history[-MAX_HISTORY:]


def start_chart_contest(
    db: dict[str, Any],
    question: str,
    photo_file_id: str | None,
    duration_minutes: int = 1440,
    reward_points: int = 5,
) -> dict[str, Any]:
    existing = db.get("chart_contest", {})
    if not isinstance(existing, dict):
        existing = {}
    _refresh_timed_contest(existing)
    if existing.get("status") in {"active", "awaiting_result"}:
        raise ValueError("مسابقه چارت تسویه‌نشده وجود دارد.")
    if existing.get("id") and existing.get("status") == "closed":
        _archive_contest(db, existing, "chart")
    now = utc_now()
    contest = {
        "id": f"chart_{uuid.uuid4().hex[:10]}",
        "status": "active",
        "active": True,
        "question": str(question or "جهت بعدی بازار؟").strip()[:1000],
        "photo_file_id": photo_file_id,
        "answers": {},
        "created_at": utc_iso(now),
        "ends_at": utc_iso(now + timedelta(minutes=_duration(duration_minutes))),
        "reward_points": _reward(reward_points, name="امتیاز مسابقه چارت"),
    }
    db["chart_contest"] = contest
    return contest


def get_open_chart_contest(db: dict[str, Any]) -> dict[str, Any] | None:
    contest = db.get("chart_contest", {})
    if not isinstance(contest, dict):
        return None
    _refresh_timed_contest(contest)
    return contest if contest.get("status") == "active" else None


def add_chart_answer(db: dict[str, Any], user_id: int | str, choice: str, *, contest_id: str | None = None) -> str:
    contest = get_open_chart_contest(db)
    if not contest:
        return "NO_ACTIVE"
    choice = str(choice).upper()
    if choice not in {"UP", "DOWN", "FLAT"}:
        return "INVALID"
    guard=entry_guard(db,contest,user_id,contest_id)
    if guard:return guard
    uid = str(user_id)
    answers = contest.setdefault("answers", {})
    if uid in answers:
        return "ALREADY"
    answers[uid] = {"choice": choice, "submitted_at": utc_iso()}
    record_event(db, uid, "join_chart_contest")
    return "OK"


def end_chart_contest(db: dict[str, Any], correct_choice: str) -> tuple[dict[str, Any] | None, list[str]]:
    contest = db.get("chart_contest", {})
    if not isinstance(contest, dict):
        return None, []
    _refresh_timed_contest(contest)
    if contest.get("status") not in {"active", "awaiting_result"}:
        return None, []
    correct = str(correct_choice).upper().strip()
    if correct not in {"UP", "DOWN", "FLAT"}:
        raise ValueError("پاسخ باید UP، DOWN یا FLAT باشد.")
    winners: list[str] = []
    reward_points = _reward(contest.get("reward_points", 5), name="امتیاز مسابقه چارت")
    for uid, payload in contest.get("answers", {}).items():
        if isinstance(payload, dict) and str(payload.get("choice", "")).upper() == correct:
            winners.append(str(uid))
            row={'uid':str(uid),'rank':len(winners) if contest.get('tie_handling')=='earliest' else 1,'points':reward_points}
            award_row(db,contest,row,'chart')
            contest.setdefault('results',[]).append(row)
    contest.update(
        {
            "status": "closed",
            "active": False,
            "answer": correct,
            "winners": winners,
            "closed_at": utc_iso(),
            "reward_points": reward_points,
        }
    )
    _archive_contest(db, contest, "chart")
    return contest, winners


def start_candle_contest(
    db: dict[str, Any],
    duration_minutes: int = 1440,
    reward_by_rank: dict[int, int] | None = None,
    *,
    question: str = "",
) -> dict[str, Any]:
    existing = db.get("candle_contest", {})
    if not isinstance(existing, dict):
        existing = {}
    _refresh_timed_contest(existing)
    if existing.get("status") in {"active", "awaiting_result"}:
        raise ValueError("مسابقه کندل تسویه‌نشده وجود دارد.")
    if existing.get("id") and existing.get("status") == "closed":
        _archive_contest(db, existing, "candle")
    now = utc_now()
    rewards = reward_by_rank or {1: 10, 2: 7, 3: 5, **{rank: 3 for rank in range(4, 11)}}
    normalized_rewards = {
        str(rank): _reward(points, name=f"امتیاز رتبه {rank}")
        for rank, points in rewards.items()
        if 1 <= int(rank) <= 10
    }
    defaults = {1: 10, 2: 7, 3: 5, **{rank: 3 for rank in range(4, 11)}}
    for rank in range(1, 11):
        normalized_rewards.setdefault(str(rank), defaults[rank])
    contest = {
        "id": f"candle_{uuid.uuid4().hex[:10]}",
        "status": "active",
        "active": True,
        "answers": {},
        "question": str(question or "قیمت بسته‌شدن کندل چقدر خواهد بود؟").strip()[:1000],
        "created_at": utc_iso(now),
        "ends_at": utc_iso(now + timedelta(minutes=_duration(duration_minutes))),
        "reward_by_rank": normalized_rewards,
    }
    db["candle_contest"] = contest
    return contest


def get_open_candle_contest(db: dict[str, Any]) -> dict[str, Any] | None:
    contest = db.get("candle_contest", {})
    if not isinstance(contest, dict):
        return None
    _refresh_timed_contest(contest)
    return contest if contest.get("status") == "active" else None


def add_candle_guess(db: dict[str, Any], user_id: int | str, guess: float, *, contest_id: str | None = None) -> str:
    contest = get_open_candle_contest(db)
    if not contest:
        return "NO_ACTIVE"
    guard=entry_guard(db,contest,user_id,contest_id)
    if guard:return guard
    uid = str(user_id)
    answers = contest.setdefault("answers", {})
    if uid in answers:
        return "ALREADY"
    answers[uid] = {"guess": _finite(exact_number(guess,contest.get("price_tick"))), "guess_text":exact_number(guess,contest.get("price_tick")), "submitted_at": utc_iso()}
    return "OK"


def end_candle_contest(db: dict[str, Any], final_price: float) -> tuple[dict[str, Any] | None, list[dict[str, Any]]]:
    contest = db.get("candle_contest", {})
    if not isinstance(contest, dict):
        return None, []
    _refresh_timed_contest(contest)
    if contest.get("status") not in {"active", "awaiting_result"}:
        return None, []
    final_text=exact_number(final_price,contest.get("price_tick"))
    final = _finite(final_text)
    results: list[dict[str, Any]] = []
    for uid, payload in contest.get("answers", {}).items():
        if not isinstance(payload, dict):
            continue
        guess = _finite(payload.get("guess"))
        results.append({"uid": str(uid), "guess": guess, "guess_text":payload.get("guess_text",str(guess)), "diff": abs(guess - final), "diff_text":format(abs(Decimal(payload.get("guess_text",str(guess)))-Decimal(final_text)),"f")})
    results.sort(key=lambda row: (Decimal(row["diff_text"]), row["uid"]))
    stored_rewards = contest.get("reward_by_rank", {"1": 10, "2": 7, "3": 5, **{str(rank): 3 for rank in range(4, 11)}})
    defaults = {1: 10, 2: 7, 3: 5, **{rank: 3 for rank in range(4, 11)}}
    reward_by_rank = {
        rank: _reward(stored_rewards.get(str(rank), stored_rewards.get(rank, defaults[rank])), name=f"امتیاز رتبه {rank}")
        for rank in range(1, 11)
    }
    _rank_by_diff(results, reward_by_rank)
    for row in results:
        award_row(db,contest,row,'candle')

    contest.update(
        {
            "status": "closed",
            "active": False,
            "final_price": final,
            "final_price_text":final_text,
            "results": results,
            "closed_at": utc_iso(),
            "reward_by_rank": {str(rank): points for rank, points in reward_by_rank.items()},
        }
    )
    _archive_contest(db, contest, "candle")
    return contest, results


def start_news_direction_contest(
    db: dict[str, Any],
    news_name: str,
    *,
    duration_minutes: int = 30,
    reward_points: int = 5,
) -> dict[str, Any]:
    existing = db.get("news_direction_contest", {})
    if not isinstance(existing, dict):
        existing = {}
    _refresh_timed_contest(existing)
    if existing.get("status") in {"active", "awaiting_result"}:
        raise ValueError("یک مسابقه خبر تسویه‌نشده وجود دارد.")
    if existing.get("id") and existing.get("status") == "closed":
        _archive_contest(db, existing, "news_direction")
    clean_name = str(news_name or "").strip()[:500]
    if len(clean_name) < 2:
        raise ValueError("نام خبر الزامی است.")
    now = utc_now()
    contest = {
        "id": f"news_{uuid.uuid4().hex[:10]}",
        "type": "news_direction",
        "news_name": clean_name,
        "status": "active",
        "active": True,
        "answers": {},
        "created_at": utc_iso(now),
        "ends_at": utc_iso(now + timedelta(minutes=_duration(duration_minutes))),
        "reward_points": _reward(reward_points, name="امتیاز مسابقه خبر"),
    }
    db["news_direction_contest"] = contest
    return contest


def get_open_news_direction_contest(db: dict[str, Any]) -> dict[str, Any] | None:
    contest = db.get("news_direction_contest", {})
    if not isinstance(contest, dict):
        return None
    _refresh_timed_contest(contest)
    return contest if contest.get("status") == "active" else None


def add_news_direction_answer(db: dict[str, Any], user_id: int | str, choice: str, *, contest_id: str | None = None) -> str:
    contest = get_open_news_direction_contest(db)
    if not contest:
        return "NO_ACTIVE"
    normalized = str(choice or "").upper().strip()
    if normalized not in {"UP", "DOWN", "RANGE"}:
        return "INVALID"
    guard=entry_guard(db,contest,user_id,contest_id)
    if guard:return guard
    uid = str(user_id)
    answers = contest.setdefault("answers", {})
    if uid in answers:
        return "ALREADY"
    answers[uid] = {"choice": normalized, "submitted_at": utc_iso()}
    record_event(db, uid, "join_news_direction_contest")
    return "OK"


def end_news_direction_contest(db: dict[str, Any], correct_choice: str) -> tuple[dict[str, Any] | None, list[str]]:
    contest = db.get("news_direction_contest", {})
    if not isinstance(contest, dict):
        return None, []
    _refresh_timed_contest(contest)
    if contest.get("status") not in {"active", "awaiting_result"}:
        return None, []
    correct = str(correct_choice or "").upper().strip()
    if correct not in {"UP", "DOWN", "RANGE"}:
        raise ValueError("نتیجه باید UP، DOWN یا RANGE باشد.")
    points = _reward(contest.get("reward_points", 5), name="امتیاز مسابقه خبر")
    winners: list[str] = []
    for uid, payload in contest.get("answers", {}).items():
        if isinstance(payload, dict) and str(payload.get("choice", "")).upper() == correct:
            winners.append(str(uid))
            row={'uid':str(uid),'rank':len(winners) if contest.get('tie_handling')=='earliest' else 1,'points':points}
            award_row(db,contest,row,'news_direction')
            contest.setdefault('results',[]).append(row)
    contest.update({
        "status": "closed",
        "active": False,
        "answer": correct,
        "winners": winners,
        "closed_at": utc_iso(),
        "reward_points": points,
    })
    _archive_contest(db, contest, "news_direction")
    return contest, winners
