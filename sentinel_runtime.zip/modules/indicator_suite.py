"""Deterministic closed-bar confirmations; correlated votes are not probabilities.

QQE: RSI14, EMA5, double EMA27 absolute RSI change, factor4.236.
Supertrend: Wilder ATR10, multiplier3. No external signal service is required.
"""
from decimal import Decimal as D

from modules.strategies.common import ema, indicators as core_indicators, wilder

CATALOG = {
    'ema_group': 'EMA 20 / 50 / 100', 'rsi': 'RSI 14', 'macd': 'MACD 12 / 26 / 9',
    'dmi': 'DMI 14', 'stochastic': 'Stochastic 14 / 3 / 3', 'cci': 'CCI 20',
    'roc': 'ROC 12', 'williams': 'Williams %R 14', 'supertrend': 'Supertrend 10 × 3',
    'qqe': 'QQE RSI14 / EMA5 / 4.236', 'bollinger': 'Bollinger 20 × 2', 'vwma': 'VWMA 20',
    'aroon': 'Aroon 25', 'donchian': 'Donchian 20', 'cmf': 'Chaikin Money Flow 21',
}
DEFAULT_SELECTION = tuple(CATALOG)
LEGACY_SELECTION = ('ema_group', 'rsi', 'macd', 'dmi')
SUITE_VERSION = 'closed-suite-15-v2'
FAMILIES = {
    'trend': ('ema_group', 'dmi', 'supertrend', 'aroon'),
    'momentum': ('rsi', 'macd', 'stochastic', 'cci', 'roc', 'williams', 'qqe'),
    'price_position': ('bollinger', 'donchian'), 'volume': ('vwma', 'cmf'),
}


def grouped_agreement(votes):
    return {family: {'selected': [k for k in keys if k in votes],
                     'aligned': all(votes[k] for k in keys if k in votes)
                     if any(k in votes for k in keys) else None}
            for family, keys in FAMILIES.items()}


def _sma(values, period):
    return [None if i+1 < period or any(v is None for v in values[i+1-period:i+1])
            else sum(values[i+1-period:i+1])/D(period) for i in range(len(values))]


def _supertrend(bars):
    tr = [bars[0].high-bars[0].low] + [max(b.high-b.low, abs(b.high-a.close), abs(b.low-a.close))
                                           for a,b in zip(bars,bars[1:])]
    atrs = wilder(tr, 10)
    upper = lower = line = None
    up = False
    for i, (bar, atr) in enumerate(zip(bars, atrs)):
        if atr is None:continue
        basic_upper = (bar.high+bar.low)/2+3*atr
        basic_lower = (bar.high+bar.low)/2-3*atr
        if upper is None:
            upper, lower, line = basic_upper, basic_lower, basic_upper
            continue
        old_upper, old_line = upper, line
        upper = basic_upper if basic_upper<upper or bars[i-1].close>upper else upper
        lower = basic_lower if basic_lower>lower or bars[i-1].close<lower else lower
        up = bar.close>upper if old_line==old_upper else not bar.close<lower
        line = lower if up else upper
    return {'line':line, 'direction':'BUY' if up else 'SELL'}


def _qqe(rsi):
    known = [v for v in rsi if v is not None]
    if len(known)<56:return {'rsi':None,'trail':None}
    smooth = ema(known, 5)
    changes = [abs(b-a) for a,b in zip(smooth,smooth[1:])]
    distances = [v*D('4.236') for v in ema(ema(changes,27),27)]
    long = short = None
    trend = 1
    for i, distance in enumerate(distances, 1):
        value, prev = smooth[i], smooth[i-1]
        new_long, new_short = value-distance, value+distance
        if long is None:
            long, short = new_long, new_short
            continue
        old_long, old_short = long, short
        long = max(long,new_long) if prev>long and value>long else new_long
        short = min(short,new_short) if prev<short and value<short else new_short
        if prev<=old_short and value>old_short:trend=1
        elif prev>=old_long and value<old_long:trend=-1
    return {'rsi':smooth[-1], 'trail':long if trend==1 else short}


def indicators(bars):
    if len(bars)<105:raise ValueError('INDICATOR_WARMUP_INCOMPLETE')
    stats = core_indicators(bars)
    closes = [b.close for b in bars]
    fast = []
    for i, bar in enumerate(bars):
        window = bars[max(0,i-13):i+1]
        high, low = max(b.high for b in window), min(b.low for b in window)
        fast.append(None if i<13 or high==low else (bar.close-low)/(high-low)*100)
    k = _sma(fast,3);d = _sma(k,3)
    typical = [(b.high+b.low+b.close)/3 for b in bars[-20:]]
    mean = sum(typical)/len(typical)
    deviation = sum(abs(x-mean) for x in typical)/len(typical)
    cci = (typical[-1]-mean)/(D('.015')*deviation) if deviation else D(0)
    bb = _sma(closes,20)
    variance = sum((v-bb[-1])**2 for v in closes[-20:])/20
    last = bars[-1];window=bars[-14:]
    hi,lo = max(b.high for b in window),min(b.low for b in window)
    volume = [b.volume for b in bars[-20:]]
    usable = (len(volume)==20 and all(v is not None and v>=0 for v in volume) and sum(volume)>0
              and len({b.volume_kind for b in bars[-20:]})==1)
    vwma = sum(b.close*b.volume for b in bars[-20:])/sum(volume) if usable else None
    # 25 elapsed intervals require 26 prices; repeated extrema use the newest.
    aw = bars[-26:]
    aup = D(max(range(26), key=lambda i: (aw[i].high, i)))*4
    adown = D(min(range(26), key=lambda i: (aw[i].low, -i)))*4
    dc_high, dc_low = max(b.high for b in bars[-20:]), min(b.low for b in bars[-20:])
    money = bars[-21:]
    money_usable = (all(b.volume is not None and b.volume >= 0 for b in money)
                    and len({b.volume_kind for b in money}) == 1
                    and money[0].volume_kind in {'traded', 'tick_proxy', 'reported_tick_proxy'}
                    and sum(b.volume for b in money) > 0)
    cmf = (sum((D(0) if b.high == b.low else (2*b.close-b.high-b.low)/(b.high-b.low))*b.volume
               for b in money)/sum(b.volume for b in money)) if money_usable else None
    stats['suite'] = {'stochastic_k':k[-1], 'stochastic_d':d[-1], 'cci':cci,
        'roc':(last.close/closes[-13]-1)*100, 'williams':-100*(hi-last.close)/(hi-lo) if hi!=lo else None,
        'supertrend':_supertrend(bars), 'qqe':_qqe(stats['rsi']),
        'bb_basis':bb[-1], 'bb_previous_basis':bb[-4],
        'bb_upper':bb[-1]+2*variance.sqrt(), 'bb_lower':bb[-1]-2*variance.sqrt(),
        'vwma':vwma, 'close':last.close, 'volume_kind':last.volume_kind,
        'aroon_up':aup, 'aroon_down':adown,
        'donchian_high':dc_high, 'donchian_low':dc_low, 'donchian_basis':(dc_high+dc_low)/2,
        'donchian_previous_high':max(b.high for b in bars[-21:-1]),
        'donchian_previous_low':min(b.low for b in bars[-21:-1]),
        'cmf':cmf, 'cmf_volume_kind':money[0].volume_kind if money_usable else 'unavailable',
        'cmf_is_order_flow':False,
        'version':SUITE_VERSION}
    return stats


def agreement(stats, direction, selected=None):
    selected = DEFAULT_SELECTION if selected is None else tuple(selected)
    if len(set(selected))!=len(selected) or set(selected)-set(CATALOG):
        raise ValueError('INDICATOR_SELECTION_INVALID')
    sign = D(1) if direction=='BUY' else D(-1)
    ma=stats['ma'];extra=stats.get('suite',{})
    def side(value, midpoint=0):return value is not None and sign*(value-D(midpoint))>0
    st=extra.get('supertrend',{});qq=extra.get('qqe',{})
    k,d=extra.get('stochastic_k'),extra.get('stochastic_d')
    votes={
        'ema_group':all(sign*(ma[n][-1]-ma[n][-4])>0 for n in (20,50,100)),
        'rsi':side(stats['rsi'][-1],50), 'macd':side(stats['macd_hist'][-1]),
        'dmi':side(stats['plus_di']-stats['minus_di']),
        'stochastic':side(k,50) and d is not None and sign*(k-d)>=0,
        'cci':side(extra.get('cci')), 'roc':side(extra.get('roc')),
        'williams':side(extra.get('williams'),-50),
        'supertrend':st.get('direction')==direction and st.get('line') is not None
                     and side(extra.get('close')-st['line']),
        'qqe':side(qq.get('rsi'),50) and qq.get('trail') is not None and side(qq['rsi']-qq['trail']),
        'bollinger':extra.get('bb_basis') is not None and side(extra['close']-extra['bb_basis'])
                    and side(extra['bb_basis']-extra['bb_previous_basis']),
        'vwma':extra.get('vwma') is not None and side(extra['close']-extra['vwma']),
        'aroon':extra.get('aroon_up') is not None and extra.get('aroon_down') is not None
                 and side(extra['aroon_up']-extra['aroon_down']),
        'donchian':extra.get('donchian_basis') is not None and side(extra['close']-extra['donchian_basis']),
        'cmf':side(extra.get('cmf')),
    }
    chosen={name:bool(votes[name]) for name in selected}
    return bool(chosen) and all(chosen.values()),chosen


def revalidate_plan(plan,bars,*,custom_scope=False):
    facts=[f.get('detail',{}) for f in plan.get('evidence',()) if f.get('kind')=='all_directional_indicators']
    if not facts:raise ValueError('INDICATOR_CONFIRMATIONS_MISSING')
    # Old four-vote queues must not bypass today's standalone engine policy.
    # Custom combinations have a separate frozen-subset revalidation path.
    selected=(tuple(facts[0].get('directional_agreement',{})) if custom_scope
              else DEFAULT_SELECTION if plan.get('engine')=='indicators' else tuple(facts[0].get('directional_agreement',{})))
    if not selected or not agreement(indicators(bars),plan['direction'],selected)[0]:
        raise ValueError('INDICATOR_DIRECTION_CHANGED_BEFORE_PUBLICATION')
