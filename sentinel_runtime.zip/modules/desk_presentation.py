"""Private display facts; never alter a trading plan or infer a future price."""
from decimal import Decimal, InvalidOperation

QUOTE_TTL_MS = 5000


def quote_status(quote, now):
    times = [quote.get(k) for k in ('event_ms', 'received_ms')]
    valid_times = all(type(t) is int and 0 <= now-t <= QUOTE_TTL_MS for t in times)
    try:
        bid, ask = (Decimal(str(quote.get(k, 'NaN'))) for k in ('bid', 'ask'))
        prices = bid.is_finite() and ask.is_finite() and 0 < bid <= ask
    except (InvalidOperation, TypeError, ValueError):
        prices = False
    fresh = bool(valid_times and prices)
    return {'state': 'FRESH' if fresh else 'STALE' if quote else 'UNAVAILABLE',
            'event_ms': quote.get('event_ms'), 'received_ms': quote.get('received_ms'),
            'observed_ms': now, 'valid_until_ms': min(times)+QUOTE_TTL_MS if fresh else None,
            'ttl_ms': QUOTE_TTL_MS, 'fresh': fresh}


def presentation_group(plan):
    from repositories.v2.common import content_hash
    # Identical price geometry, mode and timeframe only. Every child keeps its
    # own strategy, plan hash, approval and independent virtual account.
    fields = ('symbol', 'direction', 'timeframe', 'entry', 'stop', 'zone_low', 'zone_high')
    return content_hash({**{k: plan.get(k) for k in fields},
                         'mode': plan.get('execution_mode', 'PENDING')})[:16]
