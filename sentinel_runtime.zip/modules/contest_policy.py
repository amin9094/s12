"""Contest identity, shared eligibility and auditable provisional settlement."""
from copy import deepcopy
from decimal import Decimal,InvalidOperation
from uuid import uuid4
from core.utils import utc_iso

KINDS={'chart':'chart_contest','candle':'candle_contest','news_direction':'news_direction_contest'}


def current(db,kind):
    if kind=='price':
        return next((r for r in reversed(db.get('contests',[])) if r.get('status') in {'active','awaiting_result'}),None)
    return db.get(KINDS.get(kind,''))


def exact_number(value,tick=None):
    text=str(value).strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩٫','01234567890123456789.')).replace(',','').replace('٬','')
    if len(text)>80 or isinstance(value,bool):raise ValueError('عدد مسابقه معتبر نیست')
    try:
        number=Decimal(text)
        if not number.is_finite() or not 0<number<=Decimal('1e18') or number.as_tuple().exponent < -18:raise ValueError('عدد مسابقه معتبر نیست')
        if tick and number%Decimal(str(tick)):raise ValueError('قیمت با دقت اعلام‌شدهٔ مسابقه هماهنگ نیست')
        return format(number,'f')
    except (InvalidOperation,ArithmeticError):raise ValueError('عدد مسابقه معتبر نیست') from None


def entry_guard(db,contest,uid,contest_id=None):
    def reject(reason):
        counters=contest.setdefault('health_counters',{}).setdefault('rejected',{})
        counters[reason]=counters.get(reason,0)+1
        return reason
    if contest_id is not None and str(contest.get('id'))!=str(contest_id):return reject('STALE')
    from core.domain import is_vip
    uid=str(uid);audience=contest.get('eligible_group','everyone')
    allowed=(audience!='selected' or uid in set(map(str,contest.get('allowed_user_ids',[]))))
    allowed=allowed and not (audience=='vip' and not is_vip(db,uid) or audience=='nonvip' and is_vip(db,uid) or audience=='referral' and not db.get('users',{}).get(uid,{}).get('referred_by'))
    if not allowed:return reject('NOT_ELIGIBLE')
    entries=contest.get('participants',contest.get('answers',{}))
    if uid in entries:return reject('ALREADY')
    if int(contest.get('max_participants',0)) and len(entries)>=int(contest['max_participants']):return reject('FULL')
    return None


def update_policy(db,actor,kind,values,*,expected_id=None,expected_revision=None):
    from modules.admin_access import has_permission,PERMISSION_CONTEST_PUBLISH
    from core.domain import audit
    if not has_permission(db,actor,PERMISSION_CONTEST_PUBLISH):raise PermissionError('FORBIDDEN')
    contest=current(db,kind)
    if contest and ((expected_id is not None and contest['id']!=expected_id) or
                    (expected_revision is not None and int(contest.get('rules_revision',1))!=expected_revision)):
        raise ValueError('مسابقه تغییر کرده است؛ صفحه را تازه کنید')
    if not contest or contest.get('status')!='active':raise ValueError('مسابقه فعال نیست')
    if contest.get('participants') or contest.get('answers'):raise ValueError('پس از اولین پاسخ، قوانین مسابقه قفل است')
    allowed={'reference_name','observation_at','price_tick','tie_handling','eligible_group','max_participants','allowed_user_ids','prize_by_rank'}
    if set(values)-allowed:raise ValueError('تنظیم نامعتبر است')
    merged={**contest,**deepcopy(values)}
    if merged.get('eligible_group','everyone') not in {'everyone','vip','nonvip','selected','referral'}:raise ValueError('گروه نامعتبر است')
    if merged.get('tie_handling','shared') not in {'shared','earliest'}:raise ValueError('قانون تساوی نامعتبر است')
    if not 0<=int(merged.get('max_participants',0))<=100000:raise ValueError('سقف شرکت‌کننده نامعتبر است')
    if merged.get('price_tick'):exact_number(merged['price_tick'])
    from modules.prize_delivery import validate_prize
    for rank,prize in merged.get('prize_by_rank',{}).items():
        if str(rank) not in {'1','2','3'}:raise ValueError('رتبهٔ جایزه نامعتبر است')
        validate_prize(prize)
    contest.update(deepcopy(values));contest['rules_revision']=int(contest.get('rules_revision',1))+1
    audit(db,actor,'contest_policy_updated',contest['id'])
    return contest


def result_preview(db,kind,value):
    contest=current(db,kind)
    if not contest or contest.get('status') not in {'active','awaiting_result'}:raise ValueError('مسابقه تسویه‌نشده‌ای وجود ندارد')
    entries=contest.get('participants',contest.get('answers',{}));rows=[]
    if kind in {'price','candle'}:
        number=Decimal(exact_number(value,contest.get('price_tick')))
        for uid,entry in entries.items():
            guess=Decimal(entry.get('guess_text',str(entry['guess'])))
            rows.append({'uid':str(uid),'difference':format(abs(guess-number),'f'),'submitted_at':entry.get('submitted_at','')})
        rows.sort(key=lambda r:(Decimal(r['difference']),r['submitted_at'] if contest.get('tie_handling')=='earliest' else '',r['uid']))
    else:
        value=str(value).upper()
        if value not in ({'UP','DOWN','FLAT'} if kind=='chart' else {'UP','DOWN','RANGE'}):raise ValueError('نتیجه نامعتبر است')
        rows=[{'uid':str(uid),'difference':'0','submitted_at':entry.get('submitted_at','')} for uid,entry in entries.items() if entry.get('choice')==value]
        rows.sort(key=lambda r:(r['submitted_at'],r['uid']))
    rank=0;previous=None
    for i,row in enumerate(rows,1):
        if contest.get('tie_handling')=='earliest' or Decimal(row['difference'])!=previous:rank=i
        row['rank']=rank;previous=Decimal(row['difference'])
    return rows


def contest_hash(contest):
    from repositories.v2.common import content_hash
    return content_hash({k:v for k,v in contest.items() if k not in {'health_counters'}})


def propose_result(db,actor,kind,value,*,expected_id=None):
    from modules.admin_access import has_permission,PERMISSION_CONTEST_RESULT_MANAGE
    from repositories.v2.common import content_hash
    if not has_permission(db,actor,PERMISSION_CONTEST_RESULT_MANAGE):raise PermissionError('FORBIDDEN')
    contest=current(db,kind);rows=result_preview(db,kind,value)
    if expected_id is not None and (not contest or contest['id']!=expected_id):raise ValueError('مسابقه تغییر کرده است')
    contest.update(status='awaiting_result',active=False)
    token=uuid4().hex[:20]
    proposal={'id':token,'kind':kind,'contest_id':contest['id'],'value':str(value),'preview':rows,
              'contest_hash':contest_hash(contest),'created_by':str(actor),'created_at':utc_iso(),'status':'provisional'}
    db.setdefault('contest_result_proposals',{})[token]=proposal
    return proposal


def finalize_result(db,actor,token):
    from modules.admin_access import has_permission,PERMISSION_CONTEST_RESULT_MANAGE
    from modules import contest as contests
    from repositories.v2.common import content_hash
    from core.domain import audit
    if not has_permission(db,actor,PERMISSION_CONTEST_RESULT_MANAGE):raise PermissionError('FORBIDDEN')
    proposal=db.get('contest_result_proposals',{}).get(token)
    if not proposal:raise ValueError('نتیجهٔ موقت پیدا نشد')
    if proposal['status']=='finalized':return proposal
    contest=current(db,proposal['kind'])
    if not contest or contest['id']!=proposal['contest_id'] or contest_hash(contest)!=proposal['contest_hash']:
        raise ValueError('مسابقه تغییر کرده است؛ نتیجه را دوباره بررسی کنید')
    method={'price':contests.end_price_contest,'chart':contests.end_chart_contest,'candle':contests.end_candle_contest,'news_direction':contests.end_news_direction_contest}[proposal['kind']]
    contest['settlement_operation_id']='contest:'+contest['id']
    closed,result=method(db,proposal['value'])
    from modules.advanced_features import record_user_reward
    from modules.automation_outbox import enqueue_automation_message
    rewards=closed.get('results',result)
    for winner in rewards:
        if not winner.get('points') and not winner.get('prize'):continue
        uid=winner['uid'];label=winner.get('prize_label') or str(winner.get('points',0))+' امتیاز'
        if not winner.get('prize'):
            record_user_reward(db,uid,'جایزهٔ مسابقه',reward_type='points',detail=label,
                               source='contest:'+proposal['kind'],reference_id=closed['id'])
        enqueue_automation_message(db,dedupe_key=f"contest:{closed['id']}:notification:{uid}",kind='contest_prize',recipient_id=uid,
                                   payload={'text':'🏆 جایزهٔ مسابقهٔ شما: '+label},priority=4)
    proposal.update(status='finalized',finalized_by=str(actor),finalized_at=utc_iso())
    audit(db,actor,'contest_result_finalized',closed['id'])
    return proposal


def award_row(db,contest,row,kind):
    """Shared prize rules; every credit has an immutable economic source ID."""
    from modules.prize_delivery import deliver_prize,prize_label
    from core.domain import record_event
    configured=contest.get('prize_by_rank') or {}
    prize=configured.get(str(row['rank'])) if configured else {'points':int(row.get('points',0))}
    row['points']=int((prize or {}).get('points',0))
    if not prize or not any(prize.values()):return
    deliver_prize(db,row['uid'],prize,source_event=f"contest:{contest['id']}:winner:{row['uid']}",
                  title=contest.get('title','مسابقه'),source='contest')
    row['prize']=dict(prize);row['prize_label']=prize_label(prize)
    record_event(db,row['uid'],'win_news_direction_contest' if kind=='news_direction' else 'win_contest')


def latest(db,kind):
    return current(db,kind) or (next(iter(reversed(db.get('contests',[]))),None) if kind=='price' else db.get(KINDS.get(kind,'')))


def solution_lesson(db,actor,kind,contest_id,text=None):
    from modules.admin_access import has_permission,PERMISSION_CONTEST_RESULT_MANAGE,PERMISSION_EDUCATION_EDIT
    if not has_permission(db,actor,PERMISSION_CONTEST_RESULT_MANAGE) or not has_permission(db,actor,PERMISSION_EDUCATION_EDIT):raise PermissionError('FORBIDDEN')
    contest=latest(db,kind)
    if not contest or contest['id']!=contest_id or contest.get('status')!='closed':raise ValueError('فقط مسابقهٔ پایان‌یافته قابل تبدیل به درس است')
    if text is not None:
        if not str(text).strip():raise ValueError('توضیح خالی است')
        contest.setdefault('solution_versions',[]).append({'text':str(text)[:10000],'actor':str(actor),'at':utc_iso()})
        return contest
    if not contest.get('solution_versions'):raise ValueError('ابتدا توضیح آموزشی نتیجه را ثبت کنید')
    from modules.education import create_lesson,add_lesson_attachment
    lesson=create_lesson(db,category='مرور مسابقه',title=contest.get('question') or contest.get('news_name') or 'مرور مسابقه',
                         access_type='free',price=0,text=contest['solution_versions'][-1]['text'],status='draft',actor_id=actor)
    lesson['source_contest_id']=contest_id
    if contest.get('photo_file_id'):
        add_lesson_attachment(db,lesson['id'],{'type':'photo','file_id':contest['photo_file_id']})
    return lesson


def health(db,kind):
    contest=latest(db,kind)
    if not contest:return {'kind':kind,'active':False}
    entries=contest.get('participants',contest.get('answers',{}))
    prizes=[event for key,event in db.get('economic_events',{}).items() if key.startswith('contest:'+contest['id']+':winner:') and ':reward:' in key and event.get('status')=='applied']
    return {'kind':kind,'id':contest['id'],'status':contest.get('status'),'entries':len(entries),
            'rejected_answers':dict(contest.get('health_counters',{}).get('rejected',{})),
            'finalization_failures':int(contest.get('health_counters',{}).get('finalization_failures',0)),
            'delivered_prize_components':len(prizes),'awarded_users':len({p['user_id'] for p in prizes}),
            'health_counters_scope':'SINCE_UPGRADE_NO_BACKFILLED_REJECTION_COUNTS',
            'rules_locked':bool(entries),'reference_name':contest.get('reference_name','ثبت دستی ادمین'),
            'price_tick':contest.get('price_tick'),'observation_at':contest.get('observation_at'),
            'tie_handling':contest.get('tie_handling','shared'),'eligible_group':contest.get('eligible_group','everyone'),
            'max_participants':int(contest.get('max_participants',0))}
