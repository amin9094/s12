"""Two distinct experiments: a future order and the executable analysis quote."""
from decimal import Decimal as D
from repositories.v2.common import content_hash

MODES={'PENDING':'پیش‌بینی و سفارش','MARKET':'مارکت در لحظهٔ تحلیل'}


def market_detail(plan):
    facts=[f.get('detail') for f in plan.get('evidence',()) if f.get('kind')=='market_execution']
    if len(facts)>1:raise ValueError('MARKET_EXECUTION_EVIDENCE_INVALID')
    return facts[0] if facts else None


def mode_of(plan):return 'MARKET' if market_detail(plan) is not None else 'PENDING'


def account_identity(key):
    from repositories.v2.live_signal_inbox import STRATEGIES
    base=key.removesuffix('~market') if isinstance(key,str) else ''
    if base not in STRATEGIES:raise ValueError('PAPER_ENGINE_INVALID')
    mode='MARKET' if key!=base else 'PENDING'
    return base,mode


def account_key(engine,mode='PENDING'):
    base,_=account_identity(engine)
    if mode not in MODES:raise ValueError('SIGNAL_EXECUTION_MODE_INVALID')
    return base+('~market' if mode=='MARKET' else '')


def build_market(base,parent_id,tick,now_ms):
    from modules.signal_plan_policy import validate_locked_signal_plan
    validate_locked_signal_plan(base)
    if mode_of(base)!='PENDING' or base['submodel']=='range_breakout':
        raise ValueError('MARKET_BREAKOUT_NOT_CONFIRMED')
    quote={k:tick[k] for k in ('id','epoch','bid','ask','event_ms','received_ms')}
    if not 0<=now_ms-quote['event_ms']<=5000 or not 0<=now_ms-quote['received_ms']<=5000:
        raise ValueError('MARKET_ANALYSIS_QUOTE_STALE')
    bid,ask=D(quote['bid']),D(quote['ask'])
    quantum=D(base.get('tick_size',base.get('calculation_quantum')))
    entry=ask if base['direction']=='BUY' else bid
    if not bid.is_finite() or not ask.is_finite() or not 0<bid<=ask or entry%quantum:
        raise ValueError('MARKET_EXECUTABLE_QUOTE_INVALID')
    sign=D(1) if base['direction']=='BUY' else D(-1)
    stop,tp1=D(base['stop']),D(base['tp1'])
    if sign*(entry-stop)<=0 or sign*(tp1-entry)<2*abs(entry-stop):
        raise ValueError('MARKET_CURRENT_ENTRY_TP1_BELOW_2R')
    # Market means current price, never a retrospective midpoint/POC fill.
    if sign*(bid if sign==1 else ask)-sign*stop<=0:
        raise ValueError('MARKET_STOP_ALREADY_BREACHED')
    identity=content_hash(['MARKET_CURRENT_QUOTE_V1',base['thesis_key']])
    detail={'base_plan':base,'base_plan_hash':content_hash(base),'parent_signal_id':parent_id,
            'quote':quote,'analysis_ms':now_ms,'policy':'IMMEDIATE_AFTER_ANALYSIS_CURRENT_BID_ASK_V1',
            'reference_zone_only':True,'targets_or_stop_moved':False}
    plan={**base,'entry':str(entry),'thesis_key':identity,'setup_id':content_hash(['market',identity])[:32],
          'evidence_cutoff_ms':now_ms,
          'evidence':[{'kind':'market_execution','available_ms':now_ms,'detail':detail}],
          'initial_rr_tp2':str(abs(D(base['tp2'])-entry)/abs(entry-stop))}
    if 'rr_tp1' in base:plan['rr_tp1']=str(abs(tp1-entry)/abs(entry-stop))
    validate_market(plan)
    return plan


def validate_market(plan):
    from modules.signal_plan_policy import validate_locked_signal_plan
    detail=market_detail(plan)
    if not isinstance(detail,dict):raise ValueError('MARKET_EXECUTION_EVIDENCE_INVALID')
    if len(plan['evidence'])!=1 or detail.get('reference_zone_only') is not True:
        raise ValueError('MARKET_EXECUTION_EVIDENCE_INVALID')
    base=detail.get('base_plan',{})
    if market_detail(base) is not None or content_hash(base)!=detail.get('base_plan_hash'):
        raise ValueError('MARKET_BASE_PLAN_CHANGED')
    validate_locked_signal_plan(base)
    changed={'entry','setup_id','thesis_key','evidence','evidence_cutoff_ms','initial_rr_tp2','rr_tp1'}
    if {k:v for k,v in plan.items() if k not in changed}!={k:v for k,v in base.items() if k not in changed}:
        raise ValueError('MARKET_REFERENCE_GEOMETRY_CHANGED')
    if detail.get('policy')!='IMMEDIATE_AFTER_ANALYSIS_CURRENT_BID_ASK_V1' or detail.get('targets_or_stop_moved') is not False:
        raise ValueError('MARKET_EXECUTION_POLICY_INVALID')
    identity=content_hash(['MARKET_CURRENT_QUOTE_V1',base['thesis_key']])
    if plan['thesis_key']!=identity or plan['setup_id']!=content_hash(['market',identity])[:32]:
        raise ValueError('MARKET_IDENTITY_CHANGED')
    q=detail['quote'];now=detail['analysis_ms']
    if plan['evidence_cutoff_ms']!=now or now<base['evidence_cutoff_ms'] or not 0<=now-q['event_ms']<=5000 or not 0<=now-q['received_ms']<=5000:
        raise ValueError('MARKET_ANALYSIS_QUOTE_STALE')
    entry,stop,tp1=D(plan['entry']),D(plan['stop']),D(plan['tp1'])
    sign=D(1) if plan['direction']=='BUY' else D(-1)
    quantum=D(base.get('tick_size',base.get('calculation_quantum')))
    bid,ask=D(q['bid']),D(q['ask'])
    if not bid.is_finite() or not ask.is_finite() or not 0<bid<=ask or entry!=(ask if sign==1 else bid) or entry%quantum:
        raise ValueError('MARKET_EXECUTABLE_QUOTE_INVALID')
    if sign*(entry-stop)<=0 or sign*(tp1-entry)<2*abs(entry-stop):raise ValueError('MARKET_CURRENT_ENTRY_TP1_BELOW_2R')
    risk=next((f.get('detail',{}) for f in base['evidence'] if f.get('kind')=='native_grid_risk'),{})
    if abs(entry-stop)<max(D(risk.get('atr','0')),3*(ask-bid),4*quantum):
        raise ValueError('MARKET_STOP_VOLATILITY_FLOOR_REQUIRED')
    return base


def assert_publish_quote(plan,tick,now):
    validate_market(plan)
    quantum=D(plan.get('tick_size',plan.get('calculation_quantum')))
    if not 0<=now-tick['event_ms']<=5000 or not 0<=now-tick['received_ms']<=5000:
        raise ValueError('MARKET_PUBLICATION_QUOTE_STALE')
    current=D(tick['ask'] if plan['direction']=='BUY' else tick['bid'])
    if abs(current-D(plan['entry']))>quantum:raise ValueError('MARKET_PRICE_MOVED_RESCAN_REQUIRED')
    sign=D(1) if plan['direction']=='BUY' else D(-1)
    if sign*(D(plan['tp1'])-current)<2*abs(current-D(plan['stop'])):
        raise ValueError('MARKET_PUBLICATION_TP1_BELOW_2R')


def reference_plan(plan):return validate_market(plan) if mode_of(plan)=='MARKET' else plan
