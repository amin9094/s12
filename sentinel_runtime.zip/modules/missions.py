from __future__ import annotations

import copy
from datetime import UTC, datetime
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso

ALLOWED_EVENTS = {
    "manual",
    "daily_login",
    "risk_calculator",
    "join_chart_contest",
    "win_contest",
    "complete_lesson",
    "open_signal",
    "signal_taken",
    "create_price_alert",
    "open_support_ticket",
    "faq_feedback",
    "referral_join",
    "account_visit",
}
ALLOWED_PERIODS = {"one_time", "daily", "weekly", "monthly"}


def normalize_mission(item: dict[str, Any]) -> dict[str, Any]:
    item.setdefault("title", "مأموریت")
    item.setdefault("description", "")
    item.setdefault("event", "manual")
    item.setdefault("reward", 0)
    item.setdefault("target", 1)
    item.setdefault("period", "one_time")
    item.setdefault("active", True)
    item.setdefault("starts_at", None)
    item.setdefault("ends_at", None)
    item.setdefault("badge", "")
    item.setdefault("chain_after", None)
    item.setdefault("random_bonus_max", 0)
    item.setdefault("created_at", utc_iso())
    item.setdefault("updated_at", item.get("created_at"))
    return item


def ensure_missions(db: dict[str, Any]) -> None:
    for item in db.setdefault("missions", []):
        if isinstance(item, dict):
            normalize_mission(item)
    db.setdefault("user_missions", {})


def find_mission(db: dict[str, Any], mission_id: int | str) -> dict[str, Any] | None:
    ensure_missions(db)
    try:
        wanted = int(mission_id)
    except (TypeError, ValueError):
        return None
    return next(
        (item for item in db.get("missions", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == wanted),
        None,
    )


def create_mission(
    db: dict[str, Any],
    *,
    title: str,
    reward: int,
    event: str,
    target: int = 1,
    period: str = "one_time",
    description: str = "",
    active: bool = True,
    starts_at: str | None = None,
    ends_at: str | None = None,
    badge: str = "",
    random_bonus_max: int = 0,
    actor_id: int | str = 0,
) -> dict[str, Any]:
    ensure_missions(db)
    event_name = str(event).strip()
    if event_name not in ALLOWED_EVENTS:
        raise ValueError("event مأموریت معتبر نیست")
    period_name = str(period).strip()
    if period_name not in ALLOWED_PERIODS:
        raise ValueError("دوره مأموریت معتبر نیست")
    reward_value = int(reward)
    target_value = int(target)
    if reward_value < 0 or reward_value > 1_000_000:
        raise ValueError("امتیاز مأموریت باید بین صفر تا یک میلیون باشد")
    if target_value < 1 or target_value > 1_000_000:
        raise ValueError("هدف مأموریت باید حداقل یک باشد")
    if not str(title).strip():
        raise ValueError("عنوان مأموریت الزامی است")
    if starts_at and parse_dt(starts_at) is None:
        raise ValueError("تاریخ شروع معتبر نیست")
    if ends_at and parse_dt(ends_at) is None:
        raise ValueError("تاریخ پایان معتبر نیست")
    item = normalize_mission({
        "id": next_id(db, "mission"),
        "title": str(title).strip()[:150],
        "description": str(description).strip()[:1000],
        "reward": reward_value,
        "event": event_name,
        "target": target_value,
        "period": period_name,
        "active": bool(active),
        "starts_at": starts_at,
        "ends_at": ends_at,
        "badge": str(badge).strip()[:80],
        "random_bonus_max": max(0, min(int(random_bonus_max), 1_000_000)),
        "created_by": str(actor_id),
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
    })
    db["missions"].append(item)
    return item


def update_mission(db: dict[str, Any], mission_id: int | str, **changes: Any) -> dict[str, Any]:
    item = find_mission(db, mission_id)
    if not item:
        raise ValueError("مأموریت پیدا نشد")
    original = item
    item = copy.deepcopy(item)
    if "title" in changes:
        title = str(changes["title"]).strip()
        if not title:
            raise ValueError("عنوان خالی است")
        item["title"] = title[:150]
    if "description" in changes:
        item["description"] = str(changes["description"]).strip()[:1000]
    if "reward" in changes:
        value = int(changes["reward"])
        if not 0 <= value <= 1_000_000:
            raise ValueError("امتیاز نامعتبر است")
        item["reward"] = value
        if item.get("prize"):
            from modules.prize_delivery import validate_prize
            updated = {**item["prize"], "points": value}
            item["prize"] = validate_prize(updated)
    if "prize" in changes:
        from modules.prize_delivery import validate_prize
        item["prize"] = validate_prize(changes["prize"])
        item["reward"] = item["prize"]["points"]
    if "max_completions" in changes:
        value = int(changes["max_completions"])
        if not 0 <= value <= 1_000_000:
            raise ValueError("ظرفیت مأموریت نامعتبر است")
        item["max_completions"] = value
    if "event" in changes:
        value = str(changes["event"]).strip()
        if value not in ALLOWED_EVENTS:
            raise ValueError("event نامعتبر است")
        item["event"] = value
    if "target" in changes:
        value = int(changes["target"])
        if not 1 <= value <= 1_000_000:
            raise ValueError("هدف نامعتبر است")
        item["target"] = value
    if "period" in changes:
        value = str(changes["period"]).strip()
        if value not in ALLOWED_PERIODS:
            raise ValueError("دوره نامعتبر است")
        item["period"] = value
    for key in ("active",):
        if key in changes:
            item[key] = bool(changes[key])
    for key in ("starts_at", "ends_at"):
        if key in changes:
            value = changes[key] or None
            if value and parse_dt(value) is None:
                raise ValueError("تاریخ نامعتبر است")
            item[key] = value
    if "badge" in changes:
        item["badge"] = str(changes["badge"]).strip()[:80]
    if "random_bonus_max" in changes:
        item["random_bonus_max"] = max(0, min(int(changes["random_bonus_max"]), 1_000_000))
    item["updated_at"] = utc_iso()
    original.clear()
    original.update(item)
    return original


def toggle_mission(db: dict[str, Any], mission_id: int | str) -> dict[str, Any]:
    item = find_mission(db, mission_id)
    if not item:
        raise ValueError("مأموریت پیدا نشد")
    item["active"] = not bool(item.get("active", True))
    item["updated_at"] = utc_iso()
    return item


def duplicate_mission(db: dict[str, Any], mission_id: int | str, actor_id: int | str) -> dict[str, Any]:
    item = find_mission(db, mission_id)
    if not item:
        raise ValueError("مأموریت پیدا نشد")
    clone = copy.deepcopy(item)
    clone["id"] = next_id(db, "mission")
    clone["title"] = f"کپی {item.get('title', '')}"[:150]
    clone["active"] = False
    clone["completions_count"] = 0
    clone["created_by"] = str(actor_id)
    clone["created_at"] = utc_iso()
    clone["updated_at"] = utc_iso()
    db["missions"].append(clone)
    return clone


def delete_mission(db: dict[str, Any], mission_id: int | str) -> dict[str, Any] | None:
    item = find_mission(db, mission_id)
    if not item:
        return None
    db["missions"] = [row for row in db.get("missions", []) if row is not item]
    return item


def mission_period_key(mission: dict[str, Any], now: datetime | None = None) -> str:
    current = now or datetime.now(UTC)
    period = str(mission.get("period") or "one_time")
    if period == "daily":
        return current.strftime("%Y-%m-%d")
    if period == "weekly":
        year, week, _ = current.isocalendar()
        return f"{year}-W{week:02d}"
    if period == "monthly":
        return current.strftime("%Y-%m")
    return "all"


def mission_available(mission: dict[str, Any], now: datetime | None = None) -> bool:
    if mission.get("max_completions") and int(mission.get("completions_count",0))>=int(mission["max_completions"]):
        return False
    if not mission.get("active", True):
        return False
    current = now or datetime.now(UTC)
    start = parse_dt(mission.get("starts_at"))
    end = parse_dt(mission.get("ends_at"))
    if start and current < start:
        return False
    if end and current > end:
        return False
    return True


def mission_user_state(db: dict[str, Any], user_id: int | str, mission: dict[str, Any]) -> dict[str, Any]:
    uid = str(user_id)
    mid = str(mission.get("id"))
    root = db.setdefault("user_missions", {}).setdefault(uid, {}).setdefault(mid, {})
    # Migrate legacy one-time state into period records.
    periods = root.setdefault("periods", {})
    key = mission_period_key(mission)
    if root.get("completed") and "all" not in periods:
        periods["all"] = {
            "completed": True,
            "completed_at": root.get("completed_at"),
            "reward": root.get("reward", mission.get("reward", 0)),
            "progress": int(mission.get("target", 1) or 1),
        }
    row = periods.setdefault(key, {"progress": 0, "completed": False, "reward": 0})
    root["current_period"] = key
    root["progress"] = int(row.get("progress", 0) or 0)
    root["completed"] = bool(row.get("completed"))
    return row


def mission_progress_snapshot(db: dict[str, Any], user_id: int | str, mission: dict[str, Any]) -> dict[str, Any]:
    row = mission_user_state(db, user_id, mission)
    target = max(1, int(mission.get("target", 1) or 1))
    progress = min(target, int(row.get("progress", 0) or 0))
    return {
        "period_key": mission_period_key(mission),
        "progress": progress,
        "target": target,
        "completed": bool(row.get("completed")),
        "completed_at": row.get("completed_at"),
        "reward": int(row.get("reward", 0) or 0),
    }
