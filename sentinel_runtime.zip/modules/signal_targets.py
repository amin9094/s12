"""One ordered target vocabulary shared by plans, execution, charts and reports."""
TARGET_KEYS=tuple(f'tp{i}' for i in range(1,11))


def pairs(plan):return [(key,plan[key]) for key in TARGET_KEYS if plan.get(key) is not None]


def validate(plan):
    from decimal import Decimal as D
    sign=D(1) if plan['direction']=='BUY' else D(-1);last=D(plan['entry']);missing=False
    for key in TARGET_KEYS:
        value=plan.get(key)
        if value is None:missing=True;continue
        price=D(str(value))
        if missing or not price.is_finite() or price<=0 or sign*(price-last)<=0:raise ValueError('SIGNAL_TARGET_ORDER_INVALID')
        last=price
