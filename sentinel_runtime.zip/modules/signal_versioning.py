from __future__ import annotations

import copy
import hashlib
import json
from typing import Any

from core.utils import utc_iso

VERSION_FIELDS = (
    "symbol",
    "display_symbol",
    "market_category",
    "side",
    "entries",
    "entry",
    "stop",
    "targets",
    "risk",
    "target",
    "expires_at",
    "update_note",
)


def _snapshot(row: dict[str, Any]) -> dict[str, Any]:
    return {key: copy.deepcopy(row.get(key)) for key in VERSION_FIELDS if key in row}


def _digest(payload: dict[str, Any], previous_hash: str = "") -> str:
    raw = json.dumps(
        {"payload": payload, "previous_hash": previous_hash},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _stored_for_signal(revision_store: list[dict[str, Any]] | None, signal_id: Any) -> list[dict[str, Any]]:
    target = str(signal_id or "")
    if not revision_store or not target:
        return []
    return [
        item
        for item in revision_store
        if isinstance(item, dict) and str(item.get("signal_id") or "") == target
    ]


def _append_store(
    revision_store: list[dict[str, Any]] | None,
    row: dict[str, Any],
    revision: dict[str, Any],
) -> None:
    if revision_store is None:
        return
    stored = {
        **copy.deepcopy(revision),
        "signal_id": int(row.get("id", 0) or 0),
        "revision": int(revision.get("version", 1) or 1),
    }
    if any(
        str(item.get("signal_id")) == str(stored["signal_id"])
        and int(item.get("revision", 0) or 0) == stored["revision"]
        for item in revision_store
        if isinstance(item, dict)
    ):
        return
    revision_store.append(stored)


def ensure_initial_version(
    row: dict[str, Any],
    *,
    actor_id: int | str = "system",
    reason: str = "created",
    revision_store: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    versions = row.setdefault("versions", [])
    if not isinstance(versions, list):
        versions = []
        row["versions"] = versions

    stored = _stored_for_signal(revision_store, row.get("id"))
    if stored:
        stored.sort(key=lambda item: int(item.get("revision", item.get("version", 0)) or 0))
        row["revision"] = int(stored[-1].get("revision", 1) or 1)
        if not versions:
            row["versions"] = [
                {
                    key: copy.deepcopy(value)
                    for key, value in item.items()
                    if key not in {"signal_id", "revision"}
                }
                for item in stored[-30:]
            ]
        return row

    if versions:
        row.setdefault("revision", int(versions[-1].get("version", len(versions)) or len(versions)))
        for revision in versions:
            _append_store(revision_store, row, revision)
        return row

    payload = _snapshot(row)
    revision = {
        "version": 1,
        "actor_id": str(actor_id),
        "reason": str(reason or "created")[:200],
        "changed_fields": [],
        "snapshot": payload,
        "previous_hash": "",
        "hash": _digest(payload),
        "created_at": utc_iso(),
    }
    versions.append(revision)
    row["revision"] = 1
    _append_store(revision_store, row, revision)
    return row


def append_signal_version(
    row: dict[str, Any],
    *,
    actor_id: int | str,
    reason: str,
    before: dict[str, Any] | None = None,
    revision_store: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    ensure_initial_version(
        row,
        actor_id=actor_id,
        reason="baseline",
        revision_store=revision_store,
    )
    payload = _snapshot(row)
    store_rows = _stored_for_signal(revision_store, row.get("id"))
    previous_revision = store_rows[-1] if store_rows else row["versions"][-1]
    prior = before or previous_revision.get("snapshot") or {}
    changed = [key for key in VERSION_FIELDS if prior.get(key) != payload.get(key)]
    previous_hash = str(previous_revision.get("hash") or "")
    new_hash = _digest(payload, previous_hash)
    if not changed:
        return row

    version = int(previous_revision.get("revision", previous_revision.get("version", 0)) or 0) + 1
    revision = {
        "version": version,
        "actor_id": str(actor_id),
        "reason": str(reason or "updated")[:200],
        "changed_fields": changed,
        "snapshot": payload,
        "previous_hash": previous_hash,
        "hash": new_hash,
        "created_at": utc_iso(),
    }
    row.setdefault("versions", []).append(revision)
    # The canonical append-only table keeps every revision. The signal record
    # retains only a small read cache for backwards-compatible Telegram views.
    row["versions"] = row["versions"][-30:]
    row["revision"] = version
    row["versioned_at"] = revision["created_at"]
    _append_store(revision_store, row, revision)
    return row


def signal_version_history(
    row: dict[str, Any],
    revision_store: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    ensure_initial_version(row, revision_store=revision_store)
    stored = _stored_for_signal(revision_store, row.get("id"))
    if stored:
        stored.sort(key=lambda item: int(item.get("revision", item.get("version", 0)) or 0))
        return copy.deepcopy(stored)
    return copy.deepcopy(list(row.get("versions") or []))


def verify_revision_chain(revisions: list[dict[str, Any]]) -> bool:
    previous_hash = ""
    for item in sorted(
        (row for row in revisions if isinstance(row, dict)),
        key=lambda row: int(row.get("revision", row.get("version", 0)) or 0),
    ):
        payload = item.get("snapshot") if isinstance(item.get("snapshot"), dict) else {}
        if str(item.get("previous_hash") or "") != previous_hash:
            return False
        expected = _digest(payload, previous_hash)
        if str(item.get("hash") or "") != expected:
            return False
        previous_hash = expected
    return True
