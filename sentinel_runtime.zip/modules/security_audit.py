from __future__ import annotations

import hashlib
import json
from typing import Any

from core.utils import utc_iso


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def append_security_audit(
    db: dict[str, Any],
    *,
    action: str,
    actor_id: int | str,
    details: dict[str, Any] | None = None,
    source: str = "sentinel",
) -> dict[str, Any]:
    """Append a tamper-evident security event without truncating history.

    Security audit retention is deliberately separate from conversational AI
    retention. Each row includes the previous row hash so removal/reordering or
    alteration is detectable during an audit.
    """
    rows = db.setdefault("security_audit_log", [])
    previous_hash = str(rows[-1].get("entry_hash") or "GENESIS") if rows else "GENESIS"
    row = {
        "sequence": int(db.get("next_security_audit_sequence", 1) or 1),
        "action": str(action or "unknown")[:160],
        "actor_id": str(actor_id or "system")[:80],
        "source": str(source or "sentinel")[:120],
        "details": dict(details or {}),
        "created_at": utc_iso(),
        "previous_hash": previous_hash,
    }
    row["entry_hash"] = hashlib.sha256(
        (previous_hash + "|" + _canonical({k: v for k, v in row.items() if k != "entry_hash"})).encode("utf-8")
    ).hexdigest()
    rows.append(row)
    db["next_security_audit_sequence"] = row["sequence"] + 1
    return dict(row)


def verify_security_audit_chain(rows: list[dict[str, Any]]) -> dict[str, Any]:
    previous = "GENESIS"
    for index, row in enumerate(rows):
        if str(row.get("previous_hash") or "") != previous:
            return {"valid": False, "index": index, "reason": "PREVIOUS_HASH_MISMATCH"}
        expected = hashlib.sha256(
            (previous + "|" + _canonical({k: v for k, v in row.items() if k != "entry_hash"})).encode("utf-8")
        ).hexdigest()
        if str(row.get("entry_hash") or "") != expected:
            return {"valid": False, "index": index, "reason": "ENTRY_HASH_MISMATCH"}
        previous = expected
    return {"valid": True, "count": len(rows), "head": previous}
