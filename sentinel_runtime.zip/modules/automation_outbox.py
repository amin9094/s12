from __future__ import annotations
from core.logging_context import operation_id

from datetime import datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo
from uuid import uuid4

from core.db import next_id
from core.utils import parse_dt, utc_iso, utc_now
from modules.incident_center import record_incident
from modules.management_suite import automation_settings

CLAIM_TTL_MINUTES = 10
MAX_OUTBOX_ROWS = 100_000


def recipient_is_deleted(db: dict[str, Any], recipient_id: int | str) -> bool:
    request = db.get("privacy_requests", {}).get(str(recipient_id), {})
    return isinstance(request, dict) and request.get("status") == "completed"


def _cancel_deleted_delivery(db: dict[str, Any], row: dict[str, Any]) -> None:
    _release_budget(db, row)
    row.update(status="cancelled", cancelled_reason="Account deleted", updated_at=utc_iso(),
               claim_token=None, claimed_at=None, next_attempt_at=None, payload={}, finalizers=[])


def cancel_user_deliveries(db: dict[str, Any], user_id: str, pseudonym: str) -> None:
    for row in db.get("automation_outbox", {}).values():
        if not isinstance(row, dict) or row.get("recipient_scope") != "user" or str(row.get("recipient_id")) != user_id:
            continue
        if row.get("status") not in {"sent", "cancelled"}:
            started = bool(row.get("delivery_started_at"))
            _cancel_deleted_delivery(db, row)
            if started:
                row["status"] = "uncertain"  # An already in-flight send cannot be recalled.
        row.update(recipient_id=pseudonym, payload={}, finalizers=[], claim_token=None)


def _recipient_local_now(db: dict[str, Any], recipient_id: str) -> datetime:
    from modules.contact_budget import local_now
    return local_now(db,recipient_id)


def _quiet_hours_active(db: dict[str, Any], recipient_id: str) -> bool:
    settings = automation_settings(db)
    if not settings.get("crm_quiet_hours_enabled", True):
        return False
    start = max(0, min(int(23 if settings.get('crm_quiet_start_hour') is None else settings['crm_quiet_start_hour']), 23))
    end = max(0, min(int(8 if settings.get('crm_quiet_end_hour') is None else settings['crm_quiet_end_hour']), 23))
    hour = _recipient_local_now(db, recipient_id).hour
    return False if start==end else start <= hour < end if start < end else hour >= start or hour < end


def _contact_key(db: dict[str, Any], recipient_id: str) -> str:
    local = _recipient_local_now(db, recipient_id)
    return f"{local.date().isoformat()}:{recipient_id}"


def _daily_contacts(db: dict[str, Any], recipient_id: str) -> int:
    from modules.contact_budget import usage
    return usage(db,recipient_id)


def _increment_contacts(db: dict[str, Any], recipient_id: str, kind: str) -> None:
    key = _contact_key(db, recipient_id)
    row = db.setdefault("automation_contact_log", {}).setdefault(
        key,
        {"recipient_id": recipient_id, "count": 0, "kinds": {}, "updated_at": utc_iso()},
    )
    row["count"] = int(row.get("count", 0) or 0) + 1
    kinds = row.setdefault("kinds", {})
    kinds[kind] = int(kinds.get(kind, 0) or 0) + 1
    row["updated_at"] = utc_iso()


def _resolve_value(value: Any, *, success: bool, detail: str, now: str) -> Any:
    if value == "$now":
        return now
    if value == "$detail":
        return detail
    if value == "$status":
        return "sent" if success else "failed"
    return value


def _apply_finalizers(
    db: dict[str, Any],
    steps: list[dict[str, Any]],
    *,
    success: bool,
    detail: str,
) -> None:
    now = utc_iso()
    for step in steps:
        if not isinstance(step, dict):
            continue
        when = str(step.get("when") or "success")
        if when == "success" and not success:
            continue
        if when == "failure" and success:
            continue
        path = [str(item) for item in step.get("path", []) if str(item)]
        if not path or len(path) > 8:
            continue
        node: dict[str, Any] = db
        for part in path:
            child = node.setdefault(part, {})
            if not isinstance(child, dict):
                child = {}
                node[part] = child
            node = child
        values = step.get("values", {})
        if isinstance(values, dict):
            node.update(
                {
                    str(key): _resolve_value(value, success=success, detail=detail, now=now)
                    for key, value in values.items()
                }
            )


def enqueue_automation_message(
    db: dict[str, Any],
    *,
    dedupe_key: str,
    kind: str,
    recipient_id: int | str,
    payload: dict[str, Any],
    finalizers: list[dict[str, Any]] | None = None,
    recipient_scope: str = "user",
    not_before: Any = None,
    max_attempts: int = 5,
    priority: int = 3,
) -> dict[str, Any]:
    key = str(dedupe_key or "").strip()[:200]
    recipient = str(recipient_id or "").strip()
    if not key:
        raise ValueError("Automation outbox dedupe key is required.")
    if not recipient.lstrip("-").isdigit() or int(recipient) == 0:
        raise ValueError("Automation outbox recipient is invalid.")
    index = db.setdefault("automation_outbox_index", {})
    existing_id = str(index.get(key) or "")
    existing = db.setdefault("automation_outbox", {}).get(existing_id)
    if isinstance(existing, dict):
        return existing

    row_id = f"AOB-{next_id(db, 'automation_outbox'):09d}"
    due = parse_dt(not_before) or utc_now()
    row = {
        "id": row_id,
        "dedupe_key": key,
        "operation_id": operation_id(key),
        "kind": str(kind or "automation")[:64],
        "recipient_id": recipient,
        "recipient_scope": "admin" if recipient_scope == "admin" else "user",
        "payload": dict(payload),
        "finalizers": list(finalizers or []),
        "status": "pending",
        "priority": max(1, min(int(priority), 5)),
        "attempts": 0,
        "max_attempts": max(1, min(int(max_attempts), 20)),
        "next_attempt_at": utc_iso(due),
        "claimed_at": None,
        "sent_at": None,
        "last_error": "",
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
    }
    db["automation_outbox"][row_id] = row
    index[key] = row_id
    if row["recipient_scope"] == "user" and recipient_is_deleted(db, recipient):
        _cancel_deleted_delivery(db, row)
    if len(db["automation_outbox"]) > MAX_OUTBOX_ROWS:
        removable = [
            item
            for item in db["automation_outbox"].values()
            if isinstance(item, dict) and item.get("status") in {"sent", "dead_letter"}
        ]
        removable.sort(key=lambda item: str(item.get("updated_at") or ""))
        for old in removable[: max(0, len(db["automation_outbox"]) - MAX_OUTBOX_ROWS)]:
            db["automation_outbox"].pop(str(old.get("id") or ""), None)
            index.pop(str(old.get("dedupe_key") or ""), None)
    return row


def claim_due_automation_messages(
    db: dict[str, Any],
    *,
    limit: int = 50,
) -> list[dict[str, Any]]:
    now = utc_now()
    settings = automation_settings(db)
    if not settings.get('enabled',True):return []
    daily_cap = max(1, min(int(settings.get("crm_daily_contact_cap", 3) or 3), 20))
    candidates: list[dict[str, Any]] = []
    for row in db.setdefault("automation_outbox", {}).values():
        if not isinstance(row, dict) or row.get("status") not in {"pending", "retry", "processing"}:
            continue
        if row.get("recipient_scope") == "user" and recipient_is_deleted(db, row.get("recipient_id", "")):
            _cancel_deleted_delivery(db, row)
            continue
        dedupe=str(row.get('dedupe_key') or '')
        if dedupe.startswith('av2:'):
            rule=db.get('automation_rules_v2',{}).get(dedupe.split(':')[1])
            if rule and (not rule.get('enabled') or rule.get('deleted_at')):continue
        claimed_at = parse_dt(row.get("claimed_at"))
        if (
            row.get("status") == "processing"
            and claimed_at
            and claimed_at + timedelta(minutes=CLAIM_TTL_MINUTES) > now
        ):
            continue
        if row.get('status')=='processing' and row.get('delivery_started_at'):
            row.update(status='uncertain',updated_at=utc_iso(now),last_error='Expired delivery lease; delivery may have occurred')
            continue
        if row.get('status')=='processing':
            _release_budget(db,row)
        due = parse_dt(row.get("next_attempt_at")) or now
        if due > now:
            continue
        recipient = str(row.get("recipient_id") or "")
        if row.get("recipient_scope") == "user":
            priority = int(row.get("priority", 3) or 3)
            # Critical safety alerts may bypass quiet hours, but never the daily
            # contact cap. This keeps promotional traffic quiet while allowing
            # prop/risk emergencies to surface promptly.
            if (priority < 5 and _quiet_hours_active(db, recipient)) or _daily_contacts(db, recipient) >= daily_cap:
                continue
        candidates.append(row)
    candidates.sort(
        key=lambda row: (
            -int(row.get("priority", 3) or 3),
            str(row.get("next_attempt_at") or ""),
            str(row.get("id") or ""),
        )
    )
    claimed: list[dict[str, Any]] = []
    for row in candidates:
        if len(claimed)>=max(1,min(int(limit),200)):break
        if row.get('recipient_scope')=='user':
            from modules.contact_budget import reserve
            reserved=reserve(db,str(row['recipient_id']),str(row['id']))
            if not reserved:continue
            row['budget_reservation']=reserved
        row["status"] = "processing"
        row['claim_token']=uuid4().hex
        row['delivery_started_at']=None
        row["claimed_at"] = utc_iso(now)
        row["attempts"] = int(row.get("attempts", 0) or 0) + 1
        row["updated_at"] = utc_iso(now)
        claimed.append(dict(row))
    return claimed


def mark_automation_message_result(
    db: dict[str, Any],
    row_id: str,
    *,
    success: bool,
    detail: str = "",
    claim_token: str | None = None,
    uncertain: bool = False,
) -> dict[str, Any]:
    row = db.setdefault("automation_outbox", {}).get(str(row_id))
    if not isinstance(row, dict):
        raise ValueError("Automation outbox row not found.")
    if claim_token is not None and row.get('claim_token')!=claim_token:
        raise ValueError('AUTOMATION_DELIVERY_LEASE_CHANGED')
    if row.get('status') in {'sent','cancelled'}:
        return row
    if claim_token is not None and row.get('status')!='processing':
        raise ValueError('AUTOMATION_DELIVERY_STATE_CHANGED')
    row["claimed_at"] = None
    row["updated_at"] = utc_iso()
    row["last_error"] = str(detail or "")[:1000]
    if uncertain:
        row.update(status='uncertain',next_attempt_at=None)
        return row
    if success:
        row["status"] = "sent"
        row["sent_at"] = row["updated_at"]
        row["next_attempt_at"] = None
        if row.get("recipient_scope") == "user":
            _release_budget(db,row,sent=True)
    else:
        _release_budget(db,row)
        attempts = int(row.get("attempts", 0) or 0)
        maximum = max(1, int(row.get("max_attempts", 5) or 5))
        if attempts >= maximum:
            row["status"] = "dead_letter"
            row["next_attempt_at"] = None
            record_incident(
                db,
                source="automation_outbox",
                kind="delivery_dead_letter",
                detail=f"{row.get('kind')} / {row.get('dedupe_key')}: {detail}",
                severity="warning",
                metadata={
                    "outbox_id": str(row.get("id") or ""),
                    "recipient_id": str(row.get("recipient_id") or ""),
                    "attempts": attempts,
                },
                dedupe_minutes=30,
            )
        else:
            base = max(1, min(int(automation_settings(db).get("crm_retry_base_minutes", 5) or 5), 240))
            delay = min(base * (2 ** max(attempts - 1, 0)), 24 * 60)
            row["status"] = "retry"
            row["next_attempt_at"] = utc_iso(utc_now() + timedelta(minutes=delay))
    if success or row.get("status") == "dead_letter":
        _apply_finalizers(
            db,
            list(row.get("finalizers") or []),
            success=success,
            detail=row["last_error"],
        )
    return row


def _release_budget(db,row,*,sent=False):
    from modules.contact_budget import release
    return release(db,row.get('budget_reservation'),str(row['id']),sent=sent,kind=str(row.get('kind','automation')))


def authorize_automation_delivery(db,row_id,claim_token):
    """A separate committed pre-send boundary; a claimed row is not a sent row."""
    row=db.get('automation_outbox',{}).get(row_id)
    if not row or row.get('claim_token')!=claim_token or row.get('status')!='processing':return False
    if row.get('recipient_scope') == 'user' and recipient_is_deleted(db, row.get('recipient_id', '')):
        _cancel_deleted_delivery(db, row)
        return False
    cfg=automation_settings(db)
    key=str(row.get('dedupe_key',''))
    rule=db.get('automation_rules_v2',{}).get(key.split(':')[1]) if key.startswith('av2:') else None
    allowed=(cfg.get('enabled',True) or cfg.get('pause_mode')=='drain') and not (rule and (not rule.get('enabled') or rule.get('deleted_at')))
    if not allowed:
        row.update(status='cancelled',cancelled_reason='Paused before delivery',updated_at=utc_iso())
        _release_budget(db,row)
        return False
    if row.get('recipient_scope')=='user':
        from modules.contact_budget import key as day_key,reserve
        uid=str(row['recipient_id'])
        if int(row.get('priority',3))<5 and _quiet_hours_active(db,uid):
            _release_budget(db,row)
            row.update(status='retry',claimed_at=None,next_attempt_at=utc_iso(utc_now()+timedelta(minutes=30)))
            return False
        if row.get('budget_reservation')!=day_key(db,uid):
            _release_budget(db,row)
            row['budget_reservation']=reserve(db,uid,row_id)
        if not row.get('budget_reservation'):
            row.update(status='retry',claimed_at=None,next_attempt_at=utc_iso(utc_now()+timedelta(minutes=5)))
            return False
    row['delivery_started_at']=utc_iso()
    return True


def resolve_uncertain_message(db,row_id,*,actor_id,delivered):
    from core.domain import audit
    from modules.admin_access import has_permission,PERMISSION_AUTOMATIONS
    if not has_permission(db,actor_id,PERMISSION_AUTOMATIONS):raise PermissionError('FORBIDDEN')
    row=db.get('automation_outbox',{}).get(row_id)
    if not row or row.get('status')!='uncertain':raise ValueError('AUTOMATION_NOT_UNCERTAIN')
    row.update(status='sent' if delivered else 'cancelled',resolved_at=utc_iso(),resolved_by=str(actor_id),claimed_at=None)
    _release_budget(db,row,sent=delivered)
    if delivered:
        row['sent_at']=utc_iso()
        _apply_finalizers(db,list(row.get('finalizers') or []),success=True,detail='Admin reconciled delivery')
    audit(db,actor_id,'automation_delivery_reconciled',f'{row_id}:{bool(delivered)}')
    return row


def retry_automation_message(
    db: dict[str, Any],
    row_id: str,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    row = db.setdefault("automation_outbox", {}).get(str(row_id))
    if not isinstance(row, dict):
        raise ValueError("Automation outbox row not found.")
    if row.get("status") not in {"retry", "dead_letter"}:
        raise ValueError("Only retry or dead-letter messages can be retried.")
    row.update(
        {
            "status": "retry",
            "attempts": 0,
            "claimed_at": None,
            "next_attempt_at": utc_iso(),
            "last_error": "",
            "manual_retry_by": str(actor_id),
            "manual_retry_at": utc_iso(),
            "updated_at": utc_iso(),
        }
    )
    return row


def automation_outbox_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    rows = [row for row in db.setdefault("automation_outbox", {}).values() if isinstance(row, dict)]
    counts: dict[str, int] = {}
    for row in rows:
        status = str(row.get("status") or "unknown")
        counts[status] = counts.get(status, 0) + 1
    return {
        "total": len(rows),
        "status": counts,
        "dead_letters": [
            dict(row)
            for row in sorted(rows, key=lambda item: str(item.get("updated_at") or ""), reverse=True)
            if row.get("status") == "dead_letter"
        ][:25],
    }
