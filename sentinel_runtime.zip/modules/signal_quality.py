"""Explain optional evidence without presenting agreement as win probability."""
from modules.signal_execution import reference_plan


def explain(plan):
    facts={f.get('kind'):f.get('detail') or {} for f in reference_plan(plan).get('evidence',[])}
    custom=facts.get('custom_strategy',{})
    fib=custom.get('fibonacci') or facts.get('shared_fibonacci_confirmation',{})
    po3=facts.get('shared_goldbach_confirmation',{})
    priority=custom.get('confluence_priority') or facts.get('entry_confluence_priority',{})
    rows=[{'id':'independent_fibonacci','label_fa':'فیبوناچی موج مستقل','confirmed':bool(fib.get('confirmed') or fib.get('matches'))},
          {'id':'independent_po3','label_fa':'سطوح PO3 مستقل','confirmed':bool(po3.get('confirmed'))},
          {'id':'golden_structure_overlap','label_fa':'هم‌پوشانی گلدن‌زون و سطح ساختاری','confirmed':bool(priority.get('confirmed'))}]
    return {'optional_evidence':rows,'confirmed_count':sum(x['confirmed'] for x in rows),
            'is_win_probability':False,'mandatory_rules_changed':False,
            'original_dmns_amd_connected':False,'count_model':'GROUPED_EVIDENCE_NOT_INDEPENDENT_VOTES'}
