from __future__ import annotations

import hashlib
import mimetypes
import os
from pathlib import Path
from typing import Any

from config import SETTINGS
from core.utils import utc_iso
from modules.signal_template_editor import (
    ensure_signal_template_settings,
    move_signal_template_field,
    reset_signal_template_background,
    reset_signal_template_side,
    store_and_autodetect_signal_template_background,
    store_signal_template_background,
)

_ALLOWED_MIME = {"image/jpeg", "image/png", "image/webp"}
_ALLOWED_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp"}
_MAX_BYTES = 12 * 1024 * 1024


def _storage_root() -> Path:
    mount = os.getenv("PERSISTENT_DATA_DIR") or os.getenv("RAILWAY_VOLUME_MOUNT_PATH") or os.getenv("VOLUME_MOUNT_PATH")
    root = Path(mount) / "ai_admin_assets" if mount else SETTINGS.db_file.parent / "ai_admin_assets"
    root.mkdir(parents=True, exist_ok=True)
    return root.resolve()


def _safe_path(path: str | Path) -> Path:
    resolved = Path(path).resolve()
    resolved.relative_to(_storage_root())
    return resolved


def register_admin_ai_asset(
    db: dict[str, Any],
    actor_id: int | str,
    payload: bytes,
    *,
    original_name: str = "asset.jpg",
    mime_type: str = "",
    telegram_file_id: str = "",
) -> dict[str, Any]:
    if not payload or len(payload) > _MAX_BYTES:
        raise ValueError("AI_ASSET_SIZE_INVALID")
    suffix = Path(original_name).suffix.lower()
    guessed = mimetypes.guess_type(original_name)[0] or ""
    content_type = str(mime_type or guessed).lower()
    if suffix not in _ALLOWED_SUFFIXES or content_type not in _ALLOWED_MIME:
        raise ValueError("AI_ASSET_TYPE_INVALID")
    digest = hashlib.sha256(payload).hexdigest()
    root = _storage_root()
    target = root / f"{digest[:24]}{suffix}"
    if not target.exists():
        temp = target.with_suffix(target.suffix + ".tmp")
        temp.write_bytes(payload)
        os.chmod(temp, 0o600)
        temp.replace(target)
    seq = int(db.get("next_admin_ai_asset_id", 1) or 1)
    row = {
        "id": seq,
        "actor_id": str(actor_id),
        "path": str(target),
        "sha256": digest,
        "original_name": Path(original_name).name[:180],
        "mime_type": content_type,
        "size": len(payload),
        "telegram_file_id": str(telegram_file_id or "")[:300],
        "status": "active",
        "created_at": utc_iso(),
    }
    db["next_admin_ai_asset_id"] = seq + 1
    db.setdefault("admin_ai_assets", []).append(row)
    db["admin_ai_assets"] = db["admin_ai_assets"][-1000:]
    db.setdefault("ai_audit_log", []).append({
        "action": "ai_asset_registered", "actor_id": str(actor_id), "asset_id": seq,
        "sha256": digest, "created_at": utc_iso(),
    })
    db["ai_audit_log"] = db["ai_audit_log"][-5000:]
    return dict(row)


def admin_ai_asset(db: dict[str, Any], asset_id: int | str | None, *, actor_id: int | str | None = None) -> dict[str, Any] | None:
    rows = [row for row in db.get("admin_ai_assets", []) if isinstance(row, dict) and row.get("status", "active") == "active"]
    if asset_id in (None, "", "latest", "last"):
        if actor_id is not None:
            rows = [row for row in rows if str(row.get("actor_id")) == str(actor_id)] or rows
        return dict(rows[-1]) if rows else None
    target = int(str(asset_id))
    row = next((row for row in rows if int(row.get("id", 0) or 0) == target), None)
    return dict(row) if row else None


def apply_asset_to_signal_template(
    db: dict[str, Any],
    actor_id: int | str,
    *,
    side: str,
    asset_id: int | str | None = None,
    autodetect: bool = True,
) -> dict[str, Any]:
    normalized_side = str(side or "").strip().lower()
    if normalized_side not in {"buy", "sell"}:
        raise ValueError("SIGNAL_TEMPLATE_SIDE_INVALID")
    asset = admin_ai_asset(db, asset_id, actor_id=actor_id)
    if not asset:
        raise ValueError("AI_ASSET_NOT_FOUND")
    path = _safe_path(str(asset.get("path") or ""))
    payload = path.read_bytes()
    if autodetect:
        result = store_and_autodetect_signal_template_background(
            db, normalized_side, payload, original_name=str(asset.get("original_name") or path.name)
        )
    else:
        result = {
            "background": store_signal_template_background(
                db, normalized_side, payload, original_name=str(asset.get("original_name") or path.name)
            )
        }
    db.setdefault("ai_audit_log", []).append({
        "action": "ai_signal_template_asset_applied", "actor_id": str(actor_id),
        "asset_id": int(asset["id"]), "side": normalized_side, "created_at": utc_iso(),
    })
    db["ai_audit_log"] = db["ai_audit_log"][-5000:]
    return {"side": normalized_side, "asset": asset, **result}


def update_signal_template_layout(db: dict[str, Any], actor_id: int | str, payload: dict[str, Any]) -> dict[str, Any]:
    side = str(payload.get("side") or "").lower()
    field = str(payload.get("field") or "").lower()
    if side not in {"buy", "sell"} or not field:
        raise ValueError("SIGNAL_TEMPLATE_SIDE_FIELD_REQUIRED")
    result: dict[str, Any] = {}
    if payload.get("dx") is not None or payload.get("dy") is not None:
        result["layout"] = move_signal_template_field(db, side, field, dx=int(payload.get("dx") or 0), dy=int(payload.get("dy") or 0))
    elif payload.get("x") is not None or payload.get("y") is not None:
        # Convert absolute coordinates into a relative move from the current box.
        from modules.signal_template_editor import signal_template_layout
        current_side = signal_template_layout(db, side)
        current = (current_side.get("fields") or {}).get(field, {})
        box = list(current.get("box") or [0, 0, 60, 30])
        current_x, current_y = int(box[0]), int(box[1])
        result["layout"] = move_signal_template_field(
            db, side, field,
            dx=int(payload.get("x", current_x)) - current_x,
            dy=int(payload.get("y", current_y)) - current_y,
        )
    if payload.get("size") is not None or payload.get("font_delta") is not None:
        from modules.signal_template_editor import signal_template_layout
        current_side = signal_template_layout(db, side)
        current = (current_side.get("fields") or {}).get(field, {})
        current_size = int(current.get("font_size", 46) or 46)
        requested = (
            int(str(payload.get("size")))
            if payload.get("size") is not None
            else current_size + int(payload.get("font_delta") or 0)
        )
        requested = max(18, min(72, requested))
        # The editor intentionally supports only the bundled server-side font;
        # Gemini may set its size but cannot load arbitrary font files.
        settings = ensure_signal_template_settings(db)
        settings[side]["fields"][field]["font_size"] = requested
        result["font"] = dict(settings[side]["fields"][field])
    if payload.get("font") not in (None, "", "default", "bundled"):
        raise ValueError("SIGNAL_TEMPLATE_CUSTOM_FONT_UNSUPPORTED")
    if not result:
        raise ValueError("SIGNAL_TEMPLATE_LAYOUT_CHANGE_REQUIRED")
    db.setdefault("ai_audit_log", []).append({
        "action": "ai_signal_template_layout_updated", "actor_id": str(actor_id),
        "side": side, "field": field, "created_at": utc_iso(),
    })
    return result


def reset_ai_signal_template(db: dict[str, Any], actor_id: int | str, *, side: str, background: bool = True, layout: bool = True) -> dict[str, Any]:
    normalized_side = str(side or "").lower()
    if normalized_side not in {"buy", "sell"}:
        raise ValueError("SIGNAL_TEMPLATE_SIDE_INVALID")
    result: dict[str, Any] = {"side": normalized_side}
    if background:
        result["background"] = reset_signal_template_background(db, normalized_side)
    if layout:
        result["layout"] = reset_signal_template_side(db, normalized_side)
    db.setdefault("ai_audit_log", []).append({
        "action": "ai_signal_template_reset", "actor_id": str(actor_id), "side": normalized_side,
        "background": bool(background), "layout": bool(layout), "created_at": utc_iso(),
    })
    return result


def enqueue_channel_operation(db: dict[str, Any], actor_id: int | str, payload: dict[str, Any]) -> dict[str, Any]:
    operation = str(payload.get("operation") or "").strip().lower()
    if operation not in {"edit_text", "edit_media", "delete", "pin", "unpin"}:
        raise ValueError("CHANNEL_OPERATION_INVALID")
    chat_id = payload.get("chat_id")
    message_id = payload.get("message_id")
    signal_id = payload.get("signal_id")
    if signal_id and (not chat_id or not message_id):
        signals = [row for row in db.get("signals", []) if isinstance(row, dict)]
        if str(signal_id).lower() in {"latest", "last"}:
            signal = signals[-1] if signals else None
        else:
            signal = next((row for row in signals if str(row.get("id")) == str(signal_id) or str(row.get("display_number")) == str(signal_id)), None)
        if not signal:
            raise ValueError("SIGNAL_NOT_FOUND")
        deliveries = [row for row in signal.get("deliveries", []) if isinstance(row, dict)]
        if not deliveries:
            raise ValueError("SIGNAL_DELIVERY_NOT_FOUND")
        selected = deliveries[0]
        chat_id = chat_id or selected.get("chat_id")
        message_id = message_id or selected.get("message_id")
    if not chat_id or not message_id:
        raise ValueError("CHANNEL_CHAT_MESSAGE_REQUIRED")
    asset = None
    if payload.get("asset_id") not in (None, ""):
        asset = admin_ai_asset(db, payload.get("asset_id"), actor_id=actor_id)
        if not asset:
            raise ValueError("AI_ASSET_NOT_FOUND")
    seq = int(db.get("next_ai_channel_operation_id", 1) or 1)
    row = {
        "id": seq,
        "status": "queued",
        "operation": operation,
        "chat_id": int(chat_id),
        "message_id": int(message_id),
        "text": str(payload.get("text") or "")[:4096],
        "asset_path": str(asset.get("path") or "") if asset else "",
        "asset_id": int(asset["id"]) if asset else None,
        "signal_id": str(signal_id or ""),
        "requested_by": str(actor_id),
        "attempts": 0,
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
    }
    db["next_ai_channel_operation_id"] = seq + 1
    db.setdefault("ai_channel_operations", []).append(row)
    db["ai_channel_operations"] = db["ai_channel_operations"][-3000:]
    return dict(row)


def enqueue_signal_refresh(db: dict[str, Any], actor_id: int | str, signal_id: int | str) -> dict[str, Any]:
    seq = int(db.get("next_ai_signal_refresh_id", 1) or 1)
    row = {"id": seq, "signal_id": str(signal_id), "status": "queued", "requested_by": str(actor_id), "attempts": 0, "created_at": utc_iso(), "updated_at": utc_iso()}
    db["next_ai_signal_refresh_id"] = seq + 1
    db.setdefault("ai_signal_refresh_queue", []).append(row)
    db["ai_signal_refresh_queue"] = db["ai_signal_refresh_queue"][-3000:]
    return dict(row)
