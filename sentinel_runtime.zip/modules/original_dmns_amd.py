"""Input contract for an authorized original-script bridge, not an AMD replica.

An authenticated import is not evidence that the original algorithm was run.
Only an independently checked parity attestation can qualify that claim.
"""
import hashlib,hmac,os,re
from decimal import Decimal as D
from repositories.v2.common import json_dump,content_hash

SCRIPT='dmns-ICT-AMD-Goldbach'


def validate(payload,signature,*,now_ms):
    secret=os.getenv('DMNS_AMD_BRIDGE_SIGNING_KEY','')
    if len(secret)<32:raise ValueError('ORIGINAL_DMNS_AMD_BRIDGE_NOT_CONFIGURED')
    if not isinstance(signature,str) or not re.fullmatch('[a-f0-9]{64}',signature):raise ValueError('ORIGINAL_DMNS_AMD_SIGNATURE_INVALID')
    expected=hmac.new(secret.encode(),json_dump(payload).encode(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,signature):raise ValueError('ORIGINAL_DMNS_AMD_SIGNATURE_INVALID')
    required={'version','script','script_version','authorized_source_hash','symbol','timeframe','provider','venue','product',
              'bar_end_ms','available_ms','settings','dr_shift','levels','chart_reference'}
    if not isinstance(payload,dict) or set(payload)!=required or payload['version']!=1 or payload['script']!=SCRIPT:raise ValueError('ORIGINAL_DMNS_AMD_INPUT_INVALID')
    from modules.automated_market_scope import require_global_symbol
    require_global_symbol(payload['symbol'])
    if payload['timeframe'] not in {'1m','5m','1h','4h','1d'}:raise ValueError('ORIGINAL_DMNS_AMD_TIMEFRAME_INVALID')
    if any(not isinstance(payload[k],str) or not 1<=len(payload[k])<=160 for k in ('provider','venue','product','script_version','chart_reference')):raise ValueError('ORIGINAL_DMNS_AMD_INPUT_INVALID')
    if not re.fullmatch('[a-f0-9]{64}',payload['authorized_source_hash']):raise ValueError('ORIGINAL_DMNS_AMD_SOURCE_INVALID')
    if any(type(payload[k]) is not int for k in ('bar_end_ms','available_ms')) or not 0<=payload['bar_end_ms']<=payload['available_ms']<=now_ms:raise ValueError('ORIGINAL_DMNS_AMD_FUTURE_INPUT_REJECTED')
    shift=D(str(payload['dr_shift']))
    if not shift.is_finite() or abs(shift)>1000:raise ValueError('ORIGINAL_DMNS_AMD_SHIFT_INVALID')
    if not isinstance(payload['settings'],dict) or len(json_dump(payload['settings']))>8000:raise ValueError('ORIGINAL_DMNS_AMD_SETTINGS_INVALID')
    if not isinstance(payload['levels'],list) or not 2<=len(payload['levels'])<=200:raise ValueError('ORIGINAL_DMNS_AMD_LEVELS_INVALID')
    for level in payload['levels']:
        if not isinstance(level,dict) or set(level)!={'price','label','role'}:raise ValueError('ORIGINAL_DMNS_AMD_LEVELS_INVALID')
        price=D(str(level['price']))
        if not price.is_finite() or price<=0 or level['role'] not in {'SUPPORT','RESISTANCE','INTERNAL'} or not isinstance(level['label'],str) or len(level['label'])>60:raise ValueError('ORIGINAL_DMNS_AMD_LEVELS_INVALID')
    return {'input_hash':content_hash(payload),'settings_hash':content_hash(payload['settings']),
            'authenticated_bridge':True,'original_algorithm_verified':False,
            'status':'AUTHENTICATED_IMPORT_AWAITING_ORIGINAL_PARITY','required_for_entry':False}


def parity(reference,candidate,*,tick_size):
    """Compare actual exported level sets, identity and shift; no image guessing."""
    tick=D(str(tick_size))
    if not tick.is_finite() or tick<=0:raise ValueError('PARITY_TICK_INVALID')
    identity=('script','script_version','symbol','timeframe','provider','venue','product','bar_end_ms','settings','dr_shift')
    if any(reference.get(k)!=candidate.get(k) for k in identity):return {'matched':False,'reason':'IDENTITY_OR_SETTINGS_DIFFER'}
    a={(x['label'],x['role']):D(str(x['price'])) for x in reference['levels']};b={(x['label'],x['role']):D(str(x['price'])) for x in candidate['levels']}
    if len(a)!=len(reference['levels']) or len(b)!=len(candidate['levels']) or a.keys()!=b.keys():return {'matched':False,'reason':'LEVEL_SET_DIFFER'}
    errors=[abs(a[k]-b[k])/tick for k in a]
    return {'matched':all(x<=1 for x in errors),'maximum_tick_error':str(max(errors)),
            'reference_hash':content_hash(reference),'candidate_hash':content_hash(candidate),
            'does_not_attest_original_source_authenticity':True}
