from __future__ import annotations

import hashlib
import math
import re
from collections import Counter
from typing import Any, Iterable

_TOKEN_RE = re.compile(r"[A-Za-z0-9_\u0600-\u06ff]{2,}")
_EMBED_DIMENSIONS = 256


def _normalize(text: str) -> str:
    value = str(text or "").casefold()
    value = value.translate(str.maketrans("يكى", "یکی"))
    return re.sub(r"\s+", " ", value).strip()


def _tokens(text: str) -> list[str]:
    normalized = _normalize(text)
    words = _TOKEN_RE.findall(normalized)
    compact = re.sub(r"\s+", "", normalized)
    grams = [f"§{compact[i:i+3]}" for i in range(max(0, len(compact) - 2))]
    return words + grams[:3000]


def _chunks(text: str, *, max_chars: int = 1800, overlap: int = 180) -> list[str]:
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n|(?<=[.!؟])\s+", str(text or "")) if part.strip()]
    result: list[str] = []
    current = ""
    for paragraph in paragraphs:
        if len(paragraph) > max_chars:
            if current:
                result.append(current)
                current = ""
            start = 0
            while start < len(paragraph):
                result.append(paragraph[start:start + max_chars])
                start += max(1, max_chars - overlap)
            continue
        candidate = f"{current}\n{paragraph}".strip()
        if current and len(candidate) > max_chars:
            result.append(current)
            current = f"{current[-overlap:]}\n{paragraph}".strip()
        else:
            current = candidate
    if current:
        result.append(current)
    return result


def _hash_embedding(text: str, *, dimensions: int = _EMBED_DIMENSIONS) -> dict[str, float]:
    """Deterministic local semantic-ish vector.

    It is intentionally provider-independent: word and character features are
    projected into a signed hashing space. This is not sold as a neural
    embedding; it gives the knowledge base semantic/fuzzy recall, stable builds,
    and zero external data disclosure. A hosted embedding provider can later be
    plugged in behind the same stored-vector contract.
    """
    vector = [0.0] * dimensions
    for token, count in Counter(_tokens(text)).items():
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        bucket = int.from_bytes(digest[:4], "big") % dimensions
        sign = -1.0 if digest[4] & 1 else 1.0
        weight = 1.0 + math.log1p(float(count))
        if token.startswith("§"):
            weight *= 0.35
        vector[bucket] += sign * weight
    norm = math.sqrt(sum(item * item for item in vector)) or 1.0
    return {str(index): round(value / norm, 8) for index, value in enumerate(vector) if value}


def _embedding_cosine(left: dict[str, Any], right: dict[str, Any]) -> float:
    if not left or not right:
        return 0.0
    # Stored vectors are unit normalized.
    smaller, larger = (left, right) if len(left) <= len(right) else (right, left)
    return sum(float(value) * float(larger.get(key, 0.0)) for key, value in smaller.items())


def source_set_hash(sources: Iterable[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for source in sorted(sources, key=lambda row: (str(row.get("source") or ""), str(row.get("version") or ""))):
        for value in (
            source.get("source"), source.get("version"), source.get("status", "approved"),
            source.get("text"),
        ):
            digest.update(str(value or "").encode("utf-8"))
            digest.update(b"\0")
    return digest.hexdigest()


def build_index(sources: list[dict[str, Any]]) -> dict[str, Any]:
    documents: list[dict[str, Any]] = []
    document_frequency: Counter[str] = Counter()
    approved_sources = [row for row in sources if str(row.get("status") or "approved").lower() in {"approved", "published", "active"}]
    for source in approved_sources:
        source_name = str(source.get("source") or "unknown")[:200]
        source_version = str(source.get("version") or "1")[:80]
        source_text = str(source.get("text") or "")
        source_hash = hashlib.sha256((source_version + "\0" + source_text).encode("utf-8")).hexdigest()
        for index, chunk in enumerate(_chunks(source_text)):
            counts = Counter(_tokens(chunk))
            if not counts:
                continue
            document_frequency.update(counts.keys())
            documents.append({
                "source": source_name,
                "source_version": source_version,
                "source_hash": source_hash,
                "chunk_id": index,
                "citation": f"KB:{source_hash[:12]}:{index}",
                "text": chunk,
                "tokens": dict(counts),
                "embedding": _hash_embedding(chunk),
                "length": sum(counts.values()),
            })
    total = max(1, len(documents))
    idf = {token: math.log((total + 1) / (frequency + 1)) + 1.0 for token, frequency in document_frequency.items()}
    return {
        "schema_version": 3,
        "embedding": {"kind": "signed_feature_hash", "dimensions": _EMBED_DIMENSIONS},
        "source_set_hash": source_set_hash(sources),
        "source_count": len(approved_sources),
        "chunk_count": len(documents),
        "idf": idf,
        "documents": documents,
    }


def search(index: dict[str, Any], query: str, *, limit: int = 8) -> list[dict[str, Any]]:
    query_counts = Counter(_tokens(query))
    if not query_counts:
        return []
    query_embedding = _hash_embedding(query)
    idf = index.get("idf") if isinstance(index.get("idf"), dict) else {}
    query_norm = math.sqrt(sum((count * float(idf.get(token, 1.0))) ** 2 for token, count in query_counts.items())) or 1.0
    results: list[dict[str, Any]] = []
    normalized_query = _normalize(query)
    for document in index.get("documents", []):
        if not isinstance(document, dict):
            continue
        counts = document.get("tokens") if isinstance(document.get("tokens"), dict) else {}
        overlap = set(query_counts) & set(counts)
        lexical = 0.0
        word_hits = 0
        if overlap:
            dot = sum(query_counts[token] * int(counts[token]) * float(idf.get(token, 1.0)) ** 2 for token in overlap)
            doc_norm = math.sqrt(sum((int(count) * float(idf.get(token, 1.0))) ** 2 for token, count in counts.items())) or 1.0
            lexical = dot / (query_norm * doc_norm)
            word_hits = sum(1 for token in overlap if not token.startswith("§"))
            lexical += min(0.35, word_hits * 0.06)
        semantic = max(0.0, _embedding_cosine(query_embedding, document.get("embedding") or {}))
        exact = 0.25 if normalized_query and normalized_query in _normalize(document.get("text") or "") else 0.0
        score = 0.58 * lexical + 0.32 * semantic + exact
        if score <= 0.015:
            continue
        results.append({
            "source": document.get("source"),
            "source_version": document.get("source_version"),
            "source_hash": document.get("source_hash"),
            "chunk_id": document.get("chunk_id"),
            "citation": document.get("citation"),
            "score": round(score, 6),
            "score_breakdown": {"lexical": round(lexical, 6), "semantic": round(semantic, 6), "exact": exact},
            "text": document.get("text"),
        })
    results.sort(key=lambda row: (-float(row.get("score", 0.0)), str(row.get("source") or ""), int(row.get("chunk_id", 0) or 0)))
    # Re-rank to avoid one large source monopolizing every citation.
    selected: list[dict[str, Any]] = []
    per_source: Counter[str] = Counter()
    for row in results:
        source = str(row.get("source") or "")
        if per_source[source] >= 3 and len({str(item.get("source")) for item in selected}) < 3:
            continue
        selected.append(row)
        per_source[source] += 1
        if len(selected) >= max(1, min(int(limit), 20)):
            break
    return selected
