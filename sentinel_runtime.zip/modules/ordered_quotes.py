"""Public book continuity and bounded quote evidence, without trading calls.

Continuity is at the provider's published books cadence (100 ms), not a claim
of every exchange execution or a broker fill. Closed/open native OHLC is also
required when promoting a prepared proposal so sampled quotes alone do not
certify full-zone freshness.
"""

from collections import deque
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from hashlib import sha256
from zlib import crc32

from modules.canonical_market import Quote, price
from repositories.v2.common import json_dump


@dataclass(frozen=True)
class OrderedQuote:
    quote: Quote
    epoch: str
    sequence: int
    previous_sequence: int
    snapshot: bool = False
    feed: str = 'OKX_PUBLIC_BOOKS_100MS'
    ordering: str = 'NATIVE_SEQUENCE_LINK'
    checksum: int | None = None


def native_utc_ms(stamp):
    """Require exchange UTC; truncate sub-ms precision without float rounding."""
    if not isinstance(stamp, str) or not stamp.endswith('Z'):
        raise ValueError('NATIVE_UTC_TIMESTAMP_REQUIRED')
    parsed = datetime.fromisoformat(stamp[:-1] + '+00:00')
    elapsed = parsed - datetime(1970, 1, 1, tzinfo=UTC)
    return (elapsed.days * 86400 + elapsed.seconds) * 1000 + elapsed.microseconds // 1000


def kraken_book_checksum(bids, asks):
    """Kraken v2 CRC32: top ten asks then bids, preserving decimal zeros."""
    pieces = []
    for levels, reverse in ((asks, False), (bids, True)):
        for px in sorted(levels, reverse=reverse)[:10]:
            for value in (px, levels[px]):
                pieces.append(format(value, 'f').replace('.', '').lstrip('0'))
    return crc32(''.join(pieces).encode('ascii')) & 0xffffffff


class KrakenBook:
    """Checksum-validated spot book. Its ordinal is LOCAL, never native seqId.

    A checksum validates the received top-ten book state, not every trade or
    an exchange sequence gap. Reconnects always require a new epoch/review.
    """
    def __init__(self, symbol, tick_size, epoch, *, depth=10):
        if not symbol.endswith('USDT') or depth not in {10, 25, 100, 500, 1000}:
            raise ValueError('KRAKEN_BOOK_MARKET_OR_DEPTH_INVALID')
        self.symbol, self.tick_size, self.epoch = symbol, price(tick_size), epoch
        self.depth = depth
        self.bids, self.asks = {}, {}
        self.sequence, self.last_ms, self.failed = 0, 0, False

    def update(self, row, *, action, received_ms):
        if self.failed:
            raise ValueError('KRAKEN_BOOK_EPOCH_INTERRUPTED')
        try:
            return self._update(row, action=action, received_ms=received_ms)
        except Exception:
            self.failed = True
            raise

    def _update(self, row, *, action, received_ms):
        snapshot = action == 'snapshot'
        if row.get('symbol') != self.symbol[:-4] + '/USDT':
            raise ValueError('ORDER_BOOK_MARKET_MISMATCH')
        stamp = native_utc_ms(row['timestamp'])
        if action not in {'snapshot', 'update'} or stamp < self.last_ms:
            raise ValueError('ORDER_BOOK_ORDER_INVALID')
        if snapshot and self.sequence or not snapshot and not self.sequence:
            raise ValueError('ORDER_BOOK_UNEXPECTED_SNAPSHOT_OR_MISSING_INITIAL_STATE')
        checksum = row['checksum']
        if type(checksum) is not int or not 0 <= checksum <= 0xffffffff:
            raise ValueError('ORDER_BOOK_CHECKSUM_INVALID')
        for name, levels in (('bids', self.bids), ('asks', self.asks)):
            for level in row.get(name) or []:
                # A float decoder already lost wire precision/trailing zeros.
                if any(isinstance(level[key], float | bool) for key in ('price', 'qty')):
                    raise ValueError('ORDER_BOOK_DECIMAL_DECODER_REQUIRED')
                px, size = price(level['price']), Decimal(str(level['qty']))
                if px % self.tick_size or not size.is_finite() or size < 0:
                    raise ValueError('ORDER_BOOK_LEVEL_INVALID')
                if size == 0:
                    levels.pop(px, None)
                else:
                    # Decimal keys compare numerically: replace the key too,
                    # preserving the latest wire spelling for CRC32.
                    levels.pop(px, None)
                    levels[px] = size
            ordered = sorted(levels, reverse=name == 'bids')[:self.depth]
            setattr(self, name, {px: levels[px] for px in ordered})
        if not self.bids or not self.asks or max(self.bids) > min(self.asks):
            raise ValueError('ORDER_BOOK_EMPTY_OR_CROSSED')
        if kraken_book_checksum(self.bids, self.asks) != checksum:
            raise ValueError('ORDER_BOOK_CHECKSUM_MISMATCH')
        previous = self.sequence
        self.sequence += 1
        self.last_ms = stamp
        quote = Quote(self.symbol, 'kraken', 'kraken_spot_USDT', 'spot', stamp, received_ms,
                      max(self.bids), min(self.asks), self.tick_size,
                      f'kraken:book:{self.symbol}:{self.epoch}:{self.sequence}:{row["timestamp"]}:{checksum}',
                      ('INITIAL_SNAPSHOT_NO_CONTINUITY',) if snapshot else ())
        return OrderedQuote(quote, self.epoch, self.sequence, previous, snapshot,
                            'KRAKEN_PUBLIC_BOOK_V2_CRC32', 'LOCAL_RECEIVE_ORDINAL_CRC32', checksum)


class OKXBook:
    def __init__(self, symbol, tick_size, epoch):
        if not symbol.endswith('USDT'):
            raise ValueError('CRYPTO_USDT_MARKET_REQUIRED')
        self.symbol, self.tick_size, self.epoch = symbol, price(tick_size), epoch
        self.bids, self.asks = {}, {}
        self.sequence = None
        self.last_ms = 0

    def update(self, row, *, action, received_ms):
        seq, previous, stamp = int(row['seqId']), int(row['prevSeqId']), int(row['ts'])
        snapshot = action == 'snapshot'
        if row.get('instId', self.symbol[:-4] + '-USDT') != self.symbol[:-4] + '-USDT':
            raise ValueError('ORDER_BOOK_MARKET_MISMATCH')
        if action not in {'snapshot', 'update'} or seq < 0 or stamp < self.last_ms:
            raise ValueError('ORDER_BOOK_ORDER_INVALID')
        if snapshot:
            if self.sequence is not None or previous != -1:
                raise ValueError('ORDER_BOOK_UNEXPECTED_SNAPSHOT')
            self.bids, self.asks = {}, {}
        elif self.sequence is None or previous != self.sequence:
            raise ValueError('ORDER_BOOK_SEQUENCE_GAP')
        # A same-sequence empty heartbeat is not a new quote or price touch.
        elif seq == previous:
            if row.get('asks') or row.get('bids'):
                raise ValueError('ORDER_BOOK_SEQUENCE_REUSED_WITH_CHANGES')
            return None
        for name, levels in (('bids', self.bids), ('asks', self.asks)):
            seen = set()
            for level in row.get(name) or []:
                px, size = price(level[0]), Decimal(str(level[1]))
                if px in seen or px % self.tick_size or not size.is_finite() or size < 0:
                    raise ValueError('ORDER_BOOK_LEVEL_INVALID')
                seen.add(px)
                if size == 0:
                    levels.pop(px, None)
                else:
                    levels[px] = size
            ordered = sorted(levels, reverse=name == 'bids')[:400]
            setattr(self, name, {px: levels[px] for px in ordered})
        if not self.bids or not self.asks or max(self.bids) > min(self.asks):
            raise ValueError('ORDER_BOOK_EMPTY_OR_CROSSED')
        self.sequence, self.last_ms = seq, stamp  # Maintenance resets may decrease seq, with a valid link.
        quote = Quote(self.symbol, 'okx', 'okx_spot_USDT', 'spot', stamp, received_ms,
                      max(self.bids), min(self.asks), self.tick_size,
                      f'okx:books:{self.symbol}:{self.epoch}:{seq}:{stamp}',
                      ('INITIAL_SNAPSHOT_NO_CONTINUITY',) if snapshot else ())
        return OrderedQuote(quote, self.epoch, seq, previous, snapshot)


class QuoteJournal:
    def __init__(self, limit=2048):
        self.rows = deque(maxlen=limit)
        self.failure = ''

    def append(self, frame):
        if self.failure:
            raise ValueError('QUOTE_EPOCH_ALREADY_INTERRUPTED')
        expected = {'okx':('OKX_PUBLIC_BOOKS_100MS','NATIVE_SEQUENCE_LINK'),
                    'kraken':('KRAKEN_PUBLIC_BOOK_V2_CRC32','LOCAL_RECEIVE_ORDINAL_CRC32')}
        if expected.get(frame.quote.provider)!=(frame.feed,frame.ordering) or (
            frame.quote.provider=='kraken' and (type(frame.checksum) is not int or not 0<=frame.checksum<=0xffffffff)
        ):
            self.failure = 'QUOTE_FEED_INTEGRITY_METADATA_INVALID'
            raise ValueError(self.failure)
        if self.rows:
            last = self.rows[-1]
            a, b = last.quote, frame.quote
            if frame.snapshot or frame.epoch != last.epoch or frame.previous_sequence != last.sequence or (
                a.symbol, a.provider, a.venue, a.product, a.tick_size
            ) != (b.symbol, b.provider, b.venue, b.product, b.tick_size) or b.event_ms < a.event_ms or (
                frame.feed, frame.ordering
            ) != (last.feed, last.ordering) or (
                frame.ordering=='LOCAL_RECEIVE_ORDINAL_CRC32' and frame.sequence!=last.sequence+1
            ):
                self.failure = 'QUOTE_JOURNAL_CONTINUITY_GAP'
                raise ValueError(self.failure)
        elif not frame.snapshot:
            raise ValueError('QUOTE_JOURNAL_SNAPSHOT_REQUIRED')
        self.rows.append(frame)

    def proof(self, plan, *, epoch, start_ms, through_ms, now_ms):
        if not 0 < start_ms <= through_ms:
            raise ValueError('QUOTE_PROOF_TIME_RANGE_INVALID')
        if self.failure or not self.rows or self.rows[-1].epoch != epoch:
            raise ValueError('QUOTE_EPOCH_INTERRUPTED')
        if self.rows[0].quote.event_ms > start_ms:
            raise ValueError('QUOTE_WINDOW_TRUNCATED_OR_STARTED_TOO_LATE')
        last = self.rows[-1]
        if last.quote.event_ms < through_ms or not last.quote.fresh(now_ms):
            raise ValueError('QUOTE_WATERMARK_NOT_READY')
        market = (plan.symbol, plan.provider, plan.venue, plan.product, plan.tick_size)
        if (last.quote.symbol, last.quote.provider, last.quote.venue, last.quote.product, last.quote.tick_size) != market:
            raise ValueError('QUOTE_MARKET_MISMATCH')
        rows = [r for r in self.rows if r.quote.event_ms >= start_ms]
        if any(r.quote.bid <= plan.zone_high and r.quote.ask >= plan.zone_low for r in rows):
            raise ValueError('ORIGINAL_ZONE_TOUCHED_BEFORE_DELIVERY')
        native_sequence = last.ordering == 'NATIVE_SEQUENCE_LINK'
        content = [{'quote':r.quote.as_dict(),
                    'seq' if native_sequence else 'receive_ordinal':r.sequence,
                    'prev' if native_sequence else 'previous_receive_ordinal':r.previous_sequence,
                    'checksum':r.checksum} for r in rows]
        return {'untouched':True,'complete_coverage':True,'observed_through_ms':last.quote.event_ms,
                'start_ms':start_ms,'epoch':epoch,'feed':last.feed,'ordering':last.ordering,
                'coverage_scope':'CONTINUOUS_RECEIVED_BOOK_SESSION_PLUS_NATIVE_CANDLE_BRIDGE_REQUIRED',
                'native_sequence_available':native_sequence,
                'first_sequence':(rows[0].sequence if rows else last.sequence) if native_sequence else None,
                'last_sequence':last.sequence if native_sequence else None,
                'last_receive_ordinal':None if native_sequence else last.sequence,
                'quote_count':len(rows),'quotes':content,'content_hash':sha256(json_dump(content).encode()).hexdigest(),
                'all_exchange_ticks_claimed':False,'is_broker_fill':False}
