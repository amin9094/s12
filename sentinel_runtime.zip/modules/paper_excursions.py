"""Observed executable-side excursions, never reconstructed intra-candle paths."""
from decimal import Decimal as D


def observe(p,tick):
    if p.get('entered_ms') is None:return p
    if p['state']=='NEEDS_REVIEW':
        if p.get('excursions'):p['excursions']['coverage_complete']=False
        return p
    if p['state'] not in {'OPEN','CLOSED'} or p.get('last_tick_id')!=tick['id'] or p.get('epoch')!=tick['epoch']:return p
    prior=p.get('excursions') or {}
    if prior.get('last_quote_id')==tick['id']:return p
    distance=D(p.get('risk_distance',str(abs(D(p['fill_price'])-D(p['plan']['stop'])))))
    if distance<=0:return p
    sign=D(1) if p['plan']['direction']=='BUY' else D(-1)
    price=D(tick['bid'] if sign==1 else tick['ask']);r=sign*(price-D(p['fill_price']))/distance
    result={**prior,'model':'OBSERVED_EXECUTABLE_QUOTES','is_full_price_path':False,
            'coverage_complete':prior.get('coverage_complete',True),'last_quote_id':tick['id'],
            'last_observed_ms':tick['event_ms'],'observations':prior.get('observations',0)+1}
    if r>D(prior.get('mfe_r','0')):result.update(mfe_r=str(r),mfe_ms=tick['event_ms'],mfe_price=str(price))
    if -r>D(prior.get('mae_r','0')):result.update(mae_r=str(-r),mae_ms=tick['event_ms'],mae_price=str(price))
    result.setdefault('mfe_r','0');result.setdefault('mae_r','0')
    result['time_to_tp_ms']={e['type']:e['at_ms']-p['entered_ms'] for e in p.get('events',[]) if e.get('type','').startswith('TP')}
    p['excursions']=result
    return p
