"""Expiry is proposed to the admin; the scheduler cannot silently publish it."""

from __future__ import annotations

from core.utils import parse_dt, utc_now
from modules.signal_safety import FINAL_SIGNAL_STATUSES


def expiry_candidates(database, *, now=None):
    now = now or utc_now()
    result = []
    for row in database.get("signals", []):
        if not isinstance(row, dict) or row.get("status", "open") in FINAL_SIGNAL_STATUSES:
            continue
        expiry = parse_dt(row.get("expires_at"))
        if expiry is None or expiry > now:
            continue
        result.append(
            {
                "signal_id": row["id"],
                "display_number": row.get("display_number", row["id"]),
                "symbol": row.get("symbol", ""),
                "event": "expired",
                "price": None,
                "low": None,
                "high": None,
                "source": "expiry_clock_admin_review",
                "auto_publish_safe": False,
                "ambiguous": False,
                "stale": False,
                "snapshot": False,
                "expires_at": row.get("expires_at"),
            }
        )
    return result
