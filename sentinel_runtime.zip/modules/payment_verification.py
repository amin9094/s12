from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
from typing import Any

from config import SETTINGS
from core.http_client import get_json, request
from core.utils import utc_iso

_TX_RE = re.compile(r"^(?:0x)?[0-9a-fA-F]{64}$")
_EVM_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
_TRON_ADDRESS_RE = re.compile(r"^T[1-9A-HJ-NP-Za-km-z]{33}$")
_TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
_USDT_CONTRACTS = {
    "ERC20": ("0xdac17f958d2ee523a2206206994597c13d831ec7", 6),
    "BEP20": ("0x55d398326f99059ff775485246999027b3197955", 18),
}
_MIN_CONFIRMATIONS = {"TRC20": 20, "ERC20": 12, "BEP20": 15}
_CHAIN_IDS = {"ERC20": 1, "BEP20": 56}


@dataclass(frozen=True, slots=True)
class VerificationResult:
    status: str
    network: str
    txid: str
    verified: bool
    destination: str = ""
    amount: str = ""
    confirmations: int = 0
    provider: str = ""
    reason: str = ""
    checked_at: str = ""

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def normalize_network(value: str) -> str:
    clean = re.sub(r"[^A-Z0-9]", "", str(value or "").upper())
    aliases = {
        "TRON": "TRC20",
        "TRX": "TRC20",
        "TRC": "TRC20",
        "ETH": "ERC20",
        "ETHEREUM": "ERC20",
        "ERC": "ERC20",
        "BSC": "BEP20",
        "BNB": "BEP20",
        "BEP": "BEP20",
        "BINANCESMARTCHAIN": "BEP20",
    }
    return aliases.get(clean, clean)


def normalize_txid(value: str) -> str:
    clean = str(value or "").strip()
    if clean.lower().startswith("0x"):
        clean = clean[2:]
    if not re.fullmatch(r"[0-9a-fA-F]{64}", clean):
        raise ValueError("TXID باید دقیقاً یک هش ۶۴ کاراکتری معتبر باشد.")
    return clean.lower()


def wallet_valid(network: str, address: str) -> bool:
    network = normalize_network(network)
    clean = str(address or "").strip()
    if network == "TRC20":
        return bool(_TRON_ADDRESS_RE.fullmatch(clean))
    if network in {"ERC20", "BEP20"}:
        return bool(_EVM_ADDRESS_RE.fullmatch(clean))
    return 10 <= len(clean) <= 160


def txid_used(db: dict[str, Any], txid: str, *, exclude_order_id: str = "") -> bool:
    normalized = normalize_txid(txid)
    return any(
        isinstance(order, dict)
        and str(order.get("order_id") or "") != exclude_order_id
        and str(order.get("transaction_hash") or "").lower().removeprefix("0x") == normalized
        for order in db.get("vip_orders", [])
    )


def _decimal(value: Any) -> Decimal:
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("0")


def _match_amount(received: Decimal, expected: Decimal) -> bool:
    # Permit tiny exchange/rounding differences, but not an underpayment above 1%.
    tolerance = max(Decimal("0.01"), expected * Decimal("0.01"))
    return received + tolerance >= expected


async def _verify_tron(txid: str, wallet: str, expected: Decimal) -> VerificationResult:
    base = SETTINGS.usdt_tron_api_url.rstrip("/")
    headers = {"TRON-PRO-API-KEY": SETTINGS.usdt_trongrid_api_key} if SETTINGS.usdt_trongrid_api_key else None
    payload = await get_json(
        f"{base}/api/transaction-info",
        params={"hash": txid},
        headers=headers,
        timeout_seconds=max(8, SETTINGS.request_timeout_seconds),
        retries=2,
    )
    if not isinstance(payload, dict) or not payload:
        return VerificationResult("not_found", "TRC20", txid, False, provider="Tronscan", reason="تراکنش پیدا نشد", checked_at=utc_iso())
    success = str(payload.get("contractRet") or payload.get("contract_ret") or "").upper() in {"SUCCESS", "SUCESS"}
    rows = payload.get("trc20TransferInfo") or payload.get("trc20_transfer_info") or []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        symbol = str(row.get("symbol") or row.get("tokenAbbr") or "").upper()
        if symbol and symbol != "USDT":
            continue
        destination = str(row.get("to_address") or row.get("toAddress") or "").strip()
        decimals = int(row.get("decimals", 6) or 6)
        raw_amount = row.get("amount_str", row.get("amount", 0))
        amount = _decimal(raw_amount) / (Decimal(10) ** decimals)
        matched_wallet = destination == wallet
        raw_confirmations = payload.get("confirmations")
        if raw_confirmations is None and payload.get("confirmed") is True:
            raw_confirmations = _MIN_CONFIRMATIONS["TRC20"]
        confirmations = max(0, int(raw_confirmations or 1))
        enough_confirmations = confirmations >= _MIN_CONFIRMATIONS["TRC20"]
        verified = success and matched_wallet and _match_amount(amount, expected) and enough_confirmations
        reason = ""
        if not success:
            reason = "تراکنش ناموفق است"
        elif not matched_wallet:
            reason = "آدرس مقصد با کیف پول فروشگاه مطابقت ندارد"
        elif not _match_amount(amount, expected):
            reason = "مبلغ دریافت‌شده کمتر از مبلغ سفارش است"
        elif not enough_confirmations:
            reason = f"تراکنش در انتظار {_MIN_CONFIRMATIONS['TRC20']} تأیید شبکه است"
        return VerificationResult(
            "verified" if verified else ("pending" if success and matched_wallet and _match_amount(amount, expected) else "mismatch"),
            "TRC20",
            txid,
            verified,
            destination=destination,
            amount=format(amount, "f"),
            confirmations=confirmations,
            provider="Tronscan",
            reason=reason,
            checked_at=utc_iso(),
        )
    return VerificationResult("mismatch", "TRC20", txid, False, provider="Tronscan", reason="انتقال USDT در تراکنش پیدا نشد", checked_at=utc_iso())


async def _rpc(rpc_url: str, method: str, params: list[Any]) -> Any:
    response = await request(
        "POST",
        rpc_url,
        json_body={"jsonrpc": "2.0", "id": 1, "method": method, "params": params},
        timeout_seconds=max(8, SETTINGS.request_timeout_seconds),
        retries=2,
    )
    payload = response.json()
    if not isinstance(payload, dict) or payload.get("error"):
        raise RuntimeError(str(payload.get("error") if isinstance(payload, dict) else "invalid RPC response"))
    return payload.get("result")


async def _verify_evm(network: str, txid: str, wallet: str, expected: Decimal) -> VerificationResult:
    rpc_url = SETTINGS.usdt_ethereum_rpc_url if network == "ERC20" else SETTINGS.usdt_bsc_rpc_url
    if not rpc_url:
        return VerificationResult("manual_review", network, txid, False, provider="", reason="RPC این شبکه تنظیم نشده است", checked_at=utc_iso())
    receipt = await _rpc(rpc_url, "eth_getTransactionReceipt", ["0x" + txid])
    if not isinstance(receipt, dict):
        return VerificationResult("pending", network, txid, False, provider="JSON-RPC", reason="تراکنش هنوز تأیید نشده یا پیدا نشد", checked_at=utc_iso())
    if str(receipt.get("status") or "").lower() not in {"0x1", "1"}:
        return VerificationResult("failed", network, txid, False, provider="JSON-RPC", reason="تراکنش ناموفق است", checked_at=utc_iso())
    chain_raw = await _rpc(rpc_url, "eth_chainId", [])
    try:
        chain_id = int(str(chain_raw), 16)
    except (TypeError, ValueError):
        return VerificationResult("manual_review", network, txid, False, provider="JSON-RPC", reason="Chain ID قابل تأیید نیست", checked_at=utc_iso())
    if chain_id != _CHAIN_IDS[network]:
        return VerificationResult("mismatch", network, txid, False, provider="JSON-RPC", reason="تراکنش روی شبکه دیگری ثبت شده است", checked_at=utc_iso())
    latest_raw = await _rpc(rpc_url, "eth_blockNumber", [])
    try:
        latest_block = int(str(latest_raw), 16)
        transaction_block = int(str(receipt.get("blockNumber")), 16)
        confirmations = max(0, latest_block - transaction_block + 1)
    except (TypeError, ValueError):
        confirmations = 0
    contract, decimals = _USDT_CONTRACTS[network]
    expected_wallet = wallet.lower()
    for log in receipt.get("logs", []):
        if not isinstance(log, dict) or str(log.get("address") or "").lower() != contract:
            continue
        topics = log.get("topics") or []
        if len(topics) < 3 or str(topics[0]).lower() != _TRANSFER_TOPIC:
            continue
        destination = "0x" + str(topics[2])[-40:]
        try:
            amount = Decimal(int(str(log.get("data") or "0x0"), 16)) / (Decimal(10) ** decimals)
        except (ValueError, InvalidOperation):
            continue
        matched_wallet = destination.lower() == expected_wallet
        enough_confirmations = confirmations >= _MIN_CONFIRMATIONS[network]
        verified = matched_wallet and _match_amount(amount, expected) and enough_confirmations
        reason = ""
        if not matched_wallet:
            reason = "آدرس مقصد با کیف پول فروشگاه مطابقت ندارد"
        elif not _match_amount(amount, expected):
            reason = "مبلغ دریافت‌شده کمتر از مبلغ سفارش است"
        elif not enough_confirmations:
            reason = f"تراکنش در انتظار {_MIN_CONFIRMATIONS[network]} تأیید شبکه است"
        return VerificationResult(
            "verified" if verified else ("pending" if matched_wallet and _match_amount(amount, expected) else "mismatch"),
            network,
            txid,
            verified,
            destination=destination,
            amount=format(amount, "f"),
            confirmations=confirmations,
            provider="JSON-RPC",
            reason=reason,
            checked_at=utc_iso(),
        )
    return VerificationResult("mismatch", network, txid, False, provider="JSON-RPC", reason="انتقال USDT در تراکنش پیدا نشد", checked_at=utc_iso())


async def verify_usdt_transaction(*, network: str, txid: str, wallet: str, expected_amount: Any) -> VerificationResult:
    normalized_network = normalize_network(network)
    normalized_txid = normalize_txid(txid)
    expected = _decimal(expected_amount)
    if expected < 0:
        raise ValueError("مبلغ مورد انتظار نامعتبر است")
    if not wallet_valid(normalized_network, wallet):
        return VerificationResult("configuration_error", normalized_network, normalized_txid, False, reason="آدرس کیف پول تنظیم‌شده معتبر نیست", checked_at=utc_iso())
    if not SETTINGS.usdt_verification_enabled:
        return VerificationResult("manual_review", normalized_network, normalized_txid, False, reason="بررسی خودکار غیرفعال است", checked_at=utc_iso())
    try:
        if normalized_network == "TRC20":
            return await _verify_tron(normalized_txid, wallet, expected)
        if normalized_network in {"ERC20", "BEP20"}:
            return await _verify_evm(normalized_network, normalized_txid, wallet, expected)
        return VerificationResult("manual_review", normalized_network, normalized_txid, False, reason="شبکه برای بررسی خودکار پشتیبانی نمی‌شود", checked_at=utc_iso())
    except Exception as exc:
        return VerificationResult(
            "manual_review",
            normalized_network,
            normalized_txid,
            False,
            reason=f"سرویس بررسی در دسترس نبود: {exc.__class__.__name__}",
            checked_at=utc_iso(),
        )
