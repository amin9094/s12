from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any

from core.utils import parse_dt

ATTRIBUTION_MODELS = {"first_touch", "last_touch"}


def _integer(value: Any) -> int:
    try:
        return int(float(str(value or "0").replace(",", "").strip()))
    except (TypeError, ValueError):
        return 0


def _metric_row(row: dict[str, Any]) -> dict[str, Any]:
    unique_joins = max(0, _integer(row.get("unique_join_count")))
    active_members = max(0, _integer(row.get("active_members")))
    cost = max(0, _integer(row.get("cost")))
    orders = max(0, _integer(row.get("approved_orders")))
    revenue = max(0, _integer(row.get("revenue")))
    return {
        **row,
        "unique_joins": unique_joins,
        "active_members": active_members,
        "cost": cost,
        "approved_orders": orders,
        "revenue": revenue,
        "join_to_purchase_rate": round(orders / max(1, unique_joins) * 100, 2),
        "active_retention_rate": round(active_members / max(1, unique_joins) * 100, 2),
        "cac": round(cost / max(1, orders), 2) if cost else 0,
        "cost_per_join": round(cost / max(1, unique_joins), 2) if cost else 0,
        "roas": round(revenue / cost, 2) if cost else 0,
        "roi": round((revenue - cost) / cost * 100, 2) if cost else 0,
    }


def _group_rows(rows: list[dict[str, Any]], field: str) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}
    for row in rows:
        key = str(row.get(field) or "نامشخص").strip() or "نامشخص"
        item = grouped.setdefault(
            key,
            {
                "name": key,
                "links": 0,
                "unique_join_count": 0,
                "active_members": 0,
                "cost": 0,
                "approved_orders": 0,
                "revenue": 0,
            },
        )
        item["links"] += 1
        item["unique_join_count"] += _integer(row.get("unique_join_count"))
        item["active_members"] += _integer(row.get("active_members"))
        item["cost"] += _integer(row.get("cost"))
        item["approved_orders"] += _integer(row.get("approved_orders"))
        item["revenue"] += _integer(row.get("revenue"))
    return sorted(
        (_metric_row(item) for item in grouped.values()),
        key=lambda item: (item["revenue"], item["approved_orders"], item["unique_joins"]),
        reverse=True,
    )


def growth_link_lab(
    db: dict[str, Any],
    *,
    attribution_model: str = "last_touch",
) -> dict[str, Any]:
    """Compare campaign links with non-duplicated first/last-touch revenue."""
    model = str(attribution_model or "last_touch").strip().lower()
    if model not in ATTRIBUTION_MODELS:
        raise ValueError("مدل Attribution باید first_touch یا last_touch باشد.")

    links = [
        dict(row)
        for row in db.get("public_channel_links", [])
        if isinstance(row, dict) and str(row.get("id") or "").isdigit()
    ]
    campaigns = {
        str(key): row
        for key, row in db.get("marketing_campaigns", {}).items()
        if isinstance(row, dict)
    }
    # Bot deep links are first-class acquisition links too.  Model them beside
    # public-channel invite links so one attribution engine covers both paths.
    for campaign_id, campaign in campaigns.items():
        bot_link = str(campaign.get("bot_tracking_link") or "")
        if not bot_link:
            continue
        tracking = campaign.get("tracking", {}) if isinstance(campaign.get("tracking"), dict) else {}
        links.append(
            {
                "id": f"bot:{campaign_id}",
                "name": f"{campaign.get('name') or campaign_id} · Bot",
                "invite_link": bot_link,
                "campaign_id": campaign_id,
                "advertiser": str(tracking.get("advertiser") or ""),
                "source": str(tracking.get("source") or "direct"),
                "medium": str(tracking.get("medium") or "telegram"),
                "creative": str(tracking.get("creative") or "default"),
                "cost": 0,
                "status": str(campaign.get("status") or "active"),
                "attribution_window_days": 30,
                "unique_join_count": 0,
                "active_members": 0,
                "kind": "bot_deep_link",
            }
        )

    # Campaign budget is a campaign-level cost.  Split it across the active
    # tracking endpoints so link_both never double-counts spend.
    campaign_link_counts: dict[str, int] = defaultdict(int)
    for link in links:
        campaign_id = str(link.get("campaign_id") or "")
        if campaign_id:
            campaign_link_counts[campaign_id] += 1
    for link in links:
        campaign_id = str(link.get("campaign_id") or "")
        campaign = campaigns.get(campaign_id)
        if not campaign:
            continue
        tracking = campaign.get("tracking", {}) if isinstance(campaign.get("tracking"), dict) else {}
        budget = max(0, _integer(tracking.get("budget")))
        endpoint_count = max(1, campaign_link_counts.get(campaign_id, 1))
        link["cost"] = round(budget / endpoint_count)

    by_id = {str(row["id"]): row for row in links}
    touches: dict[str, list[tuple[datetime, str]]] = defaultdict(list)
    for event in db.get("public_channel_link_events", []):
        if not isinstance(event, dict) or event.get("type") not in {"join", "rejoin"}:
            continue
        user_id = str(event.get("user_id") or "")
        link_id = str(event.get("link_id") or "")
        touched_at = parse_dt(event.get("created_at"))
        if not user_id.isdigit() or link_id not in by_id or touched_at is None:
            continue
        touches[user_id].append((touched_at, link_id))
    for event in db.get("campaign_events", []):
        if not isinstance(event, dict) or str(event.get("type") or "") != "bot_start":
            continue
        user_id = str(event.get("user_id") or "")
        campaign_id = str(event.get("campaign_id") or "")
        link_id = f"bot:{campaign_id}"
        touched_at = parse_dt(event.get("created_at"))
        if not user_id.isdigit() or link_id not in by_id or touched_at is None:
            continue
        touches[user_id].append((touched_at, link_id))
    for rows in touches.values():
        rows.sort(key=lambda item: item[0])
    for link_id, link in by_id.items():
        if str(link.get("kind") or "") != "bot_deep_link":
            continue
        members = {uid for uid, rows in touches.items() if any(item_id == link_id for _, item_id in rows)}
        link["unique_join_count"] = len(members)
        link["active_members"] = len(members & {str(uid) for uid in db.get("users", {})})

    attributed_orders: dict[str, int] = defaultdict(int)
    attributed_revenue: dict[str, int] = defaultdict(int)
    assisted_orders: dict[str, int] = defaultdict(int)
    for order in db.get("vip_orders", []):
        if not isinstance(order, dict) or str(order.get("status") or "") != "approved":
            continue
        user_id = str(order.get("user_id") or "")
        order_time = parse_dt(order.get("approved_at") or order.get("created_at"))
        if order_time is None:
            continue
        eligible: list[tuple[datetime, str]] = []
        for touched_at, link_id in touches.get(user_id, []):
            window = max(1, min(365, _integer(by_id[link_id].get("attribution_window_days")) or 30))
            if touched_at <= order_time <= touched_at + timedelta(days=window):
                eligible.append((touched_at, link_id))
        if not eligible:
            continue
        selected = eligible[0] if model == "first_touch" else eligible[-1]
        selected_link = selected[1]
        attributed_orders[selected_link] += 1
        attributed_revenue[selected_link] += max(0, _integer(order.get("price")))
        for assisted_link in {link_id for _, link_id in eligible if link_id != selected_link}:
            assisted_orders[assisted_link] += 1

    enriched: list[dict[str, Any]] = []
    campaign_names = {
        campaign_id: str(value.get("name") or campaign_id)
        for campaign_id, value in campaigns.items()
    }
    for link in links:
        link_id = str(link["id"])
        campaign_id = str(link.get("campaign_id") or "")
        enriched.append(
            _metric_row(
                {
                    **link,
                    "campaign_name": campaign_names.get(campaign_id, campaign_id or "بدون کمپین"),
                    "approved_orders": attributed_orders[link_id],
                    "revenue": attributed_revenue[link_id],
                    "assisted_orders": assisted_orders[link_id],
                }
            )
        )
    enriched.sort(
        key=lambda item: (item["revenue"], item["approved_orders"], item["unique_joins"]),
        reverse=True,
    )

    totals = _metric_row(
        {
            "links": len(enriched),
            "unique_join_count": sum(_integer(row.get("unique_join_count")) for row in enriched),
            "active_members": sum(_integer(row.get("active_members")) for row in enriched),
            "cost": sum(_integer(row.get("cost")) for row in enriched),
            "approved_orders": sum(_integer(row.get("approved_orders")) for row in enriched),
            "revenue": sum(_integer(row.get("revenue")) for row in enriched),
        }
    )
    return {
        "attribution_model": model,
        "totals": totals,
        "links": enriched[:100],
        "advertisers": _group_rows(enriched, "advertiser")[:50],
        "sources": _group_rows(enriched, "source")[:50],
        "campaigns": _group_rows(enriched, "campaign_name")[:50],
        "generated_from": {
            "links": len(links),
            "events": sum(len(rows) for rows in touches.values()),
            "approved_orders": sum(attributed_orders.values()),
        },
    }
