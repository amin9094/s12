from __future__ import annotations

import copy
import hashlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any, Iterable

from core.utils import parse_dt, utc_iso
from modules.automation_v2 import process_automation_event

_MAX_EVENTS_PER_COMMIT = 500


def _rows(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, dict):
        return [row for row in value.values() if isinstance(row, dict)]
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    return []


def _row_id(row: dict[str, Any], index: int = 0) -> str:
    for key in ("id", "user_id", "order_id", "ticket_id", "signal_id", "campaign_id", "code", "event_id"):
        value = str(row.get(key) or "").strip()
        if value:
            return value
    payload = json.dumps(row, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(f"{index}:{payload}".encode()).hexdigest()[:24]


def _index(value: Any) -> dict[str, dict[str, Any]]:
    return {_row_id(row, index): row for index, row in enumerate(_rows(value))}


def _event_id(trigger: str, entity_id: str, row: dict[str, Any], suffix: str = "") -> str:
    version = str(row.get("updated_at") or row.get("created_at") or row.get("status") or "")
    raw = f"{trigger}:{entity_id}:{version}:{suffix}"
    return hashlib.sha256(raw.encode()).hexdigest()[:40]


def _event(trigger: str, entity_id: str, row: dict[str, Any], *, suffix: str = "", **extra: Any) -> tuple[str, dict[str, Any]]:
    payload = {
        "event_id": _event_id(trigger, entity_id, row, suffix),
        "entity_id": entity_id,
        "trigger": trigger,
        "occurred_at": str(row.get("updated_at") or row.get("created_at") or utc_iso()),
        **copy.deepcopy(row),
        **extra,
    }
    return trigger, payload


def _new_rows(before: Any, after: Any) -> Iterable[tuple[str, dict[str, Any]]]:
    old = _index(before)
    for key, row in _index(after).items():
        if key not in old:
            yield key, row


def _changed_rows(before: Any, after: Any) -> Iterable[tuple[str, dict[str, Any], dict[str, Any]]]:
    old = _index(before)
    for key, row in _index(after).items():
        previous = old.get(key)
        if isinstance(previous, dict) and previous != row:
            yield key, previous, row


def derive_automation_events(
    before: dict[str, Any],
    after: dict[str, Any],
    *,
    active_triggers: set[str] | None = None,
) -> list[tuple[str, dict[str, Any]]]:
    """Derive only events that currently have an enabled consumer.

    Comparing large compatibility sections is expensive.  Trigger-aware
    derivation avoids scanning payment, signal, CRM and campaign histories when
    no enabled rule subscribes to those domains.
    """
    wanted = {str(item).strip().lower() for item in (active_triggers or set()) if str(item).strip()}

    def wants(*names: str) -> bool:
        return not wanted or bool(wanted.intersection(names))

    events: list[tuple[str, dict[str, Any]]] = []
    diff_cache: dict[str, tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, dict[str, Any], dict[str, Any]]]]] = {}

    def _section_diff(section: str) -> tuple[list[tuple[str, dict[str, Any]]], list[tuple[str, dict[str, Any], dict[str, Any]]]]:
        cached = diff_cache.get(section)
        if cached is not None:
            return cached
        old_value, new_value = before.get(section), after.get(section)
        if old_value is new_value or old_value == new_value:
            result = ([], [])
        else:
            old, new = _index(old_value), _index(new_value)
            added = [(key, row) for key, row in new.items() if key not in old]
            changed = [(key, old[key], row) for key, row in new.items() if key in old and old[key] != row]
            result = (added, changed)
        diff_cache[section] = result
        return result

    def _new(section: str) -> list[tuple[str, dict[str, Any]]]:
        return _section_diff(section)[0]

    def _changed(section: str) -> list[tuple[str, dict[str, Any], dict[str, Any]]]:
        return _section_diff(section)[1]

    if wants("user_registered"):
        for user_id, row in _new("users"):
            events.append(_event("user_registered", user_id, row, user_id=user_id))

    if wants("payment_created", "payment_approved", "payment_rejected"):
        if wants("payment_created"):
            for order_id, row in _new("vip_orders"):
                events.append(_event("payment_created", order_id, row, order_id=order_id, user_id=str(row.get("user_id") or "")))
        if wants("payment_approved", "payment_rejected"):
            for order_id, previous, row in _changed("vip_orders"):
                old_status = str(previous.get("status") or "").lower()
                new_status = str(row.get("status") or "").lower()
                trigger = "payment_approved" if new_status == "approved" else "payment_rejected" if new_status in {"rejected", "declined", "cancelled"} else ""
                if old_status != new_status and trigger and wants(trigger):
                    events.append(_event(trigger, order_id, row, suffix=new_status, order_id=order_id, user_id=str(row.get("user_id") or ""), previous_status=old_status))

    if wants("ticket_created", "ticket_closed", "ticket_waiting"):
        seen_ticket_events: set[tuple[str, str]] = set()
        for section in ("tickets", "support_tickets"):
            if wants("ticket_created"):
                for ticket_id, row in _new(section):
                    key = ("ticket_created", ticket_id)
                    if key not in seen_ticket_events:
                        events.append(_event("ticket_created", ticket_id, row, user_id=str(row.get("user_id") or ""), ticket_id=ticket_id, source_section=section))
                        seen_ticket_events.add(key)
            if wants("ticket_closed", "ticket_waiting"):
                for ticket_id, previous, row in _changed(section):
                    old_status = str(previous.get("status") or "").lower()
                    new_status = str(row.get("status") or "").lower()
                    old_waiting = str(previous.get("waiting_for") or "").lower()
                    new_waiting = str(row.get("waiting_for") or "").lower()
                    if wants("ticket_closed") and old_status != new_status and new_status in {"closed", "resolved"}:
                        key = ("ticket_closed", ticket_id)
                        if key not in seen_ticket_events:
                            events.append(_event("ticket_closed", ticket_id, row, suffix=new_status, user_id=str(row.get("user_id") or ""), ticket_id=ticket_id, previous_status=old_status))
                            seen_ticket_events.add(key)
                    elif wants("ticket_waiting") and old_waiting != new_waiting and new_waiting in {"admin", "support"}:
                        key = ("ticket_waiting", ticket_id)
                        if key not in seen_ticket_events:
                            events.append(_event("ticket_waiting", ticket_id, row, suffix=new_waiting, user_id=str(row.get("user_id") or ""), ticket_id=ticket_id))
                            seen_ticket_events.add(key)

    if wants("signal_created", "signal_published", "signal_tp", "signal_sl", "signal_closed"):
        if wants("signal_created"):
            for signal_id, row in _new("signals"):
                events.append(_event("signal_created", signal_id, row, signal_id=signal_id))
        if wants("signal_published", "signal_tp", "signal_sl", "signal_closed"):
            for signal_id, previous, row in _changed("signals"):
                old_status = str(previous.get("status") or "").lower()
                new_status = str(row.get("status") or "").lower()
                if old_status == new_status:
                    continue
                if new_status in {"published", "active", "open"}:
                    trigger = "signal_published"
                elif new_status.startswith("tp") or new_status in {"target", "target_hit", "won"}:
                    trigger = "signal_tp"
                elif new_status in {"sl", "stop", "stop_loss", "lost"}:
                    trigger = "signal_sl"
                elif new_status in {"closed", "cancelled", "expired", "breakeven", "be"}:
                    trigger = "signal_closed"
                else:
                    continue
                if wants(trigger):
                    events.append(_event(trigger, signal_id, row, suffix=new_status, signal_id=signal_id, previous_status=old_status))

    if wants("campaign_created", "campaign_published"):
        if wants("campaign_created"):
            for campaign_id, row in _new("marketing_campaigns"):
                events.append(_event("campaign_created", campaign_id, row, campaign_id=campaign_id))
        if wants("campaign_published"):
            for campaign_id, previous, row in _changed("marketing_campaigns"):
                old_status = str(previous.get("status") or previous.get("ai_ad_status") or "").lower()
                new_status = str(row.get("status") or row.get("ai_ad_status") or "").lower()
                if old_status != new_status and new_status in {"published", "sent", "completed"}:
                    events.append(_event("campaign_published", campaign_id, row, suffix=new_status, campaign_id=campaign_id, previous_status=old_status))

    if wants("link_clicked"):
        for link_event_id, row in _new("public_channel_link_events"):
            event_type = str(row.get("type") or "").lower()
            if event_type in {"click", "clicked", "open", "join", "rejoin"}:
                events.append(_event("link_clicked", link_event_id, row, suffix=event_type, user_id=str(row.get("user_id") or ""), link_id=str(row.get("link_id") or "")))

    if wants("contest_started", "contest_ended"):
        if wants("contest_started"):
            for contest_id, row in _new("contests"):
                if str(row.get("status") or "active").lower() in {"active", "started", "open"}:
                    events.append(_event("contest_started", contest_id, row, contest_id=contest_id))
        if wants("contest_ended"):
            for contest_id, previous, row in _changed("contests"):
                old_status = str(previous.get("status") or "").lower()
                new_status = str(row.get("status") or "").lower()
                if old_status != new_status and new_status in {"closed", "ended", "completed", "settled"}:
                    events.append(_event("contest_ended", contest_id, row, suffix=new_status, contest_id=contest_id))

    if wants("mission_completed"):
        for mission_id, previous, row in _changed("user_missions"):
            if not bool(previous.get("completed")) and bool(row.get("completed")):
                events.append(_event("mission_completed", mission_id, row, user_id=str(row.get("user_id") or ""), mission_id=mission_id))

    if wants("system_error"):
        for incident_id, row in _new("incidents"):
            events.append(_event("system_error", incident_id, row, incident_id=incident_id))

    if wants("provider_down"):
        for provider_id, previous, row in _changed("provider_health"):
            old_status = str(previous.get("status") or "").lower()
            new_status = str(row.get("status") or "").lower()
            if old_status != new_status and new_status in {"down", "offline", "failed", "unavailable", "degraded"}:
                events.append(_event("provider_down", provider_id, row, suffix=new_status, provider=provider_id, previous_status=old_status))

    if wants("mt5_risk"):
        for alert_id, row in _new("mt5_risk_alerts"):
            events.append(_event("mt5_risk", alert_id, row, user_id=str(row.get("user_id") or ""), alert_id=alert_id))

    return events[:_MAX_EVENTS_PER_COMMIT]


def dispatch_automation_events_inplace(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    rules = after.get("automation_rules_v2")
    if not isinstance(rules, dict) or not any(isinstance(row, dict) and row.get("enabled") for row in rules.values()):
        return {"events": 0, "runs": 0}
    active_triggers = {
        str(row.get("trigger") or "").strip().lower()
        for row in rules.values()
        if isinstance(row, dict) and row.get("enabled")
    }
    events = derive_automation_events(before, after, active_triggers=active_triggers)
    run_count = 0
    errors: list[dict[str, Any]] = []
    for trigger, payload in events:
        try:
            result = process_automation_event(after, trigger, payload, actor_id="event_bus")
            run_count += int(result.get("count", 0) or 0)
        except Exception as exc:
            errors.append({"trigger": trigger, "event_id": payload.get("event_id"), "error": f"{exc.__class__.__name__}:{str(exc)[:300]}"})
    if events or errors:
        after.setdefault("automation_v2_event_log", []).append({
            "id": hashlib.sha256(f"{utc_iso()}:{len(events)}:{run_count}".encode()).hexdigest()[:20],
            "event_count": len(events), "run_count": run_count, "errors": errors[:50], "created_at": utc_iso(),
        })
        after["automation_v2_event_log"] = after["automation_v2_event_log"][-5000:]
    return {"events": len(events), "runs": run_count, "errors": errors}


def collect_scheduled_automation_events(
    db: dict[str, Any], *, now: datetime | None = None, active_triggers: set[str] | None = None,
) -> list[tuple[str, dict[str, Any]]]:
    """Generate periodic expiry and schedule events without re-emitting them.

    The event IDs use the due date, making retries idempotent while allowing a
    new event on the next day. This function mutates only a tiny watermark map.
    """
    current = (now or datetime.now(UTC)).astimezone(UTC)
    wanted = {str(item).strip().lower() for item in (active_triggers or set()) if str(item).strip()}
    if wanted and not wanted.intersection({"vip_expiring", "vip_expired"}):
        return []
    day = current.date().isoformat()
    watermark = db.setdefault("automation_v2_schedule_watermarks", {})
    events: list[tuple[str, dict[str, Any]]] = []
    for user_id, row in _index(db.get("vip_users")).items():
        expires = parse_dt(row.get("expires_at") or row.get("expiry") or row.get("end_at"))
        if not expires:
            continue
        days_left = (expires.date() - current.date()).days
        if days_left <= 3:
            trigger = "vip_expired" if days_left < 0 else "vip_expiring"
            if wanted and trigger not in wanted:
                continue
            key = f"{trigger}:{user_id}:{day}"
            if watermark.get(key):
                continue
            payload = {
                "event_id": key, "user_id": user_id, "entity_id": user_id,
                "days_left": days_left, "expires_at": utc_iso(expires), "occurred_at": utc_iso(current),
            }
            events.append((trigger, payload))
            watermark[key] = utc_iso(current)
    # Keep only recent watermarks.
    cutoff = current - timedelta(days=45)
    for key, value in list(watermark.items()):
        dt = parse_dt(value)
        if dt and dt < cutoff:
            watermark.pop(key, None)
    return events
