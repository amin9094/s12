from __future__ import annotations

import csv
import io
import re
from html.parser import HTMLParser
from typing import Any

from modules.portfolio import add_journal_entry, update_journal_result


class _TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell: list[str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "tr":
            self._row = []
        elif tag.lower() in {"td", "th"} and self._row is not None:
            self._cell = []

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            self._cell.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(" ".join("".join(self._cell).split()))
            self._cell = None
        elif tag.lower() == "tr" and self._row is not None:
            if any(value.strip() for value in self._row):
                self.rows.append(self._row)
            self._row = None


def _clean_header(value: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "_", str(value or "").strip().lower()).strip("_")
    aliases = {
        "ticket": "ticket", "deal": "ticket", "order": "ticket",
        "open_time": "open_time", "time": "open_time", "open": "open_time",
        "close_time": "close_time", "close": "close_time",
        "type": "type", "direction": "type",
        "size": "volume", "volume": "volume", "lots": "volume",
        "item": "symbol", "symbol": "symbol", "instrument": "symbol",
        "price": "open_price", "open_price": "open_price",
        "close_price": "close_price", "price_2": "close_price",
        "s_l": "stop", "sl": "stop", "stop_loss": "stop",
        "t_p": "take_profit", "tp": "take_profit", "take_profit": "take_profit",
        "commission": "commission", "swap": "swap", "profit": "profit",
        "comment": "comment",
    }
    return aliases.get(value, value)


def _number(value: Any, default: float | None = None) -> float | None:
    clean = str(value or "").strip().replace(" ", "").replace(",", "")
    clean = clean.replace("−", "-")
    if not clean:
        return default
    try:
        return float(clean)
    except (TypeError, ValueError):
        return default


def _rows_from_csv(content: str) -> list[dict[str, str]]:
    sample = content[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.reader(io.StringIO(content), dialect)
    rows = [row for row in reader if any(str(cell).strip() for cell in row)]
    if not rows:
        return []
    headers = [_clean_header(value) for value in rows[0]]
    # MetaTrader sometimes repeats "Price" twice. Preserve the second as close price.
    seen: dict[str, int] = {}
    normalized: list[str] = []
    for header in headers:
        seen[header] = seen.get(header, 0) + 1
        normalized.append("close_price" if header == "open_price" and seen[header] == 2 else header)
    return [dict(zip(normalized, row, strict=False)) for row in rows[1:] if len(row) >= 4]


def _rows_from_html(content: str) -> list[dict[str, str]]:
    parser = _TableParser()
    parser.feed(content)
    rows = parser.rows
    header_index = next((i for i, row in enumerate(rows) if any(_clean_header(v) in {"ticket", "open_time", "symbol", "profit"} for v in row)), None)
    if header_index is None:
        return []
    headers = [_clean_header(value) for value in rows[header_index]]
    seen: dict[str, int] = {}
    normalized: list[str] = []
    for header in headers:
        seen[header] = seen.get(header, 0) + 1
        normalized.append("close_price" if header == "open_price" and seen[header] == 2 else header)
    return [dict(zip(normalized, row, strict=False)) for row in rows[header_index + 1 :] if len(row) >= 4]


def parse_broker_statement(content: str, *, filename: str = "") -> list[dict[str, Any]]:
    text = str(content or "").lstrip("\ufeff")
    is_html = filename.lower().endswith(('.html', '.htm')) or "<table" in text.lower()
    raw_rows = _rows_from_html(text) if is_html else _rows_from_csv(text)
    output: list[dict[str, Any]] = []
    for row in raw_rows:
        symbol = str(row.get("symbol") or "").strip().upper().replace("/", "")
        trade_type = str(row.get("type") or "").strip().lower()
        if not symbol or trade_type in {"balance", "credit", "deposit", "withdrawal"}:
            continue
        side = "BUY" if any(token in trade_type for token in ("buy", "long")) else "SELL" if any(token in trade_type for token in ("sell", "short")) else ""
        if not side:
            continue
        output.append({
            "external_id": str(row.get("ticket") or "").strip(),
            "symbol": symbol,
            "side": side,
            "opened_at": str(row.get("open_time") or "").strip(),
            "closed_at": str(row.get("close_time") or "").strip(),
            "entry_price": _number(row.get("open_price")),
            "exit_price": _number(row.get("close_price")),
            "volume": _number(row.get("volume")),
            "actual_stop": _number(row.get("stop")),
            "take_profit": _number(row.get("take_profit")),
            "commission": _number(row.get("commission"), 0.0) or 0.0,
            "swap": _number(row.get("swap"), 0.0) or 0.0,
            "profit": _number(row.get("profit")),
            "comment": str(row.get("comment") or "").strip(),
        })
    return output


def import_broker_statement(
    db: dict[str, Any], user_id: int | str, content: str, *, filename: str = "statement.csv", broker: str = "MT5", account_id: int | str | None = None
) -> dict[str, Any]:
    rows = parse_broker_statement(content, filename=filename)
    existing_ids = {
        str(row.get("external_id") or "")
        for row in db.setdefault("trade_journal", {}).setdefault(str(user_id), [])
        if isinstance(row, dict) and row.get("source") == "broker_import"
    }
    imported = 0
    skipped = 0
    errors: list[dict[str, Any]] = []
    for index, trade in enumerate(rows, start=1):
        external_id = str(trade.get("external_id") or "")
        if external_id and external_id in existing_ids:
            skipped += 1
            continue
        try:
            entry = add_journal_entry(
                db, user_id,
                symbol=trade["symbol"], side=trade["side"], entry_price=trade.get("entry_price"),
                volume=trade.get("volume"), actual_stop=trade.get("actual_stop"), account_id=account_id,
                note=trade.get("comment") or f"Imported from {broker}", source="broker_import",
                external_id=external_id, broker=broker, opened_at=trade.get("opened_at") or None,
            )
            if trade.get("closed_at") or trade.get("profit") is not None:
                update_journal_result(
                    db, user_id, entry["id"], pnl_percent=0.0, exit_price=trade.get("exit_price"),
                    pnl_amount=trade.get("profit"), commission=float(trade.get("commission") or 0),
                    swap=float(trade.get("swap") or 0), closed_at=trade.get("closed_at") or None,
                )
            imported += 1
            if external_id:
                existing_ids.add(external_id)
        except (TypeError, ValueError) as exc:
            errors.append({"row": index, "ticket": external_id, "error": str(exc)})
    return {"imported": imported, "skipped": skipped, "parsed": len(rows), "errors": errors[:100], "broker": broker}
