"""Independent public PO3/base-zero Goldbach price-grid confluence.

Not the protected fxdmn script. No AMD/GB-time/AWR reproduction is claimed.
GB labels named FVG/OB are grid labels, never detections of a real gap/block.
"""
from dataclasses import dataclass,replace
from decimal import Decimal as D,ROUND_FLOOR
from repositories.v2.common import content_hash

LEVELS=(('-0.111','Ext'),('0','Low'),('.03','RB'),('.11','OB'),('.17','FVG'),
        ('.29','LV'),('.41','BR'),('.47','MB'),('.5','EQ'),('.53','MB'),
        ('.59','BR'),('.71','LV'),('.83','FVG'),('.89','OB'),('.97','RB'),('1','High'),('1.111','Ext'))
PO3_VALUES=tuple(3**i for i in range(0,13))


@dataclass(frozen=True)
class GoldbachSettings:
    enabled: bool=True
    po3: int=9
    shift: D=D(0)
    price_unit: D | None=None
    scan_adjacent: bool=True
    shift_radius: int=1
    half_steps: bool=True

    def validate(self):
        if type(self.enabled) is not bool or type(self.scan_adjacent) is not bool or type(self.po3) is not int or self.po3 not in PO3_VALUES:
            raise ValueError('GOLDBACH_PO3_INVALID')
        if not self.shift.is_finite() or abs(self.shift)>10 or self.shift%D('.5'):
            raise ValueError('GOLDBACH_SHIFT_INVALID')
        if self.price_unit is not None and (not self.price_unit.is_finite() or self.price_unit<=0):
            raise ValueError('GOLDBACH_PRICE_UNIT_INVALID')
        if type(self.shift_radius) is not int or not 0<=self.shift_radius<=10 or type(self.half_steps) is not bool:
            raise ValueError('GOLDBACH_SCAN_RANGE_INVALID')


def evaluate(context,plan):
    from modules.strategies.common import indicators
    config=getattr(context,'goldbach_settings',GoldbachSettings());config.validate()
    result={'kind':'GOLDBACH_PO3_COMPLEMENT','implementation':'INDEPENDENT_BASE_ZERO_SHIFT_FAMILY_V2',
            'protected_script_replica':False,'required_for_entry':False,'entry_changed':False,
            'stop_changed':False,'targets_changed':False,'is_win_probability':False,
            'confirmed':False,'state':'DISABLED' if not config.enabled else 'NO_CONFLUENCE',
            'available_ms':context.cutoff_ms,'po3':config.po3,'shift':str(config.shift),
            'range_locked_at_proposal':True,'gb_time_used':False,'awr_autoselection_used':False}
    if not config.enabled:return result
    bars=context.closed
    if not bars:return {**result,'state':'NO_CLOSED_REFERENCE'}
    # Forex uses a documented pip unit. Other products use an explicit price
    # unit (default one quote-price unit), never a guessed broker execution grid.
    unit=config.price_unit or context.pip_size or D(1)
    size=D(config.po3)*unit;reference=bars[-1].close
    low=(reference/size).to_integral_value(rounding=ROUND_FLOOR)*size+config.shift*size
    high=low+size
    atr=indicators(bars)['atr'];entry=D(plan['entry'])
    cap=size*D('.01');tolerance=min(max(context.tick_size*2,context.spread*2,atr*D('.1')),cap)
    # A bounded, prospectively configured family, never a shift fitted to a
    # winning trade. Half-range neighbours reflect the explicit half setting.
    step=2 if config.half_steps else 1
    offsets=tuple(D(i)/step for i in range(-config.shift_radius*step,config.shift_radius*step+1)) if config.scan_adjacent else (D(0),)
    ranges=[{'shift':str(config.shift+offset),'low':str(low+offset*size),
             'high':str(high+offset*size)} for offset in offsets]
    grid=[{'ratio':ratio,'label':label,'price':str(D(r['low'])+D(ratio)*size),
           'shift':r['shift'],'range_low':r['low'],'range_high':r['high'],
           'is_actual_fvg_or_ob':False,
           'is_outer_boundary':D(ratio)<=D('.03') or D(ratio)>=D('.97')} for r in ranges for ratio,label in LEVELS
          if D(r['low'])+D(ratio)*size>0]
    result.update(price_unit=str(unit),unit_basis='EXPLICIT' if config.price_unit else 'FOREX_PIP' if context.pip_size else 'QUOTE_PRICE_UNIT',
                  range_low=str(low),range_high=str(high),reference_price=str(reference),
                  reference_bar_end_ms=bars[-1].end_ms,
                  levels=[level for level in grid if D(level['shift'])==config.shift],tolerance=str(tolerance),
                  ranges=ranges,scan_adjacent=config.scan_adjacent,
                  shift_radius=config.shift_radius,half_steps=config.half_steps,
                  searched_shift_offsets=[str(x) for x in offsets],
                  shift_selection='FIXED_BEFORE_EVALUATION_NOT_OUTCOME_FITTED')
    if context.tick_size*2>cap or context.spread*2>cap:
        return {**result,'state':'INSUFFICIENT_GRID_RESOLUTION'}
    # An excessively dense grid cannot manufacture a strong confirmation.
    if size<atr:return {**result,'state':'RANGE_SMALLER_THAN_ATR'}
    candidates=[level for level in grid if abs(D(level['price'])-entry)<=tolerance]
    matches=[]
    for level in candidates:
        ratio=D(level['ratio'])
        support=ratio<=D('.11');resistance=ratio>=D('.89')
        approach = reference > entry if plan['direction']=='BUY' else reference < entry
        aligned=approach and ((plan['direction']=='BUY' and support) or (plan['direction']=='SELL' and resistance))
        matches.append({**level,'distance_to_entry':str(abs(D(level['price'])-entry)),
                        'role':'SUPPORT' if support else 'RESISTANCE' if resistance else 'INTERNAL_GRID',
                        'direction_aligned':aligned})
    matches.sort(key=lambda x:(not x['direction_aligned'],not x['is_outer_boundary'],D(x['distance_to_entry'])))
    result.update(matches=matches,confirmed=any(x['direction_aligned'] for x in matches),
                  outer_boundary_confirmed=any(x['direction_aligned'] and x['is_outer_boundary'] for x in matches))
    if result['confirmed']:result['state']='ALIGNED_SUPPORT_RESISTANCE'
    elif matches:result['state']='GRID_NEAR_ENTRY_NOT_DIRECTIONAL_SUPPORT'
    return result


def priority_confluence(plan, fibonacci, goldbach):
    """A real entry zone AND minor-wave golden AND directional GB at one price.

    No score is a probability. Separate hits at distant edges of a large gap
    do not qualify, nor do grid labels named OB/FVG create real structures.
    """
    result={'priority':'NORMAL','confirmed':False,'is_win_probability':False,
            'required_for_entry':False,'matches':[],'entry_changed':False,
            'basis':'ENTRY_ZONE_MINOR_GOLDEN_DIRECTIONAL_GB_COMMON_INTERSECTION'}
    kinds={fact.get('kind') for fact in plan.get('evidence',())}
    if not ((plan.get('engine')=='sweep_fvg' and 'fvg_third_close' in kinds)
            or (plan.get('engine')=='order_block' and 'ob_full_candle' in kinds)
            or (plan.get('engine')=='indicators' and 'all_directional_indicators' in kinds)
            or (plan.get('engine')=='fibonacci_pullback' and 'experimental_pullback_levels' in kinds)):
        return result
    if not goldbach.get('confirmed'):
        return result
    tolerance=D(goldbach['tolerance']);entry=D(plan['entry'])
    low,high=D(plan['zone_low']),D(plan['zone_high'])
    for wave in (fibonacci or {}).get('confirmations',()):
        if wave.get('kind')!='OTHER_MINOR_WAVE_GOLDEN_OVERLAP':
            continue
        for level in goldbach.get('matches',()):
            if not level.get('direction_aligned'):
                continue
            a=max(low,D(wave['golden_low']),entry-tolerance,D(level['price'])-tolerance)
            b=min(high,D(wave['golden_high']),entry+tolerance,D(level['price'])+tolerance)
            if a<=b:
                result['matches'].append({'overlap_low':str(a),'overlap_high':str(b),
                    'golden_low':wave['golden_low'],'golden_high':wave['golden_high'],
                    'anchor_source_ids':wave.get('anchor_source_ids',[]),
                    'goldbach_price':level['price'],'goldbach_ratio':level['ratio'],
                    'dr_shift':level.get('shift',goldbach.get('shift','0')),
                    'role':level['role']})
    if result['matches']:
        result.update(priority='HIGH',confirmed=True,label_fa='هم‌پوشانی ویژهٔ گلدن‌زون و PO3 مستقل')
    return result


def attach(context,row):
    """Attach before locking the plan hash; never create a plan from a grid."""
    plan=row.get('plan') or row.get('draft_plan')
    if not plan:return row
    detail=evaluate(context,plan);row['goldbach_confirmation']=detail
    kinds={f.get('kind') for f in plan.get('evidence',())}
    detail['structural_confluence']=bool(detail.get('confirmed') and kinds.intersection({'fvg_third_close','ob_full_candle'}))
    detail['outer_structural_confluence']=bool(detail['structural_confluence'] and detail.get('outer_boundary_confirmed'))
    fact={'kind':'shared_goldbach_confirmation','available_ms':context.cutoff_ms,'detail':detail}
    priority=priority_confluence(plan,row.get('fibonacci_confirmation'),detail)
    row['confluence_priority']=priority
    priority_fact={'kind':'entry_confluence_priority','available_ms':context.cutoff_ms,'detail':priority}
    if row.get('plan'):
        from modules.setup_lifecycle import SetupPlan
        locked=SetupPlan.from_dict(plan)
        row['plan']=replace(locked,evidence=(*locked.evidence,fact,priority_fact)).as_dict()
    else:
        row['draft_plan']={**plan,'evidence':[*plan['evidence'],fact,priority_fact]}
        row['draft_hash']=content_hash(row['draft_plan'])
    return row
