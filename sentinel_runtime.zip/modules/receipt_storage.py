from __future__ import annotations

import hashlib
import logging
import os
import secrets
import shutil
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from config import SETTINGS

logger = logging.getLogger(__name__)


class ReceiptStorageUnavailable(RuntimeError):
    """Raised when receipt storage is unavailable rather than merely missing."""


def _s3_error_code(exc: Exception) -> str:
    response = getattr(exc, "response", None)
    if isinstance(response, dict):
        error = response.get("Error")
        if isinstance(error, dict) and error.get("Code"):
            return str(error.get("Code"))
        metadata = response.get("ResponseMetadata")
        if isinstance(metadata, dict) and metadata.get("HTTPStatusCode"):
            return str(metadata.get("HTTPStatusCode"))
    return exc.__class__.__name__


def _s3_not_found(exc: Exception) -> bool:
    return _s3_error_code(exc).lower() in {"404", "nosuchkey", "notfound", "nosuchobject"}


def _raise_storage_unavailable(operation: str, exc: Exception) -> None:
    code = _s3_error_code(exc)
    logger.error("receipt S3 operation failed operation=%s code=%s", operation, code)
    raise ReceiptStorageUnavailable(f"RECEIPT_STORAGE_UNAVAILABLE:{operation}:{code}") from exc


def _local_root() -> Path:
    configured = str(os.getenv("RECEIPT_STORAGE_DIR") or "").strip()
    if configured:
        root = Path(configured)
    else:
        mount = str(
            os.getenv("PERSISTENT_DATA_DIR")
            or os.getenv("RAILWAY_VOLUME_MOUNT_PATH")
            or os.getenv("VOLUME_MOUNT_PATH")
            or ""
        ).strip()
        root = Path(mount) / "payment_receipts" if mount else SETTINGS.db_file.parent / "payment_receipts"
    root = root.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _s3_settings() -> dict[str, str]:
    return {
        "bucket": str(os.getenv("RECEIPT_S3_BUCKET") or "").strip(),
        "endpoint": str(os.getenv("RECEIPT_S3_ENDPOINT") or "").strip(),
        "region": str(os.getenv("RECEIPT_S3_REGION") or "auto").strip() or "auto",
        "access_key": str(os.getenv("RECEIPT_S3_ACCESS_KEY_ID") or os.getenv("AWS_ACCESS_KEY_ID") or "").strip(),
        "secret_key": str(os.getenv("RECEIPT_S3_SECRET_ACCESS_KEY") or os.getenv("AWS_SECRET_ACCESS_KEY") or "").strip(),
        "prefix": str(os.getenv("RECEIPT_S3_PREFIX") or "sentinel/receipts").strip("/"),
    }


def _s3_client(settings: dict[str, str]):
    try:
        import boto3
    except ImportError as exc:  # pragma: no cover - only used in S3 deployments
        raise RuntimeError("boto3 is required when RECEIPT_S3_BUCKET is configured") from exc
    kwargs: dict[str, Any] = {
        "service_name": "s3",
        "region_name": settings["region"],
        "aws_access_key_id": settings["access_key"] or None,
        "aws_secret_access_key": settings["secret_key"] or None,
    }
    if settings["endpoint"]:
        kwargs["endpoint_url"] = settings["endpoint"]
    from botocore.config import Config
    kwargs["config"] = Config(
        connect_timeout=max(1, int(os.getenv("RECEIPT_S3_CONNECT_TIMEOUT_SECONDS", "3") or 3)),
        read_timeout=max(2, int(os.getenv("RECEIPT_S3_READ_TIMEOUT_SECONDS", "10") or 10)),
        retries={"max_attempts": max(1, int(os.getenv("RECEIPT_S3_MAX_ATTEMPTS", "3") or 3)), "mode": "standard"},
    )
    endpoint = str(settings.get("endpoint") or "")
    if endpoint:
        parsed = urlsplit(endpoint)
        production = str(os.getenv("SENTINEL_ENV") or os.getenv("ENVIRONMENT") or os.getenv("RAILWAY_ENVIRONMENT") or "").lower() in {"production", "prod"} or bool(os.getenv("RAILWAY_PROJECT_ID"))
        if production and parsed.scheme != "https" and (parsed.hostname or "").lower() not in {"localhost", "127.0.0.1", "::1", "minio"}:
            raise RuntimeError("RECEIPT_S3_ENDPOINT must use HTTPS in production")
    return boto3.client(**kwargs)


def store_receipt_blob(payload: bytes, *, user_id: int | str, mime_type: str = "image/webp") -> dict[str, Any]:
    checksum = hashlib.sha256(payload).hexdigest()
    stamp = datetime.now(UTC)
    # Content-addressed keys make retried/concurrent uploads overwrite the same
    # object instead of leaking orphaned blobs before DB deduplication completes.
    leaf = f"{int(user_id)}-{checksum}.webp"
    settings = _s3_settings()
    if settings["bucket"]:
        key = "/".join(filter(None, (settings["prefix"], stamp.strftime("%Y/%m"), leaf)))
        extra: dict[str, Any] = {
            "ContentType": mime_type,
            "Metadata": {"sha256": checksum},
            "ACL": "private",
        }
        encryption = str(os.getenv("RECEIPT_S3_SERVER_SIDE_ENCRYPTION") or "AES256").strip()
        if encryption not in {"AES256", "aws:kms"}:
            raise RuntimeError("unsupported receipt S3 server-side encryption")
        extra["ServerSideEncryption"] = encryption
        kms_key = str(os.getenv("RECEIPT_S3_KMS_KEY_ID") or "").strip()
        if encryption == "aws:kms" and kms_key:
            extra["SSEKMSKeyId"] = kms_key
        _s3_client(settings).put_object(Bucket=settings["bucket"], Key=key, Body=payload, **extra)
        return {
            "storage_backend": "s3",
            "object_key": key,
            "bucket": settings["bucket"],
            "checksum": checksum,
            "path": "",
            "mime": mime_type,
            "size_bytes": len(payload),
        }

    root = _local_root()
    path = (root / stamp.strftime("%Y/%m") / leaf).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.relative_to(root)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(payload)
    temporary.replace(path)
    return {
        "storage_backend": "local",
        "object_key": str(path.relative_to(root)),
        "bucket": "",
        "checksum": checksum,
        "path": str(path),
        "mime": mime_type,
        "size_bytes": len(payload),
    }


def receipt_exists(record: dict[str, Any]) -> bool:
    backend = str(record.get("storage_backend") or ("local" if record.get("path") else ""))
    if backend == "s3":
        settings = _s3_settings()
        bucket = str(record.get("bucket") or settings["bucket"])
        key = str(record.get("object_key") or "")
        if not bucket or not key:
            return False
        try:
            _s3_client(settings).head_object(Bucket=bucket, Key=key)
            return True
        except Exception as exc:
            if _s3_not_found(exc):
                return False
            _raise_storage_unavailable("head_object", exc)
    raw = str(record.get("path") or "").strip()
    if raw:
        return Path(raw).is_file()
    key = str(record.get("object_key") or "").strip()
    if not key:
        return False
    try:
        path = (_local_root() / key).resolve()
        path.relative_to(_local_root())
    except (OSError, ValueError):
        return False
    return path.is_file()


def read_receipt_bytes(record: dict[str, Any]) -> bytes | None:
    backend = str(record.get("receipt_storage_backend") or record.get("storage_backend") or ("local" if record.get("receipt_path") or record.get("path") else ""))
    if backend == "s3":
        settings = _s3_settings()
        bucket = str(record.get("receipt_bucket") or record.get("bucket") or settings["bucket"])
        key = str(record.get("receipt_object_key") or record.get("object_key") or "")
        if not bucket or not key:
            return None
        try:
            response = _s3_client(settings).get_object(Bucket=bucket, Key=key)
            payload = response["Body"].read()
        except Exception as exc:
            if _s3_not_found(exc):
                return None
            _raise_storage_unavailable("get_object", exc)
    else:
        raw = str(record.get("receipt_path") or record.get("path") or "").strip()
        if raw:
            path = Path(raw).expanduser().resolve()
        else:
            key = str(record.get("receipt_object_key") or record.get("object_key") or "").strip()
            if not key:
                return None
            try:
                root = _local_root()
                path = (root / key).resolve()
                path.relative_to(root)
            except (OSError, ValueError):
                return None
        try:
            payload = path.read_bytes()
        except OSError:
            return None
    expected = str(record.get("receipt_checksum") or record.get("checksum") or "").strip()
    if expected and not secrets.compare_digest(hashlib.sha256(payload).hexdigest(), expected):
        return None
    return payload


def receipt_storage_status() -> dict[str, Any]:
    """Return a safe storage-health snapshot without exposing secrets or paths."""
    settings = _s3_settings()
    if settings["bucket"]:
        healthy = False
        detail = "configured"
        try:
            _s3_client(settings).head_bucket(Bucket=settings["bucket"])
            healthy = True
            detail = "reachable"
        except Exception as exc:  # pragma: no cover - external provider
            detail = exc.__class__.__name__
        return {
            "backend": "s3",
            "persistent": True,
            "healthy": healthy,
            "detail": detail,
            "bucket_configured": True,
        }
    root = _local_root()
    mount_configured = bool(
        os.getenv("RECEIPT_STORAGE_DIR")
        or os.getenv("PERSISTENT_DATA_DIR")
        or os.getenv("RAILWAY_VOLUME_MOUNT_PATH")
        or os.getenv("VOLUME_MOUNT_PATH")
    )
    writable = False
    try:
        probe = root / ".sentinel-write-probe"
        probe.write_bytes(b"ok")
        probe.unlink(missing_ok=True)
        writable = True
    except OSError:
        writable = False
    usage = shutil.disk_usage(root)
    minimum_free = max(64 * 1024 * 1024, int(os.getenv("RECEIPT_MIN_FREE_BYTES", str(256 * 1024 * 1024)) or 0))
    enough_space = usage.free >= minimum_free
    return {
        "backend": "local",
        "persistent": mount_configured,
        "healthy": writable and enough_space,
        "detail": "persistent_volume" if mount_configured else "ephemeral_filesystem",
        "bucket_configured": False,
        "free_bytes": int(usage.free),
        "minimum_free_bytes": minimum_free,
    }


def delete_receipt_blob(record: dict[str, Any]) -> bool:
    """Delete a stored receipt through the configured backend.

    Returns ``True`` when the object was deleted or was already absent. Secrets
    and absolute storage paths are never returned to callers.
    """
    backend = str(record.get("storage_backend") or ("local" if record.get("path") else ""))
    if backend == "s3":
        settings = _s3_settings()
        bucket = str(record.get("bucket") or settings["bucket"])
        key = str(record.get("object_key") or "")
        if not bucket or not key:
            return False
        try:
            _s3_client(settings).delete_object(Bucket=bucket, Key=key)
            return True
        except Exception as exc:  # pragma: no cover - external provider
            if _s3_not_found(exc):
                return True
            _raise_storage_unavailable("delete_object", exc)
    try:
        root = _local_root()
        raw = str(record.get("path") or "").strip()
        path = Path(raw).expanduser().resolve() if raw else (root / str(record.get("object_key") or "")).resolve()
        path.relative_to(root)
        path.unlink(missing_ok=True)
        return True
    except (OSError, ValueError):
        return False
