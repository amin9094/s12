from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.utils import parse_dt, utc_iso
from modules.admin_control_center import notification_allowed, notification_preferences
from modules.i18n import user_language
from modules.user_today import user_today_snapshot


def _clock_minutes(value: str, fallback: int = 9 * 60) -> int:
    try:
        hour_text, minute_text = str(value).split(":", 1)
        hour, minute = int(hour_text), int(minute_text)
        if 0 <= hour <= 23 and 0 <= minute <= 59:
            return hour * 60 + minute
    except (TypeError, ValueError):
        pass
    return fallback


def _local_now(pref: dict[str, Any], now: datetime) -> datetime:
    try:
        return now.astimezone(ZoneInfo(str(pref.get("timezone") or "Asia/Tehran")))
    except (ZoneInfoNotFoundError, ValueError):
        return now.astimezone(UTC)


def _delivery_root(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    return db.setdefault("notification_digest_delivery", {}).setdefault(str(int(user_id)), {})


def _claim_expired(row: dict[str, Any], now: datetime) -> bool:
    claim_until = parse_dt(row.get("claim_until"))
    return claim_until is None or claim_until <= now


def _period_key(kind: str, local_now: datetime) -> str:
    if kind == "weekly":
        year, week, _ = local_now.isocalendar()
        return f"{year}-W{week:02d}"
    return local_now.date().isoformat()


def _kind_due(db: dict[str, Any], user_id: str, kind: str, pref: dict[str, Any], now: datetime) -> tuple[bool, str]:
    local = _local_now(pref, now)
    target = _clock_minutes(str(pref.get("digest_time") or "09:00"))
    if local.hour * 60 + local.minute < target:
        return False, _period_key(kind, local)
    if kind == "weekly" and local.weekday() != int(pref.get("weekly_digest_day", 0) or 0):
        return False, _period_key(kind, local)
    key = "weekly_digest" if kind == "weekly" else "daily_digest"
    if not notification_allowed(db, user_id, key, now=now):
        return False, _period_key(kind, local)
    return True, _period_key(kind, local)


def claim_due_user_digests(
    db: dict[str, Any],
    *,
    now: datetime | None = None,
    limit: int = 100,
    claim_minutes: int = 10,
) -> list[dict[str, str]]:
    """Claim due digests durably so multiple workers never double-send them.

    A failed delivery releases its claim in ``mark_user_digest_delivery`` and can
    be retried by the next worker pass. A successful period key is never sent
    twice, even across process restarts.
    """
    current = (now or datetime.now(UTC)).astimezone(UTC)
    users = db.get("users", {})
    if not isinstance(users, dict):
        return []
    claims: list[dict[str, str]] = []
    for uid in sorted(users, key=lambda value: int(value) if str(value).isdigit() else str(value)):
        if len(claims) >= max(1, int(limit)):
            break
        try:
            normalized_uid = str(int(uid))
        except (TypeError, ValueError):
            continue
        pref = notification_preferences(db, normalized_uid)
        # Weekly replaces the daily digest on its configured weekday to avoid
        # sending two near-identical summaries at the same local time.
        candidates = ("weekly", "daily")
        weekly_claimed_or_sent = False
        for kind in candidates:
            due, period_key = _kind_due(db, normalized_uid, kind, pref, current)
            if kind == "daily" and weekly_claimed_or_sent:
                continue
            if not due:
                continue
            root = _delivery_root(db, normalized_uid)
            state = root.setdefault(kind, {})
            if str(state.get("last_sent_key") or "") == period_key:
                if kind == "weekly":
                    weekly_claimed_or_sent = True
                continue
            if not _claim_expired(state, current):
                if kind == "weekly" and str(state.get("claim_key") or "") == period_key:
                    weekly_claimed_or_sent = True
                continue
            state["claim_key"] = period_key
            state["claim_until"] = utc_iso(current + timedelta(minutes=max(1, int(claim_minutes))))
            state["claimed_at"] = utc_iso(current)
            state["attempts"] = int(state.get("attempts", 0) or 0) + 1
            state["status"] = "claimed"
            claims.append({"user_id": normalized_uid, "kind": kind, "period_key": period_key})
            if kind == "weekly":
                weekly_claimed_or_sent = True
            break
    return claims


def mark_user_digest_delivery(
    db: dict[str, Any],
    user_id: int | str,
    kind: str,
    period_key: str,
    *,
    success: bool,
    error: str = "",
    now: datetime | None = None,
) -> None:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    state = _delivery_root(db, user_id).setdefault(str(kind), {})
    # Ignore a stale worker result if another period has since been claimed.
    claim_key = str(state.get("claim_key") or "")
    if claim_key and claim_key != str(period_key):
        return
    state["claim_until"] = None
    state["claim_key"] = None
    if success:
        state["last_sent_key"] = str(period_key)
        state["last_sent_at"] = utc_iso(current)
        state["last_error"] = ""
        state["status"] = "sent"
    else:
        state["last_failed_at"] = utc_iso(current)
        state["last_error"] = str(error or "delivery_failed")[:500]
        state["status"] = "retry"


def _weekly_activity(db: dict[str, Any], user_id: int | str, now: datetime) -> dict[str, int | float]:
    uid = str(int(user_id))
    cutoff = now - timedelta(days=7)
    choices = db.get("user_signal_choices", {}).get(uid, {})
    if not isinstance(choices, dict):
        choices = {}
    recent_choices = []
    for row in choices.values():
        if not isinstance(row, dict):
            continue
        stamp = parse_dt(row.get("updated_at") or row.get("selected_at"))
        if stamp and stamp >= cutoff:
            recent_choices.append(row)

    journals = db.get("trade_journal", {}).get(uid, [])
    if not isinstance(journals, list):
        journals = []
    recent_journal = []
    for row in journals:
        if not isinstance(row, dict):
            continue
        stamp = parse_dt(row.get("closed_at") or row.get("updated_at") or row.get("created_at"))
        if stamp and stamp >= cutoff:
            recent_journal.append(row)
    closed = [row for row in recent_journal if str(row.get("status") or "").lower() in {"closed", "win", "loss", "breakeven"} or row.get("closed_at")]
    wins = sum(1 for row in closed if float(row.get("result_r", 0) or 0) > 0 or float(row.get("pnl_percent", 0) or 0) > 0)
    losses = sum(1 for row in closed if float(row.get("result_r", 0) or 0) < 0 or float(row.get("pnl_percent", 0) or 0) < 0)
    return {
        "signal_choices": len(recent_choices),
        "journal_touched": len(recent_journal),
        "journal_closed": len(closed),
        "journal_wins": wins,
        "journal_losses": losses,
    }


def build_user_digest(
    db: dict[str, Any],
    user_id: int | str,
    kind: str,
    *,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    language = user_language(db, user_id) or "fa"
    today = user_today_snapshot(db, user_id, now=current)
    weekly = _weekly_activity(db, user_id, current) if kind == "weekly" else None
    return {"language": language, "kind": kind, "today": today, "weekly": weekly}


def render_user_digest(payload: dict[str, Any]) -> str:
    language = str(payload.get("language") or "fa")
    kind = str(payload.get("kind") or "daily")
    today = payload.get("today") if isinstance(payload.get("today"), dict) else {}
    signals = today.get("signals") if isinstance(today.get("signals"), dict) else {}
    latest = today.get("latest_signal") if isinstance(today.get("latest_signal"), dict) else None
    event = today.get("next_event") if isinstance(today.get("next_event"), dict) else None
    if language == "en":
        title = "📅 <b>Your weekly SENTINEL summary</b>" if kind == "weekly" else "☀️ <b>Your SENTINEL daily summary</b>"
        lines = [
            title,
            "",
            f"📡 Signals: <b>{int(signals.get('total', 0) or 0)}</b> total · <b>{int(signals.get('open', 0) or 0)}</b> open",
            f"⭐ Watchlist: <b>{int(today.get('watchlist_count', 0) or 0)}</b> · 🔔 Alerts: <b>{int(today.get('active_alert_count', 0) or 0)}</b>",
            f"📓 Journal: <b>{int(today.get('journal_total', 0) or 0)}</b> total · <b>{int(today.get('journal_open', 0) or 0)}</b> open",
            f"🎫 Open support tickets: <b>{int(today.get('open_ticket_count', 0) or 0)}</b>",
            f"💎 VIP: <b>{'active' if today.get('vip_active') else 'inactive'}</b>" + (f" · {int(today.get('vip_days_left', 0) or 0)} days left" if today.get('vip_active') else ""),
        ]
        if latest:
            lines.append(f"📌 Latest signal: <b>{latest.get('symbol') or '-'}</b> · {latest.get('side') or latest.get('direction') or '-'}")
        if event:
            lines.append(f"🗓 Next event: <b>{event.get('title') or event.get('title_fa') or '-'}</b> · {event.get('currency') or ''}")
        if kind == "weekly":
            weekly = payload.get("weekly") if isinstance(payload.get("weekly"), dict) else {}
            lines.extend([
                "",
                "<b>Last 7 days</b>",
                f"✅ Signal decisions: <b>{int(weekly.get('signal_choices', 0) or 0)}</b>",
                f"📓 Journal activity: <b>{int(weekly.get('journal_touched', 0) or 0)}</b> · closed <b>{int(weekly.get('journal_closed', 0) or 0)}</b>",
                f"🏆 Wins/Losses: <b>{int(weekly.get('journal_wins', 0) or 0)}</b>/<b>{int(weekly.get('journal_losses', 0) or 0)}</b>",
            ])
        lines.append("\nUse ‘Today’ for the live dashboard or Notification Center to change delivery settings.")
        return "\n".join(lines)

    title = "📅 <b>خلاصه هفتگی SENTINEL</b>" if kind == "weekly" else "☀️ <b>خلاصه روزانه SENTINEL</b>"
    lines = [
        title,
        "",
        f"📡 سیگنال‌ها: <b>{int(signals.get('total', 0) or 0)}</b> کل · <b>{int(signals.get('open', 0) or 0)}</b> باز",
        f"⭐ واچ‌لیست: <b>{int(today.get('watchlist_count', 0) or 0)}</b> · 🔔 هشدارها: <b>{int(today.get('active_alert_count', 0) or 0)}</b>",
        f"📓 ژورنال: <b>{int(today.get('journal_total', 0) or 0)}</b> کل · <b>{int(today.get('journal_open', 0) or 0)}</b> باز",
        f"🎫 تیکت باز: <b>{int(today.get('open_ticket_count', 0) or 0)}</b>",
        f"💎 VIP: <b>{'فعال' if today.get('vip_active') else 'غیرفعال'}</b>" + (f" · {int(today.get('vip_days_left', 0) or 0)} روز باقی‌مانده" if today.get('vip_active') else ""),
    ]
    if latest:
        lines.append(f"📌 آخرین سیگنال: <b>{latest.get('symbol') or '-'}</b> · {latest.get('side') or latest.get('direction') or '-'}")
    if event:
        lines.append(f"🗓 رویداد بعدی: <b>{event.get('title_fa') or event.get('title') or '-'}</b> · {event.get('currency') or ''}")
    if kind == "weekly":
        weekly = payload.get("weekly") if isinstance(payload.get("weekly"), dict) else {}
        lines.extend([
            "",
            "<b>۷ روز گذشته</b>",
            f"✅ تصمیم روی سیگنال: <b>{int(weekly.get('signal_choices', 0) or 0)}</b>",
            f"📓 فعالیت ژورنال: <b>{int(weekly.get('journal_touched', 0) or 0)}</b> · بسته‌شده <b>{int(weekly.get('journal_closed', 0) or 0)}</b>",
            f"🏆 برد/باخت: <b>{int(weekly.get('journal_wins', 0) or 0)}</b>/<b>{int(weekly.get('journal_losses', 0) or 0)}</b>",
        ])
    lines.append("\nبرای وضعیت لحظه‌ای «امروز من» و برای تغییر زمان ارسال «مرکز اعلان‌ها» را باز کنید.")
    return "\n".join(lines)
