"""Immutable plans and observed first-visit lifecycle; never broker execution."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal
from hashlib import sha256

from modules.canonical_market import ANALYSIS_TIMEFRAMES, Quote, price
from repositories.v2.common import json_dump

ENGINES = {"indicators", "sweep_fvg", "order_block", "fibonacci", "fibonacci_pullback", "custom"}
FIRST_VISIT_ENGINES = {"sweep_fvg", "order_block", "fibonacci_pullback"}
TERMINAL = {"CANCELLED", "VERIFIED_ENTRY", "MANUAL_ADMIN_ENTRY"}
PREVIOUS_RULE_VERSION = "session-20261013-tp1-2r-usdt"
CURRENT_RULE_VERSION = "session-20261013-poc-midpoint-tick-shared-fib"


@dataclass(frozen=True, slots=True)
class SetupPlan:
    setup_id: str
    thesis_key: str
    engine: str
    submodel: str
    symbol: str
    timeframe: str
    direction: str
    provider: str
    venue: str
    product: str
    evidence_cutoff_ms: int
    zone_low: Decimal
    zone_high: Decimal
    entry: Decimal
    stop: Decimal
    tp1: Decimal
    tp2: Decimal
    tp3: Decimal | None
    tick_size: Decimal
    source_ids: tuple[str, ...]
    evidence: tuple[dict, ...]
    plan_version: int = 1
    rule_version: str = CURRENT_RULE_VERSION

    tp4: Decimal | None = None
    tp5: Decimal | None = None
    tp6: Decimal | None = None
    tp7: Decimal | None = None
    tp8: Decimal | None = None
    tp9: Decimal | None = None
    tp10: Decimal | None = None

    def __post_init__(self):
        if (
            self.engine not in ENGINES
            or self.timeframe not in ANALYSIS_TIMEFRAMES
            or self.direction not in {"BUY", "SELL"}
        ):
            raise ValueError("SETUP_CLASSIFICATION_INVALID")
        for field in ("zone_low", "zone_high", "entry", "stop", "tp1", "tp2", "tick_size"):
            object.__setattr__(self, field, price(getattr(self, field)))
        from modules.signal_targets import TARGET_KEYS,validate
        for key in TARGET_KEYS[2:]:
            if getattr(self,key) is not None:object.__setattr__(self,key,price(getattr(self,key)))
        validate({key:getattr(self,key) for key in (*TARGET_KEYS,'direction','entry')})
        if not self.zone_low < self.zone_high or not self.zone_low <= self.entry <= self.zone_high:
            raise ValueError("SETUP_ENTRY_ZONE_INVALID")
        sign = Decimal(1) if self.direction == "BUY" else Decimal(-1)
        if (
            sign * (self.entry - self.stop) <= 0
            or sign * (self.tp1 - self.entry) <= 0
            or sign * (self.tp2 - self.tp1) <= 0
        ):
            raise ValueError("SETUP_STRUCTURAL_LEVELS_INVALID")
        if self.tp3 is not None and sign * (self.tp3 - self.tp2) <= 0:
            raise ValueError("SETUP_TARGET_ORDER_INVALID")
        if self.rr_tp2 < 2:
            raise ValueError("SETUP_TP2_BELOW_2R")
        if self.rule_version in {CURRENT_RULE_VERSION, PREVIOUS_RULE_VERSION}:
            self.validate_current_policy()
        if self.entry % self.tick_size != 0:
            raise ValueError("EXACT_ENTRY_NOT_EXECUTABLE_AT_TICK_SIZE")
        if self.rule_version != CURRENT_RULE_VERSION and self.engine == "sweep_fvg" and self.entry != (self.zone_low + self.zone_high) / 2:
            raise ValueError("FVG_ENTRY_MUST_BE_ORIGINAL_MIDPOINT")
        if self.rule_version != CURRENT_RULE_VERSION and self.engine == "order_block" and self.entry != (self.zone_low + self.zone_high) / 2:
            raise ValueError("OB_ENTRY_MUST_BE_FULL_CANDLE_MIDPOINT")
        if not all((self.setup_id, self.thesis_key, self.provider, self.venue, self.product, self.source_ids)):
            raise ValueError("SETUP_PROVENANCE_MISSING")
        if any(
            int(row.get("available_ms", self.evidence_cutoff_ms + 1)) > self.evidence_cutoff_ms for row in self.evidence
        ):
            raise ValueError("SETUP_FUTURE_EVIDENCE")
        if self.rule_version == CURRENT_RULE_VERSION:
            self._validate_session_selector()

    def _validate_session_selector(self):
        from modules.entry_selection import fvg_entry, inside_tick

        if self.engine=='custom':
            from modules.custom_strategy import validate_plan
            base=validate_plan(self.as_dict())
            SetupPlan.from_dict(base)
            return

        if self.engine not in {"sweep_fvg", "order_block"}:
            if self.engine == "fibonacci":
                raise ValueError("FIBONACCI_CONFIRMATION_CANNOT_CREATE_ENTRY")
            return
        choices = [row.get("detail") for row in self.evidence if row.get("kind") == "entry_selection"]
        if len(choices) != 1 or not isinstance(choices[0], dict):
            raise ValueError("SESSION_ENTRY_SELECTION_EVIDENCE_REQUIRED")
        selection = choices[0]
        if self.engine == "sweep_fvg":
            if selection.get("selector") != "FVG_MIDPOINT_SMALL_OFFSET":
                raise ValueError("FVG_SESSION_SELECTOR_INVALID")
            expected, _ = fvg_entry(self.zone_low, self.zone_high, direction=self.direction,
                                    tick_size=self.tick_size, pip_size=selection.get("pip_size"))
        else:
            poc = selection.get("poc") or {}
            if selection.get("selector") != "CAUSAL_WAVE_POC" or poc.get("kind") != "POC":
                raise ValueError("OB_CAUSAL_POC_REQUIRED")
            if not poc.get("source_id") or not poc.get("source_ids") or poc.get("volume_kind") not in {"traded", "tick_proxy"}:
                raise ValueError("OB_POC_NATIVE_VOLUME_EVIDENCE_REQUIRED")
            if (poc.get("symbol"), poc.get("provider"), poc.get("venue"), poc.get("product")) != (self.symbol, self.provider, self.venue, self.product):
                raise ValueError("OB_POC_MARKET_MISMATCH")
            if not 0 < int(poc.get("start_ms", 0)) < int(poc.get("end_ms", 0)) <= self.evidence_cutoff_ms:
                raise ValueError("OB_POC_WINDOW_INVALID")
            if max(int(poc.get("available_ms", self.evidence_cutoff_ms + 1)), int(poc.get("window_locked_ms", self.evidence_cutoff_ms + 1))) > self.evidence_cutoff_ms:
                raise ValueError("OB_POC_FUTURE_EVIDENCE")
            expected = inside_tick(poc.get("price"), self.zone_low, self.zone_high, self.tick_size, self.direction)
        if self.entry != expected or selection.get("entry") != str(expected):
            raise ValueError("SESSION_EXACT_ENTRY_SELECTOR_MISMATCH")

    @property
    def rr_tp1(self):
        return abs(self.tp1 - self.entry) / abs(self.entry - self.stop)

    def validate_current_policy(self):
        if self.rr_tp1 < 2:
            raise ValueError("SETUP_TP1_BELOW_2R")
        if self.provider in {"kraken", "binance", "bybit", "okx"} and (
            not self.symbol.endswith("USDT") or not self.venue.endswith("USDT")
        ):
            raise ValueError("CRYPTO_USDT_MARKET_REQUIRED")

    @property
    def rr_tp2(self):
        return abs(self.tp2 - self.entry) / abs(self.entry - self.stop)

    @property
    def first_visit_only(self):
        if self.engine=='custom':
            base=next(f['detail']['base_plan'] for f in self.evidence if f['kind']=='custom_strategy')
            return SetupPlan.from_dict(base).first_visit_only
        return self.engine in FIRST_VISIT_ENGINES or (
            self.engine == "fibonacci" and self.submodel.startswith("advanced")
        )

    def as_dict(self):
        result = asdict(self)
        for field in ("zone_low", "zone_high", "entry", "stop", "tp1", "tp2", "tp3", "tick_size"):
            result[field] = str(result[field]) if result[field] is not None else None
        for n in range(4,11):
            key=f'tp{n}'
            if result[key] is None:result.pop(key)
            else:result[key]=str(result[key])
        result["initial_rr_tp2"] = str(self.rr_tp2)
        return result

    @property
    def plan_hash(self):
        return sha256(json_dump(self.as_dict()).encode()).hexdigest()

    @classmethod
    def from_dict(cls, data):
        row = dict(data)
        row.pop("initial_rr_tp2", None)
        row.pop("initial_rr_tp1", None)
        # Missing rule labels are historical; do not rewrite their locked hash.
        row.setdefault("rule_version", "approved-227")
        row["source_ids"] = tuple(row["source_ids"])
        row["evidence"] = tuple(row["evidence"])
        return cls(**row)


@dataclass(frozen=True, slots=True)
class LifecycleState:
    phase: str = "PROPOSED_PRETOUCH"
    first_touch_ms: int | None = None
    entry_ms: int | None = None
    last_quote_ms: int = 0
    reason: str = ""
    fresh_for_new_proposal: bool = True
    last_quote_id: str = ''


def observe_quote(
    plan: SetupPlan,
    state: LifecycleState,
    quote: Quote,
    *,
    now_ms: int,
    meaningful_rejection=False,
    structural_invalidated=False,
    sequence_ordered=False,
):
    if state.phase in TERMINAL:
        return state
    if (quote.symbol, quote.provider, quote.venue, quote.product, quote.tick_size) != (
        plan.symbol,
        plan.provider,
        plan.venue,
        plan.product,
        plan.tick_size,
    ):
        return LifecycleState(**{**asdict(state), "phase": "NEEDS_REVIEW", "reason": "QUOTE_MARKET_MISMATCH"})
    unordered = quote.event_ms < state.last_quote_ms or (
        quote.event_ms == state.last_quote_ms and (not sequence_ordered or quote.source_id == state.last_quote_id))
    if unordered or not quote.fresh(now_ms) or quote.event_ms < plan.evidence_cutoff_ms:
        return LifecycleState(**{**asdict(state), "phase": "NEEDS_REVIEW", "reason": "STALE_OR_UNORDERED_QUOTE"})
    if state.phase == "NEEDS_REVIEW":
        return state  # gaps are not automatically repaired by one later good quote
    values = {**asdict(state), "last_quote_ms": quote.event_ms, 'last_quote_id':quote.source_id}
    executable = quote.ask if plan.direction == "BUY" else quote.bid
    inside = plan.zone_low <= executable <= plan.zone_high
    if structural_invalidated:
        return LifecycleState(**{**values, "phase": "CANCELLED", "reason": "STRUCTURAL_INVALIDATION"})
    if (plan.direction=='BUY' and executable<=plan.stop) or (plan.direction=='SELL' and executable>=plan.stop):
        return LifecycleState(**{**values,'phase':'CANCELLED','reason':'PRE_ENTRY_STRUCTURAL_STOP_BREACH'})
    # An actual exact quote touch can verify; a gap over Entry cannot.
    if inside and executable == plan.entry:
        return LifecycleState(
            **{
                **values,
                "phase": "VERIFIED_ENTRY",
                "entry_ms": quote.event_ms,
                "first_touch_ms": state.first_touch_ms or quote.event_ms,
                "fresh_for_new_proposal": False,
                "reason": "SIDE_CORRECT_EXACT_QUOTE_TOUCH",
            }
        )
    if state.first_touch_ms is None and inside:
        return LifecycleState(
            **{
                **values,
                "phase": "FIRST_TOUCH_IN_PROGRESS",
                "first_touch_ms": quote.event_ms,
                "fresh_for_new_proposal": False,
                "reason": "FIRST_EDGE_CONTACT",
            }
        )
    if state.first_touch_ms is not None:
        if meaningful_rejection or (plan.first_visit_only and not inside):
            return LifecycleState(
                **{
                    **values,
                    "phase": "CANCELLED",
                    "reason": "MISSED_ENTRY_REJECTION" if meaningful_rejection else "FULL_ZONE_EXIT_BEFORE_ENTRY",
                }
            )
    return LifecycleState(**values)


def observe_ohlc_ambiguity(state: LifecycleState):
    if state.phase in TERMINAL:
        return state
    return LifecycleState(**{**asdict(state), "phase": "NEEDS_REVIEW", "reason": "INTRABAR_ORDER_UNPROVEN"})
