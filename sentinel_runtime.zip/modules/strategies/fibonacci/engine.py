"""Fourth engine: optional confluence from preconfirmed, separate waves."""

from __future__ import annotations

from decimal import Decimal as D

from modules.fibonacci_geometry import golden_extension_band, wave_level
from modules.strategies.common import confirmed_swings


def price_role(value, plan):
    low,high,entry = (D(plan[k]) for k in ('zone_low','zone_high','entry'))
    if low <= value <= high:
        return 'ENTRY_ZONE_CONFIRMATION'
    sign = D(1) if plan['direction'] == 'BUY' else D(-1)
    return 'PROFIT_SIDE_REFERENCE' if sign*(value-entry)>0 else 'PROTECTIVE_SIDE_REFERENCE'


def causal_wave(bars, swings, direction, origin_index, *, confirmation_right=2):
    kind = "low" if direction == "BUY" else "high"
    starts = [s for s in swings if s.kind == kind and s.index + confirmation_right <= origin_index]
    if not starts:
        return None
    start = starts[-1]
    # First available opposite swing locks the initial wave; later extrema are
    # distinct prospective scenarios and cannot rewrite the original anchors.
    ends = [s for s in swings if s.kind != kind and s.index > origin_index]
    if not ends:
        return None
    end = ends[0]
    sign = D(1) if direction == "BUY" else D(-1)
    if sign * (end.value - start.value) <= 0:
        return None
    return start, end


class Fibonacci:
    name = "fibonacci"

    def evaluate(self, context, candidates=()):
        bars = context.closed
        swings = confirmed_swings(bars, context.parameters)
        result = []
        for row in candidates:
            plan = row.get("plan") or row.get('draft_plan')
            if not plan:
                continue
            details = [fact["detail"] for fact in plan["evidence"] if fact["kind"] == "causal_wave"]
            wave = details[0] if details else None
            anchor = None
            if wave:
                expected_kind='low' if plan['direction']=='BUY' else 'high'
                pair = [next((s for s in swings if s.index == wave[key]
                              and s.kind == (expected_kind if key=='start_index' else
                                             'high' if expected_kind=='low' else 'low')
                              and (wave.get('start_price' if key=='start_index' else 'end_price') is None
                                   or s.value==D(wave['start_price' if key=='start_index' else 'end_price']))), None)
                        for key in ('start_index','end_index')]
                if wave.get('anchor_basis') == 'ACTUAL_SWEEP_EXTREME_TO_CONFIRMED_IMPULSE_END':
                    from modules.strategies.common import Swing
                    pair[0] = Swing(wave['start_index'], 'low' if plan['direction'] == 'BUY' else 'high',
                                    D(wave['start_price']), context.cutoff_ms)
                if all(pair) and pair[0].index<pair[1].index:
                    anchor = tuple(pair)
            if anchor is None and wave is None and plan['engine'] != 'sweep_fvg':
                origins = [s for s in swings if s.available_ms <= context.cutoff_ms]
                pairs = [(a, b) for a, b in zip(origins, origins[1:]) if a.kind != b.kind]
                expected = "low" if plan["direction"] == "BUY" else "high"
                anchor = next((pair for pair in reversed(pairs) if pair[0].kind == expected), None)
            low, high = D(plan["zone_low"]), D(plan["zone_high"])
            confirmations = []
            main_levels = {}
            level_roles, minor_zones = [],[]
            profile = {'status':'NATIVE_PROFILE_UNAVAILABLE','entry_changed':False,'targets_changed':False}
            if anchor:
                start, end = anchor
                main_levels["0"] = str(start.value)
                main_levels["1"] = str(end.value)
                for ratio in (D(".61"), D(".71")):
                    if ratio == D(".71") and plan["engine"] != "sweep_fvg":
                        continue
                    level = wave_level(start.value, end.value, ratio)
                    main_levels[str(ratio)] = str(level)
                    level_roles.append({'ratio':str(ratio),'price':str(level),'role':price_role(level,plan),
                                        'available_ms':max(start.available_ms,end.available_ms),
                                        'anchor_source_ids':[bars[start.index].source_id,bars[end.index].source_id]})
                    if low <= level <= high:
                        confirmations.append({"kind": "MAIN_WAVE_LEVEL_IN_ZONE", "ratio": str(ratio), "price": str(level),
                                              'role':'ENTRY_ZONE_CONFIRMATION'})
                magnitude = abs(end.value - start.value)
                for a, b in zip(swings, swings[1:]):
                    if a.kind == b.kind or a.index >= b.index or (a.index, b.index) == (start.index, end.index):
                        continue
                    if max(a.available_ms, b.available_ms) > context.cutoff_ms or abs(b.value - a.value) >= magnitude:
                        continue
                    if any(x.end_ms != y.start_ms for x, y in zip(bars[a.index:b.index], bars[a.index + 1:b.index + 1])):
                        continue
                    try:
                        golden_low, golden_high = golden_extension_band(a.value, b.value, convention="two_anchor")
                    except ValueError:
                        continue
                    entry_overlap = golden_low <= high and golden_high >= low
                    matched_targets = [key for key in ('tp1','tp2','tp3','tp4','tp5','tp6','tp7','tp8','tp9','tp10')
                                       if plan.get(key) is not None and golden_low <= D(plan[key]) <= golden_high]
                    minor_zones.append({'anchor_source_ids':[bars[a.index].source_id,bars[b.index].source_id],
                        'golden_low':str(golden_low),'golden_high':str(golden_high),
                        'available_ms':max(a.available_ms,b.available_ms),'convention':'two_anchor',
                        'overlaps_entry_zone':entry_overlap,'overlaps_target_prices':matched_targets,
                        'role':'ENTRY_ZONE_CONFIRMATION' if entry_overlap else 'TARGET_REFERENCE' if matched_targets else
                               price_role((golden_low+golden_high)/2,plan)})
                    if golden_low <= high and golden_high >= low:
                        confirmations.append({
                            "kind": "OTHER_MINOR_WAVE_GOLDEN_OVERLAP", "anchors": [a.index, b.index],
                            "anchor_source_ids": [bars[a.index].source_id, bars[b.index].source_id],
                            "golden_low": str(golden_low), "golden_high": str(golden_high),
                            "available_ms": max(a.available_ms, b.available_ms), "convention": "two_anchor",
                            'role':'ENTRY_ZONE_CONFIRMATION',
                        })
                # Reuse a prelocked entry POC, or derive only from the same
                # confirmed causal window and source-matched native volume.
                selector = next((f.get('detail',{}) for f in plan['evidence'] if f.get('kind')=='entry_selection'),{})
                poc = selector.get('poc')
                if poc is None and context.profile_candles:
                    from modules.volume_profile import anchored_profile
                    try:
                        poc = anchored_profile(context.profile_candles,start_ms=bars[start.index].start_ms,
                            end_ms=bars[end.index].end_ms,cutoff_ms=context.cutoff_ms,tick_size=context.tick_size,
                            parent_bars=tuple(bars[start.index:end.index+1]),review_only=getattr(context,'review_only',False))
                    except ValueError as exc:
                        profile['status'] = str(exc)
                if poc:
                    value = D(poc['price'])
                    profile = {'status':'SOURCE_BOUND_PROFILE','price':str(value),'role':price_role(value,plan),
                               'entry_selector':plan['engine']=='order_block',
                               'near_target_keys':[key for key in ('tp1','tp2','tp3') if plan.get(key) is not None
                                                   and abs(D(plan[key])-value)<=context.tick_size],
                               'start_ms':poc['start_ms'],'end_ms':poc['end_ms'],'volume_kind':poc['volume_kind'],
                               'is_order_book_liquidity':False,'entry_changed':False,'targets_changed':False}
            result.append({
                "engine": self.name, "submodel": "shared_confirmation", "state": "CONFIRMATION_ONLY",
                "setup_id": plan["setup_id"], "main_levels": main_levels, "confirmations": confirmations,
                "confirmed": bool(confirmations), "required_for_entry": False,
                "is_win_probability": False, "entry_changed": False,
                'orientation':'ZERO_AT_START_ONE_AT_END','main_level_roles':level_roles,
                'minor_wave_zones':minor_zones,'volume_reference':profile,
                'target_reference_is_entry_confirmation':False,'targets_changed':False,
            })
        return result
