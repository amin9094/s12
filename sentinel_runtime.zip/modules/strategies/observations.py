"""Price-only observations. This module cannot construct a SetupPlan.

Execution engines keep their native quote, grid, volume and freshness gates.
These records describe candle patterns for private review, not trade signals.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal as D
from hashlib import sha256

from modules.canonical_market import ANALYSIS_TIMEFRAMES, TIMEFRAMES, validate_series
from modules.strategies.common import Parameters, confirmed_swings, indicators
from repositories.v2.common import json_dump


@dataclass(frozen=True)
class ObservationContext:
    candles: tuple
    cutoff_ms: int
    parameters: Parameters = Parameters()
    engine_parameters: tuple = ()

    @property
    def closed(self):
        return [b for b in self.candles if b.is_closed and b.available_ms <= self.cutoff_ms]

    def validate(self):
        if not self.candles or self.candles[0].timeframe not in ANALYSIS_TIMEFRAMES:
            raise ValueError('ANALYSIS_TIMEFRAME_UNAPPROVED')
        validate_series(self.candles,now_ms=self.cutoff_ms)
        if any(b.available_ms>self.cutoff_ms for b in self.candles):
            raise ValueError('CANDLE_FUTURE_TIMESTAMP')
        if len(self.closed) < 105:
            raise ValueError('INDICATOR_WARMUP_INCOMPLETE')
        if self.cutoff_ms-self.closed[-1].end_ms > 2*TIMEFRAMES[self.closed[-1].timeframe]:
            raise ValueError('MARKET_DATA_STALE_OR_SESSION_CLOSED')
        if any('DELAYED' in flag for b in self.candles for flag in b.quality_flags):
            raise ValueError('DELAYED_ANALYSIS_SOURCE')
        profiles = dict(self.engine_parameters)
        if len(profiles) != len(self.engine_parameters) or set(profiles)-{'indicators','sweep_fvg','order_block','fibonacci_pullback'}:
            raise ValueError('ENGINE_PROFILE_SELECTION_INVALID')


def contiguous(bars, start=0, end=None):
    window = bars[start:end]
    return all(b.start_ms == a.end_ms for a,b in zip(window,window[1:]))


def safe_swings(bars,p):
    return [s for s in confirmed_swings(bars,p)
            if contiguous(bars,s.index-p.swing_left,s.index+p.swing_right+1)]


def observation(context, engine, model, direction, zone, thesis, *, after_ms, facts=(), wave=None, missing=()):
    low,high = zone
    if low <= 0 or high < low:
        return None
    later = [b for b in context.candles if b.end_ms > after_ms]
    # Merely absence of observed OHLC overlap; never a native first-visit proof.
    if not later or any(b.low <= high and b.high >= low for b in later):
        return None
    last = context.candles[-1]
    if direction == 'BUY' and last.close <= high or direction == 'SELL' and last.close >= low:
        return None
    identity = [engine,model,direction,last.symbol,last.timeframe,last.provider,last.venue,last.product,
                context.parameters.profile_id,thesis]
    identifier = sha256(json_dump(identity).encode()).hexdigest()[:32]
    gaps = not contiguous(context.candles)
    subject = {'observation_id':identifier,'engine':engine,'submodel':model,'direction':direction,
               'symbol':last.symbol,'timeframe':last.timeframe,'provider':last.provider,'venue':last.venue,
               'product':last.product,'zone_low':str(low),'zone_high':str(high),
               'causal_wave':wave,'facts':list(facts),'after_ms':after_ms,
               'last_closed_ms':context.closed[-1].end_ms,'candle_cutoff_ms':context.cutoff_ms,
               'observed_ohlc_overlap':False,'native_first_visit_proven':False,
               'history_has_gaps':gaps,'session_calendar_verified':False,
               'quality_flags':sorted({flag for b in context.candles for flag in b.quality_flags}),
               'missing_requirements':list(dict.fromkeys(['SOURCE_MATCHED_NATIVE_BID_ASK','NATIVE_PRICE_GRID',
                   'CONTINUOUS_PRETOUCH_PROOF','STRUCTURAL_TARGETS_AND_NET_RISK_REVIEW',*missing]))}
    return {'engine':engine,'submodel':model,'state':'ANALYTICAL_OBSERVATION','reason':'CANDLE_PATTERN_ONLY',
            'title_fa':'مشاهدهٔ تحلیلی؛ ورود تأیید نشده',
            'explanation_fa':'این محدوده از کندل‌های منبع مشخص استخراج شده است؛ قیمت ورود، استاپ و تارگت معامله هنوز تأیید نشده‌اند.',
            'required_action_fa':'پیش از هر سیگنال ورود، دادهٔ قیمت و مشخصات همان بازار و شرایط کامل استراتژی بررسی شود.',
            **{key:subject[key] for key in ('symbol','timeframe','provider','venue','product','direction')},
            'profile_id':context.parameters.profile_id,'thesis_key':identifier,'available_ms':context.cutoff_ms,
            'original_zone':[str(low),str(high)],'observation':subject,
            'execution_eligible':False,'is_signal':False}


def evaluate_observations(context):
    context.validate()
    from modules.strategies.indicators.observer import observe as indicator_observer
    from modules.strategies.order_block.observer import observe as ob_observer
    from modules.strategies.sweep_fvg.observer import observe as sweep_observer
    from modules.strategies.fibonacci.observer import confirm
    profiles = dict(context.engine_parameters)
    results = []
    for engine,observer in [('indicators',indicator_observer),('sweep_fvg',sweep_observer),('order_block',ob_observer)]:
        selected = replace(context,parameters=profiles.get(engine,context.parameters))
        rows = observer(selected)
        for row in rows[-5:]:
            row['fibonacci_confirmation'] = confirm(selected,row)
            results.append(row)
    collaborations = []
    for i,a in enumerate(results):
        for b in results[i+1:]:
            if a['engine'] == b['engine'] or a['direction'] != b['direction']:
                continue
            if max(D(a['original_zone'][0]),D(b['original_zone'][0])) <= min(D(a['original_zone'][1]),D(b['original_zone'][1])):
                collaborations.append({'observation_ids':[a['thesis_key'],b['thesis_key']],
                                       'kind':'SAME_SOURCE_ZONE_OVERLAP','execution_eligible':False,
                                       'poc_priority_pending':a['engine']=='order_block' or b['engine']=='order_block'})
    return {'state':'ANALYTICAL_OBSERVATIONS','analysis_mode':'CANDLE_ONLY','production_qualified':False,
            'results':results,'collaborations':collaborations,'execution_eligible':False,'is_signal':False,
            'symbol':context.candles[-1].symbol,'timeframe':context.candles[-1].timeframe,
            'provider':context.candles[-1].provider,'venue':context.candles[-1].venue,'product':context.candles[-1].product,
            'last_closed_ms':context.closed[-1].end_ms,
            'history_has_gaps':not contiguous(context.candles),
            'engine_roles':{'indicators':'INDEPENDENT_CANDLE_OBSERVER','sweep_fvg':'INDEPENDENT_CANDLE_OBSERVER',
                            'order_block':'PRICE_PATTERN_POC_AND_VOLUME_PENDING','fibonacci':'SHARED_OPTIONAL_CONFIRMATION',
                            'fibonacci_pullback':'EXPERIMENTAL_EXECUTION_ENGINE_REQUIRES_NATIVE_MARKET'},
            'selected_engine_profiles':{engine:p.profile_id for engine,p in profiles.items()}}

