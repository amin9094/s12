"""Same directional votes and four model labels, without guessed order levels."""
from decimal import Decimal as D
from modules.indicator_suite import indicators
from modules.strategies.indicators.engine import directional_agreement
from modules.strategies.observations import observation,safe_swings


def observe(context):
    bars,p = context.closed,context.parameters
    stats,swings = indicators(bars),safe_swings(bars,p)
    atr,last = stats['atr'],bars[-1]
    if atr <= 0:
        return []
    rows = []
    for direction,sign,kind in [('BUY',D(1),'low'),('SELL',D(-1),'high')]:
        agreed,votes = directional_agreement(stats,direction)
        protected = [s for s in swings if s.kind==kind]
        if not agreed or len(protected)<2:
            continue
        a,b = protected[-2:]
        ma,rsi = stats['ma'],stats['rsi']
        models = []
        trend = sign*(ma[20][-1]-ma[50][-1])>0 and sign*(ma[50][-1]-ma[100][-1])>0
        if trend and stats['adx']>=p.adx_trend:
            models.append(('trend_continuation',ma[20][-1]))
        divergence = rsi[a.index] is not None and rsi[b.index] is not None and sign*(b.value-a.value)<0 and sign*(rsi[b.index]-rsi[a.index])>0
        if divergence and sign*(stats['macd_hist'][-1]-stats['macd_hist'][-3])>0:
            models.append(('early_reversal',b.value))
        lows,highs = [s for s in swings if s.kind=='low'][-2:],[s for s in swings if s.kind=='high'][-2:]
        if stats['adx']<=p.adx_range and len(lows)==len(highs)==2:
            low,high = max(s.value for s in lows),min(s.value for s in highs)
            if low<high:
                models.append(('range_reversal',low if direction=='BUY' else high))
                edge = high if direction=='BUY' else low
                # A candle breakout only after the edge was actually closed
                # through; a future break cannot be called a confirmed event.
                if sign*(last.close-edge)>0:
                    models.append(('range_breakout',edge))
        for name,level in models:
            row = observation(context,'indicators',name,direction,(level-atr*D('.05'),level+atr*D('.05')),
                              [name,last.source_id],after_ms=last.end_ms,
                              facts=[{'kind':'all_directional_indicators','votes':votes,'adx':str(stats['adx']),
                                      'atr':str(atr),'forecast_arrival_time_claimed':False,
                                      'atr_is_directional_vote':False,'indicators_use_observed_bars_only':True}])
            if row:
                rows.append(row)
    return rows

