"""Isolated indicators strategy family."""
