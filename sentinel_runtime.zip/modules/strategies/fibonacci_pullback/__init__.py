"""Isolated fibonacci_pullback strategy family."""
