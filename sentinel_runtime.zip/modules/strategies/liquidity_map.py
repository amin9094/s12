"""Confirmed, unconsumed swing pools. Prominence is not measured order size."""
from decimal import Decimal as D


def pool_map(bars, swings, parameters, atr, *, before_index, spread=D(0)):
    if not 0 < before_index <= len(bars):
        return []
    cutoff = bars[before_index].start_ms if before_index < len(bars) else bars[-1].available_ms
    known = [s for s in swings if s.index+parameters.swing_right < before_index and s.available_ms <= cutoff]
    tolerance = max(atr*parameters.compact_cluster_atr,spread*2)
    breach = max(atr*parameters.sweep_atr,spread*2)
    suffix_low, suffix_high = [None]*(before_index+1),[None]*(before_index+1)
    for i in range(before_index-1,-1,-1):
        suffix_low[i] = bars[i].low if suffix_low[i+1] is None else min(bars[i].low,suffix_low[i+1])
        suffix_high[i] = bars[i].high if suffix_high[i+1] is None else max(bars[i].high,suffix_high[i+1])
    result = []
    for kind in ('low','high'):
        all_levels = [s for s in known if s.kind == kind]
        fresh = []
        for s in all_levels:
            extreme = (suffix_low if kind == 'low' else suffix_high)[s.index+1]
            if extreme is None or (s.value-extreme if kind == 'low' else extreme-s.value) < breach:
                fresh.append(s)
        groups = []
        for s in sorted(fresh,key=lambda s:(s.value,s.index)):
            if not groups or s.value-groups[-1][0].value > tolerance:
                groups.append([s])
            else:
                groups[-1].append(s)
        outer = (min(s.value for s in all_levels) if kind == 'low' else max(s.value for s in all_levels)) if all_levels else None
        for members in groups:
            pivot = min(members,key=lambda s:(s.value,-s.index)) if kind == 'low' else max(members,key=lambda s:(s.value,s.index))
            external = pivot.value == outer
            detail = {'side':'SELL_SIDE' if kind == 'low' else 'BUY_SIDE','reference_price':str(pivot.value),
                'cluster_low':str(min(s.value for s in members)),'cluster_high':str(max(s.value for s in members)),
                'confirmed_touch_count':len(members),
                'member_source_ids':[bars[s.index].source_id for s in sorted(members,key=lambda s:s.index)],
                'available_ms':max(s.available_ms for s in members),'reference_source_id':bars[pivot.index].source_id,
                'source_window_start_ms':bars[0].start_ms,'evaluated_before_ms':cutoff,
                'scope':'AVAILABLE_SAME_SOURCE_TIMEFRAME_WINDOW',
                'relative_structure':'OUTER_CONFIRMED_SWING_EXTREME' if external else 'INTERNAL_CONFIRMED_POOL',
                'prominence_policy':'OUTER_THEN_CLUSTER_THEN_RECENCY','consumed_before_event':False,
                'order_quantity_verified':False,'is_heavy_liquidity_measurement':False}
            result.append({'pivot':pivot,'detail':detail,
                           'rank':(external,len(members)>1,len(members),max(s.index for s in members))})
    return sorted(result,key=lambda item:item['rank'],reverse=True)


def target_inventory(bars, swings, direction, entry, stop):
    sign = D(1) if direction == 'BUY' else D(-1)
    kind = 'high' if direction == 'BUY' else 'low'
    active,consumed = [],[]
    for s in swings:
        if s.kind != kind or sign*(s.value-entry) <= 0:
            continue
        taken = any(b.high >= s.value if direction == 'BUY' else b.low <= s.value for b in bars[s.index+1:])
        item = {'price':str(s.value),'source_id':bars[s.index].source_id,'available_ms':s.available_ms,
                'kind':'HISTORICAL_STRUCTURAL_LEVEL' if taken else 'UNCONSUMED_SWING_LIQUIDITY',
                'consumed':taken,'role':'TARGET_OBJECTIVE'}
        (consumed if taken else active).append(item)
    unique = {}
    # A crossed swing can still be a genuine structural objective after a
    # prospective pullback; it must not be mislabelled as untouched liquidity.
    for item in [*active,*consumed]:
        unique.setdefault(D(item['price']),item)
    ordered = sorted(unique,reverse=direction == 'SELL')
    return {'objectives':[unique[v] for v in ordered],'consumed_objectives':consumed,
            'unconsumed_liquidity_objectives':active,
            'nearest_objective_rr':str(abs(ordered[0]-entry)/abs(entry-stop)) if ordered and entry != stop else None,
            'nearest_objective_skipped_for_rr':False,'target_prices_moved':False,'pool_quantity_verified':False}
