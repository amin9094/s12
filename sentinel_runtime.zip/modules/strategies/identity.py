"""Match a pre-upgrade thesis without rewriting an existing approved plan."""
from hashlib import sha256

from repositories.v2.common import json_dump


def identity_detail(plan):
    return next((fact.get('detail') for fact in plan.evidence if fact.get('kind')=='strategy_identity_v2'),None)


def matches_legacy_identity(new_plan,old_plan):
    detail=identity_detail(new_plan)
    if not detail or identity_detail(old_plan) or (
        new_plan.engine,new_plan.submodel,new_plan.symbol,new_plan.timeframe,new_plan.direction,
        new_plan.provider,new_plan.venue,new_plan.product
    )!=(old_plan.engine,old_plan.submodel,old_plan.symbol,old_plan.timeframe,old_plan.direction,
        old_plan.provider,old_plan.venue,old_plan.product):
        return False
    indices={source_id:index for index,source_id in enumerate(old_plan.source_ids)}
    anchors=[item for item in detail['identity'] if item in new_plan.source_ids]
    if not anchors or any(item not in indices for item in anchors):return False
    identity=[indices[item] if item in indices and new_plan.engine!='order_block' else item
              for item in detail['identity']]
    legacy=sha256(json_dump({'identity':identity,'direction':new_plan.direction,
                             'profile_id':detail['profile_id']}).encode()).hexdigest()
    return legacy==old_plan.thesis_key
