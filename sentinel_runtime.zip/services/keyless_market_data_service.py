"""Documented anonymous OHLC feed, kept distinct from broker execution data.

biquote combines upstream history and tick aggregation. Its bars do not carry
per-bar broker/volume provenance, so neither execution quotes nor POC are
inferred from them. TradingView widgets are not used as data APIs.
"""
from __future__ import annotations

import time
from decimal import Decimal, InvalidOperation
from datetime import UTC, datetime, timedelta

from modules.canonical_market import Candle, TIMEFRAMES, validate_series

BIQUOTE_ORIGIN = "https://biquote.io"
BIQUOTE_FLAGS = (
    "AGGREGATED_INDICATIVE_HISTORY_NO_EXECUTION_QUOTE",
    "UPSTREAM_PER_BAR_PROVENANCE_UNVERIFIED",
    "REPORTED_TICK_VOLUME_UNVERIFIED",
)


def supported_symbols():
    from services.canonical_market_service import FX_TICKERS

    return {"XAUUSD", *FX_TICKERS}


def _utc_ms(value):
    if not isinstance(value, str):
        raise ValueError("BIQUOTE_CANDLE_TIME_INVALID")
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if stamp.tzinfo is None or stamp.utcoffset() != timedelta(0) or stamp.microsecond % 1000:
        raise ValueError("BIQUOTE_CANDLE_TIME_INVALID")
    elapsed = stamp - datetime(1970, 1, 1, tzinfo=UTC)
    result = (elapsed.days * 86400 + elapsed.seconds) * 1000 + elapsed.microseconds // 1000
    if result <= 0:
        raise ValueError("BIQUOTE_CANDLE_TIME_INVALID")
    return result


def parse_biquote_history(raw, *, symbol, timeframe, observed_ms, limit=300, before_ms=None, review_volume=False):
    from services.canonical_market_service import MarketUnavailable

    if symbol not in supported_symbols() or timeframe not in TIMEFRAMES:
        raise MarketUnavailable("MARKET_PROVIDER_MISMATCH")
    if not isinstance(raw, dict) or raw.get("symbol") != symbol or raw.get("interval") != timeframe:
        raise MarketUnavailable("BIQUOTE_HISTORY_IDENTITY_INVALID")
    source = raw.get("bars")
    if not isinstance(source, list) or not source:
        raise MarketUnavailable("MARKET_BARS_EMPTY")
    if len(source) > 2001:
        raise MarketUnavailable("BIQUOTE_HISTORY_INVALID")
    rows = []
    try:
        # The documented API prepends the open bar; the observed series is
        # newest first. Reverse that order, never sort away corrupt ordering.
        for index, row in enumerate(source):
            if not isinstance(row, dict) or type(row.get("isOpen")) is not bool:
                raise ValueError("BIQUOTE_HISTORY_INVALID")
            if row["isOpen"] and index != 0:
                raise ValueError("BIQUOTE_HISTORY_INVALID")
            start = _utc_ms(row["openTime"])
            end = start + TIMEFRAMES[timeframe]
            if not row["isOpen"] and end > observed_ms:
                raise ValueError("BIQUOTE_CLOSE_NOT_AVAILABLE")
            volume = None
            if review_volume and row.get('tickVolume') is not None:
                volume = Decimal(str(row['tickVolume']))
                if not volume.is_finite() or volume < 0 or volume != volume.to_integral_value() or volume > 10**12:
                    raise ValueError('BIQUOTE_HISTORY_INVALID')
            rows.append(Candle(
                symbol, "biquote", "biquote_aggregate_indicative", "indicative", timeframe,
                start, end, *(row[name] for name in ("open", "high", "low", "close")),
                volume, "reported_tick_proxy" if volume is not None else "unavailable", not row["isOpen"], observed_ms,
                f"biquote:{'reported:' if review_volume else ''}{symbol}:{timeframe}:{start}", BIQUOTE_FLAGS,
            ))
        rows.reverse()
        validate_series(rows, now_ms=observed_ms)
    except (ValueError, TypeError, KeyError, OverflowError, InvalidOperation):
        raise MarketUnavailable("BIQUOTE_HISTORY_INVALID") from None
    if before_ms is not None:
        rows = [bar for bar in rows if bar.start_ms < before_ms]
    return rows[-max(1, min(500, int(limit))):]


async def biquote_history(symbol, timeframe, limit, before_ms):
    from services.canonical_market_service import MarketUnavailable, _request

    if symbol not in supported_symbols() or timeframe not in TIMEFRAMES:
        raise MarketUnavailable("MARKET_PROVIDER_MISMATCH")
    params = {"interval": timeframe, "limit": max(1, min(500, int(limit)))}
    if before_ms is not None:
        params["to"] = datetime.fromtimestamp(before_ms / 1000, UTC).isoformat().replace("+00:00", "Z")
    raw = await _request(f"{BIQUOTE_ORIGIN}/api/{symbol}/ohlc", params)
    return parse_biquote_history(
        raw, symbol=symbol, timeframe=timeframe, observed_ms=int(time.time() * 1000),
        limit=limit, before_ms=before_ms,
    )
