"""Actionable data blockers without exposing provider messages or credentials."""

import re

ISSUES = {
    'CLOSED_CANDLE_REOPEN_OR_STALE_REVISION_REQUIRES_REVIEW': (
        'منبع، کندل بسته را باز یا با زمان دریافت قدیمی‌تر گزارش کرده است.',
        'پاسخ تازه با کندل بستهٔ معتبر دریافت شود؛ این پاسخ تاریخچه را بازنویسی نمی‌کند.'),
    'REVIEW_PRICE_STREAM_NOT_FRESH': ('جریان قیمت پیشنهادهای ادمین هنوز تازه نیست.', 'پس از اتصال دوباره و دریافت قیمت تازه، بررسی خودکار تکرار می‌شود؛ سیگنال دیررس فرستاده نمی‌شود.'),
    'CHART_ANALYSIS_MARKET_IDENTITY_MISMATCH': (
        'منبع یا محصول کندل تحلیل با نمودار انتخاب‌شده یکسان نیست.',
        'نمودار همان منبع دوباره بارگذاری شود؛ تحلیل منبع دیگر روی این نمودار نمایش داده نمی‌شود.'),
    'BIQUOTE_HISTORY_IDENTITY_INVALID': (
        'نماد یا تایم‌فریم پاسخ منبع رایگان با درخواست منطبق نیست.',
        'پاسخ منبع بررسی شود؛ طلا یا جفت‌ارز دیگری جایگزین پنهان نمی‌شود.'),
    'BIQUOTE_HISTORY_INVALID': (
        'زمان، ترتیب، وضعیت بسته‌شدن یا OHLC کندل‌های biquote معتبر نیست.',
        'پاسخ ناقص برای تحلیل استفاده نشود؛ منبع جایگزین از مسیر کنترل‌شده بررسی می‌شود.'),
    'STREAMDATA_BUDGET_STORAGE_UNAVAILABLE': (
        'دفتر پایدار سهمیهٔ StreamData در دسترس نیست؛ درخواست بدون شمارش ارسال نشد.',
        'اتصال پایگاه داده و سلامت دفتر سهمیه بررسی شود؛ این محافظ خاموش نمی‌شود.'),
    'STREAMDATA_API_TOKEN_MISSING': (
        'اتصال StreamData آمادهٔ پیکربندی است، اما توکن اختصاصی در محیط اجرا وجود ندارد.',
        'توکن همین حساب در STREAMDATA_API_TOKEN تنظیم و دسترسی کندل همان نماد آزمایش شود؛ این اتصال هنوز فعال تأیید نشده است.'),
    'STREAMDATA_TOKEN_REJECTED': (
        'سرویس StreamData توکن تنظیم‌شده را نپذیرفت.',
        'اعتبار توکن و مجوز تاریخچهٔ همین حساب بررسی شود.'),
    'STREAMDATA_SYMBOL_NOT_CONFIGURED': (
        'نام نماد در فهرست تنظیم‌شدهٔ StreamData وجود ندارد.',
        'نام دقیق نماد از فهرست سرویس‌دهنده در STREAMDATA_SYMBOLS_JSON ثبت شود؛ ارز تومانی جای جفت‌ارز جهانی نیست.'),
    'STREAMDATA_SYMBOL_MAP_INVALID': (
        'قالب نگاشت نمادهای StreamData معتبر نیست.',
        'نگاشت JSON نام‌های طلا/فارکس به شناسه‌های واقعی سرویس بررسی شود؛ شاخص CFD در این اتصال تأیید نشده است.'),
    'STREAMDATA_SYMBOL_UNAVAILABLE': (
        'StreamData برای این نماد داده ارائه نکرد.',
        'نام نماد و مجوز حساب از فهرست رسمی همان سرویس بررسی شود.'),
    'STREAMDATA_HISTORY_UNAVAILABLE': (
        'StreamData تاریخچهٔ قابل استفاده برنگرداند.',
        'توکن، پوشش نماد و تایم‌فریم بررسی شود؛ متن خام خطای منبع منتشر نمی‌شود.'),
    'STREAMDATA_CANDLE_ARRAYS_INVALID': (
        'آرایه‌های زمان و OHLC منبع هم‌اندازه و معتبر نیستند.',
        'دادهٔ ناقص برای ساخت کندل استفاده نشود؛ پاسخ منبع بررسی شود.'),
    'STREAMDATA_CANDLE_TIME_INVALID': (
        'زمان کندل تاریخچه با قرارداد ثانیهٔ UTC منطبق نیست.',
        'واحد و مرز زمان منبع بررسی شود؛ زمان به‌صورت حدسی گرد یا تبدیل نمی‌شود.'),
    'STREAMDATA_MINUTE_BUDGET_EXHAUSTED': (
        'بودجهٔ محافظتی این دقیقهٔ StreamData مصرف شده است.',
        'تا بازشدن سهمیه صبر شود؛ منبع جایگزینِ مجاز می‌تواند استفاده شود.'),
    'STREAMDATA_DAILY_BUDGET_EXHAUSTED': (
        'بودجهٔ محافظتی روزانهٔ StreamData مصرف شده است.',
        'بازنشانی بر اساس UTC است؛ سقف تنظیم‌شده و قرارداد همین حساب بررسی شود.'),
    'CLOSED_CANDLE_CORRECTION_REQUIRES_REVIEW': (
        'منبع، کندل بستهٔ ذخیره‌شده را تغییر داده است؛ سابقه بازنویسی نشد.',
        'تفاوت داده با سابقه بررسی شود؛ تا تصمیم روشن، طرح تازه از این مجموعه ساخته نمی‌شود.'),
    'CANDLE_PROVENANCE_CHANGE_REQUIRES_REVIEW': (
        'هویت محصول یا مشخصات کندل با سابقهٔ همان منبع تغییر کرده است.',
        'نماد و محصول منبع بررسی شود؛ ادغام تاریخچه انجام نمی‌شود.'),
    'TWELVE_DATA_MINUTE_BUDGET_EXHAUSTED': (
        'بودجهٔ محافظتی درخواست‌های این دقیقه مصرف شده است.',
        'تا دقیقهٔ بعد صبر شود؛ تحلیل‌های قبلی و قیمت مرجع جداگانه باقی می‌مانند.'),
    'TWELVE_DATA_DAILY_BUDGET_EXHAUSTED': (
        'بودجهٔ محافظتی روزانهٔ Twelve Data مصرف شده است.',
        'در صورت پوشش، منبع دیگر استفاده می‌شود؛ بازنشانی روزانه بر اساس UTC است.'),
    'TWELVE_DATA_NON_GOLD_BUDGET_EXHAUSTED': (
        'بودجهٔ سایر نمادها برای حفظ اعتبار طلا محدود شده است.',
        'فارکس از منبع جایگزین بررسی شود؛ درخواست Twelve Data تا بازنشانی روزانه تکرار نشود.'),
    'MARKET_DATA_STALE_OR_SESSION_CLOSED': (
        'آخرین کندل برای تحلیل جدید تازه نیست یا بازار بسته است.',
        'داده با زمان اصلی نمایش داده می‌شود؛ پس از دریافت کندل تازه تحلیل ادامه می‌یابد.'),
    'INDICATOR_WARMUP_INCOMPLETE': (
        'تاریخچهٔ کندل برای محاسبهٔ کامل اندیکاتورها کافی نیست.',
        'حداقل ۱۰۵ کندل بسته از همان منبع لازم است.'),
    'DELAYED_ANALYSIS_SOURCE': (
        'منبع داده با برچسب تأخیر مشخص شده است.',
        'این داده برای سیگنال پیش از لمس کافی نیست؛ منبع تازهٔ همان محصول لازم است.'),
    'INVALID_ANALYSIS_CANDLES': (
        'ترتیب یا هویت کندل‌های تحلیل معتبر نیست.',
        'پاسخ منبع بررسی شود؛ کندل منابع مختلف ترکیب نمی‌شود.'),
    'CORE_NATIVE_LIVE_SOURCE_NOT_CONFIGURED': (
        'مسیر فعلی این بازار هنوز منبع یکپارچهٔ کندل و قیمت ورودِ معتبر ندارد.',
        'کندل، Bid/Ask دارای زمان UTC و مشخصات نماد از یک منبع قابل دسترس وصل شود؛ برای شاخص‌ها محصول باید همان CFD باشد.'),
    'REQUESTED_CFD_HISTORY_UNAVAILABLE_CASH_INDEX_IS_DIFFERENT_PRODUCT': (
        'دادهٔ فعلی شاخص نقدی است؛ کندل CFD موردنظر در دسترس نیست.',
        'کندل و Bid/Ask همان نماد CFD از یک بروکر مشخص وصل شود؛ تغییر نام شاخص کافی نیست.'),
    'MATCHING_SPREAD_AND_TICK_SIZE_UNVERIFIED': (
        'کندل موجود است، اما Bid/Ask و اندازهٔ گام قیمتِ منطبق تأیید نشده‌اند.',
        'جریان دارای زمان UTC و مشخصات نماد از همان منبع کندل لازم است؛ برای فارکس اندازهٔ pip هم باید مشخص باشد.'),
    'TWELVE_DATA_API_KEY_MISSING': (
        'کلید Twelve Data در محیط اجرای فعلی تنظیم نشده است.',
        'مقدار موجود TWELVE_DATA_API_KEY در متغیرهای سرور تنظیم و دسترسی همین نماد آزمایش شود.'),
    'TWELVE_DATA_BARS_UNAVAILABLE': (
        'منبع Twelve Data کندل قابل استفاده برنگرداند.',
        'نماد، تایم‌فریم و دسترسی دادهٔ همین حساب بررسی شود.'),
    'MARKET_BARS_EMPTY': (
        'پاسخ منبع فاقد کندل است.',
        'پوشش نماد، ساعات بازار و دسترسی منبع بررسی شود.'),
    'MARKET_PROVIDER_MISMATCH': (
        'منبع انتخاب‌شده این بازار را در مسیر فعلی پوشش نمی‌دهد.',
        'منبع پشتیبانی‌شدهٔ همان محصول انتخاب شود؛ جایگزینی پنهان منبع مجاز نیست.'),
}


def safe_market_error(exc):
    """Only internally bounded codes may leave the server, never raw URLs/keys."""
    from services.canonical_market_service import MarketUnavailable
    if isinstance(exc, (MarketUnavailable, ValueError)) and str(exc) in ISSUES:
        return str(exc)
    if isinstance(exc, MarketUnavailable):
        code = str(exc)
        if code in ISSUES or re.fullmatch(r'PROVIDER_(?:HTTP|ERROR)_[1-5]\d{2}', code):
            return code
        if re.fullmatch(r'PROVIDER_TRANSPORT_[A-Za-z]{1,64}', code):
            return code
    return 'MARKET_DATA_REQUEST_FAILED'


def data_block(reason, **details):
    text = ISSUES.get(reason)
    if text is None and reason in {'PROVIDER_ERROR_401','PROVIDER_ERROR_403','PROVIDER_HTTP_401','PROVIDER_HTTP_403'}:
        text = ('منبع داده درخواست را نپذیرفت؛ احراز هویت یا مجوز دسترسی این بازار باید بررسی شود.',
                'اعتبار کلید و دسترسی همان حساب به همین نماد بررسی شود؛ پرداخت یا اشتراک جدید خودکار انجام نمی‌شود.')
    elif text is None and reason in {'PROVIDER_ERROR_429','PROVIDER_HTTP_429'}:
        text = ('سهمیهٔ درخواست منبع داده کافی نیست یا موقتاً محدود شده است.',
                'تا بازشدن سهمیه صبر و تعداد درخواست‌ها متناسب با سهمیه تنظیم شود؛ درخواست مجدد سریع انجام نشود.')
    elif text is None and reason in {'PROVIDER_ERROR_404','PROVIDER_HTTP_404'}:
        text = ('مسیر یا نماد در منبع داده پیدا نشد.',
                'نام معتبر نماد و پوشش محصول در همین منبع بررسی شود؛ شاخص نقدی به‌جای CFD جا زده نمی‌شود.')
    elif text is None and reason in {'PROVIDER_ERROR_400','PROVIDER_HTTP_400'}:
        text = ('منبع داده پارامترها یا نماد درخواست را نپذیرفت.',
                'نگاشت نماد، تایم‌فریم و مشخصات درخواست با قرارداد منبع تطبیق داده شود.')
    elif text is None:
        text = ('دریافت دادهٔ معتبر این بازار کامل نشد.',
                'دسترسی شبکه و سلامت منبع بررسی شود؛ تا رفع مشکل، ورود یا هدف حدس زده نمی‌شود.')
    return {'state':'NEEDS_REVIEW','production_qualified':False,'results':[],
            'reason':reason,'explanation_fa':text[0],'required_action_fa':text[1],**details}


def automatic_source_block(symbol, timeframe):
    """Candle observations are available independently of live execution."""
    return None
