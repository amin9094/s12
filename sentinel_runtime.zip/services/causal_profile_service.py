"""Fetch only the causal wave windows that actually need a minute profile."""
from dataclasses import replace
import time
from core.async_runtime import run_blocking
from repositories.v2.market_evidence import MarketEvidenceRepository


async def wave_profile(context,*,engine_parameters=(),fetch=None,repository=None):
    from modules.strategies.order_block.engine import OrderBlockVolume
    from services.canonical_market_service import historical_bars
    fetch=fetch or historical_bars;repo=repository or MarketEvidenceRepository()
    contexts=[context]+[replace(context,parameters=p) for name,p in engine_parameters if name=='order_block']
    windows=[]
    for current in contexts:
        for item in OrderBlockVolume().evaluate(current):
            wave=item.get('causal_wave')
            if wave:windows.append((wave['start_ms'],wave['end_ms']))
    if not windows:return ()
    start=min(x[0] for x in windows);end=max(x[1] for x in windows)
    source=context.candles[-1];identity=(source.symbol,source.provider,source.venue,source.product)
    collected={};before=end+1
    # The limit follows the actual wave, including long H1 waves; it is not an
    # arbitrary six-page cap. Each response is still bounded and shared-cached.
    pages=min(256,max(1,(end-start+17999999)//18000000+1))
    for _ in range(pages):
        cached=await run_blocking(repo.candles,source.symbol,source.provider,'1m',before_ms=before,limit=300,timeout=5)
        usable=[b for b in cached if b.is_closed and b.available_ms<=context.cutoff_ms]
        complete=bool(usable) and usable[-1].end_ms>=min(before-1,end) and all(a.end_ms==b.start_ms for a,b in zip(usable,usable[1:]))
        rows=usable if complete else await fetch(source.symbol,'1m',limit=300,before_ms=before,provider=source.provider)
        if not rows:break
        if any((b.symbol,b.provider,b.venue,b.product)!=identity for b in rows):raise ValueError('POC_MARKET_MISMATCH')
        if not complete:await run_blocking(repo.save_candles,rows,timeout=10)
        observed_ms=max(context.cutoff_ms,int(time.time()*1000))
        for b in rows:
            if b.is_closed and b.available_ms<=observed_ms and any(b.start_ms>=a and b.end_ms<=z for a,z in windows):
                collected[b.start_ms]=b
        oldest=min(b.start_ms for b in rows)
        if oldest<=start or oldest>=before:break
        before=oldest
    return tuple(collected[k] for k in sorted(collected))
