"""Bounded recurring research discovery and private admin notifications."""

from __future__ import annotations

import asyncio
import logging
import time
from weakref import WeakKeyDictionary

from core.async_runtime import run_blocking
from repositories.v2.strategy_outbox import StrategyOutboxRepository
from services.canonical_market_service import universe
from services.strategy_analysis_service import research_analysis
from services.strategy_review_queue_service import _save_analysis

_SCAN_DUE = WeakKeyDictionary()
_SCAN_FAILURES = WeakKeyDictionary()
_SCAN_LOCKS = WeakKeyDictionary()
MARKETS = ('gold', 'forex', 'crypto', 'indices')
logger = logging.getLogger(__name__)


def market_of(symbol):
    if symbol == 'XAUUSD':
        return 'gold'
    if symbol in {'US30', 'US100', 'NAS100'}:
        return 'indices'
    return 'crypto' if symbol.endswith('USDT') else 'forex'


def due_markets(symbols, profiles, cursor, now):
    """Each market and timeframe has its own quota; retries cannot steal it."""
    from modules.automated_market_scope import global_symbol_allowed
    symbols=[s for s in symbols if global_symbol_allowed(s)]
    if not symbols:return []
    due = _SCAN_DUE.setdefault(asyncio.get_running_loop(),{})
    profile_key = tuple((name,p.profile_id) for name,p in profiles)
    # Same Nasdaq cash chart alias must not consume two automatic requests.
    symbols = [symbol for symbol in symbols if symbol!='NAS100' or 'US100' not in symbols]
    indices = {'US30','US100','NAS100'}
    rotated = symbols[cursor%len(symbols):]+symbols[:cursor%len(symbols)]
    selected = []
    for market in MARKETS:
        for tf, capacity in [('5m', {'gold': 1, 'forex': 2, 'crypto': 3, 'indices': 1}[market]), ('1h', 1)]:
            # Never let frequently failing symbols overtake as-yet unscanned ones.
            ordered = sorted((s for s in rotated if market_of(s) == market),
                             key=lambda s: due.get((s, tf, profile_key), 0))
            for symbol in ordered:
                key = (symbol,tf,profile_key)
                if due.get(key,0)>now:
                    continue
                period = (1800 if tf=='5m' else 14400) if symbol in indices else (300 if tf=='5m' else 3600)
                due[key] = (int(now)//period+1)*period+15
                selected.append((symbol,tf))
                capacity -= 1
                if capacity==0:
                    break
    return selected


def review_message(review):
    title = review.get("title_fa") or "نیازمند بررسی ادمین"
    lines = [title, f"{review.get('symbol', '')} · {review.get('timeframe', '')} · {review.get('engine', '')}"]
    if review.get("original_zone"):
        lines.append("محدودهٔ اصلی: " + " — ".join(review["original_zone"]))
    if review.get("poc"):
        poc = review["poc"]
        lines.append(f"POC: {poc.get('price', '—')} · {poc.get('proxy_label_fa', poc.get('volume_kind', ''))}")
    if review.get("fib_061"):
        lines.append(f"فیبوناچی ۰٫۶۱: {review['fib_061']}")
    if review.get("explanation_fa"):
        lines.append(review["explanation_fa"])
    if review.get('required_action_fa'):
        lines.append('اقدام لازم: ' + review['required_action_fa'])
    if review.get('observation'):
        subject=review['observation']
        lines.append(f"منبع: {subject['provider']} · {subject['venue']} · {subject['product']}")
        lines.append('جهت مشاهده: ' + subject['direction'])
        lines.append('این محدوده سیگنال ورود نیست؛ Bid/Ask، تازگی کامل و مدیریت ریسک هنوز تأیید نشده‌اند.')
        factors=review.get('fibonacci_confirmation',{}).get('confirmations',[])
        lines.append('تأییدهای هندسی فیبوناچی: ' + str(len(factors)))
    if review.get("draft_plan"):
        p = review["draft_plan"]
        lines.append(f"پیشنهاد پژوهشی: Entry {p['entry']} · SL {p['stop']} · TP1 {p['tp1']} · TP2 {p['tp2']}")
    lines.append("این مورد برای بررسی است؛ انتشار عمومی یا اجرای معامله انجام نشده است.")
    return "\n".join(lines)[:3500]


async def deliver_reviews(bot, admin_ids):
    """Drain legacy notices into the desk; never push analysis to Telegram."""
    repository = StrategyOutboxRepository()
    allowed = {str(int(value)) for value in admin_ids}
    rows = await run_blocking(repository.claim, timeout=5)
    for row in rows:
        if row['admin_id'] not in allowed:
            await run_blocking(repository.finish,row['id'],'REVOKED',claim_token=row['payload'].get('claim_token'),timeout=5)
            continue
        if row['payload']['review'].get('review_kind')=='PREENTRY_PROPOSAL':
            from services.live_signal_service import stage_results
            from services.strategy_quote_owner import current_owner
            await stage_results({'new_review_ids':[row['review_id']]},current_owner())
        await run_blocking(repository.finish,row['id'],'SENT',detail='STORED_IN_PRIVATE_DESK_NO_PUSH',claim_token=row['payload'].get('claim_token'),timeout=5)
    return len(rows)


async def scan_cycle(bot, admin_ids, *, cursor=0, settings=None, market=None):
    """Independent runtime leases call one market; explicit full scans run them concurrently."""
    if market not in (None, *MARKETS):
        raise ValueError('SCAN_MARKET_INVALID')
    settings = settings or {}
    if not settings.get("enabled", True) or not admin_ids:
        return {"cursor": cursor, "state": "PAUSED", "analyzed": 0}
    if market is None:
        results = await asyncio.gather(*(scan_cycle(bot, admin_ids, cursor=cursor, settings=settings, market=m)
                                         for m in MARKETS), return_exceptions=True)
        reports = [r if isinstance(r, dict) else {'market': m, 'state': 'SCAN_FAILED', 'analyzed': 0}
                   for m, r in zip(MARKETS, results)]
        return {'cursor': cursor + max(1, sum(r.get('attempted', 0) for r in reports)),
                'state': 'RESEARCH_SCANNING_WITH_DATA_GAPS' if any(r['state'] in {'SCAN_FAILED', 'MARKET_UNIVERSE_UNAVAILABLE', 'RESEARCH_SCANNING_WITH_DATA_GAPS'} for r in reports) else 'RESEARCH_SCANNING',
                **{k: sum(r.get(k, 0) for r in reports) for k in ('analyzed', 'attempted', 'completed_analyses', 'skipped_missing_live_source')},
                'blocked_markets': [g for r in reports for g in r.get('blocked_markets', [])],
                'markets': reports, 'production_qualified': False, 'public_auto_publish': False}
    locks = _SCAN_LOCKS.setdefault(asyncio.get_running_loop(), {})
    lock = locks.setdefault(market, asyncio.Lock())
    if lock.locked():
        return {'cursor': cursor, 'market': market, 'state': 'ALREADY_RUNNING', 'analyzed': 0}
    async with lock:
        return await _scan_market(bot, admin_ids, cursor=cursor, settings=settings, market=market)


async def _scan_market(bot, admin_ids, *, cursor, settings, market):
    from services.canonical_market_service import CORE_SYMBOLS
    directory_state = None
    if market == 'indices' and not settings.get('indices_enabled', False):
        return {'cursor': cursor, 'market': market, 'state': 'PAUSED', 'analyzed': 0}
    if market == 'crypto':
        try:
            async with asyncio.timeout(12):
                directory = await universe()
            symbols = list(dict.fromkeys(row['symbol'] for row in directory['crypto_top20']))
            directory_state = directory.get('crypto_ranking_state')
        except Exception:
            symbols = []
            directory_state = 'CRYPTO_DIRECTORY_UNAVAILABLE'
    else:
        symbols = list(CORE_SYMBOLS)
    symbols = [s for s in symbols if market_of(s) == market]
    if not symbols:
        return {"cursor": cursor, 'market': market, "state": "MARKET_UNIVERSE_UNAVAILABLE", "analyzed": 0,
                'directory_state': directory_state}
    from services.live_signal_service import scanner_parameters
    profiles = await run_blocking(scanner_parameters, settings, timeout=10)
    selected = due_markets(symbols,profiles,cursor,time.time())
    semaphore = asyncio.Semaphore(2)

    async def analyze_inner(symbol, timeframe):
        async with semaphore:
            try:
                from services.market_data_issues import automatic_source_block
                result = automatic_source_block(symbol,timeframe)
                if result is None:
                    async with asyncio.timeout(20):
                        from services.keyless_market_data_service import supported_symbols
                        review={'admin_review':True} if symbol in supported_symbols() and settings.get('admin_review_proposals',True) else {}
                        result = await research_analysis(symbol, timeframe, engine_parameters=profiles,**review)
            except Exception as exc:
                from services.market_data_issues import data_block, safe_market_error
                result = data_block(safe_market_error(exc))
            result = dict(result)
            from repositories.v2.strategy_paths import strategy_enabled
            result['results']=[r for r in result.get('results',[]) if r.get('engine') not in {'indicators','sweep_fvg','order_block','fibonacci_pullback','custom'} or await run_blocking(strategy_enabled,r['engine'],timeout=5)]
            blocked = not result.get('results') and result.get('state') in {'NEEDS_REVIEW','UNAVAILABLE'}
            if blocked:
                result["results"] = [{"engine": "market_data", "symbol": symbol, "timeframe": timeframe,
                                       "state": "NEEDS_REVIEW", "reason": result.get("reason", "MARKET_DATA_UNAVAILABLE"),
                                       "title_fa": "نیازمند بررسی: اتصال دادهٔ این بازار کامل نیست",
                                       "available_ms": int(time.time() * 1000),
                                       **{key:result[key] for key in ('explanation_fa','required_action_fa','provider','product','data_gap') if key in result}}]
            from repositories.v2.desk_insights import record_scan
            from core.storage.engine import normalized_engine
            await run_blocking(record_scan,normalized_engine(),symbol,timeframe,result,timeout=5)
            from services.strategy_quote_owner import current_owner
            owner=current_owner()
            saved = await owner.prepare_result(result) if owner else await run_blocking(_save_analysis,result,timeout=10)
            from services.live_signal_service import stage_results
            await stage_results(saved,owner)
            return {'symbol':symbol,'timeframe':timeframe,'blocked':blocked,
                    'automatic_request_skipped':result.get('automatic_request_skipped',False),
                    'reason':result.get('reason','') if blocked else ''}

    async def analyze(symbol, timeframe):
        # Include persistence/staging in the deadline. One failed save or plan
        # must not cancel other symbols or hold another market's runtime job.
        try:
            async with asyncio.timeout(24):
                return await analyze_inner(symbol, timeframe)
        except Exception:
            logger.exception('Strategy case failed: market=%s symbol=%s timeframe=%s', market, symbol, timeframe)
            return {'symbol': symbol, 'timeframe': timeframe, 'blocked': True,
                    'automatic_request_skipped': False, 'reason': 'SCAN_CASE_FAILED'}

    # The deadline starts after acquiring this market's bounded execution slot.
    async def queued(symbol, timeframe):
        async with admission:
            return await analyze(symbol, timeframe)
    admission = asyncio.Semaphore(2)
    outcomes = await asyncio.gather(*(queued(*case) for case in selected))
    gaps=[row for row in outcomes if row['blocked']]
    # A transient source failure should be retried within the same candle,
    # while provider cooldown/budget gates still prevent a request storm.
    due=_SCAN_DUE.setdefault(asyncio.get_running_loop(),{})
    profile_key=tuple((name,p.profile_id) for name,p in profiles)
    failures = _SCAN_FAILURES.setdefault(asyncio.get_running_loop(), {})
    for row in outcomes:
        key=(row['symbol'],row['timeframe'],profile_key)
        if not row['blocked']:
            failures.pop(key, None)
            continue
        failures[key] = min(6, failures.get(key, 0) + 1)
        delay = 300 if row['reason'] == 'MARKET_DATA_STALE_OR_SESSION_CLOSED' else min(300, 30 * 2 ** (failures[key] - 1))
        due[key] = time.time() + delay
    skipped=sum(row['automatic_request_skipped'] for row in outcomes)
    return {"cursor": cursor + max(1,len(selected)), 'market': market, 'directory_state': directory_state, "state": "RESEARCH_SCANNING_WITH_DATA_GAPS" if gaps else "RESEARCH_SCANNING", "analyzed": len(selected)-skipped,
            'attempted':len(selected),'completed_analyses':len(selected)-len(gaps),'blocked_markets':gaps,
            'skipped_missing_live_source':skipped,
            "production_qualified": False, "public_auto_publish": False}
