"""User-facing export of legacy learning state and normalized owned records."""
from __future__ import annotations

import json
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from modules.privacy import export_user_data
from repositories.v2.common import json_load

EXPORT_TABLES = (
    "v8_trading_accounts", "v8_positions", "v8_position_pnl_events",
    "v8_equity_events", "v8_journal_entries", "v8_broker_snapshots", "v8_prop_rule_evaluations",
    "v8_checkout_quotes", "v8_vip_orders", "v8_vip_entitlements",
    "v8_tickets", "v8_risk_daily_plans", "v8_risk_checkins", "v8_prop_alerts",
)
JOURNAL_FIELDS = {"entry_reason_type", "entry_reason", "note", "result_r", "fees",
                  "commission", "swap", "partial_close_history", "actual_stop"}
PAYLOAD_FIELDS = {
    "v8_journal_entries": JOURNAL_FIELDS,
    "v8_risk_checkins": {"emotion", "confidence", "followed_plan", "moved_stop", "note"},
}
PREFERENCE_SECTIONS = {"user_watchlists", "economic_calendar_preferences", "personal_risk_profiles",
                       "miniapp_onboarding", "user_signal_choices", "signal_revision_acknowledgements"}


def complete_user_export(db: dict[str, Any], user_id: int | str, *, engine: DatabaseEngine | None = None) -> dict[str, Any]:
    output = export_user_data(db, user_id)
    output["schema"] = "sentinel-user-export-v2"
    uid = str(int(user_id))
    storage = engine or normalized_engine()
    records: dict[str, Any] = {}
    with storage.transaction(read_only=True, repeatable_read=True) as cursor:
        for table in EXPORT_TABLES:
            rows = cursor.execute(f"SELECT * FROM {table} WHERE user_id=?", (uid,)).fetchall()  # nosec B608 -- constant inventory
            if not rows:
                continue
            records[table] = []
            for row in rows:
                item = {key: value for key, value in row.items() if key not in {"payload", "receipt_key"}}
                if table in PAYLOAD_FIELDS:
                    payload = json_load(row.get("payload"), {})
                    if isinstance(payload, dict):
                        item.update({key: payload[key] for key in PAYLOAD_FIELDS[table] if key in payload})
                records[table].append(item)
        records["v8_daily_account_snapshots"] = [
            {key: value for key, value in row.items() if key != "payload"}
            for row in cursor.execute("""SELECT s.* FROM v8_daily_account_snapshots s
                JOIN v8_trading_accounts a ON a.id=s.account_id WHERE a.user_id=?""", (uid,)).fetchall()
        ]
        messages = cursor.execute("""SELECT m.id,m.ticket_id,m.sender_type,m.body,m.created_at
            FROM v8_ticket_messages m JOIN v8_tickets t ON t.id=m.ticket_id
            WHERE t.user_id=? AND m.sender_type IN ('user','admin','system')
            ORDER BY m.created_at,m.id""", (uid,)).fetchall()
        if messages:
            records["v8_ticket_messages"] = messages
        preferences = cursor.execute("SELECT section,updated_at,payload FROM v8_user_preferences WHERE user_id=?", (uid,)).fetchall()
        records["v8_user_preferences"] = [
            {"section": row["section"], "updated_at": row["updated_at"], "value": json_load(row.get("payload"), {})}
            for row in preferences if row["section"] in PREFERENCE_SECTIONS
        ]
        # Receipt object keys and connector credentials are never exported.
        records["v8_receipts"] = cursor.execute("""SELECT id,checksum,mime_type,size_bytes,status,order_id,created_at
            FROM v8_receipts WHERE user_id=?""", (uid,)).fetchall()
        records["v8_mt5_connectors"] = cursor.execute("""SELECT id,account_id,platform,account_login,broker,
            server_name,account_name,status,readonly_mode,last_seen_at,created_at,revoked_at
            FROM v8_mt5_connectors WHERE user_id=?""", (uid,)).fetchall()
    output["records"]["normalized"] = records
    return output


def complete_user_json(db: dict[str, Any], user_id: int | str) -> bytes:
    return json.dumps(complete_user_export(db, user_id), ensure_ascii=False, indent=2, default=str).encode("utf-8")
