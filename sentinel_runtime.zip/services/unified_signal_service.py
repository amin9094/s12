from __future__ import annotations

from typing import Any

from core.db import read_db_sections
from repositories.v2.signals import SignalRepository


def _projectable(row: Any, *, archived: bool = False) -> dict[str, Any] | None:
    if not isinstance(row, dict) or not row.get("id"):
        return None
    payload = dict(row)
    payload["source"] = str(payload.get("source") or "telegram_bot")
    if archived:
        payload["status"] = "archived"
        payload["updated_at"] = payload.get("archived_at") or payload.get("updated_at") or payload.get("created_at")
    return payload


def sync_legacy_signals_to_normalized(*, include_archive: bool = True, limit: int = 3000) -> dict[str, int]:
    """One-time migration was completed; runtime dual-sync is disabled."""
    return {"current": 0, "archived": 0, "errors": 0, "single_source": 1}
