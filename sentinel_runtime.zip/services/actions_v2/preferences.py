from __future__ import annotations

from typing import Any

from core.db import with_db
from modules.portfolio import remove_watchlist_symbol, set_watchlist_alerts, toggle_watchlist_symbol, watchlist_for_user

from repositories.v2.common import utc_iso
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action


@action("watchlist_toggle")
def watchlist_toggle(ctx: ActionContext) -> dict[str, Any]:
    symbol = str(ctx.payload.get("symbol") or "").upper().replace("/", "").strip()
    if not symbol:
        raise ValueError("INVALID_SYMBOL")
    added, item = with_db(lambda db: toggle_watchlist_symbol(db, ctx.user_id, symbol))
    items = with_db(lambda db: [dict(row) for row in watchlist_for_user(db, ctx.user_id)])
    # Project the same list into row-level preferences so every Mini App read
    # and every Telegram handler sees one logical watchlist.
    ctx.preferences.set(ctx.user_id, "user_watchlists", items)
    return {"added": added, "item": item, "items": items}


@action("watchlist_remove")
def watchlist_remove(ctx: ActionContext) -> dict[str, Any]:
    symbol = str(ctx.payload.get("symbol") or "").upper().replace("/", "").strip()
    removed = with_db(lambda db: remove_watchlist_symbol(db, ctx.user_id, symbol))
    items = with_db(lambda db: [dict(row) for row in watchlist_for_user(db, ctx.user_id)])
    ctx.preferences.set(ctx.user_id, "user_watchlists", items)
    return {"removed": removed, "items": items}


@action("watchlist_alerts")
def watchlist_alerts(ctx: ActionContext) -> dict[str, Any]:
    symbol = str(ctx.payload.get("symbol") or "").upper().replace("/", "").strip()
    updated = with_db(lambda db: set_watchlist_alerts(db, ctx.user_id, symbol, bool(ctx.payload.get("enabled", True))))
    items = with_db(lambda db: [dict(row) for row in watchlist_for_user(db, ctx.user_id)])
    ctx.preferences.set(ctx.user_id, "user_watchlists", items)
    return updated


@action("notification_preferences_update")
def notification_preferences_update(ctx: ActionContext) -> dict[str, Any]:
    from modules.admin_control_center import (
        NOTIFICATION_KEYS, notification_preferences, set_notification_timezone,
        set_notification_quiet_hours, set_notification_digest_time,
    )
    from core.utils import parse_dt
    payload = dict(ctx.payload)
    # Older clients called the quiet-hours switch "quiet".
    if "quiet" in payload and "quiet_enabled" not in payload:
        payload["quiet_enabled"] = payload.pop("quiet")
    bool_keys = {key for key, _ in NOTIFICATION_KEYS} | {"quiet_enabled"}
    allowed = bool_keys | {"quiet_start", "quiet_end", "timezone", "paused_until",
                           "markets", "symbols", "digest_time", "weekly_digest_day"}
    if set(payload) - allowed:
        raise ValueError("INVALID_NOTIFICATION_FIELD")
    if any(not isinstance(payload[key], bool) for key in bool_keys & payload.keys()):
        raise ValueError("INVALID_NOTIFICATION_BOOLEAN")
    if "weekly_digest_day" in payload and (type(payload["weekly_digest_day"]) is not int or not 0 <= payload["weekly_digest_day"] <= 6):
        raise ValueError("INVALID_DIGEST_DAY")
    if payload.get("paused_until") is not None and "paused_until" in payload:
        value = payload["paused_until"]
        paused = parse_dt(value) if isinstance(value, str) else None
        if paused is None:
            raise ValueError("INVALID_NOTIFICATION_PAUSE")
        payload["paused_until"] = paused.isoformat()
    for key in ("markets", "symbols"):
        if key in payload:
            if not isinstance(payload[key], list) or len(payload[key]) > 100 or any(not isinstance(v, str) or len(v) > 64 for v in payload[key]):
                raise ValueError("INVALID_NOTIFICATION_FILTER")

    def update(db):
        pref = notification_preferences(db, ctx.user_id)
        if "timezone" in payload:
            payload["timezone"] = set_notification_timezone(db, ctx.user_id, payload["timezone"])
        if "quiet_start" in payload or "quiet_end" in payload:
            start, end = set_notification_quiet_hours(db, ctx.user_id,
                payload.get("quiet_start", pref["quiet_start"]), payload.get("quiet_end", pref["quiet_end"]),
                enabled=payload.get("quiet_enabled", pref["quiet_enabled"]))
            payload.update(quiet_start=start, quiet_end=end)
        if "digest_time" in payload:
            payload["digest_time"] = set_notification_digest_time(db, ctx.user_id, payload["digest_time"])
        pref.update(payload)
        pref["updated_at"] = utc_iso()
        return dict(pref)
    return with_db(update)


@action("calendar_preferences_update")
def calendar_preferences_update(ctx: ActionContext) -> dict[str, Any]:
    return ctx.preferences.patch(ctx.user_id, "economic_calendar_preferences", ctx.payload)


@action("onboarding_update")
def onboarding_update(ctx: ActionContext) -> dict[str, Any]:
    with ctx.engine.atomic():
        return _onboarding_update(ctx)

def _onboarding_update(ctx: ActionContext) -> dict[str, Any]:
    """Persist first-run setup and create the user's default trading account.

    Mini App setup is an idempotent one-time mutation.  Earlier versions only
    patched the answers and never stored ``completed=True`` on the normalized
    preference row, so the onboarding modal reopened on every launch.
    """
    payload = dict(ctx.payload or {})
    experience = str(payload.get("experience") or "").strip().lower()
    goal = str(payload.get("goal") or "").strip().lower()
    market = str(payload.get("market") or "both").strip().lower()
    tolerance = str(payload.get("risk_tolerance") or "balanced").strip().lower()
    if experience not in {"beginner", "intermediate", "advanced", "professional"}:
        raise ValueError("INVALID_EXPERIENCE")
    if goal not in {"education", "signals", "prop", "journal", "growth", "income"}:
        raise ValueError("INVALID_GOAL")
    if market not in {"forex", "crypto", "both"}:
        raise ValueError("INVALID_MARKET")
    if tolerance not in {"conservative", "balanced", "aggressive"}:
        raise ValueError("INVALID_RISK_TOLERANCE")

    balance = float(payload.get("balance") or payload.get("account_size") or 0)
    equity = float(payload.get("equity") if payload.get("equity") is not None else balance)
    if balance <= 0 or equity <= 0:
        raise ValueError("ACCOUNT_BALANCE_REQUIRED")
    account_name = str(payload.get("account_name") or "حساب 1").strip()[:80] or "حساب 1"
    professional_raw = payload.get("professional")
    professional = (
        professional_raw is True
        or str(professional_raw or "").strip().lower() in {"1", "true", "yes", "professional", "pro"}
        or experience == "professional"
    )
    now = utc_iso()
    previous = ctx.preferences.get(ctx.user_id, "miniapp_onboarding", {})
    previous = previous if isinstance(previous, dict) else {}
    values = {
        "experience": experience,
        "professional": professional,
        "market": market,
        "account_name": account_name,
        "account_size": balance,
        "balance": balance,
        "equity": equity,
        "risk_tolerance": tolerance,
        "goal": goal,
        "completed": True,
        "completed_at": previous.get("completed_at") or now,
        "setup_version": 2,
        "updated_at": now,
    }
    data = ctx.preferences.patch(ctx.user_id, "miniapp_onboarding", values)

    plan = {
        "conservative": (0.5, 2.0, 3.0),
        "balanced": (1.0, 3.0, 5.0),
        "aggressive": (1.5, 4.0, 6.0),
    }.get(tolerance, (1.0, 3.0, 5.0))
    account = ctx.accounts.get(ctx.user_id)
    account_values: dict[str, Any] = {
        "name": account_name,
        "type": "personal",
        "phase": "personal",
        "currency": str(payload.get("currency") or "USD").upper()[:10],
        "balance": balance,
        "equity": equity,
        "starting_balance": float(account.get("starting_balance") or balance) if account else balance,
        "is_default": True,
        "default_risk_percent": plan[0],
        "max_daily_risk_percent": plan[1],
        "max_open_risk_percent": plan[2],
        "data_source": "manual",
        "data_confidence": 0.9,
        "data_observed_at": now,
    }
    account = ctx.accounts.upsert(ctx.user_id, account_values, account_id=account.get("id") if account else None)
    ctx.accounts.record_equity(
        ctx.user_id,
        account["id"],
        balance=balance,
        equity=equity,
        source="manual",
        confidence=0.9,
        observed_at=now,
        payload={"source": "miniapp_onboarding", "setup_version": 2, "request_id": ctx.request_id},
    )
    account = ctx.accounts.get(ctx.user_id, account["id"]) or account
    return {"onboarding": data, "account": account, "completed": True}


@action("language_update")
def language_update(ctx: ActionContext) -> dict[str, Any]:
    language = str(ctx.payload.get("language") or "fa").lower()
    if language not in {"fa", "en"}:
        raise ValueError("INVALID_LANGUAGE")
    from modules.i18n import set_user_language
    def update(db):
        set_user_language(db, ctx.user_id, language, selected_at=utc_iso())
        return {"language": language, "profile": dict(db["user_profiles"][str(ctx.user_id)])}
    return with_db(update)


@action("rules_accept")
def rules_accept(ctx: ActionContext) -> dict[str, Any]:
    from modules.rules import current_rules, accept_current_rules
    language = str(ctx.payload.get("language") or "fa")
    if language not in {"fa", "en"}:
        raise ValueError("INVALID_LANGUAGE")
    def accept(db):
        state = current_rules(db, language)
        if not state.get("text") or int(state.get("version") or 0) <= 0:
            raise ValueError("RULES_NOT_PUBLISHED")
        if int(ctx.payload.get("version") or 0) != int(state["version"]) or str(ctx.payload.get("content_hash") or "") != state["content_hash"]:
            raise ValueError("RULES_VERSION_CHANGED")
        row = accept_current_rules(db, ctx.user_id, language)
        row["source"] = "telegram_miniapp"
        return row
    return with_db(accept)
