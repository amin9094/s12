from core.db import with_db
from services.actions_v2.registry import action
from services.reward_claims import claim_reward


@action("reward_claim")
def reward_claim(ctx):
    reward_id = int(ctx.payload.get("reward_id", 0))
    # The authenticated identity and transport idempotency key are authoritative.
    source = f"shop:{ctx.user_id}:{reward_id}:{ctx.request_id}"

    def operation(db):
        kind, payload, error = claim_reward(db, ctx.user_id, reward_id, source)
        if kind == "error":
            raise ValueError(error)
        return {"kind": kind, "reward": payload.get("reward"), "code": payload.get("code", {}).get("code")}

    return with_db(operation)


@action("reward_seen")
def reward_seen(ctx):
    from modules.reward_wallet import mark_wallet_seen
    keys = ctx.payload.get("keys")
    if not isinstance(keys, list) or len(keys) > 5000:
        raise ValueError("REWARD_KEYS_INVALID")
    unread = with_db(lambda db: mark_wallet_seen(db, ctx.user_id, keys))
    return {"unread_rewards": unread}
