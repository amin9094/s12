"""Application services separated from Telegram routing."""
