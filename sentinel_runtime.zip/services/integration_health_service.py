from __future__ import annotations

from typing import Any

from core.db import read_db_sections, with_db
from core.utils import utc_iso
from repositories.v2.preferences import PreferenceRepository
from services.unified_signal_service import sync_legacy_signals_to_normalized
from services.vip_entitlement_projection import project_normalized_entitlements_to_legacy

# The contract is intentionally domain-oriented. Telegram handlers and Mini App
# endpoints are transport layers; both must converge on the same business state.
_SHARED_DOMAINS: tuple[dict[str, Any], ...] = (
    {
        "key": "signals",
        "label_fa": "سیگنال و نتیجه TP/SL",
        "label_en": "Signals and TP/SL outcomes",
        "source": "Telegram signal state + normalized signal projection",
        "direction": "bot_to_miniapp_and_user_choice_back_to_bot",
        "read_repair": True,
    },
    {
        "key": "support",
        "label_fa": "تیکت و پاسخ پشتیبانی",
        "label_en": "Support tickets and replies",
        "source": "shared support ticket store",
        "direction": "bidirectional",
        "read_repair": False,
    },
    {
        "key": "vip",
        "label_fa": "خرید VIP، رسید و دسترسی",
        "label_en": "VIP checkout, receipts and entitlement",
        "source": "normalized commerce + Telegram entitlement projection",
        "direction": "bidirectional",
        "read_repair": True,
    },
    {
        "key": "journal_risk",
        "label_fa": "ژورنال، پوزیشن و ریسک",
        "label_en": "Journal, positions and risk",
        "source": "normalized position/journal repositories",
        "direction": "bidirectional",
        "read_repair": False,
    },
    {
        "key": "watchlist",
        "label_fa": "واچ‌لیست و هشدارها",
        "label_en": "Watchlist and alerts",
        "source": "shared watchlist + normalized preference mirror",
        "direction": "bidirectional",
        "read_repair": True,
    },
    {
        "key": "market",
        "label_fa": "قیمت بازار جهانی و ایران",
        "label_en": "Global and Iran market prices",
        "source": "shared provider/cache service",
        "direction": "shared_read_model",
        "read_repair": True,
    },
    {
        "key": "admin_runtime",
        "label_fa": "دسترسی مدیر و روشن/خاموش مینی‌اپ",
        "label_en": "Admin permissions and Mini App runtime",
        "source": "shared access policy and runtime safety store",
        "direction": "bidirectional",
        "read_repair": False,
    },
    {
        "key": "events",
        "label_fa": "اعلان تغییرات و تازه‌سازی زنده",
        "label_en": "Change events and live refresh",
        "source": "normalized event stream with polling fallback",
        "direction": "server_to_all_clients",
        "read_repair": True,
    },
)


def _counts(snapshot: dict[str, Any]) -> dict[str, int]:
    watchlists = snapshot.get("user_watchlists") if isinstance(snapshot.get("user_watchlists"), dict) else {}
    tickets = snapshot.get("tickets") if isinstance(snapshot.get("tickets"), list) else []
    orders = snapshot.get("vip_orders") if isinstance(snapshot.get("vip_orders"), list) else []
    signals = snapshot.get("signals") if isinstance(snapshot.get("signals"), list) else []
    archive = snapshot.get("signal_archive") if isinstance(snapshot.get("signal_archive"), list) else []
    return {
        "signals": len(signals),
        "archived_signals": len(archive),
        "tickets": len(tickets),
        "open_tickets": sum(1 for row in tickets if isinstance(row, dict) and str(row.get("status") or "open") == "open"),
        "vip_orders": len(orders),
        "pending_vip_projection": sum(1 for row in orders if isinstance(row, dict) and bool(row.get("projection_pending"))),
        "watchlist_users": sum(1 for rows in watchlists.values() if isinstance(rows, list) and rows),
        "watchlist_symbols": sum(len(rows) for rows in watchlists.values() if isinstance(rows, list)),
    }


def integration_snapshot() -> dict[str, Any]:
    snapshot = read_db_sections((
        "signals", "signal_archive", "tickets", "vip_orders", "vip_users",
        "user_watchlists", "runtime_safety", "miniapp_runtime", "settings",
        "integration_sync_runs",
    ))
    counts = _counts(snapshot)
    pending = counts["pending_vip_projection"]
    domains = []
    for item in _SHARED_DOMAINS:
        status = "attention" if item["key"] == "vip" and pending else "connected"
        domains.append({**item, "status": status})
    runs = snapshot.get("integration_sync_runs") if isinstance(snapshot.get("integration_sync_runs"), list) else []
    return {
        "status": "attention" if pending else "connected",
        "contract_version": 1,
        "domains": domains,
        "counts": counts,
        "last_reconcile": dict(runs[-1]) if runs and isinstance(runs[-1], dict) else None,
        "guarantees": {
            "shared_user_identity": True,
            "shared_permissions": True,
            "shared_business_state": True,
            "event_stream_with_polling_fallback": True,
            "idempotent_mutations": True,
        },
        "generated_at": utc_iso(),
    }


def _mirror_watchlists() -> dict[str, int]:
    snapshot = read_db_sections(("user_watchlists",))
    watchlists = snapshot.get("user_watchlists") if isinstance(snapshot.get("user_watchlists"), dict) else {}
    repo = PreferenceRepository()
    mirrored = 0
    errors = 0
    for user_id, rows in watchlists.items():
        if not isinstance(rows, list):
            continue
        normalized = [dict(row) for row in rows if isinstance(row, dict)]
        try:
            current = repo.get(user_id, "user_watchlists", [])
            if current != normalized:
                repo.set(user_id, "user_watchlists", normalized)
                mirrored += 1
        except Exception:
            errors += 1
    return {"mirrored_users": mirrored, "errors": errors}


def reconcile_shared_state(actor_id: int | str) -> dict[str, Any]:
    signals = sync_legacy_signals_to_normalized(include_archive=True)
    vip_changed = project_normalized_entitlements_to_legacy()
    watchlists = _mirror_watchlists()
    result = {
        "signals": signals,
        "vip_entitlements_changed": int(vip_changed or 0),
        "watchlists": watchlists,
        "actor_id": str(actor_id),
        "created_at": utc_iso(),
    }

    def record(db: dict[str, Any]) -> None:
        rows = db.setdefault("integration_sync_runs", [])
        if not isinstance(rows, list):
            rows = []
            db["integration_sync_runs"] = rows
        rows.append(dict(result))
        del rows[:-200]

    with_db(record)
    return {**result, "snapshot": integration_snapshot()}
