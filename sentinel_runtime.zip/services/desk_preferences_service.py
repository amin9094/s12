"""Private per-admin desk views, versioned on the server; no browser secrets."""
import re
from repositories.v2.preferences import PreferenceRepository

FILTERS={'symbol','timeframe','direction','publication_state','paper_state','unread','sort'}


def preferences(user,body=None):
    from services.live_signal_service import permitted
    permitted(user);repo=PreferenceRepository()
    if body is None:return repo.get(user,'live_desk',{'revision':0,'view_mode':'advanced','views':{}})
    if not isinstance(body,dict) or not set(body)<={'revision','view_key','filters','view_mode','saved_view','delete_saved_view'} or type(body.get('revision')) is not int or body['revision']<0:
        raise ValueError('DESK_PREFERENCES_INVALID')
    if 'view_mode' in body and body['view_mode'] not in {'simple','advanced'}:raise ValueError('DESK_PREFERENCES_INVALID')
    saved=body.get('saved_view')
    if saved is not None:
        if not isinstance(saved,dict) or set(saved)!={'name','view_key','filters'} or not isinstance(saved['name'],str) or not 1<=len(saved['name'].strip())<=60:raise ValueError('SAVED_VIEW_INVALID')
        # Apply the exact same filter whitelist as the normal desk. This never
        # stores a role, trading setting or expanded market scope.
        preferences_validation={**body,'view_key':saved['view_key'],'filters':saved['filters']}
        body={**preferences_validation}
    if 'delete_saved_view' in body and (not isinstance(body['delete_saved_view'],str) or len(body['delete_saved_view'])>60):raise ValueError('SAVED_VIEW_INVALID')
    if 'filters' in body:
        if (not isinstance(body.get('view_key'),str) or len(body['view_key'])>80 or
            not re.fullmatch(r'[A-Za-z_~/-]*',body['view_key']) or not isinstance(body['filters'],dict) or not set(body['filters'])<=FILTERS):
            raise ValueError('DESK_PREFERENCES_INVALID')
        for key,value in body['filters'].items():
            if key=='unread':
                if type(value) is not bool:raise ValueError('DESK_PREFERENCES_INVALID')
            elif not isinstance(value,str) or len(value)>32 or not re.fullmatch('[A-Za-z0-9_]*',value):raise ValueError('DESK_PREFERENCES_INVALID')
    with repo.engine.atomic() as c:
        # Serialize updates even when this preference row does not yet exist.
        if repo.engine.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(hashtextextended(?,0))',('sentinel-desk-prefs:'+str(user),))
        current=repo.get(user,'live_desk',{'revision':0,'view_mode':'advanced','views':{}})
        if current['revision']!=body['revision']:raise ValueError('DESK_PREFERENCES_CHANGED')
        if 'view_mode' in body:current['view_mode']=body['view_mode']
        named=current.setdefault('saved_views',{})
        if saved is not None:
            if saved['name'] not in named and len(named)>=30:raise ValueError('SAVED_VIEW_LIMIT')
            named[saved['name']]={'view_key':saved['view_key'],'filters':saved['filters']}
        if 'delete_saved_view' in body:named.pop(body['delete_saved_view'],None)
        if 'filters' in body:
            views=current.setdefault('views',{})
            if body['view_key'] not in views and len(views)>=128:raise ValueError('DESK_VIEW_LIMIT')
            views[body['view_key']]={'filters':body['filters']}
        current['revision']+=1
        return repo.set(user,'live_desk',current)
