"""Predeclare a frozen-profile forward/held-out evaluation before new evidence."""
import time,uuid
from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump,json_load,content_hash


def protocols(user,body=None):
    from services.live_signal_service import permitted
    permitted(user);db=normalized_engine();now=int(time.time()*1000)
    if body is None:
        with db.transaction(read_only=True) as c:rows=c.execute('SELECT * FROM s9_research_protocols WHERE owner=? ORDER BY created_ms DESC,id DESC LIMIT 50',(str(user),)).fetchall()
        return {'items':[{**r,'payload':json_load(r['payload'])} for r in rows]}
    from repositories.v2.live_signal_inbox import STRATEGIES
    from modules.automated_market_scope import require_global_symbol
    if (not isinstance(body,dict) or set(body)!={'strategy','profile_id','training_start_ms','evaluation_days','heldout_symbols'}
        or body['strategy'] not in STRATEGIES or not isinstance(body['profile_id'],str) or not 1<=len(body['profile_id'])<=160
        or type(body['training_start_ms']) is not int or not 0<=body['training_start_ms']<now
        or type(body['evaluation_days']) is not int or not 1<=body['evaluation_days']<=90
        or not isinstance(body['heldout_symbols'],list) or not 1<=len(body['heldout_symbols'])<=20):raise ValueError('RESEARCH_PROTOCOL_INVALID')
    for symbol in body['heldout_symbols']:require_global_symbol(symbol)
    # Recording a protocol does not switch a strategy or its configuration.
    p={**body,'created_ms':now,'evaluation_start_ms':now+1,'evaluation_end_ms':now+1+body['evaluation_days']*86400000,
       'selection_frozen':True,'automatic_activation':False,'minimum_closed_per_mode':30,
       'outcome_policy':'POST_SPLIT_EVIDENCE_ONLY_UNRESOLVED_PRESERVED'}
    from modules.research_context import implementation_hash
    p['implementation_hash']=implementation_hash()
    key=uuid.uuid4().hex;p['protocol_hash']=content_hash(p)
    with db.transaction() as c:
        if db.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(hashtextextended(?,0))',('research-protocol:'+str(user),))
        if c.execute('SELECT COUNT(*) AS n FROM s9_research_protocols WHERE owner=?',(str(user),)).fetchone()['n']>=50:raise ValueError('RESEARCH_PROTOCOL_LIMIT')
        c.execute('INSERT INTO s9_research_protocols VALUES(?,?,?,?)',(key,str(user),now,json_dump(p)))
    return {'id':key,'payload':p}


def report(user,key):
    from services.live_signal_service import permitted
    permitted(user);db=normalized_engine()
    with db.transaction(read_only=True) as c:r=c.execute('SELECT * FROM s9_research_protocols WHERE id=? AND owner=?',(key,str(user))).fetchone()
    if not r:raise ValueError('RESEARCH_PROTOCOL_NOT_FOUND')
    p=json_load(r['payload']);check=dict(p);claimed=check.pop('protocol_hash')
    if content_hash(check)!=claimed:raise ValueError('RESEARCH_PROTOCOL_CHANGED')
    now=int(time.time()*1000)
    if now<=p['evaluation_start_ms']:return {'protocol':p,'state':'WAITING_FOR_NEW_EVIDENCE','groups':[],'automatic_activation':False}
    from repositories.v2.paper_research import report as analyze
    from repositories.v2.strategy_paper import StrategyPaperRepository
    result=analyze(StrategyPaperRepository(db),p['strategy'],from_ms=p['training_start_ms'],selection_end_ms=p['evaluation_start_ms'],
        evaluation_end_ms=min(p['evaluation_end_ms'],now),to_ms=now,profile_id=p['profile_id'],heldout_symbols=tuple(p['heldout_symbols']),
        not_before_evidence_ms=p['evaluation_start_ms'],implementation_hash=p['implementation_hash'])
    return {**result,'protocol':p,'state':'COLLECTING' if now<p['evaluation_end_ms'] else 'EVALUATION_WINDOW_ENDED',
            'instrument_selection_declared_after_trades':False,'validation_status':'PREDECLARED_PROTOCOL_SAMPLE_SIZE_AND_COVERAGE_STILL_REQUIRED'}
