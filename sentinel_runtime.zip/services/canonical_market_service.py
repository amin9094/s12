"""Native historical bars with explicit provider/venue identity, never proxies."""

from __future__ import annotations

import asyncio
import json
import os
import time
from datetime import UTC, datetime
from urllib.parse import quote

from core.http_client import get_json
from modules.canonical_market import TIMEFRAMES, Candle, validate_series

from modules.automated_market_scope import CORE_MARKET_SYMBOLS,FOREX_USD_PAIRS,FOREX_RANK_SOURCE

CORE_SYMBOLS = CORE_MARKET_SYMBOLS
CRYPTO_IDS = {
    "bitcoin": "BTC",
    "ethereum": "ETH",
    "tether": "USDT",
    "usd-coin": "USDC",
    "binancecoin": "BNB",
    "ripple": "XRP",
    "solana": "SOL",
    "dogecoin": "DOGE",
    "cardano": "ADA",
    "tron": "TRX",
    "avalanche-2": "AVAX",
    "chainlink": "LINK",
    "polkadot": "DOT",
    "bitcoin-cash": "BCH",
    "litecoin": "LTC",
    "sui": "SUI",
    "the-open-network": "TON",
    "stellar": "XLM",
    "shiba-inu": "SHIB",
    "hedera-hashgraph": "HBAR",
    "uniswap": "UNI",
    "near": "NEAR",
    "aptos": "APT",
    "aave": "AAVE",
    "zcash": "ZEC",
    "hyperliquid": "HYPE",
    "monero": "XMR",
    "whitebit": "WBT",
    "leo-token": "LEO",
    "rain": "RAIN",
    "cosmos": "ATOM",
    "ethereum-classic": "ETC",
    "filecoin": "FIL",
    "vechain": "VET",
    "algorand": "ALGO",
    "internet-computer": "ICP",
}
# Curated long-established candidates. Market-cap rank determines their order;
# a new listing is not automatically admitted because it jumps into a top list.
ESTABLISHED_CRYPTO_IDS = frozenset(
    {
        "bitcoin",
        "ethereum",
        "binancecoin",
        "ripple",
        "solana",
        "dogecoin",
        "cardano",
        "tron",
        "avalanche-2",
        "chainlink",
        "polkadot",
        "bitcoin-cash",
        "litecoin",
        "stellar",
        "shiba-inu",
        "hedera-hashgraph",
        "uniswap",
        "near",
        "aave",
        "zcash",
        "monero",
        "the-open-network",
        "sui",
        "aptos",
        "cosmos",
        "ethereum-classic",
        "filecoin",
        "vechain",
        "algorand",
        "internet-computer",
    }
)
_RANKING = (0.0, [])
_RANK_RETRY_AFTER = 0.0
_HISTORY_CACHE = {}
_INFLIGHT = {}
_CRYPTO_DIRECTORY = (0.0, set())
FX_TICKERS = {
    'EURUSD':'EURUSD=X','USDJPY':'JPY=X','USDCNY':'CNY=X','GBPUSD':'GBPUSD=X',
    'USDCAD':'CAD=X','AUDUSD':'AUDUSD=X','USDCHF':'CHF=X','USDHKD':'HKD=X',
    'USDSGD':'SGD=X','USDINR':'INR=X',
}
_SOURCE_COOLDOWNS = {}


class MarketUnavailable(RuntimeError):
    pass


async def _request(url, params=None, headers=None):
    started=time.monotonic()
    try:
        payload = await get_json(url, params=params, headers=headers, retries=0)
    except Exception as exc:
        from core.provider_usage import record
        record(url,False,(time.monotonic()-started)*1000)
        from repositories.v2.provider_budget import ProviderBudgetExceeded
        if isinstance(exc, ProviderBudgetExceeded):
            raise MarketUnavailable(str(exc)) from None
        status = getattr(getattr(exc, 'response', None), 'status_code', None)
        if type(status) is int and 400 <= status <= 599:
            raise MarketUnavailable(f'PROVIDER_HTTP_{status}') from None
        raise MarketUnavailable(f"PROVIDER_TRANSPORT_{type(exc).__name__}") from None
    if isinstance(payload, dict) and payload.get("status") == "error":
        from core.provider_usage import record
        record(url,False,(time.monotonic()-started)*1000)
        raise MarketUnavailable(f"PROVIDER_ERROR_{int(payload.get('code') or 0)}")
    from core.provider_usage import record
    record(url,True,(time.monotonic()-started)*1000)
    return payload


async def top20_crypto(*, force=False):
    global _RANKING
    if not force and _RANKING[0] > time.monotonic():
        return _RANKING[1]
    key = os.getenv("COINGECKO_DEMO_API_KEY", "").strip()
    headers = {"x-cg-demo-api-key": key} if key else None
    rows = await _request(
        "https://api.coingecko.com/api/v3/coins/markets",
        {"vs_currency": "usd", "order": "market_cap_desc", "per_page": 250, "page": 1, "sparkline": "false"},
        headers,
    )
    if not isinstance(rows, list) or not rows:
        raise MarketUnavailable("CRYPTO_RANKING_UNAVAILABLE")
    output = []
    observed = int(time.time() * 1000)
    supported = await supported_crypto_symbols()
    for row in rows:
        coin_id = str(row.get("id") or "")
        base = CRYPTO_IDS.get(coin_id)
        if coin_id not in ESTABLISHED_CRYPTO_IDS:
            continue
        if base not in supported:
            continue
        output.append(
            {
                "id": coin_id,
                "title": str(row.get("name") or coin_id),
                "rank": row.get("market_cap_rank"),
                "symbol": f"{base}USDT",
                "analysis_supported": True,
                "unavailable_reason": "",
                "quote_currency": "USDT",
                "eligibility": "CURATED_ESTABLISHED_NATIVE_USDT_PAIR",
                "ranking_source": "coingecko_market_cap",
                "ranking_observed_ms": observed,
            }
        )
        if len(output) == 20:
            break
    _RANKING = (time.monotonic() + 3600, output)
    return output


async def supported_crypto_symbols():
    """Discover actual native USDT spot pairs across the configured exchanges."""
    global _CRYPTO_DIRECTORY
    if _CRYPTO_DIRECTORY[0] > time.monotonic():
        return set(_CRYPTO_DIRECTORY[1])
    supported = set()
    sources = await asyncio.gather(
        _request("https://api.kraken.com/0/public/AssetPairs"),
        _request("https://api.binance.com/api/v3/exchangeInfo"),
        _request("https://api.bybit.com/v5/market/instruments-info", {"category": "spot"}),
        _request("https://www.okx.com/api/v5/public/instruments", {"instType": "SPOT"}),
        return_exceptions=True,
    )
    kraken, binance, bybit, okx = sources
    if isinstance(kraken, dict) and not kraken.get("error"):
        for row in (kraken.get("result") or {}).values():
            name = str(row.get("wsname") or "")
            if name.endswith("/USDT") and row.get("status", "online") == "online":
                base = name.split("/")[0]
                supported.add({"XBT": "BTC", "XDG": "DOGE"}.get(base, base))
    if isinstance(binance, dict):
        for row in binance.get("symbols") or []:
            if (
                row.get("quoteAsset") == "USDT"
                and row.get("status") == "TRADING"
                and row.get("isSpotTradingAllowed", True)
            ):
                supported.add(str(row["baseAsset"]))
    if isinstance(bybit, dict) and bybit.get("retCode") == 0:
        for row in (bybit.get("result") or {}).get("list") or []:
            if row.get("quoteCoin") == "USDT" and row.get("status") == "Trading":
                supported.add(str(row["baseCoin"]))
    if isinstance(okx, dict) and okx.get("code") == "0":
        for row in okx.get("data") or []:
            if row.get("instType") == "SPOT" and row.get("quoteCcy") == "USDT" and row.get("state") == "live":
                supported.add(str(row["baseCcy"]))
    # A transient outage must not remove crypto discovery for a full hour.
    _CRYPTO_DIRECTORY = (time.monotonic() + (3600 if supported else 30), supported)
    return supported


async def universe():
    global _RANK_RETRY_AFTER
    try:
        if _RANK_RETRY_AFTER > time.monotonic() and _RANKING[0] <= time.monotonic():
            raise MarketUnavailable('CRYPTO_RANKING_RETRY_BACKOFF')
        async with asyncio.timeout(5):
            crypto = await top20_crypto()
        _RANK_RETRY_AFTER = 0.0
        ranking_state = "AVAILABLE" if len(crypto) == 20 else "LIMITED_NATIVE_USDT_COVERAGE"
    except (MarketUnavailable, TimeoutError) as exc:
        if not isinstance(exc, MarketUnavailable) or str(exc) != 'CRYPTO_RANKING_RETRY_BACKOFF':
            _RANK_RETRY_AFTER = time.monotonic() + 60
        ranking_state = str(exc) if isinstance(exc, MarketUnavailable) else 'CRYPTO_RANKING_TIMEOUT'
        # This is an explicitly labelled discovery fallback, never a fabricated
        # market-cap rank or an executable quote. Every plan still verifies the
        # current native instrument, candles, Bid/Ask and ordered quote stream.
        crypto = [dict(row) for row in _RANKING[1]] if _RANKING[0] > time.monotonic() - 86400 else []
        if crypto:
            ranking_state = 'LAST_VERIFIED_SELECTION_RANKING_UNAVAILABLE'
        else:
            try:
                async with asyncio.timeout(5):
                    supported = await supported_crypto_symbols()
            except (MarketUnavailable, TimeoutError):
                supported = set()
            crypto = [{'id': coin_id, 'title': base, 'rank': None, 'symbol': base + 'USDT',
                       'analysis_supported': True, 'unavailable_reason': '', 'quote_currency': 'USDT',
                       'eligibility': 'CURATED_ESTABLISHED_NATIVE_USDT_PAIR',
                       'ranking_source': 'UNRANKED_NATIVE_DIRECTORY', 'ranking_observed_ms': None}
                      for coin_id, base in CRYPTO_IDS.items()
                      if coin_id in ESTABLISHED_CRYPTO_IDS and base in supported][:20]
            if crypto:
                ranking_state = 'CURATED_NATIVE_USDT_FALLBACK_UNRANKED'
    return {
        "core_symbols": list(CORE_SYMBOLS),
        "forex_usd_pairs":list(FOREX_USD_PAIRS),
        "forex_selection":{"count":10,"required_currency":"USD","basis":"BIS_2025_FINAL_ALL_OTC_NET_NET","source":FOREX_RANK_SOURCE},
        "crypto_top20": crypto,
        "crypto_ranking_state": ranking_state,
        "crypto_selection": {
            "quote_currency": "USDT",
            "requested_count": 20,
            "available_count": len(crypto),
            "method": 'UNRANKED_NATIVE_DIRECTORY' if ranking_state == 'CURATED_NATIVE_USDT_FALLBACK_UNRANKED' else 'LAST_VERIFIED_SELECTION' if ranking_state == 'LAST_VERIFIED_SELECTION_RANKING_UNAVAILABLE' else "MARKET_CAP_WITHIN_CURATED_ESTABLISHED_NATIVE_PAIRS",
        },
        "analysis_timeframes": ["5m", "1h"],
        "display_timeframes": list(TIMEFRAMES),
        'data_sources':[
            {'provider':'biquote','capability':'KEYLESS_AGGREGATED_INDICATIVE_CANDLES','api_key_required':False,
             'priority':'GOLD_PRIMARY_AND_FX_FALLBACK','source_url':'https://biquote.io/docs/',
             'execution_eligible':False,'native_volume_verified':False,'service_guarantee':False},
            {'provider':'twelve_data','capability':'SOURCE_LOCKED_CANDLES','api_key_required':True,
             'configured':bool(os.getenv('TWELVE_DATA_API_KEY','').strip()),'priority':'GOLD_HISTORY_AND_FX_FALLBACK'},
            {'provider':'yahoo_fx','capability':'INDICATIVE_FX_CANDLES','api_key_required':False,
             'priority':'FX_PRIMARY','service_guarantee':False},
            {'provider':'gold_api','capability':'GOLD_REFERENCE_PRICE_ONLY','api_key_required':False,
             'candle_fallback':False},
            {'provider':'goldpricetoday_ir','capability':'GOLD_REFERENCE_PRICE_ONLY','api_key_required':False,
             'candle_fallback':False,'asset_timestamp_verified':False},
            {'provider':'streamdata','capability':'TOKEN_REQUIRED_CANDLE_ADAPTER','api_key_required':True,
             'configured':bool(os.getenv('STREAMDATA_API_TOKEN','').strip()),'live_connection_verified':False,
             'default_symbols':['XAUUSD'],'fx_requires_provider_symbol_map':True},
            {'provider':'yahoo','capability':'CASH_INDEX_CANDLES_ONLY','api_key_required':False,
             'cfd_equivalent':False}],
    }


def _crypto_base(symbol):
    base = symbol[:-4] if symbol.endswith("USDT") else symbol[:-3] if symbol.endswith("USD") else ""
    if base not in CRYPTO_IDS.values() or base in {"USDT", "USDC"}:
        raise MarketUnavailable("CRYPTO_VENUE_MAPPING_UNVERIFIED")
    return base


def kraken_rest_pair(symbol):
    base = _crypto_base(symbol)
    quote_currency = "USDT" if symbol.endswith("USDT") else "USD"
    return {"BTC": "XBT", "DOGE": "XDG"}.get(base, base) + quote_currency


async def _binance(symbol, timeframe, limit, before_ms):
    if not symbol.endswith("USDT"):
        raise MarketUnavailable("CRYPTO_USDT_MARKET_REQUIRED")
    base = _crypto_base(symbol)
    params = {"symbol": base + "USDT", "interval": timeframe, "limit": limit}
    if before_ms:
        params["endTime"] = before_ms - 1
    rows = await _request("https://api.binance.com/api/v3/klines", params)
    if not isinstance(rows, list):
        raise MarketUnavailable("BINANCE_BARS_UNAVAILABLE")
    now = int(time.time() * 1000)
    result = []
    for row in rows:
        start = int(row[0])
        end = start + TIMEFRAMES[timeframe]
        result.append(
            Candle(
                symbol,
                "binance",
                "binance_spot_USDT",
                "spot",
                timeframe,
                start,
                end,
                row[1],
                row[2],
                row[3],
                row[4],
                row[5],
                "traded",
                end <= now,
                now,
                f"binance:{base}USDT:{start}",
            )
        )
    return result


async def _bybit(symbol, timeframe, limit, before_ms):
    if not symbol.endswith("USDT"):
        raise MarketUnavailable("CRYPTO_USDT_MARKET_REQUIRED")
    base = _crypto_base(symbol)
    interval = str(TIMEFRAMES[timeframe] // 60000) if timeframe != "1d" else "D"
    params = {"category": "spot", "symbol": base + "USDT", "interval": interval, "limit": limit}
    if before_ms:
        params["end"] = before_ms - 1
    payload = await _request("https://api.bybit.com/v5/market/kline", params)
    if not isinstance(payload, dict) or payload.get("retCode") != 0:
        raise MarketUnavailable("BYBIT_BARS_UNAVAILABLE")
    now = int(time.time() * 1000)
    result = []
    for row in reversed((payload.get("result") or {}).get("list") or []):
        start = int(row[0])
        end = start + TIMEFRAMES[timeframe]
        result.append(
            Candle(
                symbol,
                "bybit",
                "bybit_spot_USDT",
                "spot",
                timeframe,
                start,
                end,
                row[1],
                row[2],
                row[3],
                row[4],
                row[5],
                "traded",
                end <= now,
                now,
                f"bybit:{base}USDT:{start}",
            )
        )
    return result


async def _twelve(symbol, timeframe, limit, before_ms):
    key = os.getenv("TWELVE_DATA_API_KEY", "").strip()
    if not key:
        raise MarketUnavailable("TWELVE_DATA_API_KEY_MISSING")
    if symbol in {"US30", "US100", "NAS100"}:
        aliases = json.loads(os.getenv("MARKET_INDEX_SYMBOLS_JSON") or '{"US30":"DJI","US100":"NDX"}')
        provider_symbol = aliases["US100" if symbol == "NAS100" else symbol]
        venue, product = "twelve_data_cash_indices", "cash_index"
    else:
        provider_symbol = symbol[:3] + "/" + symbol[3:]
        venue, product = "twelve_data_composite", "spot"
    intervals = {"1m": "1min", "5m": "5min", "15m": "15min", "30m": "30min", "1h": "1h", "4h": "4h", "1d": "1day"}
    params = {
        "symbol": provider_symbol,
        "interval": intervals[timeframe],
        "outputsize": limit,
        "timezone": "UTC",
        "apikey": key,
        "order": "ASC",
    }
    if before_ms:
        params["end_date"] = datetime.fromtimestamp((before_ms - 1) / 1000, UTC).strftime("%Y-%m-%d %H:%M:%S")
    payload = await _request("https://api.twelvedata.com/time_series", params)
    if not isinstance(payload, dict) or not payload.get("values"):
        raise MarketUnavailable("TWELVE_DATA_BARS_UNAVAILABLE")
    now = int(time.time() * 1000)
    rows = []
    for row in sorted(payload["values"], key=lambda item: item["datetime"]):
        start = int(datetime.fromisoformat(row["datetime"]).replace(tzinfo=UTC).timestamp() * 1000)
        end = start + TIMEFRAMES[timeframe]
        if before_ms and start >= before_ms:
            continue
        # FX/metal/index reported volume is not authenticated exchange volume.
        rows.append(
            Candle(
                symbol,
                "twelve_data",
                venue,
                product,
                timeframe,
                start,
                end,
                row["open"],
                row["high"],
                row["low"],
                row["close"],
                None,
                "unavailable",
                end <= now,
                now,
                f"twelve_data:{provider_symbol}:{timeframe}:{start}",
            )
        )
    return rows


async def _kraken(symbol, timeframe, limit, before_ms):
    interval = TIMEFRAMES[timeframe] // 60000
    pair = kraken_rest_pair(symbol)
    quote_currency = "USDT" if symbol.endswith("USDT") else "USD"
    payload = await _request("https://api.kraken.com/0/public/OHLC", {"pair": pair, "interval": interval})
    if not isinstance(payload, dict) or payload.get("error"):
        raise MarketUnavailable("KRAKEN_PAIR_OR_BARS_UNAVAILABLE")
    result = payload.get("result") or {}
    raw = next((rows for name, rows in result.items() if name != "last"), [])
    now = int(time.time() * 1000)
    bars = []
    for i, row in enumerate(raw):
        start = int(row[0]) * 1000
        end = start + TIMEFRAMES[timeframe]
        if before_ms and start >= before_ms:
            continue
        bars.append(
            Candle(
                symbol,
                "kraken",
                f"kraken_spot_{quote_currency}",
                "spot",
                timeframe,
                start,
                end,
                row[1],
                row[2],
                row[3],
                row[4],
                row[6],
                "traded",
                i < len(raw) - 1 and end <= now,
                now,
                f"kraken:{pair}:{timeframe}:{start}",
            )
        )
    return bars[-limit:]


async def _okx(symbol, timeframe, limit, before_ms):
    if not symbol.endswith("USDT"):
        raise MarketUnavailable("CRYPTO_USDT_MARKET_REQUIRED")
    base = _crypto_base(symbol)
    bar_type = {"1h": "1H", "4h": "4H", "1d": "1Dutc"}.get(timeframe, timeframe)
    params = {"instId": base + "-USDT", "bar": bar_type, "limit": min(limit, 300)}
    if before_ms:
        params["after"] = int(before_ms) - 1
    endpoint = "history-candles" if before_ms else "candles"
    payload = await _request(f"https://www.okx.com/api/v5/market/{endpoint}", params)
    if not isinstance(payload, dict) or payload.get("code") != "0":
        raise MarketUnavailable("OKX_BARS_UNAVAILABLE")
    now = int(time.time() * 1000)
    bars = []
    for row in reversed(payload.get("data") or []):
        if len(row) != 9 or row[8] not in {"0", "1"}:
            raise MarketUnavailable("OKX_CANDLE_CONFIRMATION_INVALID")
        start = int(row[0])
        end = start + TIMEFRAMES[timeframe]
        if before_ms and start >= before_ms:
            continue
        bars.append(
            Candle(
                symbol,
                "okx",
                "okx_spot_USDT",
                "spot",
                timeframe,
                start,
                end,
                row[1],
                row[2],
                row[3],
                row[4],
                row[5],
                "traded",
                row[8] == "1" and end <= now,
                now,
                f"okx:{base}-USDT:{timeframe}:{start}",
            )
        )
    return bars[-limit:]


async def _yahoo_index(symbol, timeframe, limit, before_ms):
    """Native cash index bars only. Never substitute a CFD or futures contract."""
    ticker = {"US30": "^DJI", "US100": "^NDX", "NAS100": "^NDX"}[symbol]
    interval = {"1h": "60m", "1d": "1d"}.get(timeframe, timeframe)
    if timeframe == "4h":
        raise MarketUnavailable("NATIVE_INDEX_4H_UNAVAILABLE")
    params = {"interval": interval, "range": '3mo' if timeframe=='1h' else "5d" if timeframe in {"1m", "5m", "15m", "30m"} else "6mo"}
    if before_ms:
        end = int(before_ms) // 1000
        params = {
            "interval": interval,
            "period1": max(0, end - limit * TIMEFRAMES[timeframe] // 1000 * 3),
            "period2": end,
        }
    payload = await _request(
        f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(ticker, safe='')}",
        params,
        {"User-Agent": "SENTINEL/9.0"},
    )
    result = ((payload.get("chart") or {}).get("result") or [{}])[0]
    meta = result.get("meta") or {}
    if meta.get("symbol") != ticker:
        raise MarketUnavailable("INDEX_SOURCE_SYMBOL_MISMATCH")
    values = ((result.get("indicators") or {}).get("quote") or [{}])[0]
    now = int(time.time() * 1000)
    rows = []
    for i, stamp in enumerate(result.get("timestamp") or []):
        start = int(stamp) * 1000
        end = start + TIMEFRAMES[timeframe]
        if before_ms and start >= before_ms:
            continue
        ohlc = [
            (values.get(name) or [])[i] if i < len(values.get(name) or []) else None
            for name in ("open", "high", "low", "close")
        ]
        if any(value is None for value in ohlc):
            continue
        delayed = int(meta.get("exchangeDataDelayedBy") or 0) > 0
        flags = ("CASH_INDEX_EXECUTABLE_QUOTE_UNAVAILABLE",)
        if delayed:
            flags += ("DELAYED_INDEX_FEED",)
        offset = start % TIMEFRAMES[timeframe]
        if offset:
            flags += ("SESSION_CALENDAR_CONFIRMATION_REQUIRED",)
        rows.append(
            Candle(
                symbol,
                "yahoo",
                "cash_index_" + ticker,
                "cash_index",
                timeframe,
                start,
                end,
                *ohlc,
                None,
                "unavailable",
                end <= now,
                now,
                f"yahoo:{ticker}:{timeframe}:{start}",
                flags,
                offset,
            )
        )
    return rows[-limit:]


async def _yahoo_fx(symbol, timeframe, limit, before_ms):
    """Public indicative currency bars; not a broker execution feed or SLA.

    Yahoo may append a current quote with a non-boundary timestamp. Drop it:
    rounding would fabricate a native candle and can create a false FVG.
    """
    ticker = FX_TICKERS.get(symbol)
    if not ticker or timeframe == '4h':
        raise MarketUnavailable('MARKET_PROVIDER_MISMATCH')
    interval = {'1h':'60m', '1d':'1d'}.get(timeframe, timeframe)
    params = {'interval':interval, 'range':'1mo' if timeframe == '1h' else '5d'}
    if before_ms:
        end = int(before_ms) // 1000
        params = {'interval':interval, 'period1':max(0,end-limit*TIMEFRAMES[timeframe]//1000*3), 'period2':end}
    payload = await _request(f'https://query1.finance.yahoo.com/v8/finance/chart/{quote(ticker,safe="")}',
                             params, {'User-Agent':'SENTINEL/9.0'})
    result = ((payload.get('chart') or {}).get('result') or [{}])[0]
    meta = result.get('meta') or {}
    if meta.get('symbol') != ticker or meta.get('instrumentType') != 'CURRENCY':
        raise MarketUnavailable('FX_SOURCE_SYMBOL_MISMATCH')
    values = ((result.get('indicators') or {}).get('quote') or [{}])[0]
    now, rows = int(time.time()*1000), []
    for i, stamp in enumerate(result.get('timestamp') or []):
        start = int(stamp)*1000
        if start % TIMEFRAMES[timeframe] or before_ms and start >= before_ms:
            continue
        ohlc = [(values.get(name) or [])[i] if i < len(values.get(name) or []) else None
                for name in ('open','high','low','close')]
        if any(value is None for value in ohlc):
            continue
        flags = ('INDICATIVE_FX_NO_EXECUTION_QUOTE',)
        if int(meta.get('exchangeDataDelayedBy') or 0) > 0:
            flags += ('DELAYED_FX_FEED',)
        end = start + TIMEFRAMES[timeframe]
        rows.append(Candle(symbol,'yahoo_fx','yahoo_indicative_fx','spot',timeframe,start,end,*ohlc,
                           None,'unavailable',end<=now,now,f'yahoo_fx:{ticker}:{timeframe}:{start}',flags))
    if not rows:
        raise MarketUnavailable('MARKET_BARS_EMPTY')
    return rows[-limit:]


async def _core_route(symbol, timeframe, limit, before_ms, provider):
    indices = symbol in {'US30','US100','NAS100'}
    from services.iran_market_data_service import streamdata_history
    from services.keyless_market_data_service import biquote_history
    adapters = {'twelve_data':_twelve, 'yahoo':_yahoo_index, 'yahoo_fx':_yahoo_fx,
                'streamdata':streamdata_history,'biquote':biquote_history}
    if provider is not None:
        if provider not in adapters or provider == 'yahoo' and not indices or provider == 'yahoo_fx' and symbol not in FX_TICKERS or provider in {'streamdata','biquote'} and indices:
            raise MarketUnavailable('MARKET_PROVIDER_MISMATCH')
        for key in ((provider,symbol,timeframe),(provider,'*','*')):
            cooldown = _SOURCE_COOLDOWNS.get(key)
            if cooldown and cooldown[0] > time.monotonic():
                raise MarketUnavailable(cooldown[1])
        try:
            rows = await adapters[provider](symbol,timeframe,limit,before_ms)
            validate_series(rows,now_ms=int(time.time()*1000))
            return rows
        except (ValueError,KeyError,TypeError,IndexError):
            raise MarketUnavailable('INVALID_ANALYSIS_CANDLES') from None
    if indices:
        preferred = os.getenv('MARKET_INDEX_PROVIDER','yahoo')
        if preferred not in {'yahoo','twelve_data'}:
            raise MarketUnavailable('MARKET_PROVIDER_MISMATCH')
        names = [preferred] + [name for name in ('yahoo','twelve_data') if name != preferred]
    elif symbol in FX_TICKERS:
        preferred = os.getenv('MARKET_FX_PROVIDER','yahoo_fx')
        if preferred not in {'yahoo_fx','biquote','twelve_data','streamdata'}:
            raise MarketUnavailable('MARKET_PROVIDER_MISMATCH')
        names = [preferred] + [name for name in ('yahoo_fx','biquote','twelve_data') if name != preferred]
    else:
        preferred=os.getenv('MARKET_GOLD_PROVIDER','biquote')
        if preferred not in {'biquote','twelve_data','streamdata'}:
            raise MarketUnavailable('MARKET_PROVIDER_MISMATCH')
        names=[preferred]+[name for name in ('biquote','twelve_data') if name!=preferred]
    if not indices and os.getenv('STREAMDATA_API_TOKEN','').strip() and 'streamdata' not in names:
        names.append('streamdata')
    last = MarketUnavailable('MARKET_SOURCES_COOLING_DOWN')
    stale_display_fallback = None
    for name in names:
        if name not in adapters:
            raise MarketUnavailable('MARKET_PROVIDER_MISMATCH')
        key = (name,symbol,timeframe)
        cooldown = max((_SOURCE_COOLDOWNS.get((name,'*','*'),(0,'')),_SOURCE_COOLDOWNS.get(key,(0,''))))
        if cooldown[0] > time.monotonic():
            last = MarketUnavailable(cooldown[1])
            continue
        try:
            rows = await adapters[name](symbol,timeframe,limit,before_ms)
            if not rows:
                raise MarketUnavailable('MARKET_BARS_EMPTY')
            validate_series(rows,now_ms=int(time.time()*1000))
            _SOURCE_COOLDOWNS.pop(key,None)
            if name == 'yahoo_fx' and before_ms is None and int(time.time()*1000)-rows[-1].start_ms > 2*TIMEFRAMES[timeframe]:
                # A valid but delayed Yahoo response must not hide the next free
                # source. Keep it only for explicitly labeled historical display.
                stale_display_fallback = rows
                continue
            # A complete response from exactly one provider. Never append to
            # another source, even when failover changes the visible chart.
            return rows
        except (MarketUnavailable,ValueError,KeyError,TypeError,IndexError) as exc:
            last = exc if isinstance(exc,MarketUnavailable) else MarketUnavailable('INVALID_ANALYSIS_CANDLES')
            code = str(last)
            seconds = 65 if 'MINUTE_BUDGET' in code else 900 if '429' in code or '403' in code else 300
            if 'DAILY_BUDGET' in code or 'NON_GOLD_BUDGET' in code:
                seconds = 86400 - int(time.time()) % 86400
            _SOURCE_COOLDOWNS[key] = (time.monotonic()+seconds,code)
            if any(token in code for token in ('429','403','MINUTE_BUDGET','DAILY_BUDGET')):
                _SOURCE_COOLDOWNS[(name,'*','*')] = (time.monotonic()+seconds,code)
    if stale_display_fallback is not None:
        return stale_display_fallback
    raise last


async def _historical_bars(symbol, timeframe="5m", *, limit=300, before_ms=None, provider=None):
    symbol = str(symbol).upper().strip().replace("/", "")
    if timeframe not in TIMEFRAMES:
        raise ValueError("TIMEFRAME_UNSUPPORTED")
    limit = max(1, min(int(limit), 500))
    now = int(time.time() * 1000)
    if before_ms is not None and not 0 < int(before_ms) <= now + 1000:
        raise ValueError("HISTORY_CURSOR_INVALID")
    if symbol in CORE_SYMBOLS:
        rows = await _core_route(symbol,timeframe,limit,before_ms,provider)
    else:
        _crypto_base(symbol)
        if provider not in {None, "binance", "bybit", "kraken", "okx"}:
            raise MarketUnavailable("MARKET_PROVIDER_MISMATCH")
        # Prefer the same native venue as the sequenced public quote owner.
        # Explicit providers and historical USD pairs retain their own identity.
        # Unsupported/empty OKX markets still use the existing native fallbacks;
        # they do not inherit OKX quote continuity or execution eligibility.
        if provider is None and symbol.endswith('USDT'):
            try:
                preferred=await _okx(symbol,timeframe,limit,before_ms)
                if preferred:
                    validate_series(preferred,now_ms=int(time.time()*1000))
                    return preferred
            except MarketUnavailable:
                pass
        if provider == "okx":
            rows = await _okx(symbol, timeframe, limit, before_ms)
        elif provider == "kraken":
            rows = await _kraken(symbol, timeframe, limit, before_ms)
        elif provider == "bybit":
            rows = await _bybit(symbol, timeframe, limit, before_ms)
        elif provider == "binance":
            rows = await _binance(symbol, timeframe, limit, before_ms)
        else:
            try:
                rows = await _binance(symbol, timeframe, limit, before_ms)
            except MarketUnavailable:
                try:
                    rows = await _bybit(symbol, timeframe, limit, before_ms)
                except MarketUnavailable:
                    try:
                        rows = await _kraken(symbol, timeframe, limit, before_ms)
                    except MarketUnavailable:
                        rows = await _okx(symbol, timeframe, limit, before_ms)
    validate_series(rows, now_ms=int(time.time() * 1000))
    return rows


async def historical_bars(symbol, timeframe="5m", *, limit=300, before_ms=None, provider=None):
    symbol = str(symbol).upper().strip().replace('/', '')
    requested_limit = max(1,min(500,int(limit)))
    fetch_limit = max(300,requested_limit) if symbol in CORE_SYMBOLS and before_ms is None else requested_limit
    key = (symbol, timeframe, fetch_limit, before_ms, provider)
    cached = _HISTORY_CACHE.get(key)
    if cached and cached[0] > time.monotonic():
        from core.provider_usage import cache
        cache(provider)
        return list(cached[1][-requested_limit:])
    inflight_key = (asyncio.get_running_loop(), key)
    task = _INFLIGHT.get(inflight_key)
    if task is not None:
        from core.provider_usage import cache
        cache(provider,inflight=True)
    if task is None:

        async def fetch():
            try:
                result = await _historical_bars(*key[:2], limit=key[2], before_ms=key[3], provider=key[4])
                ttl = 300 if before_ms else max(15, int(os.getenv("MARKET_CHART_POLL_SECONDS", "60")))
                if result and result[-1].provider == 'twelve_data' and not before_ms:
                    # Candle analysis needs a new closed bar, not 60 identical
                    # downloads per hour. Public reference prices are separate.
                    ttl = max(15,(TIMEFRAMES[timeframe]-int(time.time()*1000)%TIMEFRAMES[timeframe])/1000+10)
                if len(_HISTORY_CACHE) >= 256:
                    _HISTORY_CACHE.pop(next(iter(_HISTORY_CACHE)))
                _HISTORY_CACHE[key] = (time.monotonic() + ttl, result)
                if result:
                    explicit_key = (*key[:4],result[-1].provider)
                    _HISTORY_CACHE[explicit_key] = _HISTORY_CACHE[key]
                return result
            finally:
                _INFLIGHT.pop(inflight_key, None)

        task = asyncio.create_task(fetch())
        _INFLIGHT[inflight_key] = task
    return list((await asyncio.shield(task))[-requested_limit:])


async def chart_history(symbol, timeframe="5m", *, limit=300, before_ms=None, provider=None):
    rows = await historical_bars(symbol, timeframe, limit=limit, before_ms=before_ms, provider=provider)
    if not rows:
        return {"bars": [], "has_more": False, "state": "UNAVAILABLE"}
    from core.async_runtime import run_blocking
    from repositories.v2.market_evidence import MarketEvidenceRepository

    await run_blocking(lambda: MarketEvidenceRepository().save_candles(rows), timeout=15)
    last = rows[-1]
    now = int(time.time() * 1000)
    expected_age = TIMEFRAMES[timeframe] * 2
    stale = now - last.start_ms > expected_age
    return {
        "bars": [bar.chart_bar() for bar in rows],
        "has_more": len(rows) >= (min(limit, 300) if rows[-1].provider == "okx" else limit),
        "provider": last.provider,
        "venue": last.venue,
        "product": last.product,
        "symbol": last.symbol,
        "timeframe": timeframe,
        "volume_kind": last.volume_kind,
        "display_price_precision": min(12, max(0, max(-value.normalize().as_tuple().exponent for bar in rows for value in (bar.open,bar.high,bar.low,bar.close)))),
        "display_precision_is_verified_execution_grid": False,
        "last_closed_ms": max((bar.end_ms for bar in rows if bar.is_closed), default=None),
        "observed_ms": now,
        "state": "STALE_OR_SESSION_CLOSED" if stale else "CURRENT_BARS",
        "bid_ask_state": "UNAVAILABLE",
        "poll_seconds": max(15, int(os.getenv("MARKET_CHART_POLL_SECONDS", "60"))),
        "analytical_observations_available": timeframe in {'5m','1h'} and not stale,
        "strategy_eligible": last.symbol not in CORE_SYMBOLS and timeframe in {"5m", "1h"} and not stale and not any(bar.quality_flags for bar in rows),
        "quality_flags": sorted({flag for bar in rows for flag in bar.quality_flags}),
    }
