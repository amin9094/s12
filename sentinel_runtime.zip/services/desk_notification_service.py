"""Short, private reminders for actionable signals, independent of read badges."""
import logging
import time
from core.async_runtime import run_blocking
from repositories.v2.desk_notifications import DeskNotifications
from services.live_signal_service import permitted

logger = logging.getLogger(__name__)


def notification_settings(user, body=None):
    permitted(user)
    repo = DeskNotifications()
    if body is not None:
        if not isinstance(body, dict) or not {'interval_minutes'}<=set(body)<={'interval_minutes','urgent_enabled'}:
            raise ValueError('REMINDER_SETTINGS_INVALID')
        repo.configure(user, body['interval_minutes'],urgent_enabled=body.get('urgent_enabled'))
    row = repo.ensure(user)
    return {'interval_minutes': row['interval_minutes'], 'pending': repo.pending_count(),
            'urgent_enabled':bool(row['payload'].get('urgent_enabled',False)),
            'urgent_minimum_interval_minutes':5,'urgent_threshold_r':'0.25','urgent_scan_limit':500}


async def deliver_reminders(bot,admins=()):
    repo = DeskNotifications(); now = int(time.time()*1000);notified=set()
    for admin in admins:
        try:await run_blocking(permitted,int(admin),timeout=5)
        except PermissionError:continue
        await run_blocking(repo.ensure,admin,timeout=5)
    for row in await run_blocking(repo.due, now, timeout=5):
        try:
            await run_blocking(permitted, int(row['admin_id']), timeout=5)
        except PermissionError:
            continue
        if not await run_blocking(repo.claim, row, now, timeout=5):
            continue
        count = await run_blocking(repo.pending_count, timeout=5)
        if not count:
            continue
        notified.add(row['admin_id'])
        try:
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            await bot.send_message(chat_id=int(row['admin_id']), text=f'سیگنال‌های بررسی‌نشده: {count}',
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('سیگنال‌های زنده', callback_data='ls:h')]]))
        except Exception:
            # The next configured interval is the next attempt, including
            # uncertain delivery receipts. Never flood a chat with retries.
            logger.warning('Live desk reminder delivery failed', exc_info=True)
    due=await run_blocking(repo.urgent_due,now,timeout=5)
    if due:
        identifiers=await run_blocking(repo.near_entry_ids,now,timeout=5)
        for row in due:
            try:await run_blocking(permitted,int(row['admin_id']),timeout=5)
            except PermissionError:continue
            if not identifiers or not await run_blocking(repo.claim_urgent,row,now,identifiers,timeout=5):continue
            if row['admin_id'] in notified:continue
            try:
                from telegram import InlineKeyboardButton,InlineKeyboardMarkup
                await bot.send_message(chat_id=int(row['admin_id']),text='سیگنال نزدیک ورود، منتظر بررسی ادمین است.',
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('سیگنال‌های زنده',callback_data='ls:h')]]))
            except Exception:logger.warning('Optional near-entry reminder delivery failed',exc_info=True)
