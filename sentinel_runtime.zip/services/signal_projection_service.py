from __future__ import annotations

from typing import Any
from contextlib import nullcontext

from modules.signal_status import signal_is_final
from repositories.v2.events import EventRepository
from repositories.v2.signals import SignalRepository
from repositories.v2.common import content_hash


def canonical_signal_event(row: dict[str, Any], source_event: str = "signal.updated") -> str:
    """Collapse Telegram lifecycle variants into one Mini App event contract."""
    event = str(source_event or "signal.updated").strip().lower()
    if event == "signal.deleted":
        return event
    if event == "signal.created":
        return event
    if signal_is_final(row):
        return "signal.closed"
    return "signal.updated"


def project_signal_update(
    row: dict[str, Any],
    source_event: str = "signal.updated",
    *,
    signals: SignalRepository | None = None,
    events: EventRepository | None = None,
) -> dict[str, Any]:
    """Persist the canonical signal and publish the matching durable event."""
    signals = signals or SignalRepository()
    engine = getattr(signals, 'engine', None)
    events = events or EventRepository(engine)
    if engine is not None and getattr(events, 'engine', engine) is not engine:
        raise ValueError('PROJECTION_DATABASE_MISMATCH')
    with engine.atomic() if engine is not None else nullcontext():
        normalized = signals.upsert(dict(row))
        signal_id = str(normalized.get("id") or row.get("id") or "")
        event_type = canonical_signal_event(normalized, source_event)
        key = 'signal:' + signal_id + ':' + event_type
        if event_type != 'signal.created':
            key += ':' + content_hash({k:v for k,v in normalized.items() if k != 'revision'})
        event = events.append(
        "*",
        event_type,
        {
            "signal_id": signal_id,
            "symbol": normalized.get("symbol") or row.get("symbol"),
            "status": normalized.get("status") or row.get("status"),
            "highest_target_hit": int(
                normalized.get("highest_target_hit") or row.get("highest_target_hit") or 0
            ),
            "updated_at": normalized.get("updated_at") or row.get("updated_at"),
            "source_event": str(source_event or "signal.updated"),
        },
        entity_type="signal",
        entity_id=signal_id,
        idempotency_key=key, publish=False,
        )
    if event.pop('_inserted', False) and hasattr(events, '_publish_redis'):
        events._publish_redis(event)
    return normalized


def queue_projection(db, row, source_event='signal.updated'):
    from core.utils import utc_iso
    db.setdefault('signal_projection_outbox', {})[str(row['id'])] = {
        'row': dict(row), 'source_event': source_event, 'fingerprint': content_hash(row), 'queued_at': utc_iso()}


def complete_projection(db, row):
    old=db.get('signal_projection_outbox',{}).get(str(row['id']))
    if old and old['fingerprint']==content_hash(row):
        db['signal_projection_outbox'].pop(str(row['id']),None)


def repair_projections(limit=20):
    from core.db import read_db_sections,with_db_sections
    snapshot=read_db_sections(('signal_projection_outbox','signal_deletion_audit','signals','signal_archive'))
    canonical={str(r['id']):r for r in [*snapshot.get('signal_archive',[]),*snapshot.get('signals',[])]}
    repaired=0
    for key, pending in list(snapshot.get('signal_projection_outbox',{}).items())[:max(1,min(100,limit))]:
        if key in snapshot.get('signal_deletion_audit',{}):
            with_db_sections(('signal_projection_outbox',),lambda db:db.setdefault('signal_projection_outbox',{}).pop(key,None))
            continue
        row=canonical.get(key,pending['row'])
        try:
            project_signal_update(row,pending['source_event'])
            # A newer queued version must survive this repair.
            def done(db):
                old=db.get('signal_projection_outbox',{}).get(key)
                if old and old['fingerprint']==pending['fingerprint']:db['signal_projection_outbox'].pop(key,None)
            with_db_sections(('signal_projection_outbox',),done)
            repaired+=1
        except Exception:
            import logging
            logging.getLogger(__name__).exception('Signal projection repair deferred signal_id=%s',key)
    return repaired


def invalidate_publication(record, *, delivery_id, reason, corrections, engine=None):
    from core.db import with_db
    from core.utils import utc_iso
    update={'status':'needs_review','publication_valid':False,'publication_reason':str(reason),
            'publication_corrections':corrections,'updated_at':utc_iso()}
    def mutate(db):
        found=next((r for r in db.get('signals',[]) if str(r.get('id'))==str(record['id'])),None)
        if found is None:return None
        found.update(update)
        # The canonical committing cursor projects this invalidation atomically.
        db.setdefault('signal_publication_invalidations',{})[delivery_id]=dict(found)
        return dict(found)
    from core.storage.engine import normalized_engine
    saved=with_db(mutate) if engine is None or engine is normalized_engine() else None
    if saved is None:
        # Local/injected normalized-only publishers still use the same contract.
        repo=SignalRepository(engine)
        old=repo.get(record['id']) or record
        saved=project_signal_update({**old,**update},signals=repo,events=EventRepository(repo.engine))
    return saved
