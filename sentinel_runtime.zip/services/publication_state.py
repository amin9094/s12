"""Durable publication claims; ambiguous sends never automatically repeat."""
import time
from uuid import uuid4
from repositories.v2.common import content_hash


class DeliveryUncertain(RuntimeError):
    pass


class DeliveryRejected(RuntimeError):
    pass


def acquire(db, key, data, actor):
    digest=content_hash({k:data.get(k) for k in ('symbol','side','entry','entries','stop','targets','risk',
        'locked_plan_hash','poster_snapshot','chart_photo_file_id','chart_photo_file_ids','market_category')})
    rows=db.setdefault('signal_delivery_checkpoints',{})
    old=rows.get(key,{})
    if old.get('fingerprint') and old['fingerprint']!=digest:raise ValueError('PUBLICATION_CONTENT_CHANGED')
    if old.get('record_payload') and old.get('delivered_channels'):return None
    if old.get('status') in {'sending','uncertain'}:raise DeliveryUncertain('SIGNAL_DELIVERY_UNCERTAIN')
    now=int(time.time()*1000)
    if old.get('status')=='preparing' and now-int(old.get('claimed_ms',now))<600000:
        raise ValueError('PUBLICATION_IN_PROGRESS')
    if old.get('identity'):
        from modules.signal_portal import release_reserved_signal_number
        release_reserved_signal_number(db, old['identity'])
    token=uuid4().hex
    rows[key]={**old,'status':'preparing','fingerprint':digest,'claim_token':token,
               'claimed_ms':now,'actor':str(actor)}
    rows[key].pop('identity', None)
    return token


def reserve(db, key, token, category):
    row = db.get('signal_delivery_checkpoints', {}).get(key, {})
    if not token or row.get('claim_token') != token or row.get('status') != 'preparing':
        raise ValueError('PUBLICATION_LEASE_CHANGED')
    from modules.signal_portal import reserve_signal_identity
    identity = row.get('identity') or reserve_signal_identity(db, category)
    row['identity'] = dict(identity)
    return dict(identity)


def start(db,key,token,identity):
    row=db.setdefault('signal_delivery_checkpoints',{}).get(key,{})
    if row.get('claim_token')!=token or row.get('status')!='preparing':raise ValueError('PUBLICATION_LEASE_CHANGED')
    row.update(status='sending',identity=dict(identity),send_started_ms=int(time.time()*1000))
    db.setdefault('signal_number_reservations',{}).setdefault(str(identity['id']),dict(identity))['state']='SENDING'


def failed(db,key,token,exc):
    row=db.get('signal_delivery_checkpoints',{}).get(key,{})
    if token and row.get('claim_token')!=token:return
    if row.get('status') in {'committed','delivered'}:return
    if row.get('status') == 'preparing' and row.get('identity'):
        from modules.signal_portal import release_reserved_signal_number
        release_reserved_signal_number(db, row['identity'])
    uncertain=isinstance(exc,DeliveryUncertain) or row.get('status')=='sending' and not isinstance(exc,DeliveryRejected)
    row.update(status='uncertain' if uncertain else 'failed',failure_code=type(exc).__name__,finished_ms=int(time.time()*1000))
