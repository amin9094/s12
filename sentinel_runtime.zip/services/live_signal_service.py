from modules.signal_targets import TARGET_KEYS
"""Admin-only live signal desk, exact approvals and prospective paper tracking."""
import asyncio
import time
from hashlib import sha256
from core.async_runtime import run_blocking
from repositories.v2.common import json_dump,content_hash
from repositories.v2.live_signal_inbox import LiveSignalInbox,MARKETS,STRATEGIES
from repositories.v2.strategy_paper import StrategyPaperRepository
from modules.signal_execution import mode_of,market_detail,reference_plan,account_identity,account_key,MODES


def permitted(user_id,publish=False,*,paper_action=None):
    from services.setup_review_service import can_review_setups
    from services.admin_review_delivery_service import can_publish_review
    if not can_review_setups(user_id) or publish and not can_publish_review(user_id):raise PermissionError('FORBIDDEN')
    if paper_action is not None:
        from modules.admin_access import has_permission,PAPER_ACTION_PERMISSIONS
        from core.db import read_db_sections
        if paper_action not in PAPER_ACTION_PERMISSIONS or not has_permission(read_db_sections(('delegated_admins','admin_shifts')),user_id,PAPER_ACTION_PERMISSIONS[paper_action]):
            raise PermissionError('FORBIDDEN')


def _review_tick(t,epoch):
    return {**t,'epoch':str(epoch),'id':sha256(json_dump([epoch,t]).encode()).hexdigest()}


def tape(row,owner=None,after_id=None):
    p=row['payload']['plan']
    if row['payload']['kind']=='review':
        from services.admin_review_market_service import source_monitor
        m=source_monitor(p['symbol'])
        if m.failure:raise ValueError('PAPER_SOURCE_UNAVAILABLE')
        return [_review_tick(t,m.epoch) for t in m.rows.get(p['symbol'],())]
    if owner is None:raise ValueError('PAPER_SOURCE_UNAVAILABLE')
    j=owner.journal_for(p['symbol'],p['provider'])
    if not j or j.failure:raise ValueError('PAPER_SOURCE_UNAVAILABLE')
    return [{'bid':str(f.quote.bid),'ask':str(f.quote.ask),'event_ms':f.quote.event_ms,
             'received_ms':f.quote.received_ms,'epoch':f.epoch,'id':f.quote.source_id}
            for f in (owner.paper_frames(p['symbol'],p['provider'],after_id) if after_id and hasattr(owner,'paper_frames') else j.rows) if not f.snapshot]


async def verify(row,owner=None):
    from repositories.v2.strategy_paths import strategy_enabled
    if not await run_blocking(strategy_enabled,row['payload']['plan']['engine'],timeout=5):raise ValueError('STRATEGY_DISABLED')
    from modules.automated_market_scope import require_global_symbol
    require_global_symbol(row['payload']['plan']['symbol'])
    from modules.signal_plan_policy import validate_locked_signal_plan
    from repositories.v2.common import content_hash
    if content_hash(row['payload']['plan'])!=row['payload']['plan_hash']:
        raise ValueError('SIGNAL_PLAN_CHANGED')
    validate_locked_signal_plan(row['payload']['plan'])
    if mode_of(row['payload']['plan'])=='MARKET':
        from modules.signal_execution import assert_publish_quote
        detail=market_detail(row['payload']['plan'])
        parent=await run_blocking(LiveSignalInbox().get,detail['parent_signal_id'],timeout=5)
        if not parent or parent['payload']['plan_hash']!=detail['base_plan_hash']:
            raise ValueError('MARKET_BASE_PLAN_CHANGED')
        proof=await verify(parent,owner)
        ticks=tape(row,owner)
        if not ticks:raise ValueError('MARKET_PUBLICATION_QUOTE_STALE')
        assert_publish_quote(row['payload']['plan'],ticks[-1],int(time.time()*1000))
        return proof
    from repositories.v2.market_evidence import MarketEvidenceRepository
    p=row['payload']['plan']
    if await run_blocking(MarketEvidenceRepository().pending_revisions,p['symbol'],p['provider'],timeout=5):
        raise ValueError('SOURCE_CANDLE_REVISION_PENDING')
    if row['payload']['kind']=='review':
        from services.admin_review_delivery_service import validate_proposal
        from services.admin_review_market_service import check_review_before_entry
        from repositories.v2.strategy_reviews import StrategyReviewRepository
        source=await run_blocking(StrategyReviewRepository().get,row['payload']['source_id'],timeout=5)
        if not source or source['state']!='NEEDS_REVIEW':raise ValueError('SIGNAL_NO_LONGER_PENDING')
        validate_proposal(source['payload'])
        if source['payload']['draft_hash']!=row['payload']['plan_hash']:raise ValueError('SIGNAL_PLAN_CHANGED')
        return await check_review_before_entry(source['payload'])
    from repositories.v2.setup_proposals import SetupRepository
    from modules.setup_lifecycle import SetupPlan
    repo=SetupRepository();source=await run_blocking(repo.get,row['payload']['source_id'],timeout=5)
    if (not source or source['payload']['state']['phase']!='PROPOSED_PRETOUCH'
        or source['payload'].get('tracking_state')=='NEEDS_REVIEW'
        or source['payload']['plan_hash']!=row['payload']['plan_hash']):raise ValueError('SIGNAL_NO_LONGER_PENDING')
    if owner is None:raise ValueError('QUOTE_OWNER_UNAVAILABLE')
    plan=SetupPlan.from_dict(source['payload']['plan'])
    proof=await owner.freshness(plan,epoch=source['payload']['freshness_proof'].get('epoch',''),
                                start_ms=plan.evidence_cutoff_ms,through_ms=int(time.time()*1000))
    if plan.engine in {'indicators','sweep_fvg','order_block','fibonacci_pullback','custom'}:
        from services.canonical_market_service import _historical_bars
        from modules.strategies.common import Context
        bars=await _historical_bars(plan.symbol,plan.timeframe,limit=300,provider=plan.provider)
        journal=owner.journal_for(plan.symbol,plan.provider)
        if not journal or journal.failure or not journal.rows:raise ValueError('INDICATOR_LIVE_SOURCE_LOST')
        quote=journal.rows[-1].quote
        context=Context(tuple(bars),int(time.time()*1000),plan.tick_size,quote.ask-quote.bid,current_quote=quote)
        context.validate()
        from modules.strategies.liquidity import assert_plan_direction
        assert_plan_direction(source['payload']['plan'],context.closed,quote.ask-quote.bid)
        from modules.signal_plan_policy import assert_current_stop
        assert_current_stop(source['payload']['plan'],context.closed,quote.ask-quote.bid)
        if plan.engine=='indicators':
            from modules.indicator_suite import revalidate_plan
            revalidate_plan(source['payload']['plan'],context.closed)
        if plan.engine=='custom':
            from modules.custom_strategy import revalidate_plan
            revalidate_plan(source['payload']['plan'],bars,context.cutoff_ms,quote.ask-quote.bid)
        # The additional history request cannot leave an old quote proof valid.
        proof=await owner.freshness(plan,epoch=source['payload']['freshness_proof'].get('epoch',''),
                                    start_ms=plan.evidence_cutoff_ms,through_ms=int(time.time()*1000))
    return proof


async def stage_results(result,owner=None):
    from repositories.v2.strategy_reviews import StrategyReviewRepository
    from repositories.v2.setup_proposals import SetupRepository
    reviews=StrategyReviewRepository();native=SetupRepository();inbox=LiveSignalInbox()
    candidates=[]
    for key in result.get('new_review_ids',[]):
        r=await run_blocking(reviews.get,key,timeout=5)
        if r and r['state']=='NEEDS_REVIEW' and r['payload'].get('review_kind')=='PREENTRY_PROPOSAL':
            p=r['payload'];candidates.append((r['id'],'review',p['draft_plan'],p['draft_hash'],p,p.get('profile_id')))
    for saved in result.get('stored_setups',[]):
        if saved.get('duplicate'):continue
        r=await run_blocking(native.get,saved['id'],timeout=5)
        if r:
            p=r['payload'];candidates.append((r['id'],'native',p['plan'],p['plan_hash'],None,p.get('classification',{}).get('profile_id')))
    staged=[]
    for source_id,kind,plan,digest,proposal,profile in candidates:
        from modules.automated_market_scope import global_symbol_allowed
        if not global_symbol_allowed(plan.get('symbol')):continue
        from repositories.v2.strategy_paths import strategy_enabled
        if not await run_blocking(strategy_enabled,plan['engine'],inbox.engine,timeout=5):continue
        row=await run_blocking(inbox.stage,source_id,kind,plan,digest,proposal=proposal,profile_id=profile,timeout=5)
        if row['state']!='STAGING':continue
        try:
            proof=await verify(row,owner)
            ticks=tape(row,owner)
            if not ticks or int(time.time()*1000)-ticks[-1]['event_ms']>5000:raise ValueError('PAPER_SOURCE_STALE')
            from services.signal_chart_service import capture
            chart=await run_blocking(capture,plan,inbox.engine,timeout=5)
            def finalize_stage():
                with inbox.engine.atomic():
                    enrollment=StrategyPaperRepository(inbox.engine).enroll(row,ticks[-1])
                    inbox.update(row,'PENDING',{**row['payload'],'chart_snapshot':chart,'paper_enrollment':enrollment})
            await run_blocking(finalize_stage,timeout=5)
            receipt=int(time.time()*1000)
            proof=await verify(row,owner)
            # Verify through actual inbox availability, never the earlier
            # calculation/STAGING timestamp and never an assumed read receipt.
            if kind=='native':
                await run_blocking(native.record_admin_delivery,source_id,delivered_ms=receipt,
                    untouched_through_ms=proof['observed_through_ms'],proof=proof,timeout=5)
            else:
                await run_blocking(reviews.mark_review_receipt,source_id,receipt_ms=receipt,verification=proof,timeout=5)
            staged.append(row['id'])
            market=await stage_market_signal(await run_blocking(inbox.get,row['id'],timeout=5),owner)
            if market:staged.append(market)
        except ValueError as exc:
            if str(exc)=='INBOX_CONCURRENT_CHANGE':
                # Another staging worker or an admin decision already owns
                # the new state; a duplicate cannot expire their valid card.
                continue
            await run_blocking(inbox.terminate,row['id'],'EXPIRED',str(exc),timeout=5)
            # A late admin-inbox receipt must not cancel an experiment already
            # armed before the first visit. Its quote tape determines the fill.
            if str(exc) not in {'REVIEW_ZONE_ALREADY_TOUCHED','ORIGINAL_ZONE_TOUCHED_BEFORE_DELIVERY',
                                'NATIVE_CANDLE_BRIDGE_ZONE_TOUCHED'}:
                await run_blocking(StrategyPaperRepository(inbox.engine).cancel_waiting,row['id'],reason=str(exc),timeout=5)
    return staged


async def stage_market_signal(parent,owner=None):
    """A separate immediate experiment; never fill its reference-zone order."""
    from modules.signal_execution import build_market
    if mode_of(parent['payload']['plan'])!='PENDING':return None
    try:
        ticks=tape(parent,owner)
        if not ticks:return None
        build_market(parent['payload']['plan'],parent['id'],ticks[-1],int(time.time()*1000))
        verification=await verify(parent,owner)
        ticks=tape(parent,owner)
        plan=build_market(parent['payload']['plan'],parent['id'],ticks[-1],int(time.time()*1000))
        market_detail(plan)['verification_at_analysis']=verification
    except ValueError:return None
    from services.signal_chart_service import capture
    chart=await run_blocking(capture,plan,LiveSignalInbox().engine,timeout=5)
    def save():
        inbox=LiveSignalInbox()
        with inbox.engine.atomic():
            row=inbox.stage(parent['id']+':MARKET',parent['payload']['kind'],plan,content_hash(plan),
                proposal=parent['payload'].get('proposal'),profile_id=parent['payload'].get('profile_id'))
            if row['state']!='STAGING':return None
            if not 0<=int(time.time()*1000)-ticks[-1]['received_ms']<=5000:
                inbox.update(row,'EXPIRED',{**row['payload'],'status_reason':'MARKET_ANALYSIS_QUOTE_STALE'});return None
            enrollment=StrategyPaperRepository(inbox.engine).enroll(row,ticks[-1])
            inbox.update(row,'PENDING',{**row['payload'],'chart_snapshot':chart,'paper_enrollment':enrollment})
            return row['id']
    return await run_blocking(save,timeout=10)


def desk_snapshot(user_id,*,market=None,engine=None,before=None,execution_mode=None,queue=False,**filters):
    permitted(user_id)
    if market is not None and market not in MARKETS or engine is not None and engine not in STRATEGIES:
        raise ValueError('INBOX_FILTER_INVALID')
    inbox=LiveSignalInbox();result=inbox.folders(user_id)
    if queue or market and engine:
        if queue:filters['publication_state']='PENDING'
        rows=inbox.items(market=market,engine=engine,before=before,execution_mode=execution_mode,admin=user_id,**filters)
        from modules.signal_plan_policy import entry_eligibility
        result['items']=[{**r,'entry_eligibility':entry_eligibility(r['payload']['plan']),
                          'payload':{k:v for k,v in r['payload'].items() if k not in {'proposal','chart_snapshot'}}} for r in rows]
        from repositories.v2.desk_insights import annotate_relations
        annotate_relations(inbox,result['items'])
        result['next_before']=str(rows[-1]['created_ms'])+':'+rows[-1]['id'] if len(rows)==40 else None
        if filters.get('sort')=='distance':
            result['next_before']=rows[-1].get('queue_next_before') if rows else None
        result['sort_scope']='ALL_MATCHING_SNAPSHOT' if filters.get('sort')=='distance' else 'ALL_MATCHING_ROWS'
        result['queue']=bool(queue)
    return result


def signal_status(user_id,identifier):
    permitted(user_id)
    row=LiveSignalInbox().get(identifier)
    if not row:raise ValueError('LIVE_SIGNAL_NOT_FOUND')
    from modules.automated_market_scope import require_global_symbol
    require_global_symbol(row['payload']['plan']['symbol'])
    return {'id':row['id'],'state':row['state'],'revision':row['revision'],
            'plan_hash':row['payload']['plan_hash'],'paper':StrategyPaperRepository().for_signal(identifier),
            'paper_enrollment':row['payload'].get('paper_enrollment'),'observed_ms':int(time.time()*1000)}


def signal_statuses(user_id,identifiers):
    permitted(user_id)
    import re
    if not identifiers or len(identifiers)>40 or any(not re.fullmatch('[a-f0-9]{32}',x) for x in identifiers):
        raise ValueError('SIGNAL_STATUS_SELECTION_INVALID')
    # Explicit allow-list; no arbitrary identifiers become SQL fragments.
    inbox=LiveSignalInbox()
    from repositories.v2.live_signal_inbox import global_inbox_scope
    scope,params=global_inbox_scope(inbox.engine,'i.')
    with inbox.engine.transaction(read_only=True) as c:
        query='SELECT i.id,i.state,i.created_ms,i.revision,i.payload,t.state AS paper_state,t.payload AS paper_payload,t.revision AS paper_revision FROM s9_signal_inbox i LEFT JOIN s9_strategy_paper_trades t ON t.signal_id=i.id WHERE '+scope+' AND i.id IN ('+','.join('?' for _ in identifiers)+')'  # nosec B608 -- fixed scope and placeholders only; validated identifiers are bound
        rows=c.execute(query,(*params,*identifiers)).fetchall()
    return {'items':[{'id':r['id'],'state':r['state'],'revision':r['revision'],
                     'plan_hash':r['payload']['plan_hash'],'quote_status':r['quote_status'],'distance_r':r['distance_r'],
                     'paper_state':r['paper_state'] or 'UNAVAILABLE','paper_revision':r['paper_revision']} for r in inbox._decode_rows(rows)]}


async def decide(user_id,identifier,body):
    await run_blocking(permitted,user_id,body['action']=='publish',timeout=5)
    from core.miniapp_server import _run_on_telegram_loop
    async def work():
        from services.strategy_quote_owner import current_owner
        from repositories.v2.strategy_live import StrategyLiveRepository
        from services.strategy_delivery_service import channel_target
        inbox=LiveSignalInbox();live=StrategyLiveRepository(inbox.engine)
        row=await run_blocking(inbox.get,identifier,timeout=5)
        if not row or row['payload']['plan_hash']!=body['plan_hash']:raise ValueError('SIGNAL_PLAN_CHANGED')
        action=body['action']
        if action=='publish':
            if row['state'] not in {'PENDING','PUBLISHED'}:raise ValueError('SIGNAL_NOT_PENDING')
            try:await verify(row,current_owner())
            except ValueError as exc:
                await run_blocking(inbox.terminate,identifier,'EXPIRED',str(exc),timeout=5);raise
        def commit():
            with inbox.engine.atomic():
                current=inbox.get(identifier)
                if current['revision']!=row['revision']:raise ValueError('INBOX_CONCURRENT_CHANGE')
                payload=current['payload']
                if action=='publish':
                    audience=body['audience'];target=channel_target(audience)
                    previous=payload['publications'].get(audience)
                    if previous:raise ValueError('PUBLICATION_ALREADY_REQUESTED')
                    key=live.enqueue(setup_id=identifier,version=current['revision'],event_id='LIVE_DESK_SIGNAL',audience=audience,
                                     target_id=target,content_hash=body['plan_hash'],actor=str(user_id))
                    from services.poster_presets_service import selection
                    poster=selection(audience,engine=inbox.engine)
                    with inbox.engine.transaction() as c:
                        c.execute("UPDATE s9_deliveries SET state='PENDING',attempts=0,payload=? WHERE id=? AND state='REVOKED'",(json_dump({'actor':str(user_id)}),key))
                        if poster:c.execute("UPDATE s9_deliveries SET payload=? WHERE id=? AND state='PENDING'",(json_dump({'actor':str(user_id),'poster_snapshot':poster}),key))
                    payload['publications'][audience]={'delivery_id':key,'actor':str(user_id),'state':'QUEUED'}
                    inbox.update(current,'QUEUED',payload)
                    return {'state':'QUEUED','delivery_id':key}
                if current['state']=='PUBLISHED':raise ValueError('PUBLISHED_SIGNAL_REQUIRES_EXISTING_MANAGEMENT')
                with inbox.engine.transaction() as c:
                    sending=c.execute("SELECT id FROM s9_deliveries WHERE setup_id=? AND state='SENDING'",(identifier,)).fetchone()
                    if sending:raise ValueError('PUBLICATION_ALREADY_SENDING')
                    c.execute("UPDATE s9_deliveries SET state='REVOKED' WHERE setup_id=? AND state='PENDING'",(identifier,))
                if action=='cancel_publication':
                    payload['publications']={};inbox.update(current,'PENDING',payload)
                elif action=='cancel':
                    inbox.update(current,'CANCELLED',{**payload,'cancelled_by':str(user_id),'cancelled_ms':int(time.time()*1000)})
                    # This is an editorial decision about the signal/channel.
                    # The strategy's prospective experiment keeps running.
                else:raise ValueError('SIGNAL_ACTION_INVALID')
                return {'state':'PENDING' if action=='cancel_publication' else 'CANCELLED'}
        return await run_blocking(commit,timeout=5)
    r=await _run_on_telegram_loop(work())
    return r if r is not None else await work()


async def track_paper(owner=None):
    repo=StrategyPaperRepository();inbox=LiveSignalInbox(repo.engine)
    for trade in await run_blocking(repo.tracking_batch,timeout=5):
        row=await run_blocking(inbox.get,trade['signal_id'],timeout=5)
        try:
            # The frozen experiment owns its plan and source. Editorial
            # cancellation, removal, or changes to the inbox cannot alter it.
            experiment={'payload':{'plan':trade['payload']['plan'],
                                   'kind':trade['payload']['source_kind']}}
            ticks=await run_blocking(tape,experiment,owner,**({'after_id':trade['payload']['last_tick_id']} if hasattr(owner,'paper_frames') else {}),timeout=5)
            if not ticks:raise ValueError('PAPER_SOURCE_STALE')
            if experiment['payload']['kind']=='native' and hasattr(owner,'paper_frames'):
                journal=owner.journal_for(experiment['payload']['plan']['symbol'],experiment['payload']['plan']['provider'])
                if (not journal or journal.failure or not journal.rows or journal.rows[-1].epoch!=ticks[-1]['epoch']
                    or not journal.rows[-1].quote.fresh(int(time.time()*1000))):raise ValueError('PAPER_SOURCE_STALE')
            elif not 0<=int(time.time()*1000)-ticks[-1]['event_ms']<=5000:raise ValueError('PAPER_SOURCE_STALE')
            last=trade['payload']['last_tick_id']
            index=next((i for i,t in enumerate(ticks) if t['id']==last),None)
            if index is None:raise ValueError('PAPER_REPLAY_WINDOW_MISSING')
            # Bounded catch-up across cycles. Every sample was recorded by the
            # same current epoch; no unobserved gap is bridged. The cursor is
            # committed atomically per batch; a timeout resumes from its durable cursor.
            replay=ticks[index+1:index+2001]
            await run_blocking(repo.tick_batch,trade['id'],replay,timeout=10)
            if row and row['state']=='PENDING' and mode_of(row['payload']['plan'])=='PENDING':
                # Invalidate approval as soon as the complete zone is visited.
                p=row['payload']['plan']
                from decimal import Decimal as D
                if any(D(t['bid'])<=D(p['zone_high']) and D(t['ask'])>=D(p['zone_low']) for t in replay):
                    touched=next(t['event_ms'] for t in replay if D(t['bid'])<=D(p['zone_high']) and D(t['ask'])>=D(p['zone_low']))
                    def expire_touch():
                        from repositories.v2.signal_timeline import record
                        with inbox.engine.atomic() as c:
                            record(c,row['id'],'FIRST_ZONE_TOUCH',touched,key='observed')
                            inbox.terminate(row['id'],'EXPIRED','ZONE_VISITED_BEFORE_PUBLICATION')
                    await run_blocking(expire_touch,timeout=5)
        except ValueError as exc:
            await run_blocking(repo.suspend,trade['id'],str(exc),timeout=5)
            if row and row['state'] in {'PENDING','QUEUED'}:
                await run_blocking(inbox.terminate,row['id'],'NEEDS_REVIEW',str(exc),timeout=5)
        finally:
            # Rotate fairly across all signals rather than repeatedly taking
            # the first 1000 unpublished trades. The cursor survives restarts.
            await run_blocking(repo.advance_tracking_cursor,trade,timeout=5)
    from repositories.v2.paper_equity import record as record_equity
    await run_blocking(record_equity,repo.engine,timeout=10)


def paper_snapshot(user_id,engine,**kwargs):
    permitted(user_id);return StrategyPaperRepository().snapshot(engine,**kwargs)


def paper_breakdown(user_id,engine,run_id,*,after=''):
    permitted(user_id)
    if not isinstance(after,str) or len(after)>1000:raise ValueError('PAPER_BREAKDOWN_CURSOR_INVALID')
    repo=StrategyPaperRepository();repo.snapshot(engine,run_id=run_id,limit=1)
    from repositories.v2.paper_statistics import breakdown
    with repo.engine.transaction(read_only=True,repeatable_read=True) as c:return breakdown(c,run_id,after=after)


def paper_accounts(user_id):
    permitted(user_id);repo=StrategyPaperRepository()
    return {'accounts':[{'engine':account_key(e,mode),'strategy':e,'execution_mode':mode,
                         **repo.snapshot(account_key(e,mode),limit=1)} for e in STRATEGIES for mode in MODES]}


def compare_paper(user_id,strategy,**filters):
    permitted(user_id)
    if strategy not in STRATEGIES:raise ValueError('PAPER_STRATEGY_INVALID')
    from repositories.v2.paper_comparison import comparison
    return comparison(StrategyPaperRepository(),strategy,**filters)


def paper_exposure(user_id):
    permitted(user_id)
    from repositories.v2.paper_comparison import exposure
    return exposure(StrategyPaperRepository())


def configure_paper_costs(user_id,engine,body):
    permitted(user_id,paper_action='costs')
    if not isinstance(body,dict) or set(body)!={'run_id','revision','symbol','specification'}:raise ValueError('PAPER_COST_SPEC_INVALID')
    return StrategyPaperRepository().configure_costs(engine,actor=user_id,run_id=body['run_id'],revision=body['revision'],symbol=body['symbol'],specification=body['specification'])


def control_paper(user_id,engine,body):
    permitted(user_id,paper_action='control')
    return StrategyPaperRepository().control(engine,actor=user_id,expected_run_id=body['run_id'],
            expected_revision=body['revision'],enabled=body['enabled'])


async def manage_paper_trade(user_id,engine,identifier,body):
    await run_blocking(permitted,user_id,paper_action=body['action'],timeout=5)
    async def work():
        repo=StrategyPaperRepository();ticks=None
        if body['action']=='close':
            # The API and Telegram runtime can run in different threads/loops.
            # Both native journals and the indicative monitor belong to the
            # Telegram loop; never create an empty API-loop monitor as a fallback
            # for a registered runtime. Recheck permission after dispatch too.
            await run_blocking(permitted,user_id,paper_action=body['action'],timeout=5)
            from services.strategy_quote_owner import current_owner
            trade=await run_blocking(repo.trade,identifier,timeout=5)
            if not trade or trade['run_id']!=body['run_id'] or trade['payload']['plan']['engine']!=account_identity(engine)[0]:
                raise ValueError('PAPER_TRADE_NOT_FOUND')
            ticks=tape({'payload':{'plan':trade['payload']['plan'],'kind':trade['payload']['source_kind']}},current_owner())
        return await run_blocking(repo.manage_trade,engine,identifier,actor=user_id,expected_run_id=body['run_id'],
                expected_revision=body['revision'],action=body['action'],ticks=ticks,timeout=10)
    if body['action']=='close':
        from core.miniapp_server import _run_on_telegram_loop
        result=await _run_on_telegram_loop(work())
        if result is not None:return result
    # No registered runtime: the existing local source checks still fail closed
    # without a fresh tape. Cancelling a waiting paper order needs no live data.
    return await work()


def export_paper(user_id,engine,run_id):
    permitted(user_id);return StrategyPaperRepository().export_csv(engine,run_id=run_id)


def reset_paper(user_id,engine,body):
    permitted(user_id,paper_action='reset')
    from services.strategy_profile_service import selected_parameters
    profile=body.get('profile_id')
    base,mode=account_identity(engine)
    if mode=='MARKET' and profile is not None:raise ValueError('MARKET_PROFILE_SELECTED_BY_ANALYSIS')
    if base=='custom' and profile is not None:raise ValueError('CUSTOM_PROFILE_CONFIGURED_IN_BUILDER')
    if profile is not None:selected_parameters({'selected_profiles':{engine:profile}})
    result=StrategyPaperRepository().reset(engine,actor=user_id,expected_run_id=body['run_id'],
                                          risk_percent=body.get('risk_percent'),profile_id=profile)
    if profile is not None:
        from repositories.v2.strategy_paths import StrategyPaths
        paths=StrategyPaths()
        with paths.engine.transaction() as cursor:
            cursor.execute('UPDATE s9_strategy_paths SET active=0,revision=revision+1 WHERE engine=? AND active=1',(base,))
        paths.ensure(base)
    return result


async def deliver_desk_signal(bot,intent,live,owner):
    """Reuse the numbered image publisher, with a final guard after rendering."""
    from services.strategy_delivery_service import channel_target
    from bot_runtime.growth_campaigns import _publish_signal_payload
    inbox=LiveSignalInbox(live.engine);transmitted=False
    row=await run_blocking(inbox.get,intent['setup_id'],timeout=5)
    async def guard():
        await run_blocking(permitted,intent['payload'].get('actor'),True,timeout=5)
        current=await run_blocking(inbox.get,intent['setup_id'],timeout=5)
        pub=(current or {}).get('payload',{}).get('publications',{}).get(intent['audience'],{})
        if (not current or current['state'] not in {'QUEUED','PUBLISHED'}
            or pub.get('delivery_id')!=intent['id'] or pub.get('actor')!=intent['payload'].get('actor')
            or current['payload']['plan_hash']!=intent['content_hash']
            or await run_blocking(channel_target,intent['audience'],timeout=5)!=intent['target_id']):raise ValueError('LIVE_DESK_APPROVAL_REVOKED')
        proof=await verify(current,owner)
        # No further rendering/database await between this last source check and send.
        if current['payload']['kind']=='review':
            from services.admin_review_market_service import review_monitor
            review_monitor().check(current['payload']['proposal'],int(time.time()*1000))
        else:
            from modules.setup_lifecycle import SetupPlan
            plan=SetupPlan.from_dict(reference_plan(current['payload']['plan']))
            owner.pre_send_proof(plan,epoch=proof['epoch'],verified_through_ms=proof['observed_through_ms'])
        if mode_of(current['payload']['plan'])=='MARKET':
            from modules.signal_execution import assert_publish_quote
            assert_publish_quote(current['payload']['plan'],tape(current,owner)[-1],int(time.time()*1000))
    try:
        if not row:raise ValueError('LIVE_DESK_SIGNAL_NOT_FOUND')
        await guard()
        p=row['payload']['plan']
        payload={'symbol':p['symbol'],'side':p['direction'].lower(),'entry':p['entry'],
                 'entries':[p['entry']],'stop':p['stop'],
                 'targets':[p[k] for k in TARGET_KEYS if p.get(k) is not None],
                 'risk':1.0,'timeframe':p['timeframe'],'market_category':'crypto' if row['market']=='crypto' else 'forex',
                 'source':'live_signal_desk','live_inbox_id':row['id'],'strategy':p['engine'],
                 'submodel':p['submodel'],'source_provider':p['provider'],'locked_plan_hash':intent['content_hash'],
                 'execution_mode':mode_of(p),
                 'locked_plan':p,'poster_snapshot':intent['payload'].get('poster_snapshot'),
                 'note':('مارکت با قیمت زمان تحلیل؛ انتشار به معنی ورود آزمایشی تازه نیست.' if mode_of(p)=='MARKET' else ''),'analysis':''}
        from decimal import Decimal
        remaining=Decimal(100);portions=[]
        for index in range(len(payload['targets'])):
            portion=remaining if index==len(payload['targets'])-1 else remaining/2
            portions.append(float(portion));remaining-=portion
        payload.update(partial_close_plan=portions,breakeven_after_tp=0,
                       exit_policy='HALF_REMAINING_AT_TP_LAST_CLOSES_ALL_FIXED_STOP')
        async def final_guard():
            nonlocal transmitted
            await run_blocking(live.start_delivery,intent['id'],intent['payload'].get('claim_token'),timeout=5)
            await guard();transmitted=True
        # The publisher's durable delivery checkpoint prevents retry duplicates.
        record,errors=await _publish_signal_payload(bot,payload,
            'public' if intent['audience']=='telegram_public' else 'private',intent['payload']['actor'],
            scheduled_id='live-desk:'+intent['id'],pre_send_guard=final_guard)
    except asyncio.CancelledError:raise
    except Exception as exc:
        from services.publication_state import DeliveryRejected
        failure='FAILED' if isinstance(exc,DeliveryRejected) else 'UNCERTAIN' if transmitted else 'REVOKED'
        await run_blocking(live.finish_delivery,intent['id'],failure,
                           detail=type(exc).__name__,timeout=5,claim_token=intent['payload'].get('claim_token'))
        if row:await run_blocking(inbox.terminate,row['id'],'NEEDS_REVIEW',str(exc) if isinstance(exc,ValueError) else 'PUBLICATION_RECONCILIATION_REQUIRED',timeout=5)
        return
    async def finish():
        qualified=True;proof=None;corrections=[]
        try:proof=await verify(row,owner)
        except Exception:
            qualified=False
            from services.admin_review_delivery_service import _correct
            for delivery in record.get('deliveries',[]):
                for mid in delivery.get('message_ids') or [delivery.get('message_id')]:
                    if mid:corrections.append(await _correct(bot,delivery['chat_id'],mid,row['id']))
        if not qualified:
            from services.signal_projection_service import invalidate_publication
            await run_blocking(invalidate_publication,record,delivery_id=intent['id'],reason='DELIVERY_PREENTRY_UNPROVEN',corrections=corrections,engine=inbox.engine,timeout=10)
        def update():
            with inbox.engine.atomic():
                live.finish_delivery(intent['id'],'SENT',message_id=record.get('id'),detail='NUMBERED_IMAGE_PUBLISHED' if qualified else 'DELIVERY_PREENTRY_UNPROVEN',verification={'preentry':qualified,'proof':proof,'corrections':corrections},claim_token=intent['payload'].get('claim_token'))
                current=inbox.get(row['id']);p=current['payload']
                p['publications'][intent['audience']].update(state='PUBLISHED' if qualified else 'NEEDS_REVIEW',
                    signal_id=record.get('id'),number=record.get('display_number'),receipts=record.get('deliveries',[]),
                    preentry_verified=qualified,corrections=corrections)
                inbox.update(current,'PUBLISHED' if qualified else 'NEEDS_REVIEW',p)
        await run_blocking(update,timeout=5)
    task=asyncio.create_task(finish())
    try:await asyncio.shield(task)
    except asyncio.CancelledError:await task;raise
    return 1


def scanner_parameters(settings):
    """Paper-run profile selection and reset commit in the same durable row."""
    from services.strategy_profile_service import selected_parameters
    from modules.strategy_experiments import research_profiles
    from modules.strategy_engines import Parameters
    profiles=dict(selected_parameters(settings))
    base=Parameters()
    registered={p.profile_id:p for p in (base,*research_profiles(base))}
    repository=StrategyPaperRepository()
    for engine in STRATEGIES:
        if engine=='custom':continue
        profile=repository.ensure(engine)['payload'].get('profile_id')
        if profile is not None:
            if profile not in registered:continue  # Legacy/unclassified runs cannot select a scanner profile.
            profiles[engine]=registered[profile]
    return tuple(sorted(profiles.items()))


async def migrate_legacy_publication(intent,live,owner):
    """Old chart approvals use the same image publisher after this upgrade."""
    try:
        if intent['event_id']=='SIGNAL':
            from services.setup_review_service import can_publish_approved_delivery
            if not await run_blocking(can_publish_approved_delivery,intent,timeout=5):raise ValueError('LEGACY_APPROVAL_REVOKED')
            source={'stored_setups':[{'id':intent['setup_id']}]};kind='native'
        else:
            from repositories.v2.strategy_reviews import StrategyReviewRepository
            row=await run_blocking(StrategyReviewRepository().get,intent['setup_id'],timeout=5)
            approval=(row or {}).get('payload',{}).get('approvals',{}).get(intent['audience'],{})
            if approval.get('actor')!=intent['payload'].get('actor') or approval.get('draft_hash')!=intent['content_hash']:
                raise ValueError('LEGACY_APPROVAL_REVOKED')
            source={'new_review_ids':[intent['setup_id']]};kind='review'
        await stage_results(source,owner)
        key=sha256(json_dump([kind,intent['setup_id']]).encode()).hexdigest()[:32]
        await decide(intent['payload']['actor'],key,{'action':'publish','audience':intent['audience'],'plan_hash':intent['content_hash']})
        detail='MOVED_TO_NUMBERED_IMAGE_DESK'
    except (ValueError,PermissionError):detail='LEGACY_SIGNAL_NO_LONGER_ELIGIBLE'
    await run_blocking(live.finish_delivery,intent['id'],'REVOKED',detail=detail,timeout=5,claim_token=intent['payload'].get('claim_token'))


def signal_details(user_id,identifier):
    """Compact technical evidence; source names stay in the internal ledger."""
    permitted(user_id);row=LiveSignalInbox().get(identifier)
    if not row:raise ValueError('LIVE_SIGNAL_NOT_FOUND')
    from modules.automated_market_scope import require_global_symbol
    require_global_symbol(row['payload']['plan']['symbol'])
    p=row['payload']['plan'];facts=reference_plan(p).get('evidence',[])
    def detail(kind):return next((f.get('detail',{}) for f in facts if f.get('kind')==kind),{})
    entry=detail('entry_selection');poc=entry.get('poc',{})
    indicators=detail('all_directional_indicators')
    data={'id':row['id'],'market':row['market'],'engine':row['engine'],'state':row['state'],
          'symbol':p['symbol'],'direction':p['direction'],'timeframe':p['timeframe'],'execution_mode':mode_of(p),
          'levels':{k:p[k] for k in ('entry','stop',*TARGET_KEYS) if p.get(k) is not None},
          'zone':{'low':p['zone_low'],'high':p['zone_high']},'plan_hash':row['payload']['plan_hash'],
          'indicator_votes':indicators.get('directional_agreement',{}),
          'stop_protection':detail('structural_stop') or indicators.get('stop_protection',{}),
          'indicator_families':indicators.get('indicator_families',{}),
          'indicator_values':indicators.get('indicator_values',{}),
          'liquidity_pool':detail('liquidity_pool'),
          'fvg_inventory':detail('fvg_inventory'),
          'zone_confluence':detail('zone_confluence'),
          'target_selection':detail('target_selection'),
          'fvg':detail('fvg_third_close'),
          'entry_selection':{k:v for k,v in entry.items() if k in {'selector','original_midpoint','requested_offset','entry','fib_061','fib_061_is_confirmation'}},
          'poc':{k:v for k,v in poc.items() if k in {'price','start_ms','end_ms','input_timeframe','bin_width','rows','native_total_volume','reported_total_volume','is_exact_trade_at_price'}},
          'goldbach':detail('shared_goldbach_confirmation'),
          'confluence_priority':detail('entry_confluence_priority'),
          'liquidity_regime':detail('liquidity_direction_guard'),
          'fibonacci':detail('shared_fibonacci_confirmation'),
          'sweep':{k:v for k,v in detail('sweep_reclaim').items() if k in {'pool_price','sweep_extreme'}},
          'choch':{k:v for k,v in detail('closed_choch').items() if k in {'protected_price','break_kind','prior_structure'}}}
    from modules.signal_forecast import describe
    data['forecast']=describe(p)
    from modules.signal_quality import explain
    data['quality']=explain(p)
    data['paper']=StrategyPaperRepository().for_signal(identifier)
    from modules.strategy_exit_guidance import recommend
    from repositories.v2.market_evidence import MarketEvidenceRepository
    now_ms=int(time.time()*1000)
    exit_bars=MarketEvidenceRepository().candles(p['symbol'],p['provider'],p['timeframe'],before_ms=now_ms,limit=300)
    data['exit_guidance']=recommend(p,data['paper'],exit_bars,now_ms=now_ms)
    from modules.signal_desk_lifecycle import lifecycle
    data['lifecycle']=lifecycle(row,data['paper'])
    data['created_ms']=row['created_ms']
    data['revision']=row['revision']
    data['paper_enrollment']=row['payload'].get('paper_enrollment')
    from repositories.v2.signal_timeline import timing
    with LiveSignalInbox().engine.transaction(read_only=True,repeatable_read=True) as c:
        data['timing']=timing(c,row,data['paper'])
    data['status_reason']=row['payload'].get('status_reason')
    data['chart_plan']=p  # Private transport metadata; UI does not display provider identities.
    custom=detail('custom_strategy')
    if custom:
        data['custom_strategy']={k:custom[k] for k in ('config','profile_id','base_engine','indicator_votes')}
        data['indicator_votes']=custom['indicator_votes'] or data['indicator_votes']
        data['fibonacci']=custom['fibonacci']
        data['confluence_priority']=custom['confluence_priority']
        if custom.get('poc'):
            data['poc']={k:v for k,v in custom['poc'].items() if k in {'price','start_ms','end_ms','input_timeframe','rows','is_exact_trade_at_price'}}
        config=custom['config'];matches=custom.get('matches',{})
        data['component_zones']=[{'engine':k,'low':v['zone_low'],'high':v['zone_high'],'entry':v['entry']}
            for k,v in matches.items() if v and (config.get('require_fvg') if k=='sweep_fvg' else config.get('require_ob') or config.get('require_poc'))]
    from modules.signal_plan_policy import entry_eligibility
    data['entry_eligibility']=entry_eligibility(p)
    if entry.get('original_midpoint') is not None:
        from decimal import Decimal
        data['entry_selection']['actual_offset']=str(abs(Decimal(reference_plan(p)['entry'])-Decimal(entry['original_midpoint'])))
    from modules.strategy_signal_format import independent_confirmation_label
    if data.get('confluence_priority'):
        data['confluence_priority']={**data['confluence_priority'],'label_fa':independent_confirmation_label(data['confluence_priority'].get('label_fa',''))}
    return data
