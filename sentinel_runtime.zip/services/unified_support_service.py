from __future__ import annotations

from html import escape
from typing import Any

from config import SETTINGS
from core.db import with_db, with_db_read
from core.utils import parse_dt, utc_now
from modules.admin_access import PERMISSION_TICKETS, has_permission
from modules.automation_outbox import enqueue_automation_message
from modules.support import (
    add_internal_note,
    admin_tickets,
    append_ticket_message,
    assign_ticket,
    create_ticket,
    find_ticket,
    internal_notes,
    set_ticket_priority,
    set_ticket_satisfaction,
    set_ticket_status,
    user_tickets,
)
from modules.support_attachment_storage import claim_support_attachment


def _admin_ids(db: dict[str, Any]) -> list[int]:
    values = {int(value) for value in SETTINGS.admin_ids if int(value) > 0}
    for raw_id, row in (db.get("delegated_admins") or {}).items():
        if not isinstance(row, dict) or not row.get("active", True):
            continue
        try:
            admin_id = int(row.get("user_id") or raw_id)
        except (TypeError, ValueError):
            continue
        if has_permission(db, admin_id, PERMISSION_TICKETS):
            values.add(admin_id)
    return sorted(values)


def _ticket_attachment(
    db: dict[str, Any],
    attachment: dict[str, Any] | None,
    *,
    actor_id: int | str,
    ticket_id: int | str,
    admin: bool = False,
) -> dict[str, Any] | None:
    if not isinstance(attachment, dict):
        return None
    storage_id = str(attachment.get("storage_id") or "").strip()
    if storage_id:
        claimed = claim_support_attachment(db, storage_id, actor_id=actor_id, ticket_id=ticket_id, admin=admin)
        claimed["caption"] = str(attachment.get("caption") or "")[:1000]
        return claimed
    return attachment


def _queue_admin_notification(db: dict[str, Any], ticket: dict[str, Any], *, kind: str) -> None:
    ticket_id = int(ticket.get("id", 0) or 0)
    user_id = str(ticket.get("user_id") or "")
    subject = escape(str(ticket.get("subject") or "پشتیبانی")[:120])
    priority = escape(str(ticket.get("priority") or "normal"))
    text = (
        f"🎧 <b>{'تیکت جدید' if kind == 'created' else 'پاسخ جدید کاربر'}</b>\n"
        f"شماره: <code>#{ticket_id}</code>\n"
        f"کاربر: <code>{escape(user_id)}</code>\n"
        f"موضوع: <b>{subject}</b>\n"
        f"اولویت: <b>{priority}</b>"
    )
    for admin_id in _admin_ids(db):
        enqueue_automation_message(
            db,
            dedupe_key=f"support:{kind}:ticket:{ticket_id}:admin:{admin_id}:rev:{ticket.get('updated_at')}",
            kind="support_ticket_admin",
            recipient_id=admin_id,
            recipient_scope="admin",
            priority=5 if str(ticket.get("priority")) == "urgent" else 3,
            payload={
                "text": text,
                "parse_mode": "HTML",
                "attachment": ((ticket.get("messages") or [{}])[-1].get("attachment") if isinstance((ticket.get("messages") or [{}])[-1], dict) else None),
                "buttons": [[{"label": "بازکردن تیکت", "callback_data": f"ticket_a:{ticket_id}"}]],
            },
        )


def _queue_user_notification(db: dict[str, Any], ticket: dict[str, Any], *, kind: str) -> None:
    ticket_id = int(ticket.get("id", 0) or 0)
    user_id = str(ticket.get("user_id") or "")
    if not user_id.lstrip("-").isdigit():
        return
    labels = {
        "reply": "پاسخ جدید ادمین برای تیکت شما ثبت شد.",
        "status": f"وضعیت تیکت شما به «{ticket.get('status')}» تغییر کرد.",
        "assignment": "تیکت شما به کارشناس پشتیبانی تخصیص داده شد.",
    }
    enqueue_automation_message(
        db,
        dedupe_key=f"support:{kind}:ticket:{ticket_id}:user:{user_id}:rev:{ticket.get('updated_at')}",
        kind="support_ticket_user",
        recipient_id=user_id,
        recipient_scope="user",
        priority=2,
        payload={
            "text": f"🎧 <b>پشتیبانی SENTINEL</b>\nتیکت <code>#{ticket_id}</code>\n{escape(labels.get(kind, 'تیکت شما به‌روزرسانی شد.'))}\nاز بخش پشتیبانی ربات یا مینی‌اپ مشاهده کنید.",
            "parse_mode": "HTML",
            "attachment": ((ticket.get("messages") or [{}])[-1].get("attachment") if kind == "reply" and isinstance((ticket.get("messages") or [{}])[-1], dict) else None),
        },
    )


def create_user_ticket(
    user_id: int | str,
    *,
    subject: str,
    body: str,
    category: str,
    priority: str,
    attachment: dict[str, Any] | None = None,
    technical_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        ticket = create_ticket(db, user_id, body, subject=subject, category=category, priority=priority)
        if technical_context is not None:
            from modules.support_technical_context import sanitize
            ticket['technical_context']=sanitize(technical_context.get('consent'),technical_context)
        if attachment:
            ticket["messages"][0]["attachment"] = _ticket_attachment(db, attachment, actor_id=user_id, ticket_id=ticket["id"])
        _queue_admin_notification(db, ticket, kind="created")
        return ticket
    return with_db(mutate)


def reply_user_ticket(
    user_id: int | str,
    ticket_id: int | str,
    body: str,
    attachment: dict[str, Any] | None = None,
) -> dict[str, Any]:
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        ticket = find_ticket(db, ticket_id)
        if not ticket or str(ticket.get("user_id")) != str(user_id):
            raise PermissionError("TICKET_NOT_OWNED")
        claimed = _ticket_attachment(db, attachment, actor_id=user_id, ticket_id=ticket_id)
        updated = append_ticket_message(db, ticket_id, "user", user_id, body or "فایل ضمیمه", claimed)
        _queue_admin_notification(db, updated, kind="reply")
        return updated
    return with_db(mutate)


def user_ticket_status(user_id: int | str, ticket_id: int | str, status: str) -> dict[str, Any]:
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        ticket = find_ticket(db, ticket_id)
        if not ticket or str(ticket.get("user_id")) != str(user_id):
            raise PermissionError("TICKET_NOT_OWNED")
        clean = "closed" if str(status).lower() == "closed" else "open"
        return set_ticket_status(db, ticket_id, clean)
    return with_db(mutate)


def user_ticket_satisfaction(user_id: int | str, ticket_id: int | str, score: int) -> dict[str, Any]:
    return with_db(lambda db: set_ticket_satisfaction(db, ticket_id, user_id, score))


def admin_reply_ticket(
    admin_id: int | str,
    ticket_id: int | str,
    body: str,
    attachment: dict[str, Any] | None = None,
) -> dict[str, Any]:
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        claimed = _ticket_attachment(db, attachment, actor_id=admin_id, ticket_id=ticket_id, admin=True)
        ticket = append_ticket_message(db, ticket_id, "admin", admin_id, body or "فایل ضمیمه", claimed)
        _queue_user_notification(db, ticket, kind="reply")
        return ticket
    return with_db(mutate)


def admin_ticket_status(ticket_id: int | str, status: str) -> dict[str, Any]:
    clean = str(status or "open").strip().lower()
    if clean not in {"open", "pending", "answered", "closed"}:
        raise ValueError("INVALID_TICKET_STATUS")
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        ticket = set_ticket_status(db, ticket_id, clean)
        _queue_user_notification(db, ticket, kind="status")
        return ticket
    return with_db(mutate)


def admin_assign_ticket(admin_id: int | str, ticket_id: int | str, assigned_admin_id: int | str) -> dict[str, Any]:
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        if not has_permission(db, assigned_admin_id, PERMISSION_TICKETS):
            raise PermissionError("ASSIGNEE_TICKET_PERMISSION_REQUIRED")
        ticket = assign_ticket(db, ticket_id, assigned_admin_id)
        ticket["assigned_by"] = str(admin_id)
        _queue_user_notification(db, ticket, kind="assignment")
        return ticket
    return with_db(mutate)


def admin_update_ticket_priority(admin_id: int | str, ticket_id: int | str, priority: str) -> dict[str, Any]:
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        ticket = set_ticket_priority(db, ticket_id, priority)
        ticket["priority_changed_by"] = str(admin_id)
        return ticket
    return with_db(mutate)


def admin_add_ticket_note(admin_id: int | str, ticket_id: int | str, text: str) -> dict[str, Any]:
    return with_db(lambda db: add_internal_note(db, ticket_id, admin_id, text))


def list_user_tickets(user_id: int | str, *, status: str = "", query: str = "", limit: int = 100) -> list[dict[str, Any]]:
    def read(db: dict[str, Any]) -> list[dict[str, Any]]:
        rows = user_tickets(db, user_id)
        clean_status = str(status or "").strip().lower()
        if clean_status:
            rows = [row for row in rows if str(row.get("status") or "").lower() == clean_status]
        needle = str(query or "").strip().casefold()
        if needle:
            rows = [row for row in rows if needle in f"{row.get('id','')} {row.get('subject','')} {row.get('category','')}".casefold()]
        return [dict(row) for row in rows[: max(1, min(int(limit or 100), 500))]]
    return with_db_read(read)


def get_user_ticket(user_id: int | str, ticket_id: int | str) -> dict[str, Any] | None:
    def read(db: dict[str, Any]) -> dict[str, Any] | None:
        row = find_ticket(db, ticket_id)
        if not row or str(row.get("user_id")) != str(user_id):
            return None
        return dict(row)
    return with_db_read(read)


def list_admin_tickets(
    *,
    status: str = "",
    query: str = "",
    priority: str = "",
    assigned_admin: str = "",
    overdue_only: bool = False,
    limit: int = 500,
) -> list[dict[str, Any]]:
    def read(db: dict[str, Any]) -> list[dict[str, Any]]:
        rows = admin_tickets(db, status=str(status or "").strip().lower() or None)
        needle = str(query or "").strip().casefold()
        if needle:
            rows = [row for row in rows if needle in f"{row.get('id','')} {row.get('user_id','')} {row.get('subject','')} {row.get('category','')}".casefold()]
        clean_priority = str(priority or "").strip().lower()
        if clean_priority:
            rows = [row for row in rows if str(row.get("priority") or "normal").lower() == clean_priority]
        if str(assigned_admin or "").strip():
            rows = [row for row in rows if str(row.get("assigned_admin") or "") == str(assigned_admin)]
        if overdue_only:
            now = utc_now()
            rows = [row for row in rows if (due := parse_dt(row.get("sla_due_at"))) is not None and due < now and str(row.get("status")) != "closed"]
        output: list[dict[str, Any]] = []
        for row in rows[: max(1, min(int(limit or 500), 1000))]:
            item = dict(row)
            item["internal_notes_count"] = len(internal_notes(db, row.get("id")))
            output.append(item)
        return output
    return with_db_read(read)


def get_admin_ticket(ticket_id: int | str) -> dict[str, Any] | None:
    def read(db: dict[str, Any]) -> dict[str, Any] | None:
        row = find_ticket(db, ticket_id)
        if not isinstance(row, dict):
            return None
        item = dict(row)
        item["internal_notes"] = internal_notes(db, ticket_id)
        return item
    return with_db_read(read)
