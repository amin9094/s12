"""An ownership-scoped receipt/order/entitlement timeline from recorded fields."""
from repositories.v2.commerce import CommerceRepository


def timeline(user,order_id,*,order=None,repo=None):
    repo=repo or CommerceRepository();order=order or repo.get(order_id,user_id=user)
    if not order:raise ValueError('ORDER_NOT_FOUND')
    events=[]
    def add(kind,stamp,**detail):
        if stamp:events.append({'kind':kind,'at':stamp,**detail})
    add('ORDER_CREATED',order.get('created_at'))
    add('LATEST_ORDER_STATE_RECORDED',order.get('updated_at'),state=order['status'])
    add('ORDER_APPROVED',order.get('approved_at'))
    add('PAYMENT_MANUALLY_REVIEWED',order.get('manual_reviewed_at'))
    with repo.engine.transaction(read_only=True,repeatable_read=True) as c:
        receipts=c.execute('SELECT id,status,created_at FROM v8_receipts WHERE user_id=? AND order_id=? ORDER BY created_at,id',(str(user),str(order_id))).fetchall()
        entitlements=c.execute('SELECT * FROM v8_vip_entitlements WHERE user_id=? AND order_id=?',(str(user),str(order_id))).fetchall()
    for r in receipts:add('RECEIPT_RECORDED',r['created_at'],receipt_id=r['id'],current_state=r['status'])
    for r in entitlements:
        add('ENTITLEMENT_START',r.get('starts_at'),state=r.get('status'))
        add('ENTITLEMENT_EXPIRY_BOUNDARY',r.get('expires_at'),is_scheduled_boundary=True)
    return {'order_id':order_id,'state':order['status'],'items':sorted(events,key=lambda e:(e['at'],e['kind'])),
            'historical_transitions_not_invented':True,'payment_or_activation_changed':False}
